# Taranis AI Development setup

Dependency updates use [Renovate](https://docs.renovatebot.com/) with [`.github/renovate.json`](../.github/renovate.json). Each Python component explicitly selects the established Ruff rule baseline so a Ruff upgrade does not silently enable new rules; rule-set migrations should be reviewed separately.

## Optional local signoff

This repo accepts either a successful `test and lint` workflow run or a successful local `gh signoff` on the current PR head commit. See [basecamp/gh-signoff](https://github.com/basecamp/gh-signoff/blob/main/README.md) for upstream details.

Setup:

```bash
gh auth login
gh extension install basecamp/gh-signoff
```

Workflow:

1. Commit the completed feature so the worktree is clean.
2. Run `./dev/test_push_signoff.sh` from the repository root. It prepares component environments, runs the complete local lint, unit test, and E2E pipeline, then pushes and calls `gh signoff` after validation passes.
3. If validation fails, fix and commit the problem, then run `./dev/test_push_signoff.sh` again. Every E2E run uses a fresh isolated Compose stack.
4. If you do not use local signoff, the normal `test and lint` GitHub Actions workflow remains the fallback path.

## Easy Mode

The automated setup supports macOS, Ubuntu, and Debian 13. macOS requires Homebrew; the setup uses Podman for containers. The bootstrap downloads pinned uv and Ruff installers and verifies their SHA-256 checksums before execution.

Clone Repository

```bash
git clone git@github.com:taranis-ai/taranis-ai.git
cd taranis-ai
```

Copy env.dev to worker and core

```bash
cp dev/env.dev src/core/.env
cp dev/env.dev src/worker/.env
```

```bash
./dev/start_dev.sh
```

## Hard Mode

Install pre dependencies:

* git
* tmux
* deno
* build-essential
* [podman](https://podman.io/docs/installation) or [docker](https://docs.docker.com/engine/install/)

If using docker make sure to allow running it as [non-root user](https://docs.docker.com/engine/install/linux-postinstall/)
if using podman make sure to also install `podman-compose` and `podman-docker`

Starting from the git root:

```bash
cd $(git rev-parse --show-toplevel)
```

Copy env.dev to worker and core and set up the core Flask port

```bash
cp dev/env.dev src/worker/.env
cp dev/env.dev src/core/.env
echo "FLASK_RUN_PORT=5001" >> src/core/.env
```

Copy env.dev to frontend and set the frontend Flask port

```bash
cp dev/env.dev src/frontend/.env
echo "FLASK_RUN_PORT=5002" >> src/frontend/.env
```

Start support services via the dev compose file

```bash
docker compose -f dev/compose.yml up -d
```

This starts local Redis without authentication and a pinned Centrifugo instance. Its client and authenticated admin UI port is available at `http://localhost:8000` and binds to all host interfaces, while its API and health port `9000` remains loopback-only. The development admin password defaults to `admin`; override `CENTRIFUGO_ADMIN_PASSWORD` and `CENTRIFUGO_ADMIN_SECRET` as needed.
Queue state is not persisted across local Redis restarts in this dev setup.
Browsers connect through the local NGINX ingress at `http://local.taranis.ai/sse`.
Centrifugo reaches Core through Podman's `host.containers.internal` address; set `TARANIS_CORE_PORT` when Core does not use port `5001`.
When `/sse` is unavailable, the browser retries eight times with exponential backoff and then requires a page reload; an internal connect-proxy error does not display a data-change notice.

To start the optional Grafana LGTM telemetry stack as well:

```bash
docker compose -f dev/compose.yml --profile telemetry up -d
```

Grafana and OTLP ports bind to `127.0.0.1` only. Use an SSH tunnel for remote access.

Set `OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318` in the core, frontend, and worker environments, then open Grafana at `http://localhost:3000`. The automated workflow bundles both steps:

```bash
WITH_TELEMETRY=1 ./dev/start_dev.sh
```

The automated workflow preserves profiles already set in `COMPOSE_PROFILES`.

Setup nginx.
Make sure the paths are correct. Some distributions use a different nginx configuration directory hierarchy and rely on `.conf` suffix.
Existing installed nginx configurations are not updated automatically when `dev/nginx.conf` changes. Public product publishing requires the active server block to include the tracked `/reports` proxy; recopy or update the installed configuration before validating that route.

```bash
# Debian based example
sudo cp dev/nginx.conf /etc/nginx/sites-available/local.taranis.ai
sudo ln -s /etc/nginx/sites-available/local.taranis.ai /etc/nginx/sites-enabled/local.taranis.ai
sudo nginx -t && sudo systemctl restart nginx

# Red Hat based example
sudo cp dev/nginx.conf /etc/nginx/conf.d/local.taranis.ai.conf
sudo nginx -t && sudo systemctl restart nginx
```

Start a tmux session with multiple panes for the different processes:

```bash
# Start a new session named taranis with the first tab and cd to src/core
tmux new-session -s taranis -n core -c src/core -d

# Create the second tab and cd to src/frontend
tmux new-window -t taranis:1 -n frontend -c src/frontend

# Create the third tab and cd to src/worker
tmux new-window -t taranis:2 -n worker -c src/worker

# Create the fourth tab for cron scheduler
tmux new-window -t taranis:3 -n cron -c src/worker

# Create the fifth tab for rq-dashboard (optional, for monitoring)
tmux new-window -t taranis:4 -n rq-dashboard -c src/worker

# Attach to the session
tmux attach-session -t taranis
```

Or run `./dev/start_tmux.sh` for the core, Tailwind, frontend, and worker windows. Set `WITH_CRON_RQ=1` to also start cron and rq-dashboard:

```bash
WITH_CRON_RQ=1 ./dev/start_tmux.sh
```

In Core Tab:

```bash
# If venv isn't setup already
uv venv

# Activate venv
source .venv/bin/activate

# Install requirements
uv sync --all-extras --frozen --python 3.14 --no-install-package taranis-models
uv pip install -e ../models

# Run core
flask run
```

In Worker Tab:

```bash
# If venv isn't setup already
uv venv

# Activate venv
source .venv/bin/activate

# Install requirements
uv sync --all-extras --frozen --python 3.13 --no-install-package taranis-models
uv pip install -e ../models

# Run worker
uv run python start_dev_worker.py
```

In Frontend Tab:
If `deno` is not available, check the [install guide](https://docs.deno.com/runtime/getting_started/installation/)

```bash
deno install --allow-scripts

# Watch and rebuild tailwindcss
deno task tw:watch

# Bundle vendor libraries
deno task vendor:bundle

# If venv isn't setup already
uv venv

# Activate venv
source .venv/bin/activate

# Install requirements
uv sync --all-extras --frozen --python 3.14 --no-install-package taranis-models
uv pip install -e ../models

# Run the frontend dev server
flask run
```

Taranis AI should be reachable on _local.taranis.ai_.

## Development Tools

### Migration Test Harness

Use the migration harness to reproduce production-like upgrades from the current master schema to the current branch:

```bash
./dev/test_master_to_branch_migration.sh
./dev/test_master_to_branch_migration.sh 1.4.0
```

This harness requires Podman, or Docker with `CONTAINER_CLI=docker`.

The script creates a temporary git worktree from `origin/master`, or from the release ref passed as its first argument, starts a disposable PostgreSQL container, initializes and seeds a fresh base database, and copies it. It renames the copy's `public` schema to a unique test schema and sets the database's `search_path` before starting the current branch so pending yoyo migrations are applied. Hard-coded application schema references therefore fail during the upgrade. It finally runs a configurable pytest target against the migrated database, defaulting to `tests/unit`.

Useful options:

```bash
BASE_REF=master ./dev/test_master_to_branch_migration.sh
KEEP_MIGRATION_TEST_DB=1 ./dev/test_master_to_branch_migration.sh
PG_IMAGE=docker.io/library/postgres:16-alpine ./dev/test_master_to_branch_migration.sh
PYTEST_TARGET=tests ./dev/test_master_to_branch_migration.sh
CONTAINER_CLI=docker BASE_REF=1.4.1 ./dev/test_master_to_branch_migration.sh
```

`KEEP_MIGRATION_TEST_DB=1` leaves the temporary worktree and PostgreSQL container running for inspection. Do not point this harness at shared or production databases.

After a schema-related PR is approved, CI uses this harness with the latest stable Git release tag as `BASE_REF` and the approved PR checkout as the migration target.

### RQ Cron Scheduler

The development setup includes an **RQ Cron Scheduler** that automatically enqueues recurring jobs based on database schedules. It:

* Monitors OSINT sources and bots with cron schedules in the database
* Automatically enqueues collection and bot tasks at their scheduled times
* Picks up definition changes from Redis on each poll cycle

When using `WITH_CRON_RQ=1 ./dev/start_tmux.sh`, the cron scheduler is started in window 4.

**Manual start:**
```bash
cd src/worker
uv sync --all-extras --frozen --python 3.13 --no-install-package taranis-models
uv pip install -e ../models
uv run --no-sync --frozen taranis-cron
```

**Updating schedules:**
When you update a source/bot schedule in the database (via the UI or API):
1. The change is immediately saved to the database
2. Core updates the cron definition in Redis
3. The cron scheduler picks up the change on the next poll cycle

### RQ Dashboard

The development setup includes [rq-dashboard](https://github.com/Parallels/rq-dashboard) for monitoring RQ workers and jobs. It provides:

* Real-time view of queues, workers, and jobs
* Job details including arguments, results, and tracebacks
* Ability to cancel jobs, requeue failed jobs, and empty queues

When using `WITH_CRON_RQ=1 ./dev/start_tmux.sh`, rq-dashboard is started on port **9181** in window 5.

Access it at: http://localhost:9181

**Manual start:**
```bash
cd src/worker
./install_and_run_rq_dashboard.sh
```

## Technology stack

### Backend

* Python: Used for the core backend services including [REST API](../src/core/README.md).
* RQ (Redis Queue): For managing asynchronous tasks and [worker processes](../src/worker/README.md).

### Frontend

The frontend is served by the [Flask & HTMX REST frontend](../src/frontend/README.md).

### Support Services

* PostgreSQL: As the primary database.
* Redis: For message brokering and job queue management (via RQ).

### DevOps and Deployment

* Docker: For containerization.
* docker-compose: For managing multi-container Docker applications.
* OpenTelemetry and Grafana LGTM: For request, RQ job, and metric observability.
* Sentry: For error monitoring.
* CI/CD: GitHub Actions
