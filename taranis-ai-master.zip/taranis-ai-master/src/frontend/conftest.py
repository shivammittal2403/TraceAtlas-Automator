pytest_plugins = ("tests.playwright.rq_e2e_fixtures",)
