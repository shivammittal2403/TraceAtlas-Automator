from typing import Any, cast
from uuid import uuid4

import sentry_sdk
from flask import Flask, g, redirect, render_template, url_for
from flask.json.provider import DefaultJSONProvider
from flask_babel import get_locale, get_timezone
from flask_htmx import HTMX
from flask_jwt_extended import current_user, verify_jwt_in_request
from flask_jwt_extended.exceptions import JWTExtendedException
from heroicons.jinja import (
    heroicon_micro,
    heroicon_mini,
    heroicon_outline,
    heroicon_solid,
)
from models.user import UserProfile
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from pydantic import BaseModel

import frontend.filters as filters_module
from frontend import i18n
from frontend.auth import user_has_admin_permissions
from frontend.config import Config
from frontend.log import logger
from frontend.onboarding import pending_onboarding_tasks_for_template
from frontend.views.base_view import BaseView


def handle_unauthorized(e):
    return redirect(url_for("base.login"), code=302)


def handle_forbidden(e):
    return render_template("errors/403.html"), 403


class TaranisJSONProvider(DefaultJSONProvider):
    def dumps(self, obj, **kwargs):
        transformed_obj = self._transform(obj)
        return super().dumps(transformed_obj, **kwargs)

    def _transform(self, obj):
        if isinstance(obj, BaseModel):
            return obj.model_dump(exclude_none=True)
        if isinstance(obj, list):
            return [self._transform(item) for item in obj]
        if isinstance(obj, dict):
            return {key: self._transform(value) for key, value in obj.items()}
        return obj


def index_redirect():
    return redirect(Config.APPLICATION_ROOT, code=302)


def jinja_setup(app: Flask):
    for name in filters_module.__all__:
        app.jinja_env.filters[name] = getattr(filters_module, name)
    app.jinja_env.trim_blocks = True
    app.jinja_env.lstrip_blocks = True
    all_views = dict(sorted(BaseView._registry.items(), key=lambda item: (getattr(item[1], "_index", float("inf")), item[0])))
    admin_views = {k: v for k, v in all_views.items() if hasattr(v, "_is_admin") and v._is_admin}

    template_globals = cast(dict[str, Any], app.jinja_env.globals)
    template_globals.update(
        {
            "heroicon_micro": heroicon_micro,
            "heroicon_mini": heroicon_mini,
            "heroicon_outline": heroicon_outline,
            "heroicon_solid": heroicon_solid,
            "views": all_views,
            "admin_views": admin_views,
            "get_locale": get_locale,
            "get_timezone": get_timezone,
            "pending_onboarding_tasks_for_template": pending_onboarding_tasks_for_template,
            "chat_enabled": app.config["CHAT_ENABLED"],
        }
    )

    if Config.APPLICATION_ROOT != "/":
        app.add_url_rule("/", view_func=index_redirect)


def is_user_admin(user: UserProfile) -> bool:
    """
    Checks if the current user has admin privileges.
    """
    return user_has_admin_permissions(user.permissions)


def inject_current_user() -> dict[str, Any]:
    """
    Makes `current_user` available in all Jinja templates.
    If no JWT is present, it will be None.
    """
    if getattr(g, "skip_current_user_injection", False):
        return {"current_user": None, "authenticated_user": None, "is_admin": False}

    try:
        user = current_user if current_user else None
    except RuntimeError:
        try:
            verify_jwt_in_request(optional=True)
        except JWTExtendedException:
            return {"current_user": None, "authenticated_user": None, "is_admin": False}
        user = current_user if current_user else None

    if user:
        return {"current_user": user, "authenticated_user": user, "is_admin": is_user_admin(user)}

    return {"current_user": None, "authenticated_user": None, "is_admin": False}


def setup_telemetry(app: Flask):
    _setup_sentry()
    _setup_opentelemetry(app)


def _setup_sentry():
    if not (dsn := Config.TARANIS_FRONTEND_SENTRY_DSN):
        return

    sentry_options: dict[str, Any] = {
        "dsn": dsn,
        "traces_sample_rate": 1.0,
        "profiles_sample_rate": 1.0,
    }
    if Config.SENTRY_ENABLE_LOGS:
        sentry_options["enable_logs"] = True
    if Config.SENTRY_SEND_DEFAULT_PII:
        sentry_options["send_default_pii"] = True

    sentry_sdk.init(**sentry_options)


def _setup_opentelemetry(app: Flask):
    if not (endpoint := Config.OTEL_EXPORTER_OTLP_ENDPOINT):
        return

    service_name = Config.OTEL_SERVICE_NAME
    resource = Resource.create({SERVICE_NAME: service_name, "service.instance.id": str(uuid4())})
    tracer_provider = TracerProvider(resource=resource)
    tracer_provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=f"{endpoint}/v1/traces")))
    meter_provider = MeterProvider(
        resource=resource,
        metric_readers=[
            PeriodicExportingMetricReader(
                OTLPMetricExporter(endpoint=f"{endpoint}/v1/metrics"),
                export_interval_millis=Config.OTEL_METRIC_EXPORT_INTERVAL,
            )
        ],
    )
    FlaskInstrumentor().instrument_app(app, tracer_provider=tracer_provider, meter_provider=meter_provider)
    RequestsInstrumentor().instrument(tracer_provider=tracer_provider, meter_provider=meter_provider)


def init(app: Flask):
    setup_telemetry(app)
    i18n.init(app)
    app.json_provider_class = TaranisJSONProvider
    app.json = app.json_provider_class(app)
    HTMX(app)
    app.register_error_handler(401, handle_unauthorized)
    app.register_error_handler(403, handle_forbidden)

    app.url_map.strict_slashes = False

    jinja_setup(app)
    app.context_processor(inject_current_user)
    logger.debug(f"Listening on {Config.APPLICATION_ROOT} and Core URL {Config.TARANIS_CORE_URL}")
