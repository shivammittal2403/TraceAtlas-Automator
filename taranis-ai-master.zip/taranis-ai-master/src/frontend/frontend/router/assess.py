from typing import cast

from flask import Blueprint, Flask
from flask.typing import RouteCallable

from frontend.auth import auth_required
from frontend.views.analyst_review_views import AnalystReviewView
from frontend.views.story_bookmark_views import StoryBookmarkView
from frontend.views.story_views import StoryView


def init(app: Flask):
    assess_bp = Blueprint("assess", __name__, url_prefix=f"{app.config['APPLICATION_ROOT']}")

    assess_bp.add_url_rule("/assess", view_func=StoryView.as_view("assess"))
    assess_bp.add_url_rule(
        "/analyst-review/start",
        view_func=AnalystReviewView.start,
        methods=["GET", "POST"],
        endpoint="analyst_review_start",
    )
    assess_bp.add_url_rule(
        "/analyst-review/<string:run_id>",
        view_func=AnalystReviewView.review,
        methods=["GET"],
        endpoint="analyst_review",
    )
    assess_bp.add_url_rule(
        "/analyst-review/<string:run_id>/actions",
        view_func=AnalystReviewView.apply_action,
        methods=["POST"],
        endpoint="analyst_review_action",
    )
    assess_bp.add_url_rule("/bookmarks", view_func=StoryBookmarkView.list_view, methods=["GET"], endpoint="bookmarks")
    assess_bp.add_url_rule("/bookmarks", view_func=StoryBookmarkView.create_bookmark, methods=["POST"], endpoint="bookmark_create")
    assess_bp.add_url_rule("/bookmarks/order", view_func=StoryBookmarkView.reorder_bookmarks, methods=["PATCH"], endpoint="bookmark_reorder")
    assess_bp.add_url_rule("/bookmarks/<string:bookmark_id>", view_func=StoryBookmarkView.detail_view, methods=["GET"], endpoint="bookmark")
    assess_bp.add_url_rule(
        "/bookmarks/<string:bookmark_id>", view_func=StoryBookmarkView.update_bookmark, methods=["PATCH"], endpoint="bookmark_update"
    )
    assess_bp.add_url_rule(
        "/bookmarks/<string:bookmark_id>", view_func=StoryBookmarkView.delete_bookmark, methods=["DELETE"], endpoint="bookmark_delete"
    )
    assess_bp.add_url_rule(
        "/bookmarks/<string:bookmark_id>/stories/remove",
        view_func=StoryBookmarkView.remove_stories,
        methods=["POST"],
        endpoint="bookmark_remove_stories",
    )
    assess_bp.add_url_rule("/story/<string:story_id>", view_func=StoryView.story_view, methods=["GET"], endpoint="story")
    assess_bp.add_url_rule("/story/<string:story_id>/cti", view_func=StoryView.story_cti_dialog, methods=["GET"], endpoint="story_cti")
    assess_bp.add_url_rule(
        "/story/<string:story_id>", view_func=StoryView.patch_story, methods=["POST", "PUT", "PATCH"], endpoint="story_update"
    )
    assess_bp.add_url_rule("/story/<string:story_id>", view_func=StoryView.delete_story, methods=["DELETE"], endpoint="story_delete")
    assess_bp.add_url_rule(
        "/story/<string:story_id>/edit", view_func=cast(RouteCallable, auth_required("ASSESS_UPDATE")(StoryView.as_view("story_edit")))
    )
    assess_bp.add_url_rule(
        "/story/<string:story_id>/bots", view_func=StoryView.trigger_bot_action, methods=["POST"], endpoint="story_trigger_bot"
    )
    assess_bp.add_url_rule("/stories/bots", view_func=StoryView.trigger_stories_bot_action, methods=["POST"], endpoint="stories_trigger_bot")
    assess_bp.add_url_rule(
        "/news-item/<string:news_item_id>", view_func=StoryView.update_news_item, methods=["POST"], endpoint="update_news_item"
    )
    assess_bp.add_url_rule(
        "/news-item/<string:news_item_id>/tags",
        view_func=StoryView.update_news_item_tags,
        methods=["POST"],
        endpoint="update_news_item_tags",
    )
    assess_bp.add_url_rule("/news-item", view_func=StoryView.create_news_item, methods=["POST"], endpoint="create_news_item")
    assess_bp.add_url_rule("/news-item/<string:news_item_id>", view_func=StoryView.news_item_view, methods=["GET"], endpoint="get_news_item")
    assess_bp.add_url_rule(
        "/news-item/<string:news_item_id>/cti", view_func=StoryView.news_item_cti_dialog, methods=["GET"], endpoint="news_item_cti"
    )
    assess_bp.add_url_rule(
        "/news-item/<string:news_item_id>", view_func=StoryView.delete_news_item, methods=["DELETE"], endpoint="delete_news_item"
    )
    assess_bp.add_url_rule("/news-item", view_func=StoryView.news_item_view, methods=["GET"], endpoint="get_news_item")
    assess_bp.add_url_rule("/ungroup/<string:story_id>", view_func=StoryView.ungroup, methods=["POST"], endpoint="ungroup")
    assess_bp.add_url_rule("/search", view_func=StoryView.get_search_dialog, methods=["GET"], endpoint="search_stories")
    assess_bp.add_url_rule("/search", view_func=StoryView.submit_search_dialog, methods=["POST"], endpoint="submit_search_stories")
    assess_bp.add_url_rule("/saved-filters", view_func=StoryView.get_saved_filters_dialog, methods=["GET"], endpoint="saved_filters")
    assess_bp.add_url_rule("/saved-filters", view_func=StoryView.save_saved_filter, methods=["POST"], endpoint="save_saved_filter")
    assess_bp.add_url_rule(
        "/saved-filters/<string:filter_id>/default",
        view_func=StoryView.set_saved_filter_default,
        methods=["POST"],
        endpoint="set_saved_filter_default",
    )
    assess_bp.add_url_rule(
        "/saved-filters/<string:filter_id>",
        view_func=StoryView.delete_saved_filter,
        methods=["DELETE"],
        endpoint="delete_saved_filter",
    )
    assess_bp.add_url_rule("/story/sharing", view_func=StoryView.get_sharing_dialog, methods=["GET"], endpoint="share_story")
    assess_bp.add_url_rule("/story/sharing", view_func=StoryView.submit_sharing_dialog, methods=["POST"], endpoint="submit_share_story")
    assess_bp.add_url_rule("/story/report", view_func=StoryView.get_report_dialog, methods=["GET"], endpoint="report_story")
    assess_bp.add_url_rule("/story/report", view_func=StoryView.submit_report_dialog, methods=["POST"], endpoint="submit_report_story")
    assess_bp.add_url_rule("/story/bookmark", view_func=StoryBookmarkView.get_add_dialog, methods=["GET"], endpoint="bookmark_story")
    assess_bp.add_url_rule(
        "/story/bookmark", view_func=StoryBookmarkView.submit_add_dialog, methods=["POST"], endpoint="submit_bookmark_story"
    )
    assess_bp.add_url_rule(
        "/story/<string:story_id>/bookmark",
        view_func=StoryBookmarkView.instant_bookmark_story,
        methods=["POST"],
        endpoint="instant_bookmark_story",
    )
    assess_bp.add_url_rule("/story/cluster", view_func=StoryView.get_cluster_dialog, methods=["GET"], endpoint="cluster_story")
    assess_bp.add_url_rule("/story/cluster", view_func=StoryView.submit_cluster_dialog, methods=["POST"], endpoint="submit_cluster_story")
    assess_bp.add_url_rule(
        "/story/<string:story_id>/news-item-order",
        view_func=StoryView.news_item_order,
        methods=["GET", "POST"],
        endpoint="story_news_item_order",
    )
    assess_bp.add_url_rule("/story/export", view_func=StoryView.export_stories, methods=["GET"], endpoint="export_stories")
    assess_bp.add_url_rule("/story/import", view_func=StoryView.import_stories, methods=["POST"], endpoint="import_stories")
    assess_bp.add_url_rule("/tags", view_func=StoryView.get_tags, methods=["GET"], endpoint="get_tags")

    assess_bp.add_url_rule("/stories/bulk_action", view_func=StoryView.bulk_action, methods=["POST"], endpoint="bulk_action")

    # Story revision history routes
    assess_bp.add_url_rule("/story/<string:story_id>/versions", view_func=StoryView.versions_view, methods=["GET"], endpoint="story_versions")
    assess_bp.add_url_rule(
        "/story/<string:story_id>/diff/<int:from_rev>.<int:to_rev>",
        view_func=StoryView.diff_view,
        methods=["GET"],
        endpoint="story_diff",
    )

    app.register_blueprint(assess_bp)
