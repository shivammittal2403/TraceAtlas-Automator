import contextlib
from collections.abc import Callable, Iterable
from datetime import UTC, datetime, timedelta
from functools import wraps
from typing import Any, ParamSpec, TypeVar, cast
from urllib.parse import unquote, urlsplit

from flask import Flask, Response, abort, current_app, g, make_response, redirect, render_template, request, url_for
from flask_jwt_extended import (
    JWTManager,
    current_user,
    get_jwt,
    get_jwt_identity,
    get_jwt_request_location,
    unset_access_cookies,
    verify_jwt_in_request,
)
from flask_jwt_extended.exceptions import JWTExtendedException
from models.user import UserProfile
from requests import RequestException
from requests.models import Response as ReqResponse
from werkzeug.exceptions import HTTPException, MethodNotAllowed, NotFound
from werkzeug.routing import RequestRedirect

from frontend.cache import add_user_to_cache, get_user_from_cache
from frontend.config import Config
from frontend.core_api import CoreApi
from frontend.log import logger
from frontend.utils.router_helpers import is_htmx_request


jwt = JWTManager()
P = ParamSpec("P")
R = TypeVar("R")


def init(app: Flask) -> None:
    jwt.init_app(app)
    app.after_request(refresh_expiring_jwts)


def refresh_expiring_jwts(response: Response) -> Response:
    try:
        exp_timestamp = get_jwt()["exp"]
        target_timestamp = datetime.timestamp(datetime.now(UTC) + timedelta(minutes=30))
        if get_jwt_request_location() == "cookies" and target_timestamp > exp_timestamp and current_user:
            core_response = CoreApi().refresh()
            if core_response.ok:
                for header in core_response.raw.headers.getlist("Set-Cookie"):
                    response.headers.add("Set-Cookie", header)
            elif core_response.status_code == 401:
                unset_access_cookies(response)
    except RuntimeError, KeyError:
        pass
    except RequestException:
        logger.exception("Core token refresh failed")
    return response


def user_has_admin_permissions(permissions: Iterable[str] | None) -> bool:
    permission_set = set(permissions or [])
    return "ADMIN_OPERATIONS" in permission_set or any(permission.startswith("CONFIG_") for permission in permission_set)


def is_safe_redirect_target(next_target: str | None) -> bool:
    if not next_target:
        return False

    decoded_target = unquote(next_target)
    if any(char in decoded_target for char in ("\x00", "\r", "\n", "\\")):
        return False

    parsed_target = urlsplit(decoded_target)
    if parsed_target.scheme or parsed_target.netloc or decoded_target.startswith("//") or not parsed_target.path.startswith("/"):
        return False

    adapter = current_app.url_map.bind_to_environ(request.environ)

    try:
        rule, _ = adapter.match(parsed_target.path, method="GET", return_rule=True)
    except RequestRedirect as exc:
        redirected_path = urlsplit(exc.new_url).path
        try:
            rule, _ = adapter.match(redirected_path, method="GET", return_rule=True)
        except RequestRedirect, NotFound, MethodNotAllowed:
            return False
    except NotFound, MethodNotAllowed:
        return False

    return rule.endpoint != "base.login"


def _login_url_with_next() -> str:
    login_url = url_for("base.login")

    if request.endpoint == "base.login":
        return login_url

    path = request.path or ""
    query_string = request.query_string.decode()

    next_target = path
    if query_string:
        next_target = f"{path}?{query_string}"

    if next_target == login_url or not is_safe_redirect_target(next_target):
        return login_url

    return url_for("base.login", next=next_target)


def _redirect_to_login_with_next():
    return redirect(_login_url_with_next(), code=302)


def render_login_page(**context: Any) -> str:
    g.skip_current_user_injection = True
    return render_template("login/index.html", **context)


def _redirect_expired_session_to_login():
    response = make_response(redirect(_login_url_with_next(), code=302))
    unset_access_cookies(response)
    return response


def _resolve_authenticated_user() -> tuple[str, UserProfile] | None:
    try:
        verify_jwt_in_request()
    except JWTExtendedException:
        logger.info("JWT verification failed")
        return None

    user_name = get_jwt_identity()
    if not user_name:
        logger.error("Missing identity in JWT")
        return None

    user = current_user
    if not user:
        logger.error(f"Unable to resolve current user for identity {user_name}")
        return None

    return user_name, user


def logout() -> tuple[str, int] | Response:
    error_msg = "Logout failed"
    try:
        core_response: ReqResponse = CoreApi().logout()
    except HTTPException:
        raise
    except RequestException as exc:
        # If the core isn't reachable, fall back to the login page without crashing.
        logger.error(f"Core logout failed: {exc}")
        return render_login_page(login_error="Logout failed"), 500

    if not core_response.ok:
        with contextlib.suppress(Exception):
            error_msg = core_response.json().get("error", error_msg)
        return render_login_page(login_error=error_msg), core_response.status_code

    response = make_response("Session expired! Redirecting to Login Page", 200 if is_htmx_request() else 302)
    if is_htmx_request():
        response.headers["HX-Redirect"] = url_for("base.login")
    else:
        response.headers["Location"] = url_for("base.login")

    unset_access_cookies(response)
    return response


def auth_required(permissions: list[str] | str | None = None) -> Callable[[Callable[P, R]], Callable[P, R]]:
    def auth_required_wrap(fn: Callable[P, R]) -> Callable[P, R]:
        @wraps(fn)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            if permissions is None:
                permissions_set: set[str] = set()
            elif isinstance(permissions, list):
                permissions_set = set(permissions)
            else:
                permissions_set = {permissions}

            resolved_user = _resolve_authenticated_user()
            if not resolved_user:
                return cast(R, _redirect_to_login_with_next())

            user_name, user = resolved_user
            permission_claims = set(user.permissions or [])

            # is there at least one match with the permissions required by the call or no permissions required
            if permissions_set and not permissions_set.intersection(permission_claims):
                logger.error(
                    f"user {user_name} Insufficient permissions in JWT for identity",
                )
                abort(403)

            return fn(*args, **kwargs)

        return wrapper

    return auth_required_wrap


def admin_required() -> Callable[[Callable[P, R]], Callable[P, R]]:
    def admin_required_wrap(fn: Callable[P, R]) -> Callable[P, R]:
        @wraps(fn)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            resolved_user = _resolve_authenticated_user()
            if not resolved_user:
                return cast(R, _redirect_to_login_with_next())

            user_name, user = resolved_user
            if not user_has_admin_permissions(user.permissions):
                logger.error(f"user {user_name} is not allowed to access admin routes")
                abort(403)

            return fn(*args, **kwargs)

        return wrapper

    return admin_required_wrap


def api_key_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        error = ({"error": "not authorized"}, 401)
        auth_header = request.headers.get("Authorization", None)

        if not auth_header or not auth_header.startswith("Bearer"):
            logger.error("Missing Authorization Bearer")
            return error

        api_key = auth_header.replace("Bearer ", "")

        if Config.CORE_API_KEY.get_secret_value() != api_key:
            logger.error("Incorrect api key")
            return error

        # allow
        return fn(*args, **kwargs)

    return wrapper


def update_current_user_cache() -> UserProfile | None:
    if result := CoreApi().api_get("/users"):
        return add_user_to_cache(user=result)
    return None


@jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    if not hasattr(g, "jwt_user_lookup_user"):
        identity = jwt_data[Config.JWT_IDENTITY_CLAIM]
        g.jwt_user_lookup_user = get_user_from_cache(identity) or update_current_user_cache()
    return g.jwt_user_lookup_user


@jwt.user_identity_loader
def user_identity_lookup(user: UserProfile) -> str:
    return user.username


@jwt.token_in_blocklist_loader
def check_if_token_is_revoked(_jwt_header, _jwt_payload: dict[str, Any]) -> bool:
    """
    jtw token blacklisting is handled by core
    cached userdata is invalidated, when userdata is changed
    """
    return False


@jwt.expired_token_loader
def expired_token_callback(_jwt_header, _jwt_payload):
    return _redirect_expired_session_to_login()


@jwt.unauthorized_loader
def unauthorized_callback(callback):
    return _redirect_to_login_with_next()
