import os
import sys

import requests

from frontend.config import Config


def main() -> int:
    port = int(os.getenv("GRANIAN_PORT", "8080"))

    url = f"http://127.0.0.1:{port}{Config.APPLICATION_ROOT}/health"

    try:
        requests.get(url, timeout=5).raise_for_status()
        return 0
    except requests.RequestException as exc:
        print(f"frontend healthcheck failed: {exc}", file=sys.stderr)
        return 1
