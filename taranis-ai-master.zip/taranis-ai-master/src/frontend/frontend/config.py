from datetime import UTC, datetime
from secrets import token_urlsafe
from typing import Annotated, Any

from models.cache_contract import (
    CACHE_DEFAULT_TIMEOUT_DEFAULT,
    CACHE_ENABLED_DEFAULT,
    CACHE_KEY_PREFIX_DEFAULT,
)
from pydantic import Field, SecretStr, ValidationInfo, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    APPLICATION_ROOT: str = "/frontend"
    MODULE_ID: str = "Frontend"
    DEBUG: bool = False

    FLASK_SECRET_KEY: SecretStr = Field(default_factory=lambda: SecretStr(token_urlsafe(32)))
    JWT_SECRET_KEY: str = "supersecret"
    JWT_IDENTITY_CLAIM: str = "sub"
    JWT_ACCESS_TOKEN_EXPIRES: int = 14400
    JWT_DECODE_LEEWAY: int = 5
    JWT_TOKEN_LOCATION: list[str] = ["headers", "cookies"]
    JWT_CSRF_CHECK_FORM: bool = True
    JWT_COOKIE_SUFFIX: Annotated[str, Field(pattern=r"^[A-Za-z0-9_-]*$")] = ""
    JWT_COOKIE_CSRF_PROTECT: bool = True
    JWT_CSRF_IN_COOKIES: bool = True
    JWT_COOKIE_SECURE: bool = True
    JWT_CSRF_METHODS: list[str] = ["POST", "PUT", "PATCH", "DELETE"]
    COLORED_LOGS: bool = True
    BUILD_DATE: datetime = datetime.now(UTC)
    GIT_INFO: dict[str, str] | None = None
    TARANIS_CORE_URL: str = "http://local.taranis.ai/api"
    TARANIS_CORE_HOST: str = "http://local.taranis.ai"
    TARANIS_BASE_PATH: str = "/"
    REALTIME_ENABLED: bool = False
    SSL_VERIFICATION: bool = False
    REQUESTS_TIMEOUT: int = 60
    CHAT_ENABLED: bool = False
    CHAT_REQUEST_TIMEOUT: Annotated[int, Field(gt=0)] = 600
    REQUESTS_TRUST_ENV: bool = True
    CORE_API_KEY: SecretStr = SecretStr("supersecret")
    MAX_CONTENT_LENGTH: int = 50 * 1024 * 1024
    OSINT_SOURCE_ICON_MAX_BYTES: int = 5 * 1024 * 1024
    OSINT_SOURCE_ICON_ALLOWED_MIMETYPES: str = "image/png,image/jpeg,image/webp,image/gif"
    DISABLE_PPN_COLLECTOR: bool = True

    BABEL_DEFAULT_LOCALE: str = "en"
    BABEL_DEFAULT_TIMEZONE: str = "UTC"
    BABEL_TRANSLATION_DIRECTORIES: str = "translations"
    BABEL_SUPPORTED_LOCALES: list[str] = ["en", "de"]
    CACHE_ENABLED: bool = CACHE_ENABLED_DEFAULT
    CACHE_DEFAULT_TIMEOUT: int = CACHE_DEFAULT_TIMEOUT_DEFAULT
    CACHE_KEY_PREFIX: str = CACHE_KEY_PREFIX_DEFAULT
    CACHE_REDIS_URL: str | None = None
    CACHE_REDIS_PASSWORD: SecretStr | None = None
    REDIS_URL: str = "redis://localhost:6379"
    REDIS_PASSWORD: str | None = None
    OTEL_EXPORTER_OTLP_ENDPOINT: str | None = None
    OTEL_SERVICE_NAME: str = "taranis-frontend"
    OTEL_METRIC_EXPORT_INTERVAL: Annotated[float, Field(gt=0)] = 60_000
    TARANIS_FRONTEND_SENTRY_DSN: str | None = None
    SENTRY_ENABLE_LOGS: bool = False
    SENTRY_SEND_DEFAULT_PII: bool = False

    @property
    def JWT_ACCESS_COOKIE_NAME(self) -> str:
        return f"access_token_cookie{self.JWT_COOKIE_SUFFIX}"

    @property
    def JWT_ACCESS_CSRF_COOKIE_NAME(self) -> str:
        return f"csrf_access_token{self.JWT_COOKIE_SUFFIX}"

    @property
    def JWT_ACCESS_COOKIE_PATH(self) -> str:
        return self.TARANIS_BASE_PATH

    JWT_ACCESS_CSRF_COOKIE_PATH = JWT_ACCESS_COOKIE_PATH

    @field_validator("OTEL_EXPORTER_OTLP_ENDPOINT", "TARANIS_FRONTEND_SENTRY_DSN", mode="before")
    def normalize_optional_telemetry_url(cls, value: str | None) -> str | None:
        return value.strip().rstrip("/") or None if value else None

    @field_validator("TARANIS_BASE_PATH", mode="before")
    def ensure_start_and_end_slash(cls, v: str, info: ValidationInfo) -> str:
        if not v or v == "/":
            return "/"

        return f"/{v.strip('/')}/"

    @model_validator(mode="after")
    def set_taranis_core(self):
        if self.TARANIS_CORE_URL:
            return self
        self.TARANIS_CORE_URL = f"http://{self.TARANIS_CORE_HOST}{self.TARANIS_BASE_PATH}api"  # type: ignore
        return self


Config = Settings()


def build_config_overrides(overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    resolved_overrides = dict(overrides or {})
    if resolved_overrides.get("TESTING") and "CACHE_ENABLED" not in resolved_overrides:
        resolved_overrides["CACHE_ENABLED"] = False
    return resolved_overrides
