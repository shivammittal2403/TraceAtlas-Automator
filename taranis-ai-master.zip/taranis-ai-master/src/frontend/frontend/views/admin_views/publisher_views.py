from typing import Any, ClassVar

from flask import render_template, request
from models.admin import ProductType, PublisherPreset, ReportItemType, Template
from models.types import PRESENTER_TYPES, PUBLISHER_TYPES
from werkzeug.exceptions import HTTPException

from frontend.config import Config
from frontend.data_persistence import DataPersistenceLayer
from frontend.filters import render_item_type
from frontend.log import logger
from frontend.utils.form_data_parser import parse_formdata
from frontend.views.admin_views.admin_base_view import AdminBaseView


class PublisherView(AdminBaseView):
    model = PublisherPreset
    icon = "envelope-open"
    _index = 140

    publisher_types: ClassVar[dict[str, dict[str, str]]] = {
        member.name.lower(): {"id": member.name.lower(), "name": " ".join(part.capitalize() for part in member.name.split("_"))}
        for member in PUBLISHER_TYPES
    }

    @classmethod
    def get_extra_context(cls, base_context: dict) -> dict[str, Any]:
        parameters = {}
        parameter_values = {}
        publisher = base_context.get(cls.model_name())
        if publisher and (hasattr(publisher, "type") and (publisher_type := publisher.type)):
            parameter_values = publisher.parameters
            parameters = cls.get_worker_parameters(worker_type=PUBLISHER_TYPES(publisher_type).name.lower())

        base_context |= {
            "publisher_types": cls.publisher_types.values(),
            "parameter_values": parameter_values,
            "parameters": parameters,
            "worker_parameters_selected": bool(publisher and getattr(publisher, "type", None)),
            "secret_reveal_url": (
                f"{Config.TARANIS_BASE_PATH.rstrip('/')}/api/config/parameter-secrets/publisher-presets/{publisher.id}"
                if publisher and publisher.id
                else ""
            ),
        }
        return base_context

    @classmethod
    def get_publisher_parameters_view(cls, publisher_id: str, publisher_type: str):
        publisher_type = publisher_type.lower()
        if not publisher_id and not publisher_type:
            logger.warning("No Publisher ID or Publisher Type provided.")

        parameters = cls.get_worker_parameters(publisher_type)
        return render_template("partials/worker_parameters.html", parameters=parameters, worker_parameters_selected=True)

    @classmethod
    def get_columns(cls):
        return [
            {"title": "Name", "field": "name", "sortable": True, "renderer": None},
            {"title": "Description", "field": "description", "sortable": True, "renderer": None},
            {"title": "Type", "field": "type", "sortable": False, "renderer": render_item_type},
        ]


class ProductTypeView(AdminBaseView):
    model = ProductType
    icon = "envelope"
    _index = 150

    presenter_types: ClassVar[dict[str, dict[str, str]]] = {
        member.name.lower(): {"id": member.name.lower(), "name": " ".join(part.capitalize() for part in member.name.split("_"))}
        for member in PRESENTER_TYPES
    }

    @classmethod
    def get_extra_context(cls, base_context: dict) -> dict[str, Any]:
        dpl = DataPersistenceLayer()
        parameters = {}
        parameter_values = {}
        presenter = base_context.get(cls.model_name())
        if presenter and (hasattr(presenter, "type") and (presenter_type := presenter.type)):
            parameter_values = presenter.parameters.dict() if hasattr(presenter.parameters, "dict") else presenter.parameters
            parameters = cls.get_worker_parameters(worker_type=presenter_type.name.lower())
        base_context |= {
            "presenter_types": cls.presenter_types.values(),
            "report_types": [rt.model_dump() for rt in dpl.get_objects(ReportItemType).items],
            "parameters": parameters,
            "parameter_values": parameter_values,
            "worker_parameters_selected": bool(presenter and getattr(presenter, "type", None)),
            "secret_reveal_url": (
                f"{Config.TARANIS_BASE_PATH.rstrip('/')}/api/config/parameter-secrets/product-types/{presenter.id}"
                if presenter and presenter.id
                else ""
            ),
        }
        base_context["template_options"] = cls.get_template_options()
        return base_context

    @classmethod
    def process_form_data(cls, object_id: str):
        try:
            form_data = parse_formdata(request.form)
            return cls.store_form_data(form_data, object_id)
        except HTTPException:
            raise
        except Exception as exc:
            return None, str(exc)

    @classmethod
    def get_columns(cls):
        return [
            {"title": "Title", "field": "title", "sortable": True, "renderer": None},
            {"title": "Description", "field": "description", "sortable": True, "renderer": None},
            {"title": "Type", "field": "type", "sortable": False, "renderer": render_item_type},
        ]

    @classmethod
    def get_template_options(cls) -> list[dict[str, Any]]:
        return [{"id": t.id, "name": t.id} for t in DataPersistenceLayer().get_objects(Template).items]

    @classmethod
    def get_product_type_parameters_view(cls, product_type_id: str, presenter_type: str) -> str:
        if not product_type_id and not presenter_type:
            logger.warning("No Product Type ID or Presenter Type provided.")

        parameters = cls.get_worker_parameters(worker_type=presenter_type)
        template_options = cls.get_template_options()

        return render_template(
            "product_type/product_type_parameters.html",
            parameters=parameters,
            template_options=template_options,
            worker_parameters_selected=True,
        )
