import base64
import json
from datetime import datetime
from io import BytesIO
from types import SimpleNamespace
from typing import Any, cast
from unittest.mock import patch
from urllib.parse import parse_qs, urlparse

import pytest
from flask import render_template, url_for
from lxml import html
from models.admin import OSINTSource, ReportItemType
from models.task import Task, TaskResult
from models.types import COLLECTOR_TYPES
from models.user import AssessSavedFilter
from requests import ConnectTimeout
from werkzeug.datastructures import MultiDict

from frontend.cache import add_user_to_cache, cache
from frontend.cache_models import CacheObject
from frontend.config import Config
from frontend.views.admin_views.dashboard_views import AdminDashboardView
from frontend.views.admin_views.report_type_views import ReportItemTypeView
from frontend.views.admin_views.source_views import SourceView
from frontend.views.admin_views.word_list_views import WordListView
from frontend.views.base_view import BaseView


_VALID_PNG_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/iZk9HQAAAABJRU5ErkJggg=="
_VALID_PNG_BYTES = base64.b64decode(_VALID_PNG_BASE64)


VIEW_ITEMS = BaseView._registry.items()
VIEW_IDS = list(BaseView._registry.keys())
CRUD_ITEMS = [(name, cls) for name, cls in VIEW_ITEMS if not getattr(cls, "_read_only", False)]
CRUD_IDS = [name for name, _ in CRUD_ITEMS]
ADMIN_VIEWS = [(name, cls) for name, cls in VIEW_ITEMS if getattr(cls, "_is_admin", False)]
ADMIN_IDS = [name for name, _ in ADMIN_VIEWS]


def test_native_delete_rejects_create_id(authenticated_client):
    response = authenticated_client.post(SourceView.get_edit_route(osint_source_id="0"), data={"_action": "delete"})
    assert response.status_code == 405


def _json_request_body(call: Any) -> dict[str, Any]:
    body = call.request.body
    if isinstance(body, bytes):
        body = body.decode("utf-8")
    return json.loads(body or "{}")


def test_dashboard_limits_recent_tags_and_shows_saved_filters(authenticated_client, auth_user, responses_mock, mock_core_get_endpoints):
    _ = mock_core_get_endpoints
    saved_user = auth_user.model_copy(deep=True)
    saved_user.profile.assess_saved_filters = [
        AssessSavedFilter(
            id="filter-1",
            name="Shift queue",
            filters={"search": "incident", "tags": ["alpha"], "sort": "date_desc"},
        ),
        AssessSavedFilter(
            id="filter-2",
            name="Relevant queue",
            filters={"relevant": "true"},
        ),
        AssessSavedFilter(
            id="filter-3",
            name="Default queue",
            filters={"range": "shift"},
            is_default=True,
        ),
        AssessSavedFilter(
            id="filter-4",
            name="Hidden queue",
            filters={"search": "hidden"},
        ),
    ]
    add_user_to_cache(saved_user.model_dump(mode="json"))

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/dashboard/trending-clusters",
        json={
            "items": [
                {"name": "Location", "size": 10, "tags": [{"name": "USA", "size": 6}]},
                {
                    "name": "Organization",
                    "size": 8,
                    "tags": [{"name": "AIT", "size": 3}],
                },
                {
                    "name": "Product",
                    "size": 6,
                    "tags": [{"name": "Taranis", "size": 2}],
                },
                {"name": "Person", "size": 4, "tags": [{"name": "Arthur", "size": 1}]},
            ],
            "total_count": 4,
        },
    )

    response = authenticated_client.get("/")

    assert response.status_code == 200
    tree = html.fromstring(response.text)

    default_cards = tree.xpath('//*[@data-testid="recently-active-tags-default"]//*[@data-testid="trending-card"]')
    extra_cards = tree.xpath('//*[@data-testid="recently-active-tags-extra"]//*[@data-testid="trending-card"]')

    assert len(default_cards) == 3
    assert "Person" not in " ".join(card.text_content() for card in default_cards)
    assert len(extra_cards) == 1
    assert "Person" in extra_cards[0].text_content()

    saved_filter_cards = tree.xpath('//*[@data-testid="dashboard-saved-filters-default"]//*[@data-testid="dashboard-saved-filter-card"]')
    extra_saved_filter_cards = tree.xpath('//*[@data-testid="dashboard-saved-filters-extra"]//*[@data-testid="dashboard-saved-filter-card"]')

    assert tree.xpath('//*[@data-testid="dashboard-saved-filters"]//*[text()="Saved Filters"]')
    assert len(saved_filter_cards) == 3
    assert "Hidden queue" not in " ".join(card.text_content() for card in saved_filter_cards)
    assert len(extra_saved_filter_cards) == 1
    assert "Hidden queue" in extra_saved_filter_cards[0].text_content()
    assert extra_saved_filter_cards[0].xpath('.//button[normalize-space()="Delete"]')
    assert "Default" in saved_filter_cards[2].xpath('.//*[@data-testid="saved-filter-filter-3"]')[0].text_content()

    saved_filter_row = saved_filter_cards[0].xpath('.//*[@data-testid="saved-filter-filter-1"]')[0]
    saved_filter_url = urlparse(saved_filter_cards[0].xpath('./a[text()="Shift queue"]')[0].get("href"))
    delete_button = saved_filter_row.xpath('.//button[normalize-space()="Delete"]')[0]

    assert not saved_filter_row.xpath('.//button[normalize-space()="Update"]')
    assert not saved_filter_row.xpath('.//button[normalize-space()="Set default"]')
    assert delete_button.get("hx-delete") == url_for("assess.delete_saved_filter", filter_id="filter-1")
    assert delete_button.get("hx-target") == "closest [data-testid='dashboard-saved-filter-card']"
    assert delete_button.get("hx-swap") == "delete"
    assert saved_filter_url.path == url_for("assess.assess")
    assert parse_qs(saved_filter_url.query) == {
        "search": ["incident"],
        "tags": ["alpha"],
        "sort": ["date_desc"],
    }
    assert not tree.xpath('//*[@data-testid="dashboard-external-signals"]')


def test_dashboard_opt_in_lazy_loads_pizzint_card(authenticated_client, auth_user, responses_mock, mock_core_get_endpoints):
    _ = mock_core_get_endpoints
    saved_user = auth_user.model_copy(deep=True)
    saved_user.profile.timezone = "Europe/Vienna"
    saved_user.profile.dashboard.show_pizzint = True
    add_user_to_cache(saved_user.model_dump(mode="json"))
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/dashboard/trending-clusters",
        json={"items": [], "total_count": 0},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/dashboard/pizzint",
        json={
            "state": "fresh",
            "level": 4,
            "smoothed_index": 42.5,
            "observed_at": "2026-08-23T09:00:00Z",
            "fetched_at": "2026-08-23T09:42:39Z",
            "reason": "compute_doughcon_v9: elevated",
        },
    )
    responses_mock.get(f"{Config.TARANIS_CORE_URL}/dashboard/cluster-names", json={"items": []})

    dashboard_response = authenticated_client.get("/")
    dashboard_tree = html.fromstring(dashboard_response.text)
    placeholder = dashboard_tree.xpath('//*[@data-testid="pizzint-card-placeholder"]')[0]

    assert dashboard_response.status_code == 200
    assert placeholder.get("hx-get") == url_for("base.pizzint_card")
    assert placeholder.get("hx-trigger") == "load"

    edit_response = authenticated_client.get("/dashboard/edit")
    edit_tree = html.fromstring(edit_response.text)
    toggle = edit_tree.xpath('//input[@name="dashboard[show_pizzint]"][@type="checkbox"]')[0]
    assert toggle.get("checked") is not None

    card_response = authenticated_client.get("/dashboard/pizzint")
    card_tree = html.fromstring(card_response.text)
    card_text = card_tree.text_content()
    source_link = card_tree.xpath('//a[normalize-space()="PizzINT"]')[0]

    assert card_response.status_code == 200
    assert "DOUGHCON 4" in card_text
    assert "42.5/100" in card_text
    assert "23. August 2026 11:00" in card_text
    assert "DOUBLE TAKE • INCREASED INTELLIGENCE WATCH" in card_text
    assert "compute_doughcon_v9: elevated" not in card_text
    assert "One place spiking doesn't raise DOUGHCON" in card_text
    assert "DOUGHCON 1: Maximum Readiness" in " ".join(card_text.split())
    assert "Data correlation does not imply causation" in card_text
    assert source_link.get("target") == "_blank"
    assert source_link.get("rel") == "noopener noreferrer"
    assert card_tree.xpath('//summary[@aria-label="About DOUGHCON"]')


@pytest.mark.parametrize(
    ("payload", "expected_text", "unexpected_text"),
    [
        (
            {
                "state": "stale",
                "level": 5,
                "smoothed_index": 6.97,
                "observed_at": "2026-08-23T09:00:00Z",
                "fetched_at": "2026-08-23T09:42:39Z",
                "reason": "compute_doughcon_v9: quiet",
            },
            "Stale",
            "PizzINT data unavailable",
        ),
        (
            {
                "state": "unavailable",
                "level": None,
                "smoothed_index": None,
                "observed_at": None,
                "fetched_at": None,
                "reason": None,
            },
            "PizzINT data unavailable",
            "Smoothed index",
        ),
    ],
)
def test_pizzint_card_fallback_states(authenticated_client, responses_mock, payload, expected_text, unexpected_text):
    responses_mock.get(f"{Config.TARANIS_CORE_URL}/dashboard/pizzint", json=payload)

    response = authenticated_client.get("/dashboard/pizzint")

    assert response.status_code == 200
    assert expected_text in response.text
    assert unexpected_text not in response.text


@pytest.mark.parametrize("view_name,view_cls", ADMIN_VIEWS, ids=ADMIN_IDS)
class TestAdminViews:
    def test_admin_views(self, view_name, view_cls):
        assert view_cls._is_admin
        assert view_cls.pretty_name() == view_name

    def test_list_view_renders(self, view_name, view_cls, authenticated_client, mock_core_get_endpoints):
        """
        For each BaseView subclass:
          - GET its base route (list view) → 200
          - the unique name we injected in mock_data appears in the HTML
        """

        payload = mock_core_get_endpoints[view_name]
        target_url = view_cls.get_base_route()
        resp = authenticated_client.get(target_url)

        assert resp.status_code == 200, f"{view_name!r} list-view did not return 200 (got {resp.status_code})"

        html = resp.get_data(as_text=True)

        expected = payload.get("_expect_object", None)
        assert expected is not None, f"Expected: {expected} item in {view_name!r} not found in payload: {payload!r}"

        assert expected in html, f"Expected {expected!r} in the {view_name!r} HTML but did not find it.\nHTML snippet: {html[200:500]}…"


@pytest.mark.parametrize("view_name,view_cls", CRUD_ITEMS, ids=CRUD_IDS)
class TestCRUDViews:
    def test_create_form_renders(
        self,
        view_name,
        view_cls,
        form_data,
        form_formats_from_models,
        authenticated_client,
        mock_core_get_endpoints,
    ):
        # GET the edit form for item_id
        item_id = "0"
        # from pdb import set_trace; set_trace()
        key = view_cls._get_object_key()
        url = view_cls.get_edit_route(**{key: item_id})
        resp = authenticated_client.get(url)
        assert resp.status_code == 200

        html = resp.get_data(as_text=True)
        print(f"FORMDATA FOR : {view_name}")
        print(form_formats_from_models[view_name])
        actual_keys = form_data(html).get_cleaned_keys()
        allowed = form_formats_from_models[view_name]["allowed"]
        required = form_formats_from_models[view_name]["required"]

        missing_required = required - actual_keys
        extra = actual_keys - allowed

        assert not missing_required, f"{view_name!r} missing required fields: {missing_required} from {actual_keys!r}"
        assert not extra, f"{view_name!r} has unexpected fields: {extra}"

    def test_update_form_renders(
        self,
        view_name,
        view_cls,
        form_data,
        mock_core_get_item_endpoints,
        form_formats_from_models,
        authenticated_client,
    ):
        item_id = str(view_cls.model(**mock_core_get_item_endpoints[view_name]).id)
        key = view_cls._get_object_key()
        url = view_cls.get_edit_route(**{key: item_id})
        resp = authenticated_client.get(url)
        assert resp.status_code == 200

        html = resp.get_data(as_text=True)
        actual_keys = form_data(html).get_cleaned_keys()
        allowed = form_formats_from_models[view_name]["allowed"]
        required = form_formats_from_models[view_name]["required"]

        missing_required = required - actual_keys
        extra = actual_keys - allowed

        assert not missing_required, f"{view_name!r} missing required fields: {missing_required} from {actual_keys!r}"
        assert not extra, f"{view_name!r} has unexpected fields: {extra}"

    # def test_create_form_submits(self, view_name, view_cls, mock_core_create_endpoints, authenticated_client):
    #     url = view_cls.get_base_route()
    #     resp = authenticated_client.post(url, data=mock_core_create_endpoints[view_name])
    #     assert resp.status_code == 200

    #     html = resp.get_data(as_text=True)
    #     assert "Successfully created" in html

    # def test_update_form_submits(self, view_name, view_cls, mock_core_update_endpoints, authenticated_client):
    #     # PUT to update existing item
    #     item_id = str(mock_core_update_endpoints[view_name]["items"][0]["id"])
    #     key = view_cls._get_object_key()
    #     url = view_cls.get_edit_route(**{key: item_id})
    #     resp = authenticated_client.put(url, data={})
    #     assert resp.status_code == 200

    #     html = resp.get_data(as_text=True)
    #     assert "Successfully updated" in html

    # def test_delete_form(self, view_name, view_cls, mock_core_delete_endpoints, authenticated_client):
    #     # DELETE existing item
    #     item_id = str(mock_core_delete_endpoints[view_name]["items"][0]["id"])
    #     url = view_cls.get_edit_route(item_id)
    #     resp = authenticated_client.delete(url)
    #     assert resp.status_code == 200

    #     html = resp.get_data(as_text=True)
    #     assert "Successfully deleted" in html


class TestSourceView:
    @pytest.mark.parametrize("status", [200, 409])
    def test_native_delete_redirects_with_notification(self, authenticated_client, responses_mock, status):
        core_url = f"{Config.TARANIS_CORE_URL}/config/osint-sources/source-1"
        message = "Source deleted" if status == 200 else "Source has related news items"
        responses_mock.delete(core_url, json={"message" if status == 200 else "error": message}, status=status)

        response = authenticated_client.post(SourceView.get_edit_route(osint_source_id="source-1"), data={"_action": "delete"})

        assert response.status_code == 302
        assert response.location == SourceView.get_base_route()
        assert len([call for call in responses_mock.calls if call.request.method == "DELETE" and call.request.url == core_url]) == 1
        with authenticated_client.session_transaction() as session:
            assert ("success" if status == 200 else "error", message) in session["_flashes"]

    def test_source_menu_badge_uses_task_failure_count(self, monkeypatch):
        fake_badges = SimpleNamespace(osint_source=4)
        monkeypatch.setattr(
            "frontend.views.admin_views.source_views.DataPersistenceLayer",
            lambda: SimpleNamespace(get_object=lambda model: fake_badges),
        )

        assert SourceView.get_admin_menu_badge() == 4

    def test_bulk_delete_renders_related_news_items_error(self, authenticated_client, responses_mock, htmx_header):
        core_url = f"{Config.TARANIS_CORE_URL}/config/osint-sources"
        related_data_error = (
            "The OSINT source could not be deleted because related news items exist. "
            "Enable force deletion to delete the source and its related data."
        )
        responses_mock.delete(core_url, json={"error": related_data_error}, status=409)

        response = authenticated_client.delete(
            SourceView.get_base_route(),
            data={"ids": ["source-safe", "source-blocked"]},
            headers=htmx_header,
        )

        assert response.status_code == 409
        assert related_data_error in response.get_data(as_text=True)
        assert responses_mock.calls[0].request.url == f"{core_url}?ids=source-safe&ids=source-blocked"

    def test_source_detail_renders_collection_rate(self, authenticated_client, responses_mock):
        source = OSINTSource(
            id="source-rate",
            name="Source rate",
            description="A test source",
            type=COLLECTOR_TYPES.RSS_COLLECTOR,
            parameters={"FEED_URL": "https://example.com/feed.xml"},
            news_items_count=9,
            collection_count=1,
            collection_period="day",
        )
        responses_mock.get(
            f"{Config.TARANIS_CORE_URL}/config/osint-sources/source-rate",
            json=source.model_dump(mode="json"),
            status=200,
        )

        response = authenticated_client.get(SourceView.get_edit_route(osint_source_id="source-rate", period="day"))

        assert response.status_code == 200
        assert "Recent collection: 1 article/day" in response.text
        tree = html.fromstring(response.text)
        assert tree.xpath('//*[@data-testid="detail-collection-period-day"][@aria-current="true"]')
        assert parse_qs(urlparse(responses_mock.calls[0].request.url).query)["period"] == ["day"]

    def test_bulk_create_view_uses_url_based_collectors(self, authenticated_client):
        create_form_response = authenticated_client.get(SourceView.get_edit_route(osint_source_id="0"))
        response = authenticated_client.get(url_for("admin.bulk_create_osint_sources"))

        assert create_form_response.status_code == 200
        assert 'data-testid="bulk-create-osint-sources-button"' in create_form_response.text
        assert response.status_code == 200
        assert "Bulk Create OSINT Sources" in response.text
        assert 'href="https://taranis.ai/docs/admin/collectors/"' in create_form_response.text
        assert "rss_collector" in response.text
        assert "simple_web_collector" in response.text
        assert "rt_collector" in response.text
        assert "misp_collector" in response.text
        assert "mastodon_collector" in create_form_response.text
        assert "mastodon_collector" not in response.text
        assert "manual_collector" not in response.text
        assert "ppn_collector" not in response.text

    def test_bulk_parameter_view_only_excludes_the_varying_url_for_bulk_requests(self, authenticated_client):
        bulk_response = authenticated_client.get(
            url_for(
                "admin.osint_source_parameters",
                osint_source_id="0",
                type="rss_collector",
                bulk="true",
            )
        )
        regular_response = authenticated_client.get(
            url_for(
                "admin.osint_source_parameters",
                osint_source_id="0",
                type="rss_collector",
                bulk="false",
            )
        )

        assert bulk_response.status_code == 200
        assert 'name="parameters[FEED_URL]"' not in bulk_response.text
        assert 'name="parameters[USER_AGENT]"' in bulk_response.text
        assert regular_response.status_code == 200
        assert 'name="parameters[FEED_URL]"' in regular_response.text

    def test_bulk_create_reports_core_import_failures_with_server_status(self, authenticated_client, responses_mock):
        endpoint = f"{Config.TARANIS_CORE_URL}/config/import-osint-sources"
        responses_mock.post(endpoint, json={"error": "Core import failed."}, status=503)
        responses_mock.post(endpoint, body=ConnectTimeout("Core request timed out"))
        form_data = MultiDict(
            [
                ("sources[][name]", "Feed One"),
                ("sources[][url]", "https://example.com/one.xml"),
                ("sources[][name]", "Feed Two"),
                ("sources[][url]", "https://example.com/two.xml"),
                ("type", "rss_collector"),
            ]
        )

        upstream_failure = authenticated_client.post(url_for("admin.bulk_create_osint_sources"), data=form_data)
        transport_failure = authenticated_client.post(url_for("admin.bulk_create_osint_sources"), data=form_data)

        assert upstream_failure.status_code == 503
        assert "Core import failed." in upstream_failure.text
        assert transport_failure.status_code == 502
        assert "Failed to create OSINT sources." in transport_failure.text

    def test_import_post_view(self, authenticated_client, responses_mock):
        """
        Test that the import_post_view method correctly extracts the "sources" key
        from the uploaded JSON file.
        """
        # Create a dummy export file with a "sources" key
        dummy_export_data = {
            "version": 3,
            "sources": [{"name": "Test Source", "type": "rss", "url": "http://example.com/rss"}],
        }
        dummy_file_content = json.dumps(dummy_export_data).encode("utf-8")
        dummy_file = BytesIO(dummy_file_content)
        dummy_file.name = "test.json"

        responses_mock.post(
            f"{Config.TARANIS_CORE_URL}/config/import-osint-sources",
            json={"message": "Sources imported successfully"},
            status=200,
            content_type="application/json",
        )

        # Simulate the POST request
        resp = authenticated_client.post(
            SourceView.get_import_route(),
            data={"file": (dummy_file, "test.json")},
            content_type="multipart/form-data",
        )

        assert resp.status_code == 302, f"Expected redirect response, got {resp.status_code}"
        assert resp.headers["Location"] == SourceView.get_base_route()

        assert len(responses_mock.calls) == 1
        assert urlparse(responses_mock.calls[0].request.url).path.removeprefix("/api") == "/config/import-osint-sources"
        assert _json_request_body(responses_mock.calls[0]) == dummy_export_data

    def test_import_post_view_no_file(self, authenticated_client):
        """
        Test that the import_post_view method returns an error when no file is provided.
        """
        resp = authenticated_client.post(SourceView.get_import_route(), data={}, content_type="multipart/form-data")

        assert resp.status_code == 200, "Expected 200 OK response with error message in content"
        html = resp.get_data(as_text=True)
        assert "No file or organization provided" in html

    def test_import_post_view_api_failure(self, authenticated_client, responses_mock):
        """
        Test that the import_post_view method returns an error when the CoreApi call fails.
        """
        dummy_export_data = {
            "version": 3,
            "sources": [{"name": "Test Source", "type": "rss", "url": "http://example.com/rss"}],
        }
        dummy_file_content = json.dumps(dummy_export_data).encode("utf-8")
        dummy_file = BytesIO(dummy_file_content)
        dummy_file.name = "test.json"

        responses_mock.post(
            f"{Config.TARANIS_CORE_URL}/config/import-osint-sources",
            json={"error": "Failed to import sources"},
            status=500,
            content_type="application/json",
        )

        resp = authenticated_client.post(
            SourceView.get_import_route(),
            data={"file": (dummy_file, "test.json")},
            content_type="multipart/form-data",
        )

        assert resp.status_code == 200
        html = resp.get_data(as_text=True)
        assert "Failed to import sources" in html
        assert len(responses_mock.calls) == 1
        assert _json_request_body(responses_mock.calls[0]) == dummy_export_data

    def test_process_form_data_accepts_valid_png_icon(self, app):
        with (
            patch.object(SourceView, "store_form_data", return_value=({"stored": True}, None)) as mock_store,
            app.test_request_context(
                SourceView.get_base_route(),
                method="POST",
                data={"icon": (BytesIO(_VALID_PNG_BYTES), "icon.png", "image/png")},
                content_type="multipart/form-data",
            ),
        ):
            response, error = SourceView.process_form_data("0")

        assert error is None
        assert response == {"stored": True}
        mock_store.assert_called_once()
        processed_data = mock_store.call_args.args[0]
        assert processed_data["icon"] == base64.b64encode(_VALID_PNG_BYTES).decode("utf-8")

    def test_process_form_data_rejects_oversized_icon(self, app):
        max_bytes = Config.OSINT_SOURCE_ICON_MAX_BYTES
        oversized_icon = b"\x00" * (max_bytes + 1)

        with (
            patch.object(SourceView, "store_form_data") as mock_store,
            app.test_request_context(
                SourceView.get_base_route(),
                method="POST",
                data={"icon": (BytesIO(oversized_icon), "icon.png", "image/png")},
                content_type="multipart/form-data",
            ),
        ):
            response, error = SourceView.process_form_data("0")

        assert response is None
        assert error == f"Icon file exceeds maximum size of {max_bytes} bytes."
        mock_store.assert_not_called()

    def test_process_form_data_returns_core_error_message(self, app):
        with (
            patch.object(
                SourceView,
                "store_form_data",
                return_value=(
                    None,
                    {"error": "Icon payload is not a valid image file."},
                ),
            ),
            app.test_request_context(
                SourceView.get_base_route(),
                method="POST",
                data={"icon": (BytesIO(b"not-an-image"), "icon.png", "image/png")},
                content_type="multipart/form-data",
            ),
        ):
            response, error = SourceView.process_form_data("0")

        assert response is None
        assert error == "Icon payload is not a valid image file."

    def test_process_form_data_can_delete_icon_without_upload(self, app):
        with (
            patch.object(SourceView, "store_form_data", return_value=({"stored": True}, None)) as mock_store,
            app.test_request_context(
                SourceView.get_base_route(),
                method="POST",
                data={"delete_icon": "true"},
                content_type="multipart/form-data",
            ),
        ):
            response, error = SourceView.process_form_data("123")

        assert error is None
        assert response == {"stored": True}
        mock_store.assert_called_once()
        processed_data = mock_store.call_args.args[0]
        assert processed_data["icon"] == ""
        assert "delete_icon" not in processed_data

    def test_process_form_data_delete_icon_wins_over_file_upload(self, app):
        max_bytes = Config.OSINT_SOURCE_ICON_MAX_BYTES
        oversized_icon = b"\x00" * (max_bytes + 1)

        with (
            patch.object(SourceView, "store_form_data", return_value=({"stored": True}, None)) as mock_store,
            app.test_request_context(
                SourceView.get_base_route(),
                method="POST",
                data={
                    "delete_icon": "true",
                    "icon": (BytesIO(oversized_icon), "icon.png", "image/png"),
                },
                content_type="multipart/form-data",
            ),
        ):
            response, error = SourceView.process_form_data("123")

        assert error is None
        assert response == {"stored": True}
        mock_store.assert_called_once()
        processed_data = mock_store.call_args.args[0]
        assert processed_data["icon"] == ""

    def test_osint_source_preview_shows_failure_and_retrigger_action(self, app):
        task_result = Task(
            id="source_preview_42",
            status="FAILURE",
            result=TaskResult(
                message="Connection refused",
                reason="preview_failed",
                retryable=False,
                data=None,
            ),
        )

        with app.test_request_context("/"):
            rendered = render_template(
                "osint_source/osint_source_preview.html",
                task_result=task_result,
                osint_source_id="42",
            )

        assert "OSINT source preview failed." in rendered
        assert "Connection refused" in rendered
        assert "hx-post=" in rendered
        assert "source_preview/42" in rendered
        assert 'hx-target="#source_preview"' in rendered
        assert "Retrigger preview" in rendered

    def test_osint_source_preview_shows_started_task_without_result(self, authenticated_client, responses_mock):
        responses_mock.get(
            f"{Config.TARANIS_CORE_URL}/config/osint-sources/42/preview",
            json={"id": "source_preview_42", "status": "STARTED"},
            status=202,
        )

        response = authenticated_client.get("/admin/source_preview/42")

        assert response.status_code == 200
        assert "OSINT source preview is currently being processed." in response.text
        assert 'realtime:osint_source.preview.finished[detail.resource.id=="42"] from:document' in response.text
        assert "realtime:resync from:document" in response.text
        assert "every 20s" in response.text


class TestWordListView:
    def test_table_container_actions_replace_outer_html(self, app):
        with app.test_request_context("/admin/word_lists"):
            word_lists = CacheObject([])
            context = WordListView.get_view_context(word_lists)
            context["word_lists"] = word_lists
            tree = html.fromstring(render_template(WordListView.get_htmx_list_template(), **context))

        container_nodes = tree.xpath('//*[@id="word_list-table-container"]')
        assert container_nodes, "Expected #word_list-table-container in rendered template"

        load_default_buttons = tree.xpath('//*[@data-testid="load-default-word_list-button"]')
        assert load_default_buttons, "Expected load-default-word_list-button in rendered template"
        load_default_button = load_default_buttons[0]

        delete_buttons = tree.xpath('//*[@data-testid="delete-word_list-button"]')
        assert delete_buttons, "Expected delete-word_list-button in rendered template"
        delete_button = delete_buttons[0]

        assert load_default_button.get("hx-target") == "#word_list-table-container"
        assert load_default_button.get("hx-swap") == "outerHTML"
        assert delete_button.get("hx-target") == "#word_list-table-container"
        assert delete_button.get("hx-swap") == "outerHTML"

    def test_import_post_view_no_file_renders_inline_error(self, authenticated_client):
        resp = authenticated_client.post(WordListView.get_import_route(), data={}, content_type="multipart/form-data")

        assert resp.status_code == 200
        html = resp.get_data(as_text=True)
        assert "No file provided" in html
        assert 'hx-swap-oob="true"' not in html

    def test_import_post_view_api_failure_renders_inline_error(self, authenticated_client, responses_mock):
        dummy_export_data = {
            "version": 1,
            "data": [{"name": "Test wordlist", "entries": []}],
        }
        dummy_file_content = json.dumps(dummy_export_data).encode("utf-8")
        dummy_file = BytesIO(dummy_file_content)
        dummy_file.name = "test.json"

        responses_mock.post(
            f"{Config.TARANIS_CORE_URL}/config/import-word-lists",
            json={"error": "Failed to import word lists"},
            status=500,
            content_type="application/json",
        )

        resp = authenticated_client.post(
            WordListView.get_import_route(),
            data={"file": (dummy_file, "test.json")},
            content_type="multipart/form-data",
        )

        assert resp.status_code == 200
        html = resp.get_data(as_text=True)
        assert "Failed to import word lists" in html
        assert 'hx-swap-oob="true"' not in html


def test_report_item_type_submitted_form_model_uses_shared_normalization(app):
    with app.test_request_context(
        "/admin/report-item-types/0",
        method="POST",
        data={
            "title": "Incident Report",
            "description": "Shared normalization",
            "attribute_groups[][index]": "0",
            "attribute_groups[][title]": "Indicators",
            "attribute_groups[][attribute_group_items][][index]": "0",
            "attribute_groups[][attribute_group_items][][title]": "Domain",
            "csrf_token": "secret",
        },
    ):
        model = cast(ReportItemType | None, ReportItemTypeView._submitted_form_model())

    assert model is not None
    attribute_groups = model.attribute_groups or []
    assert model.title == "Incident Report"
    assert len(attribute_groups) == 1
    assert attribute_groups[0].title == "Indicators"
    assert len(attribute_groups[0].attribute_group_items) == 1
    assert attribute_groups[0].attribute_group_items[0].title == "Domain"


def test_osint_source_form_shows_current_icon_and_delete_option(app):
    osint_source = OSINTSource.model_construct(
        id="source-with-icon",
        name="Test source",
        description="",
        rank=3,
        type=COLLECTOR_TYPES.RSS_COLLECTOR,
        parameters={},
        icon=_VALID_PNG_BASE64,
        enabled=True,
        news_items_count=7,
        status=None,
    )

    with app.test_request_context("/"):
        html = render_template(
            "osint_source/osint_source_form.html",
            model_name="osint_source",
            submit_text="Update OSINT Source",
            form_action="/frontend/admin/sources/source-with-icon",
            form_error={},
            osint_source=osint_source,
            icon_accept="image/png",
            collector_types=[],
            parameters=[],
            parameter_values={},
        )

    assert "Current icon" in html
    assert "An icon is currently uploaded." in html
    assert 'name="delete_icon"' in html
    assert 'data-testid="current-osint-icon"' in html
    assert 'data-testid="osint-source-rank"' in html
    assert 'value="3"' in html
    assert 'aria-label="3 stars"' in html
    assert "News items in database: 7" in html
    assert "source_preview/source-with-icon" in html
    assert "source_collect/source-with-icon" in html
    assert "Preview" in html
    assert "Collect" in html
    assert "checked" in html
    assert 'hx-post="/frontend/admin/toggle_source_state/source-with-icon/enabled"' in html
    assert 'hx-post="/frontend/admin/toggle_source_state/source-with-icon/disabled"' in html
    assert html.count('hx-swap="outerHTML"') >= 3


def test_osint_source_form_disables_rank_for_manual_source(app):
    osint_source = OSINTSource.model_construct(
        id="manual",
        name="Manual",
        description="",
        rank=0,
        type=COLLECTOR_TYPES.MANUAL_COLLECTOR,
        parameters={},
        icon=None,
        enabled=True,
        news_items_count=13,
        status=None,
    )

    with app.test_request_context("/"):
        html = render_template(
            "osint_source/osint_source_form.html",
            model_name="osint_source",
            submit_text="Update OSINT Source",
            form_action='hx-put="/frontend/admin/sources/manual"',
            form_error={},
            osint_source=osint_source,
            icon_accept="image/png",
            collector_types=[],
            parameters=[],
            parameter_values={},
        )

    assert 'data-testid="osint-source-rank"' in html
    assert 'name="rank" value="0"' in html
    assert 'aria-label="Unrated"' in html
    assert "News items in database: 13" in html
    assert html.count('name="rank"') == 7
    assert html.count("disabled") >= 6
    assert "source_preview/manual" not in html
    assert "source_collect/manual" not in html


def test_admin_dashboard_renders_health_card(authenticated_client, auth_user, responses_mock, monkeypatch):
    cache.clear()
    add_user_to_cache(auth_user.model_dump(mode="json"))

    monkeypatch.setattr(Config, "BUILD_DATE", datetime.fromisoformat("2025-01-16T08:45:00+00:00"))
    monkeypatch.setattr(Config, "GIT_INFO", {"tag": "1.3.5", "HEAD": "front456", "branch": "master"})

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}{AdminDashboardView.model._core_endpoint}",
        json={
            "items": [
                {
                    "total_news_items": 10,
                    "total_story_items": 5,
                    "total_products": 2,
                    "report_items_completed": 3,
                    "report_items_in_progress": 1,
                    "latest_collected": "2025-01-14T21:16:42.699574+01:00",
                    "schedule_length": 4,
                    "conflict_count": 0,
                    "health_status": {
                        "healthy": False,
                        "services": {
                            "database": "up",
                            "seed_data": "up",
                            "broker": "down",
                            "workers": "down",
                        },
                    },
                    "task_status_totals": {
                        "successes": 3,
                        "failures": 1,
                        "total": 4,
                        "success_pct": 75,
                    },
                }
            ]
        },
        status=200,
        content_type="application/json",
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}{AdminDashboardView.model._core_endpoint}/build-info",
        json={
            "build_date": "2025-01-15T09:30:00+00:00",
            "tag": "1.3.4",
            "HEAD": "core123",
            "branch": "master",
        },
        status=200,
        content_type="application/json",
    )

    response = authenticated_client.get(AdminDashboardView.get_base_route())

    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "Release Info" in html
    assert "Core" in html
    assert "Frontend" in html
    assert "1.3.4" in html
    assert "1.3.5" in html
    assert "Commit / Branch:" not in html
    assert "core123" not in html
    assert "front456" not in html
    assert "System Health" in html
    assert "Degraded" in html
    assert "Task Status" in html
    assert "Success rate: 75%" in html
    assert "Database" in html
    assert "Pre-seeded" in html
    assert "Redis" in html
    assert "Workers" in html


def test_persistent_notification_has_no_timeout_animation(app):
    with app.test_request_context():
        persistent = render_template(
            "notification/index.html",
            notification={"message": "Persistent", "persistent": True},
            oob=False,
        )
        timed = render_template(
            "notification/index.html",
            notification={"message": "Timed"},
            oob=False,
        )

    assert "@animationend" not in persistent
    assert '@click="show = false"' in persistent
    assert "@animationend" in timed


def test_assess_page_shows_sidebar_toggle_when_sidebar_exists(authenticated_client, responses_mock):
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/filter-lists",
        json={"tags": [], "sources": [], "groups": [], "languages": []},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories",
        json={"items": [], "total_count": 0},
    )

    response = authenticated_client.get("/assess")

    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert 'aria-label="Toggle sidebar"' in html
    assert "<noscript>" in html
    assert "#sidebar {" in html
    assert "width: 16rem;" in html
    assert "#sidebar ~ main {" in html
    assert "margin-left: 16rem;" in html
    assert "max-width: calc(100vw - 16rem);" in html


def test_admin_dashboard_renders_frontend_release_info_when_core_build_info_fails(
    authenticated_client, auth_user, responses_mock, monkeypatch
):
    cache.clear()
    add_user_to_cache(auth_user.model_dump(mode="json"))

    monkeypatch.setattr(Config, "BUILD_DATE", datetime.fromisoformat("2025-01-16T08:45:00+00:00"))
    monkeypatch.setattr(Config, "GIT_INFO", {"HEAD": "front456", "branch": "master"})

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}{AdminDashboardView.model._core_endpoint}",
        json={
            "items": [
                {
                    "total_news_items": 10,
                    "total_story_items": 5,
                    "total_products": 2,
                    "report_items_completed": 3,
                    "report_items_in_progress": 1,
                    "latest_collected": "2025-01-14T21:16:42.699574+01:00",
                    "schedule_length": 4,
                    "conflict_count": 0,
                    "health_status": {
                        "healthy": True,
                        "services": {
                            "database": "up",
                            "seed_data": "up",
                            "broker": "up",
                            "workers": "up",
                        },
                    },
                    "task_status_totals": {
                        "successes": 3,
                        "failures": 1,
                        "total": 4,
                        "success_pct": 75,
                    },
                }
            ]
        },
        status=200,
        content_type="application/json",
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}{AdminDashboardView.model._core_endpoint}/build-info",
        json={"message": "unavailable"},
        status=503,
        content_type="application/json",
    )

    response = authenticated_client.get(AdminDashboardView.get_base_route())

    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "Frontend" in html
    assert "Commit / Branch:" in html
    assert "front456" in html
    assert "master" in html
    assert "Unavailable" in html
    assert "Task Status" in html
