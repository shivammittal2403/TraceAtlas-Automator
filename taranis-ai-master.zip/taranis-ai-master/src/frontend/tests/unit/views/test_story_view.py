import json
from types import SimpleNamespace
from typing import Any
from urllib.parse import parse_qs, urlparse
from uuid import UUID

import pytest
from flask import render_template, render_template_string, url_for
from lxml import html
from models.assess import FilterLists, Story, StoryUpdatePayload
from models.user import AssessSavedFilter
from requests import RequestException
from werkzeug.datastructures import MultiDict
from werkzeug.exceptions import Forbidden

from frontend.cache import add_user_to_cache
from frontend.config import Config
from frontend.views.story_views import ASSESS_SAVED_FILTER_SESSION_KEY, StoryView


def expected_search_trigger(input_id: str) -> str:
    return f"input changed delay:500ms from:#{input_id}, search from:#{input_id}"


def test_news_item_order_returns_local_safe_error_when_core_is_unavailable(authenticated_client_basic, responses_mock, htmx_header):
    responses_mock.put(
        f"{Config.TARANIS_CORE_URL}/assess/stories/story-1/news-item-order",
        body=RequestException("private connection details"),
    )
    response = authenticated_client_basic.post(
        "/story/story-1/news-item-order",
        headers=htmx_header,
        data={"news_item_ids": ["item-2", "item-1"], "expected_news_item_ids": ["item-1", "item-2"]},
    )
    assert response.status_code == 503
    assert b"Unable to save news item order" in response.data
    assert b"private connection details" not in response.data
    assert b"story-edit-form" not in response.data


def mock_story_for_edit(responses_mock, story_payload: dict):
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/filter-lists",
        json={"tags": [], "sources": [], "groups": []},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_payload['id']}",
        json=story_payload,
    )


def story_with_news_item_tags() -> dict:
    return {
        "id": "story-1",
        "title": "Tagged Story",
        "can_edit": True,
        "description": "Story description",
        "summary": "Story summary",
        "comments": "Story comment",
        "attributes": [],
        "news_items": [
            {
                "id": "news-1",
                "story_id": "story-1",
                "title": "Tagged News Item",
                "content": "News item content",
                "source": "manual",
                "osint_source_id": "manual",
                "tags": [{"name": "item-tag", "tag_type": "actor"}],
            }
        ],
    }


def _bookmark_collection_payload(bookmark_id: str, name: str, story_count: int, position: int = 0) -> dict:
    return {
        "id": bookmark_id,
        "name": name,
        "position": position,
        "created": "2026-06-01T10:00:00",
        "updated": "2026-06-02T10:00:00",
        "story_count": story_count,
        "story_ids": [],
        "stories": [],
    }


def _profile_update_payload(responses_mock: Any) -> dict[str, Any]:
    profile_update_call = next(call for call in responses_mock.calls if urlparse(call.request.url).path.endswith("/users/profile"))
    request_body = profile_update_call.request.body
    return json.loads(request_body.decode() if isinstance(request_body, bytes) else request_body)


def _cache_saved_filters(auth_user: Any, saved_filters: list[AssessSavedFilter]) -> None:
    saved_user = auth_user.model_copy(deep=True)
    saved_user.profile.assess_saved_filters = saved_filters
    add_user_to_cache(saved_user.model_dump(mode="json"))


def _mock_profile_update(responses_mock: Any) -> None:
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/users/profile",
        json={"message": "Profile updated", "id": "user-1", "user_profile": {"assess_saved_filters": []}},
    )


def test_story_diff_view_renders_compare_payload(app, authenticated_client, responses_mock):
    story_id = "story-1"
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_id}/revisions/1",
        json={
            "id": "revision-1",
            "revision": 1,
            "created_at": "2026-03-12T10:00:00",
            "created_by": "alice",
            "created_by_id": "user-1",
            "note": "created",
            "data": {
                "title": "Kill Chain im Krieg verkurzt",
                "description": "First draft",
                "summary": "Summary A",
                "comments": "Comment A",
                "likes": 1,
                "dislikes": 0,
                "tags": [{"name": "old-tag"}],
                "news_items": [{"id": "news-1", "title": "Old news"}],
                "attributes": [{"key": "TLP", "value": "clear"}],
            },
        },
        status=200,
        content_type="application/json",
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_id}/revisions/2",
        json={
            "id": "revision-2",
            "revision": 2,
            "created_at": "2026-03-12T11:00:00",
            "created_by": "bob",
            "created_by_id": "user-2",
            "note": "update",
            "data": {
                "title": "Kill Chain im Krieg deutlich verkurzt",
                "description": "First draft",
                "summary": "Summary B",
                "comments": "Comment A",
                "likes": 3,
                "dislikes": 1,
                "tags": [{"name": "new-tag"}],
                "news_items": [{"id": "news-2", "title": "New news"}],
                "attributes": [{"key": "TLP", "value": "amber"}],
            },
        },
        status=200,
        content_type="application/json",
    )

    with app.test_request_context():
        response = authenticated_client.get(url_for("assess.story_diff", story_id=story_id, from_rev=1, to_rev=2))

    assert response.status_code == 200
    html_doc = response.get_data(as_text=True)
    assert "Changes:" in html_doc
    assert "Kill Chain im Krieg deutlich verkurzt" in html_doc
    assert "old_segments" not in html_doc
    assert "deutlich " in html_doc
    assert "bg-success/20 text-success" in html_doc
    assert "bg-error/20 text-error" in html_doc
    assert "Likes" in html_doc
    assert "Dislikes" in html_doc


def test_story_diff_view_shows_no_changes_state(app, authenticated_client, responses_mock):
    story_id = "story-1"
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_id}/revisions/1",
        json={
            "id": "revision-1",
            "revision": 1,
            "created_at": "2026-03-12T10:00:00",
            "created_by": "alice",
            "created_by_id": "user-1",
            "note": "created",
            "data": {
                "title": "Story title",
                "tags": [],
                "news_items": [],
                "attributes": [],
                "description": "",
                "summary": "",
                "comments": "",
            },
        },
        status=200,
        content_type="application/json",
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_id}/revisions/2",
        json={
            "id": "revision-2",
            "revision": 2,
            "created_at": "2026-03-12T11:00:00",
            "created_by": "bob",
            "created_by_id": "user-2",
            "note": "update",
            "data": {
                "title": "Story title",
                "tags": [],
                "news_items": [],
                "attributes": [],
                "description": "",
                "summary": "",
                "comments": "",
            },
        },
        status=200,
        content_type="application/json",
    )

    with app.test_request_context():
        response = authenticated_client.get(url_for("assess.story_diff", story_id=story_id, from_rev=1, to_rev=2))

    assert response.status_code == 200
    html_doc = response.get_data(as_text=True)
    assert "No changes detected between these revisions." in html_doc


def test_story_to_core_dict_strips_export_only_fields():
    story = Story.model_validate(
        {
            "id": "story-1",
            "title": "Imported Story",
            "updated": "2026-03-12T10:00:00",
            "links": ["https://example.com/story"],
            "relevance_override": 7,
            "user_vote": "like",
            "in_reports_count": 3,
            "news_items": [
                {
                    "osint_source_id": "manual",
                    "title": "Imported Story News 1",
                    "links": ["https://example.com/news"],
                    "tags": [{"name": "news-tag", "tag_type": "misc"}],
                }
            ],
        }
    )

    normalized = story.to_core_dict()

    assert normalized["relevance_override"] == 7
    assert "updated" not in normalized
    assert "links" not in normalized
    assert "user_vote" not in normalized
    assert "in_reports_count" not in normalized
    assert "links" not in normalized["news_items"][0]
    assert normalized["news_items"][0]["tags"] == [{"name": "news-tag", "tag_type": "misc"}]


def test_story_update_payload_ignores_tags():
    payload = StoryUpdatePayload.model_validate({"title": "Updated Story", "tags": [{"name": "story-tag", "tag_type": "misc"}]})

    assert payload.model_dump(mode="json") == {"title": "Updated Story"}


def test_story_update_redirects_to_story_without_htmx(authenticated_client, responses_mock):
    responses_mock.patch(
        f"{Config.TARANIS_CORE_URL}/assess/stories/story-1",
        json={"message": "Story updated"},
    )

    response = authenticated_client.post(
        url_for("assess.story_update", story_id="story-1"),
        data={"read": "true"},
    )

    assert response.status_code == 302
    assert response.headers["Location"] == url_for("assess.story", story_id="story-1")
    assert json.loads(responses_mock.calls[0].request.body) == {"read": True}


@pytest.mark.parametrize("can_update", [True, False])
def test_story_edit_standard_post_updates_and_redirects(authenticated_client, auth_user, responses_mock, can_update):
    if not can_update:
        reader = auth_user.model_copy(deep=True)
        reader.permissions = ["ASSESS_ACCESS"]
        add_user_to_cache(reader.model_dump(mode="json"))
        for endpoint, methods in (("assess.story_edit", ("GET", "POST", "PUT")), ("assess.story_news_item_order", ("GET", "POST"))):
            for method in methods:
                assert authenticated_client.open(url_for(endpoint, story_id="story-1"), method=method).status_code == 403
        mock_story_for_edit(responses_mock, story_with_news_item_tags())
        responses_mock.get(f"{Config.TARANIS_CORE_URL}/assess/bookmarks", json={"items": [], "total_count": 0})
        assert authenticated_client.get(url_for("assess.story", story_id="story-1")).status_code == 200
        return

    responses_mock.patch(
        f"{Config.TARANIS_CORE_URL}/assess/stories/story-1",
        json={"message": "Story updated"},
    )

    response = authenticated_client.post(
        url_for("assess.story_edit", story_id="story-1"),
        data={"title": "Updated Story"},
    )

    assert response.status_code == 302
    assert response.headers["Location"] == url_for("assess.story", story_id="story-1")
    assert json.loads(responses_mock.calls[0].request.body) == {"title": "Updated Story"}


def _render_news_item_card(story: Story) -> str:
    return render_template_string(
        '{% from "assess/news_item_card.html" import news_item_card %}{{ news_item_card(story.news_items[0], story) }}',
        story=story,
    )


def test_news_item_card_shows_author_when_present(app):
    story = Story.model_validate(
        {
            "id": "story-1",
            "title": "Story with author",
            "news_items": [
                {
                    "id": "news-1",
                    "story_id": "story-1",
                    "osint_source_id": "manual",
                    "title": "News with author",
                    "author": "James Bond",
                }
            ],
        }
    )

    with app.test_request_context():
        markup = _render_news_item_card(story)

    tree = html.fromstring(markup)
    author_badge = tree.xpath('//*[@data-test-id="news-item-author"]')
    assert len(author_badge) == 1
    assert author_badge[0].text_content().strip() == "Author · James Bond"


def test_news_item_card_hides_author_when_missing_or_empty(app):
    for payload in ({}, {"author": ""}):
        story = Story.model_validate(
            {
                "id": "story-1",
                "title": "Story without author",
                "news_items": [
                    {
                        "id": "news-1",
                        "story_id": "story-1",
                        "osint_source_id": "manual",
                        "title": "News without author",
                        **payload,
                    }
                ],
            }
        )

        with app.test_request_context():
            markup = _render_news_item_card(story)

        tree = html.fromstring(markup)
        assert not tree.xpath('//*[@data-test-id="news-item-author"]')
        assert "Author ·" not in tree.text_content()


def test_manual_news_item_form_routes_htmx_errors_to_notification_bar(authenticated_client):
    response = authenticated_client.get(url_for("assess.get_news_item", news_item_id="0"))

    assert response.status_code == 200

    tree = html.fromstring(response.text)
    form = tree.xpath('//form[@id="news-item-form"]')
    file_form = tree.xpath('//form[@hx-encoding="multipart/form-data"]')
    url_form = tree.xpath('//form[@id="news-item-create-from-url-form"]')
    url_parameters_dialog = tree.xpath('//dialog[@id="create_from_url_parameters_dialog"]')

    assert len(form) == 1
    assert form[0].get("hx-status:400") == "target:#notification-bar"
    assert form[0].get("hx-status:4xx") == "target:#notification-bar"
    assert form[0].get("hx-status:5xx") == "target:#notification-bar"
    assert len(file_form) == 1
    assert file_form[0].get("hx-status:400") == "target:#notification-bar"
    assert file_form[0].get("hx-status:4xx") == "target:#notification-bar"
    assert file_form[0].get("hx-status:5xx") == "target:#notification-bar"
    assert len(url_form) == 1
    assert url_form[0].get("hx-status:400") == "target:#notification-bar"
    assert url_form[0].get("hx-status:4xx") == "target:#notification-bar"
    assert url_form[0].get("hx-status:5xx") == "target:#notification-bar"
    assert url_form[0].xpath('.//input[@name="fetch_url"]')
    assert len(url_parameters_dialog) == 1
    assert url_parameters_dialog[0].xpath('.//*[@name="parameters[XPATH]"]')
    assert url_parameters_dialog[0].xpath('.//*[@name="parameters[BROWSER_MODE]"]')
    additional_headers_input = url_parameters_dialog[0].xpath('.//input[@name="parameters[ADDITIONAL_HEADERS]"]')
    assert len(additional_headers_input) == 1
    assert not url_parameters_dialog[0].xpath('.//textarea[@name="parameters[ADDITIONAL_HEADERS]"]')

    source_input = form[0].xpath('.//input[@name="source"]')
    assert len(source_input) == 1
    assert source_input[0].get("required") is None


def test_manual_news_item_validation_error_targets_notification_bar(authenticated_client):
    response = authenticated_client.post(
        url_for("assess.create_news_item"),
        data={
            "title": "Invalid language test",
            "link": "http://blubb.xxx",
            "language": "xx",
            "osint_source_id": "manual",
        },
    )

    assert response.status_code == 400
    assert response.headers["HX-Retarget"] == "#notification-bar"
    assert response.headers["HX-Reswap"] == "outerHTML"
    tree = html.fromstring(response.text)
    notification_bar = tree.xpath('//section[@id="notification-bar"]')[0]
    assert notification_bar.get("hx-swap-oob") is None
    assert "Invalid BCP 47 language tag" in notification_bar.text_content()


@pytest.mark.parametrize("can_edit", [True, False])
def test_story_edit_renders_news_item_tag_editor(app, authenticated_client, responses_mock, can_edit):
    story_payload = story_with_news_item_tags()
    story_payload["can_edit"] = can_edit
    mock_story_for_edit(responses_mock, story_payload)
    csrf_token = "csrf-token"
    authenticated_client.set_cookie(key=app.config["JWT_ACCESS_CSRF_COOKIE_NAME"], value=csrf_token)

    response = authenticated_client.get(url_for("assess.story_edit", story_id=story_payload["id"]))

    assert response.status_code == 200
    tree = html.fromstring(response.text)

    assert bool(tree.xpath('//*[@data-testid="edit-newsitem-tags"]')) is can_edit
    assert bool(tree.xpath('//*[@data-testid="news-item-tag-name-input"]')) is can_edit
    assert "keydown[canUseAssessShortcut(event, 'r')]" in response.text
    assert ("resetTags(); tagEditorOpen = false" in response.text) is can_edit
    assert not tree.xpath('//*[@data-testid="tag-name-input"]')
    assert not tree.xpath('//*[@data-testid="tag-value-input"]')

    edit_form = tree.xpath('//form[@id="story-edit-form"]')[0]
    assert bool(edit_form.xpath("./fieldset[@disabled]")) is not can_edit
    assert edit_form.get("method") == "post"
    assert edit_form.get("action") == url_for("assess.story_edit", story_id=story_payload["id"])
    assert edit_form.get("hx-post") == edit_form.get("action")
    assert edit_form.xpath('./input[@name="csrf_token"]/@value') == [csrf_token]


def test_story_edit_advanced_view_renders_sentiment_status_chip(authenticated_client, responses_mock):
    story_payload = story_with_news_item_tags()
    story_payload["attributes"] = [
        {"key": "cybersecurity", "value": "yes"},
        {"key": "sentiment", "value": "negative"},
    ]
    mock_story_for_edit(responses_mock, story_payload)

    response = authenticated_client.get(url_for("assess.story_edit", story_id=story_payload["id"], layout="advanced"))

    assert response.status_code == 200
    assert "Story status" in response.text
    assert "Cybersecurity · Yes" in response.text
    assert "Sentiment · Negative" in response.text


def test_story_edit_misp_auto_update_is_advanced_only(authenticated_client, responses_mock):
    story_payload = story_with_news_item_tags()
    story_payload["misp_auto_update"] = {"connector_id": "connector-1", "enabled": True}
    story_payload["attributes"] = [{"key": "has_proposals", "value": "https://misp.example/event-1"}]
    assert Story(**story_payload).misp_auto_update.connector_id == "connector-1"
    mock_story_for_edit(responses_mock, story_payload)

    simple_response = authenticated_client.get(url_for("assess.story_edit", story_id=story_payload["id"], layout="simple"))
    advanced_response = authenticated_client.get(url_for("assess.story_edit", story_id=story_payload["id"], layout="advanced"))

    assert "MISP auto-update" not in simple_response.text
    assert "MISP auto-update" in advanced_response.text
    assert "Blocked by MISP proposal" in advanced_response.text
    assert "misp_auto_update[connector_id]" not in advanced_response.text
    assert "You do not have permission to change MISP auto-update settings." in advanced_response.text
    assert not any(urlparse(call.request.url).path.endswith("/assess/connectors") for call in responses_mock.calls)


def test_story_action_response_refreshes_updated_story(authenticated_client, responses_mock, htmx_header):
    story_payload = story_with_news_item_tags()
    updated_story = story_with_news_item_tags()
    updated_story["summary"] = ""
    updated_story["news_items"][0]["content"] = "Updated replacement content"
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/filter-lists",
        json={"tags": [], "sources": [{"id": "manual", "name": "Updated source"}], "groups": []},
    )
    responses_mock.get(f"{Config.TARANIS_CORE_URL}/assess/bookmarks", json={"items": [], "total_count": 0})
    story_url = f"{Config.TARANIS_CORE_URL}/assess/stories/{story_payload['id']}"
    responses_mock.get(story_url, json=story_payload)
    responses_mock.patch(f"{Config.TARANIS_CORE_URL}/assess/stories/{story_payload['id']}", json={"story": updated_story})

    authenticated_client.get(url_for("assess.story_edit", story_id=story_payload["id"]))
    responses_mock.replace("GET", story_url, json=updated_story)
    response = authenticated_client.post(url_for("assess.story_update", story_id=story_payload["id"]), headers=htmx_header)

    assert "Updated replacement content" in response.text
    assert "Updated source" in response.text


def test_story_edit_misp_auto_update_controls_require_connector_access(authenticated_client, auth_user, responses_mock):
    story_payload = story_with_news_item_tags()
    mock_story_for_edit(responses_mock, story_payload)
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/connectors",
        json={"total_count": 1, "items": [{"id": "connector-1", "name": "MISP", "type": "misp_connector"}]},
    )

    connector_user = auth_user.model_copy(deep=True)
    connector_user.permissions = ["ASSESS_UPDATE", "CONNECTOR_USER_ACCESS"]
    add_user_to_cache(connector_user.model_dump(mode="json"))

    response = authenticated_client.get(url_for("assess.story_edit", story_id=story_payload["id"], layout="advanced"))

    assert 'name="misp_auto_update[connector_id]"' in response.text
    assert 'form="story-edit-form"' in response.text


def test_update_news_item_tags_posts_to_news_item_endpoint_and_rerenders_card(authenticated_client, responses_mock):
    story_payload = story_with_news_item_tags()
    responses_mock.put(
        f"{Config.TARANIS_CORE_URL}/assess/news-items/news-1/tags",
        json={"message": "Tags updated"},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_payload['id']}",
        json=story_payload,
    )

    response = authenticated_client.post(
        url_for("assess.update_news_item_tags", news_item_id="news-1"),
        data=MultiDict(
            [
                ("story_id", story_payload["id"]),
                ("tags[][name]", "incident"),
                ("tags[][tag_type]", "actor"),
            ]
        ),
    )

    assert response.status_code == 200
    tag_call = next(call for call in responses_mock.calls if urlparse(call.request.url).path.endswith("/assess/news-items/news-1/tags"))
    assert json.loads(tag_call.request.body) == [{"name": "incident", "tag_type": "actor"}]
    assert 'id="news-item-card-news-1"' in response.text


def test_update_news_item_tags_filters_blank_rows_before_core_request(authenticated_client, responses_mock):
    story_payload = story_with_news_item_tags()
    responses_mock.put(
        f"{Config.TARANIS_CORE_URL}/assess/news-items/news-1/tags",
        json={"message": "Tags updated"},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_payload['id']}",
        json=story_payload,
    )

    response = authenticated_client.post(
        url_for("assess.update_news_item_tags", news_item_id="news-1"),
        data=MultiDict(
            [
                ("story_id", story_payload["id"]),
                ("tags[][name]", ""),
                ("tags[][tag_type]", ""),
            ]
        ),
    )

    assert response.status_code == 200
    tag_call = next(call for call in responses_mock.calls if urlparse(call.request.url).path.endswith("/assess/news-items/news-1/tags"))
    assert json.loads(tag_call.request.body) == []


def test_update_news_item_tags_propagates_core_error_and_does_not_rerender_card(authenticated_client, responses_mock):
    story_payload = story_with_news_item_tags()
    responses_mock.put(
        f"{Config.TARANIS_CORE_URL}/assess/news-items/news-1/tags",
        status=400,
        json={"message": "Tags not updated"},
    )

    response = authenticated_client.post(
        url_for("assess.update_news_item_tags", news_item_id="news-1"),
        data=MultiDict(
            [
                ("story_id", story_payload["id"]),
                ("tags[][name]", "incident"),
                ("tags[][tag_type]", "actor"),
            ]
        ),
    )

    assert response.status_code == 400
    assert "Tags not updated" in response.text
    assert 'id="news-item-card-news-1"' not in response.text


def test_assess_filters_support_htmx_and_native_form_submission(authenticated_client, responses_mock):
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/filter-lists",
        json={
            "tags": ["incident"],
            "sources": [{"id": "source-1", "name": "Source 1"}],
            "groups": [{"id": "group-1", "name": "Group 1"}],
            "languages": ["en"],
        },
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories",
        json={"items": [story_with_news_item_tags()], "total_count": 21},
    )

    response = authenticated_client.get(
        url_for("assess.assess", search="pull"),
        headers={"HX-Target": "div#story-list"},
    )

    assert response.status_code == 200

    tree = html.fromstring(response.text)
    filter_form = tree.xpath('//form[@id="assess-sidebar"]')[0]
    search_input = tree.xpath('//input[@id="story_search"]')[0]
    clear_button = tree.xpath("//button[@title='Clear time filters']")[0]
    pagination = tree.xpath('//*[@id="story-pagination"]')[0]
    changed_by_select = filter_form.xpath('.//label[.//span[text()="Changed by"]]/select')[0]
    highlight_checkbox = tree.xpath('//input[@name="highlight"]')[0]
    compact_checkbox = tree.xpath('//input[@name="compact_view"]')[0]

    assert filter_form.get("method") == "get"
    assert filter_form.get("action") == url_for("assess.assess")
    assert filter_form.get("hx-trigger") == f"{expected_search_trigger('story_search')}, change"
    assert filter_form.get("hx-include") is None
    assert filter_form.get("hx-on:submit") == "event.preventDefault()"
    assert clear_button.get("hx-include") == "#assess-sidebar"
    assert filter_form.get("hx-target:inherited") == "#assess"
    assert filter_form.get("hx-swap:inherited") == "outerHTML"
    assert filter_form.get("hx-push-url:inherited") == "true"
    assert clear_button.get("hx-on::config:request") == (
        "ctx.request.body.delete('timefrom'); ctx.request.body.delete('timeto'); ctx.request.body.delete('range')"
    )
    assert pagination.get("hx-swap-oob") == "outerHTML:#story-pagination"
    assert [option.text for option in changed_by_select.xpath("./option")] == ["Any", "Me"]
    assert highlight_checkbox.get("hx-vals") == "js:{highlight: this.checked}"
    assert compact_checkbox.get("hx-vals") == "js:{compact_view: this.checked}"
    assert search_input.get("name") == "search"
    assert search_input.get("hx-get") is None
    assert search_input.get("hx-include") is None
    assert search_input.get("hx-trigger") is None
    assert filter_form.xpath('.//button[@type="submit" and @data-testid="assess-apply-filters"]')
    assert not filter_form.xpath('.//select[@name="source"]')
    assert not filter_form.xpath('.//select[@name="group"]')
    assert not filter_form.xpath('.//select[@name="tags"]')
    assert not filter_form.xpath('.//select[@name="language"]')


def test_story_read_action_replaces_story_card(app):
    story = SimpleNamespace(id="1", read=False, important=False, revision_count=0)

    with app.test_request_context():
        markup = render_template_string(
            '{% from "assess/story_actions.html" import story_actions %}{{ story_actions(story) }}',
            story=story,
        )

    tree = html.fromstring(f"<div>{markup}</div>")
    toggle_read = tree.xpath('//*[@data-testid="toggle-read"]')[0]
    toggle_read_form = toggle_read.getparent()

    assert toggle_read.tag == "button"
    assert toggle_read.get("type") == "submit"
    assert toggle_read_form.tag == "form"
    assert toggle_read_form.get("method") == "post"
    assert toggle_read_form.get("action") == url_for("assess.story", story_id=story.id)
    csrf_inputs = toggle_read_form.xpath('./input[@name="csrf_token"]')
    assert len(csrf_inputs) == 1
    assert csrf_inputs[0].get("type") == "hidden"
    assert toggle_read_form.xpath('./input[@name="read"]/@value') == ["true"]
    assert toggle_read.get("hx-target") == "#story-1"
    assert toggle_read.get("hx-select") == "#story-1"
    assert toggle_read.get("hx-swap") == "outerHTML"


def test_assess_bookmarks_bar_renders_first_six_ordered_collections(authenticated_client, responses_mock):
    story_payload = story_with_news_item_tags()
    story_payload["misp_auto_update"] = {"connector_id": "connector-1", "enabled": True}
    bookmark_payloads = [_bookmark_collection_payload(f"bookmark-{index}", f"Bookmark {index}", index, index - 1) for index in range(1, 8)]
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/filter-lists",
        json={"tags": [], "sources": [], "groups": [], "languages": []},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories",
        json={"items": [story_payload], "total_count": 1},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/bookmarks",
        json={"items": bookmark_payloads[:6], "total_count": 7},
    )

    response = authenticated_client.get(url_for("assess.assess"))

    assert response.status_code == 200
    assert "MISP auto-update" in response.text
    tree = html.fromstring(response.text)
    bar = tree.xpath('//*[@data-testid="assess-bookmarks-bar"]')[0]
    assert bar.xpath('.//*[@data-testid="assess-bookmark-bookmark-1"]')
    assert bar.xpath('.//*[@data-testid="assess-bookmark-bookmark-6"]')
    assert not bar.xpath('.//*[@data-testid="assess-bookmark-bookmark-7"]')
    all_bookmarks = bar.xpath('.//*[@data-testid="assess-all-bookmarks"]')[0]
    assert all_bookmarks.get("href") == url_for("assess.bookmarks")
    bookmark_request = next(call for call in responses_mock.calls if urlparse(call.request.url).path.endswith("/assess/bookmarks"))
    assert parse_qs(urlparse(bookmark_request.request.url).query) == {"limit": ["6"], "order": ["position_asc"]}


def test_assess_bookmarks_bar_uses_context_limit(app: Any) -> None:
    bookmarks = [SimpleNamespace(id=f"bookmark-{index}", name=f"Bookmark {index}", story_count=index) for index in range(1, 4)]

    with app.test_request_context():
        markup = render_template("assess/bookmarks_bar.html", bookmark_collections=bookmarks, assess_bookmark_bar_limit=2)

    tree = html.fromstring(markup)
    bar = tree.xpath('//*[@data-testid="assess-bookmarks-bar"]')[0]

    assert bar.xpath('.//*[@data-testid="assess-bookmark-bookmark-1"]')
    assert bar.xpath('.//*[@data-testid="assess-bookmark-bookmark-2"]')
    assert not bar.xpath('.//*[@data-testid="assess-bookmark-bookmark-3"]')


def test_source_filter_select_accepts_group_payloads_with_null_key():
    filter_lists = FilterLists(tags=[], sources=[], groups=[{"id": "group-1", "key": None, "name": "Group 1"}], languages=[])

    select_data = StoryView._build_source_filter_select(filter_lists, {"group": ["group-1"]})

    expected_item = {"value": "group-1", "label": "Group 1", "name": "group", "group": "Group"}
    assert expected_item in select_data["options"]
    assert expected_item in select_data["selected_items"]


def test_assess_selection_key_ignores_paging_params():
    selection_key = StoryView._build_assess_selection_key(
        {
            "offset": ["40"],
            "page": ["2"],
            "search": ["incident"],
            "sort": ["date_desc"],
            "tags": ["one", "two"],
        }
    )

    assert selection_key == "search=incident&sort=date_desc&tags=one&tags=two"


def test_assess_redirects_default_saved_filter_into_browser_url(authenticated_client, auth_user, responses_mock):
    saved_user = auth_user.model_copy(deep=True)
    saved_user.profile.assess_saved_filters = [
        AssessSavedFilter(
            id="filter-1",
            name="Shift queue",
            filters={
                "source": ["source-1"],
                "language": ["en"],
                "read": "true",
                "sort": "date_desc",
            },
            is_default=True,
        )
    ]
    add_user_to_cache(saved_user.model_dump(mode="json"))

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/filter-lists",
        json={
            "tags": [],
            "sources": [{"id": "source-1", "name": "Source 1"}],
            "groups": [],
            "languages": ["de", "en"],
        },
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories",
        json={"items": [], "total_count": 0},
    )

    response = authenticated_client.get(url_for("assess.assess"), follow_redirects=False)

    assert response.status_code == 302

    location = urlparse(response.headers["Location"])
    assert location.path == url_for("assess.assess")
    assert parse_qs(location.query) == {
        "source": ["source-1"],
        "language": ["en"],
        "read": ["true"],
        "sort": ["date_desc"],
    }

    followup = authenticated_client.get(url_for("assess.assess"), follow_redirects=True)

    assert followup.status_code == 200

    tree = html.fromstring(followup.text)
    read_select = tree.xpath('//select[@name="read"]')[0]
    source_filter = tree.xpath('//section[@data-filter-id="source-filter"]')[0]
    language_filter = tree.xpath('//section[@data-filter-id="language-filter"]')[0]
    sort_select = tree.xpath('//select[@name="sort"]')[0]

    assert read_select.xpath('./option[@value="true" and @selected]')
    assert source_filter.xpath('.//input[@type="search" and @aria-label="Select sources"]')
    assert "source-1" in source_filter.get("x-data")
    assert '"name": "source"' in source_filter.get("x-data")
    assert language_filter.xpath('.//input[@type="search" and @aria-label="Select languages"]')
    assert '"value": "en"' in language_filter.get("x-data")
    assert '"name": "language"' in language_filter.get("x-data")
    assert sort_select.xpath('./option[@value="date_desc" and @selected]')

    story_request = next(call for call in responses_mock.calls if urlparse(call.request.url).path.endswith("/assess/stories"))
    parsed_query = parse_qs(urlparse(story_request.request.url).query)

    assert parsed_query["source"] == ["source-1"]
    assert parsed_query["language"] == ["en"]
    assert parsed_query["read"] == ["true"]
    assert parsed_query["sort"] == ["date_desc"]


def test_assess_save_saved_filter_posts_selected_filters_to_profile(authenticated_client, responses_mock):
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/users",
        json={
            "id": "user-1",
            "username": "admin",
            "name": "Arthur Dent",
            "profile": {"assess_saved_filters": []},
            "permissions": ["ASSESS_ACCESS"],
            "roles": [{"id": "role-1", "name": "Admin"}],
        },
    )
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/users/profile",
        json={
            "message": "Profile updated",
            "id": "user-1",
            "user_profile": {"assess_saved_filters": []},
        },
    )

    response = authenticated_client.post(
        url_for("assess.save_saved_filter"),
        data=MultiDict(
            [
                ("name", "Shift queue"),
                ("is_default", "true"),
                ("source", "source-1"),
                ("group", "group-1"),
                ("tags", "alpha"),
                ("tags", "beta"),
                ("language", "en"),
                ("language", "de"),
                ("read", "true"),
                ("important", "false"),
                ("sort", "date_desc"),
                ("range", "week"),
                ("timefrom", "2026-05-01T10:00"),
                ("timeto", "2026-05-02T11:00"),
            ]
        ),
    )

    assert response.status_code == 200
    assert "Assess filter saved." in response.text
    assert "Shift queue" in response.text

    payload = _profile_update_payload(responses_mock)
    assert "assess_default_filters" not in payload
    assert len(payload["assess_saved_filters"]) == 1
    saved_filter = payload["assess_saved_filters"][0]
    assert saved_filter["id"]
    assert UUID(saved_filter["id"]).version == 7
    assert saved_filter == {
        "id": saved_filter["id"],
        "name": "Shift queue",
        "filters": {
            "source": ["source-1"],
            "group": ["group-1"],
            "tags": ["alpha", "beta"],
            "language": ["en", "de"],
            "read": "true",
            "important": "false",
            "sort": "date_desc",
            "range": "week",
            "timefrom": "2026-05-01T10:00:00",
            "timeto": "2026-05-02T11:00:00",
        },
        "is_default": True,
    }


def test_assess_save_saved_filter_updates_existing_name(authenticated_client: Any, auth_user: Any, responses_mock: Any) -> None:
    _cache_saved_filters(
        auth_user,
        [
            AssessSavedFilter(id="filter-1", name="Shift queue", filters={"search": "old"}, is_default=False),
        ],
    )
    _mock_profile_update(responses_mock)

    response = authenticated_client.post(
        url_for("assess.save_saved_filter"),
        data=MultiDict([("name", "Shift queue"), ("search", "incident"), ("tags", "alpha"), ("sort", "date_desc")]),
    )

    assert response.status_code == 200
    assert "Assess filter updated." in response.text
    assert _profile_update_payload(responses_mock)["assess_saved_filters"] == [
        {
            "id": "filter-1",
            "name": "Shift queue",
            "filters": {"search": "incident", "tags": ["alpha"], "sort": "date_desc"},
            "is_default": False,
        }
    ]


def test_assess_save_saved_filter_rejects_duplicate_filters(authenticated_client: Any, auth_user: Any, responses_mock: Any) -> None:
    _cache_saved_filters(
        auth_user,
        [
            AssessSavedFilter(
                id="filter-1",
                name="Existing",
                filters={"search": "incident", "tags": ["alpha", "beta"], "sort": "date_desc"},
                is_default=False,
            ),
        ],
    )

    response = authenticated_client.post(
        url_for("assess.save_saved_filter"),
        data=MultiDict([("name", "Different"), ("search", "incident"), ("tags", "beta"), ("tags", "alpha"), ("sort", "DATE_DESC")]),
    )

    assert response.status_code == 400
    assert "These filters are already saved as Existing." in response.text
    assert not any(urlparse(call.request.url).path.endswith("/users/profile") for call in responses_mock.calls)


def test_assess_delete_saved_filter_persists_remaining_filters(authenticated_client: Any, auth_user: Any, responses_mock: Any) -> None:
    _cache_saved_filters(
        auth_user,
        [
            AssessSavedFilter(id="filter-1", name="Old default", filters={"search": "old"}, is_default=True),
            AssessSavedFilter(id="filter-2", name="Keep", filters={"search": "keep"}, is_default=False),
        ],
    )
    _mock_profile_update(responses_mock)

    with authenticated_client.session_transaction() as session:
        session[ASSESS_SAVED_FILTER_SESSION_KEY] = True

    response = authenticated_client.delete(url_for("assess.delete_saved_filter", filter_id="filter-1"))

    assert response.status_code == 200
    assert "Assess filter deleted." in response.text
    assert "Old default" not in response.text
    assert "Keep" in response.text
    assert _profile_update_payload(responses_mock)["assess_saved_filters"] == [
        {"id": "filter-2", "name": "Keep", "filters": {"search": "keep"}, "is_default": False}
    ]

    with authenticated_client.session_transaction() as session:
        assert session[ASSESS_SAVED_FILTER_SESSION_KEY] is False


def test_assess_set_saved_filter_default_does_not_update_session_on_profile_error(authenticated_client, auth_user, responses_mock):
    _cache_saved_filters(
        auth_user,
        [
            AssessSavedFilter(id="filter-1", name="Shift queue", filters={"search": "old"}, is_default=False),
        ],
    )
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/users/profile",
        json={"error": "Profile update failed"},
        status=400,
    )

    with authenticated_client.session_transaction() as session:
        session[ASSESS_SAVED_FILTER_SESSION_KEY] = True

    response = authenticated_client.post(url_for("assess.set_saved_filter_default", filter_id="filter-1"))

    assert response.status_code == 400

    with authenticated_client.session_transaction() as session:
        assert session[ASSESS_SAVED_FILTER_SESSION_KEY] is True


def test_assess_saved_filters_dialog_uses_submit_button(authenticated_client):
    response = authenticated_client.get(url_for("assess.saved_filters"))
    tree = html.fromstring(response.text)

    form = tree.xpath('//form[@id="saved-filter-form"]')[0]
    button = form.xpath('.//button[@type="submit"]')[0]
    disabled_reason = tree.xpath('//*[@id="saved-filter-disabled-reason"]')[0]

    assert form.get("method") == "post"
    assert form.get("action") == url_for("assess.save_saved_filter")
    assert form.get("hx-status:400") == "target:#assess_saved_filters_dialog"
    assert form.get("hx-status:4xx") == "target:#assess_saved_filters_dialog"
    assert form.get("hx-status:5xx") == "target:#assess_saved_filters_dialog"
    assert button.get("type") == "submit"
    assert button.get("disabled") == "disabled"
    assert button.get("aria-describedby") == "saved-filter-disabled-reason"
    assert disabled_reason.text_content() == "Apply at least one Assess filter before saving."


def test_assess_saved_filter_update_button_reuses_save_endpoint(authenticated_client: Any, auth_user: Any) -> None:
    _cache_saved_filters(
        auth_user,
        [
            AssessSavedFilter(id="filter-1", name="Shift queue", filters={"search": "old"}, is_default=False),
        ],
    )

    response = authenticated_client.get(url_for("assess.saved_filters", search="incident"))
    tree = html.fromstring(response.text)
    update_button = tree.xpath('//button[normalize-space()="Update"]')[0]
    update_values = update_button.get("hx-vals")

    assert update_button.get("hx-post") == url_for("assess.save_saved_filter")
    assert update_values is not None
    assert json.loads(update_values) == {"name": "Shift queue"}
    assert update_button.get("disabled") is None


def test_table_search_bar_uses_form_level_search_trigger(app):
    with app.test_request_context("/frontend/admin/osint-sources?search=alpha"):
        markup = render_template_string(
            '{% from "macros/table.html" import table_search_bar %}{{ table_search_bar("osint_table", "/frontend/admin/osint-sources") }}'
        )

    tree = html.fromstring(markup)
    form = tree.xpath("//form")[0]
    search_input = tree.xpath('//input[@id="osint_table-search"]')[0]

    assert form.get("hx-trigger") == "submit, " + expected_search_trigger("osint_table-search")
    assert form.get("method") == "get"
    assert form.get("action") == "/frontend/admin/osint-sources"
    assert form.get("hx-on:submit") is None
    assert search_input.get("hx-trigger") is None


def test_create_news_item_from_url_posts_simple_web_collector_payload(authenticated_client, responses_mock):
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/assess/news-items/fetch",
        json={"story_ids": ["story-1"], "news_item_ids": ["news-1"], "message": "1 News items added successfully"},
    )

    response = authenticated_client.post(
        url_for("assess.create_news_item"),
        data={
            "fetch_url": "https://example.com/story",
            "parameters[XPATH]": "//article",
            "parameters[TLP_LEVEL]": "green",
            "parameters[BROWSER_MODE]": "true",
            "parameters[DIGEST_SPLITTING]": "false",
            "parameters[DIGEST_SPLITTING_LIMIT]": "30",
        },
    )

    assert response.status_code == 200
    assert response.headers["HX-Redirect"] == url_for("assess.story_edit", story_id="story-1")
    assert responses_mock.calls[0].request.url == f"{Config.TARANIS_CORE_URL}/assess/news-items/fetch"
    assert responses_mock.calls[0].request.body
    assert json.loads(responses_mock.calls[0].request.body) == {
        "id": "manual",
        "type": "simple_web_collector",
        "parameters": {
            "WEB_URL": "https://example.com/story",
            "XPATH": "//article",
            "TLP_LEVEL": "green",
            "BROWSER_MODE": "true",
            "DIGEST_SPLITTING": "false",
            "DIGEST_SPLITTING_LIMIT": "30",
        },
    }


def test_story_share_page_loads_connectors_from_assess_endpoint(authenticated_client_basic, responses_mock):
    story_id = "story-1"
    connector_id = "connector-1"

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_id}",
        json={"id": story_id, "title": "Shared Story", "links": ["https://example.com/story"]},
    )
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/connectors",
        json={
            "total_count": 1,
            "items": [
                {
                    "id": connector_id,
                    "name": "MISP Connector",
                    "description": "User-visible connector",
                    "type": "misp_connector",
                }
            ],
        },
    )

    response = authenticated_client_basic.get(url_for("assess.share_story", story_id=story_id))

    assert response.status_code == 200
    assert connector_id in response.text
    assert "MISP Connector" in response.text
    tree = html.fromstring(response.text)
    share_form = tree.xpath('//form[@action="/story/sharing"]')[0]
    assert share_form.get("method") == "post"
    assert share_form.xpath('./input[@name="story_ids"]/@value') == [story_id]
    assert share_form.xpath('.//select[@id="connector"]/option[1]/@value') == [""]
    assert all(call.request.url != f"{Config.TARANIS_CORE_URL}/config/connectors" for call in responses_mock.calls)


def test_story_share_redirects_to_story_without_htmx(authenticated_client_basic, responses_mock):
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/assess/story/connector-1/share",
        json={"message": "Story shared"},
    )

    response = authenticated_client_basic.post(
        url_for("assess.submit_share_story"),
        data={"story_ids": "story-1", "connector": "connector-1"},
    )

    assert response.status_code == 302
    assert response.headers["Location"] == url_for("assess.story", story_id="story-1")
    assert json.loads(responses_mock.calls[0].request.body) == {"story_ids": ["story-1"]}


def test_story_share_validation_preserves_story_ids_without_htmx(authenticated_client_basic):
    response = authenticated_client_basic.post(
        url_for("assess.submit_share_story"),
        data=MultiDict([("story_ids", "story-1"), ("story_ids", "story-2")]),
    )

    assert response.status_code == 302
    location = urlparse(response.headers["Location"])
    assert location.path == url_for("assess.share_story")
    assert parse_qs(location.query) == {"story_ids": ["story-1", "story-2"]}
    with authenticated_client_basic.session_transaction() as session:
        assert session["_flashes"] == [("error", "No connector selected for sharing.")]


def test_story_share_failure_redirects_to_story_without_htmx(authenticated_client_basic, responses_mock):
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/assess/story/connector-1/share",
        body=RuntimeError("sharing failed"),
    )

    response = authenticated_client_basic.post(
        url_for("assess.submit_share_story"),
        data={"story_ids": "story-1", "connector": "connector-1"},
    )

    assert response.status_code == 302
    assert response.headers["Location"] == url_for("assess.story", story_id="story-1")
    with authenticated_client_basic.session_transaction() as session:
        assert session["_flashes"] == [("error", "Failed to share stories with connector.")]


def test_story_report_page_lists_reports_without_htmx(authenticated_client_basic, responses_mock):
    story_id = "story-1"
    report_id = "report-1"

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/analyze/report-items",
        json={"total_count": 1, "items": [{"id": report_id, "title": "Weekly report", "report_item_type_id": "report-type-1"}]},
    )

    response = authenticated_client_basic.get(url_for("assess.report_story", story_ids=story_id))

    assert response.status_code == 200
    tree = html.fromstring(response.text)
    report_form = tree.xpath('//form[@action="/story/report"]')[0]
    assert report_form.get("method") == "post"
    assert report_form.xpath('./input[@name="story_ids"]/@value') == [story_id]
    assert report_form.xpath('.//option[@value="report-1"]/text()') == ["Weekly report"]


def test_story_report_dialog_closes_only_after_success(authenticated_client_basic, responses_mock, htmx_header):
    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/analyze/report-items",
        json={"total_count": 1, "items": [{"id": "report-1", "title": "Weekly report", "report_item_type_id": "report-type-1"}]},
    )

    response = authenticated_client_basic.get(
        url_for("assess.report_story", story_ids="story-1"),
        headers=htmx_header,
    )

    button = html.fromstring(response.text).xpath('//*[@data-testid="share-to-report-dialog-button"]')[0]
    assert button.get("hx-on::after:request") == (
        "if (ctx.response.status < 400) document.getElementById('share_story_to_report_dialog')?.close()"
    )
    assert [button.get(f"hx-status:{status}") for status in ("400", "4xx", "5xx")] == [
        "target:#notification-bar",
        "target:#notification-bar",
        "target:#notification-bar",
    ]


def test_story_dialog_actions_return_core_failure_status(authenticated_client_basic, responses_mock, htmx_header):
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/analyze/report-items/report-1/stories",
        json={"error": "Unable to add stories"},
        status=422,
    )
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/assess/stories/group",
        json={"error": "Unable to cluster stories"},
        status=409,
    )

    report_response = authenticated_client_basic.post(
        url_for("assess.submit_report_story"),
        headers=htmx_header,
        data={"story_ids": "story-1", "report": "report-1"},
    )
    cluster_response = authenticated_client_basic.post(
        url_for("assess.submit_cluster_story"),
        headers=htmx_header,
        data=MultiDict([("story_ids", "story-1"), ("story_ids", "story-2")]),
    )

    assert report_response.status_code == 422
    assert "Unable to add stories" in report_response.text
    assert cluster_response.status_code == 409
    assert "Unable to cluster stories" in cluster_response.text


def test_add_story_to_report_redirects_to_story_without_htmx(authenticated_client_basic, responses_mock):
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/analyze/report-items/report-1/stories",
        json={"message": "Story added to report"},
    )

    response = authenticated_client_basic.post(
        url_for("assess.submit_report_story"),
        data={"story_ids": "story-1", "report": "report-1"},
    )

    assert response.status_code == 302
    assert response.headers["Location"] == url_for("assess.story", story_id="story-1")
    assert json.loads(responses_mock.calls[0].request.body) == ["story-1"]


def test_add_story_to_report_redirects_to_bookmark_without_htmx(authenticated_client_basic, responses_mock):
    responses_mock.post(
        f"{Config.TARANIS_CORE_URL}/analyze/report-items/report-1/stories",
        json={"message": "Story added to report"},
    )

    response = authenticated_client_basic.post(
        url_for("assess.submit_report_story", bookmark_id="bookmark-1"),
        data={"story_ids": "story-1", "report": "report-1"},
    )

    assert response.status_code == 302
    assert response.headers["Location"] == url_for("assess.bookmark", bookmark_id="bookmark-1")


def test_add_story_to_report_rejects_missing_story_ids_without_htmx(authenticated_client_basic, responses_mock):
    response = authenticated_client_basic.post(
        url_for("assess.submit_report_story"),
        data={"report": "report-1"},
    )

    assert response.status_code == 302
    assert response.headers["Location"] == url_for("assess.assess")
    assert not responses_mock.calls
    with authenticated_client_basic.session_transaction() as session:
        assert session["_flashes"] == [("error", "No stories selected for reporting.")]


def test_add_story_to_report_rejects_missing_report_without_htmx(authenticated_client_basic, responses_mock):
    response = authenticated_client_basic.post(
        url_for("assess.submit_report_story", bookmark_id="bookmark-1"),
        data=MultiDict([("story_ids", "story-1"), ("story_ids", "story-2")]),
    )

    assert response.status_code == 302
    location = urlparse(response.headers["Location"])
    assert location.path == url_for("assess.report_story")
    assert parse_qs(location.query) == {"bookmark_id": ["bookmark-1"], "story_ids": ["story-1", "story-2"]}
    assert not responses_mock.calls
    with authenticated_client_basic.session_transaction() as session:
        assert session["_flashes"] == [("error", "No report selected.")]


def test_story_sharing_dialog_still_renders_when_connector_loading_fails(
    authenticated_client_basic, htmx_header, monkeypatch, responses_mock
):
    story_id = "story-1"

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_id}",
        json={"id": story_id, "title": "Shared Story", "links": ["https://example.com/story"]},
    )

    def raise_connector_loading_error(*args, **kwargs):
        raise RuntimeError("permission lookup failed")

    monkeypatch.setattr("frontend.views.story_views.DataPersistenceLayer.get_objects", raise_connector_loading_error)

    response = authenticated_client_basic.get(url_for("assess.share_story", story_id=story_id), headers=htmx_header)

    assert response.status_code == 200
    assert "Share Stories" in response.text
    assert "Shared Story" not in response.text
    assert "Connector sharing is not available for your account" in response.text
    assert "Share via email" in response.text
    assert "Export to JSON" in response.text

    tree = html.fromstring(response.text)
    connector_select = tree.xpath('//select[@id="connector"]')
    assert len(connector_select) == 0


def test_story_sharing_dialog_still_renders_when_connector_loading_is_forbidden(
    authenticated_client_basic, htmx_header, monkeypatch, responses_mock
):
    story_id = "story-1"

    responses_mock.get(
        f"{Config.TARANIS_CORE_URL}/assess/stories/{story_id}",
        json={"id": story_id, "title": "Shared Story", "links": ["https://example.com/story"]},
    )

    def raise_connector_loading_error(*args, **kwargs):
        raise Forbidden("connector access denied")

    monkeypatch.setattr("frontend.views.story_views.DataPersistenceLayer.get_objects", raise_connector_loading_error)

    response = authenticated_client_basic.get(url_for("assess.share_story", story_id=story_id), headers=htmx_header)

    assert response.status_code == 200
    assert "Share Stories" in response.text
    assert "Connector sharing is not available for your account" in response.text
    assert "Share via email" in response.text
    assert "Export to JSON" in response.text

    tree = html.fromstring(response.text)
    connector_select = tree.xpath('//select[@id="connector"]')
    assert len(connector_select) == 0


def test_handle_news_item_response_returns_notification_and_content(app, monkeypatch):
    monkeypatch.setattr(StoryView, "get_notification_from_response", lambda response, oob=True: "notification")

    response = SimpleNamespace(ok=True, json=lambda: {"story_id": "story-1"})

    with app.test_request_context("/"):
        result = StoryView._handle_news_item_response(
            response,
            content_builder=lambda _story_id: "<div>content</div>",
            redirect_on_story=False,
        )

    assert result.status_code == 200  # type: ignore
    assert result.get_data(as_text=True) == "notification<div>content</div>"  # type: ignore
