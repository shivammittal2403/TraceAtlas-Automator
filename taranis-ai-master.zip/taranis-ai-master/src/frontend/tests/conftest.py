import os
import subprocess
import sys
from pathlib import Path
from typing import cast

import pytest
from dotenv import load_dotenv
from models.user import ProfileSettings, UserProfile

from tests.core_requests import CoreRequestClient
from tests.external_e2e import (
    allow_requests_passthru,
    configure_external_frontend_environment,
    external_auth_credentials,
    external_core_api_url,
    login_to_core,
)
from tests.support.cache_backend import InMemoryRedisClient


base_dir = os.path.dirname(os.path.abspath(__file__))
env_file = os.path.join(base_dir, ".env")
current_path = os.getcwd()

if not current_path.endswith("src/frontend"):
    # Change to git_root/src/frontend instead of skipping
    try:
        git_root = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except Exception:
        git_root = None

    if git_root:
        frontend_path = os.path.join(git_root, "src", "frontend")
        if os.path.isdir(frontend_path):
            os.chdir(frontend_path)
        else:
            pytest.skip(f"Expected directory does not exist: {frontend_path}")
    else:
        pytest.skip("Unable to locate git root to change into src/frontend")

load_dotenv(dotenv_path=env_file, override=True)

# Ensure local packages (models, frontend, etc.) are importable during tests
repo_root = Path(base_dir).resolve().parents[2]
for candidate in [repo_root / "src" / "models", repo_root / "src", repo_root]:
    candidate_str = str(candidate)
    if candidate.exists() and candidate_str not in sys.path:
        sys.path.insert(0, candidate_str)


def _create_access_token(app, user):
    from flask_jwt_extended import create_access_token

    with app.app_context():
        return create_access_token(identity=user)


def _build_access_token_response(app, user):
    from flask import jsonify
    from flask_jwt_extended import create_access_token, set_access_cookies

    with app.app_context():
        access_token = create_access_token(identity=user)
        response = jsonify({"access_token": access_token})
        response.status_code = 200
        set_access_cookies(response, access_token)
        return response


def _build_authenticated_client(app, access_token):
    client = app.test_client()
    client.set_cookie(
        key=app.config["JWT_ACCESS_COOKIE_NAME"],
        value=access_token,
    )
    return client


@pytest.fixture(scope="session")
def app():
    from frontend.__init__ import create_app

    external_config = configure_external_frontend_environment()

    app = create_app(
        {
            "TESTING": True,
            "DEBUG": True,
            "SERVER_NAME": "localhost",
        }
    )

    if external_config:
        external_server_name, external_application_root, external_scheme = external_config
        app.config.update(
            {
                "SERVER_NAME": external_server_name,
                "APPLICATION_ROOT": external_application_root,
                "PREFERRED_URL_SCHEME": external_scheme,
            }
        )

    yield app


@pytest.fixture(scope="session")
def auth_user():
    return UserProfile(
        id="1",
        username="admin",
        name="Arthur Dent",
        organization={"id": "1", "name": "Galactic Government"},
        permissions=["ADMIN_OPERATIONS", "ASSESS_ACCESS", "ASSESS_UPDATE", "ANALYZE_ACCESS", "PUBLISH_ACCESS", "ASSETS_ACCESS"],
        profile=ProfileSettings(),
        roles=[{"id": "1", "name": "Admin"}],
    )


@pytest.fixture(scope="session")
def auth_user_basic():
    return UserProfile(
        id="2",
        username="user",
        name="Ford Prefect",
        organization={"id": "1", "name": "Galactic Government"},
        permissions=["ASSESS_ACCESS", "ASSESS_UPDATE", "ANALYZE_ACCESS", "PUBLISH_ACCESS", "ASSETS_ACCESS"],
        profile=ProfileSettings(),
        roles=[{"id": "2", "name": "User"}],
    )


@pytest.fixture(scope="session")
def access_token(app, auth_user):
    return _create_access_token(app, auth_user)


@pytest.fixture(scope="session")
def core_request_access_token(app, auth_user):
    if external_core_url := external_core_api_url():
        username, password = external_auth_credentials()
        token = login_to_core(external_core_url, username, password).json().get("access_token")
        if not token:
            raise RuntimeError("External core login response does not contain 'access_token'")
        return token
    return _create_access_token(app, auth_user)


@pytest.fixture(scope="session")
def access_token_basic(app, auth_user_basic):
    return _create_access_token(app, auth_user_basic)


@pytest.fixture(scope="session")
def api_header():
    api_key = os.getenv("TARANIS_E2E_EXTERNAL_API_KEY", "").strip() or os.getenv("API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("Missing API key for e2e tests")
    return {"Authorization": f"Bearer {api_key}", "Content-type": "application/json"}


@pytest.fixture(scope="session")
def core_request_client(run_core, core_request_access_token):
    allow_requests_passthru(run_core)
    client = CoreRequestClient(base_url=run_core, access_token=core_request_access_token)
    yield client
    client.session.close()


@pytest.fixture
def access_token_response(app, auth_user, run_core):
    return _build_access_token_response(app, auth_user)


@pytest.fixture
def access_token_response_basic(app, auth_user_basic, run_core):
    return _build_access_token_response(app, auth_user_basic)


@pytest.fixture
def test_cache_backend(app):
    from redis import Redis

    from frontend.cache import cache

    backend = InMemoryRedisClient()
    original_client = cache.client
    original_prefix = cache.key_prefix
    original_timeout = cache.default_timeout
    cache.client = cast(Redis, backend)
    cache.key_prefix = app.config["CACHE_KEY_PREFIX"]
    cache.default_timeout = app.config["CACHE_DEFAULT_TIMEOUT"]
    try:
        yield backend
    finally:
        cache.client = original_client
        cache.key_prefix = original_prefix
        cache.default_timeout = original_timeout


def _seed_authenticated_user_cache(user: UserProfile) -> None:
    from frontend.cache import add_user_to_cache

    add_user_to_cache(user.model_dump(mode="json"))


@pytest.fixture
def authenticated_client(app, access_token, auth_user, test_cache_backend):
    _seed_authenticated_user_cache(auth_user)
    return _build_authenticated_client(app, access_token)


@pytest.fixture
def authenticated_client_basic(app, access_token_basic, auth_user_basic, test_cache_backend):
    _seed_authenticated_user_cache(auth_user_basic)
    return _build_authenticated_client(app, access_token_basic)


@pytest.fixture(scope="session")
def client(app):
    return app.test_client()


@pytest.fixture
def htmx_header():
    return {"HX-Request": True}


def pytest_addoption(parser):
    group = parser.getgroup("e2e")
    group.addoption("--e2e-ci", action="store_const", const="e2e_ci", default=None, help="run e2e tests for CI")
    group.addoption("--e2e-timeout", action="store", default="5000", help="milliseconds to wait for e2e tests")
    group.addoption("--highlight-delay", action="store", default="0", help="delay for highlighting elements in e2e tests")
    group.addoption("--record-video", action="store_true", default=False, help="create screenshots and record video")
    group.addoption("--e2e-admin", action="store_true", default=False, help="run e2e tests of admin interface")
    group.addoption("--e2e-user", action="store_true", default=False, help="run e2e tests of user interface")
    group.addoption("--e2e-user-workflow", action="store_true", default=False, help="run e2e tests for user workflow")
    group.addoption(
        "--e2e-trace",
        action="store_true",
        default=False,
        help="record unique Playwright traces for stack-backed browser tests",
    )

    group.addoption(
        "--fail-on-console",
        action="store",
        default="error,assert",
        help="Console/Page event types that should fail the test.",
    )
    group.addoption(
        "--console-allow",
        action="append",
        default=[],
        help="Regex(es) of console messages to ignore (can be passed multiple times).",
    )
    group.addoption(
        "--warn-on-console",
        action="store",
        default="warning,pageerror",
        help="Console types to forward as pytest warnings (comma-separated).",
    )


def _is_vscode(config) -> bool:
    """
    Return True when: pytest was invoked with:
       -k EXP
       -  was started from from Zed or VSCode
    """

    k_expr = None
    try:
        k_expr = config.getoption("-k")
    except Exception:
        k_expr = None
    if k_expr:
        return True
    # Detect Zed editor
    if os.getenv("ZED_TERM") or os.getenv("TERM_PROGRAM") == "Zed":
        return True
    # VS Code plugin loaded by the VS Code Python extension
    if config.pluginmanager.hasplugin("vscode_pytest"):
        return True
    # Fallbacks (sometimes present when launched from VS Code)
    return bool(os.getenv("VSCODE_PID") or os.getenv("VSCODE_CWD"))


def skip_tests(items, keyword, reason):
    skip_marker = pytest.mark.skip(reason=reason)
    for item in items:
        if keyword not in item.keywords:
            item.add_marker(skip_marker)


def pytest_collection_modifyitems(config, items):
    config.option.start_live_server = False

    if _is_vscode(config):
        config.option.headed = False
        return

    options = {
        "--e2e-ci": ("e2e_ci", "skip for --e2e-ci test"),
        "--e2e-admin": ("e2e_admin", "need --e2e-admin option to run tests marked with e2e_admin"),
        "--e2e-user": ("e2e_user", "need --e2e-user option to run tests marked with e2e_user"),
        "--e2e-user-workflow": ("e2e_user_workflow", "need --e2e-user-workflow option to run tests marked with e2e_user_workflow"),
    }

    config.option.headed = True
    for option, (keyword, reason) in options.items():
        if config.getoption(option):
            if option == "--e2e-ci":
                config.option.headed = False
            skip_tests(items, keyword, reason)
            return

    skip_all = pytest.mark.skip(reason="need --e2e-ci or --e2e-admin option to run these tests")
    for item in items:
        if any(keyword in item.keywords for keyword, _ in options.values()):
            item.add_marker(skip_all)
