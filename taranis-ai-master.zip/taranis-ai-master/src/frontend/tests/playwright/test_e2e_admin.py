import json
import uuid
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

import pytest
from base_e2e_test import BaseE2ETest
from flask import url_for
from htmx_helpers import with_htmx_wait
from playwright.sync_api import Page, expect

from tests.external_e2e import allow_requests_passthru
from tests.playwright.notification_helpers import dismiss_notifications


DASHBOARD_BASELINE_QUEUE_TEXT_FRAGMENT = "There are"
DASHBOARD_HEALTH_SERVICES = {
    "Database": "up",
    "Pre-seeded": "up",
    "Redis": "up",
    "Workers": "up",
}


def reset_admin_onboarding_tours(page: Page):
    page.goto(url_for("user.settings", _external=True))
    with expect_profile_post_response(page) as response_info:
        page.get_by_test_id("user-reset-onboarding-tours").click()
    assert response_info.value.ok, f"Failed to reset onboarding tours: {response_info.value.status}"
    expect(page.get_by_test_id("user-reset-onboarding-tours")).to_be_visible()


def expect_profile_post_response(page: Page):
    profile_url = url_for("user.settings", _external=True)
    return page.expect_response(lambda response: response.url == profile_url and response.request.method == "POST")


def expect_driver_step(page: Page, title: str):
    popover = page.locator(".driver-popover")
    expect(popover).to_be_visible()
    expect(popover).to_contain_text(title)


def go_to_next_driver_step(page: Page, title: str):
    page.get_by_role("button", name="Next").click()
    expect_driver_step(page, title)


def start_admin_onboarding_from_dashboard(page: Page):
    expect(page.locator(".driver-popover")).not_to_be_visible()
    expect(page.locator("#onboarding-root")).to_have_count(1)
    page.get_by_role("link", name="Admin Dashboard").click()
    expect_driver_step(page, "Admin Dashboard")


def remove_tz(date_time: str) -> str:
    dt = datetime.fromisoformat(date_time)
    if dt.tzinfo is not None and dt.utcoffset() is not None:
        dt = dt.astimezone(UTC)
    dt = dt.replace(tzinfo=None)
    return dt.isoformat()


@pytest.mark.e2e_admin
@pytest.mark.e2e_ci
@pytest.mark.usefixtures("e2e_ci")
class TestEndToEndAdmin(BaseE2ETest):
    """End-to-end tests for the Taranis AI admin interface."""

    def test_login(self, taranis_frontend: Page):
        page = taranis_frontend
        page.context.clear_cookies()
        self.login_with_credentials(page)

    def test_admin_welcome_onboarding_tour_complete_now(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page
        reset_admin_onboarding_tours(page)
        page.goto(url_for("admin.dashboard", _external=True))

        start_admin_onboarding_from_dashboard(page)
        go_to_next_driver_step(page, "OSINT Source")
        go_to_next_driver_step(page, "OSINT Source table")
        go_to_next_driver_step(page, "Bot")
        go_to_next_driver_step(page, "Bot table")
        go_to_next_driver_step(page, "Scheduler")
        go_to_next_driver_step(page, "Scheduled jobs")
        go_to_next_driver_step(page, "Role")
        go_to_next_driver_step(page, "Role table")
        go_to_next_driver_step(page, "User")
        go_to_next_driver_step(page, "User table")
        go_to_next_driver_step(page, "Welcome tour complete")

        with expect_profile_post_response(page) as response_info:
            page.get_by_role("button", name="Complete now").click()

        assert response_info.value.ok, f"Expected 2xx status, but got {response_info.value.status}"
        expect(page.locator(".driver-popover")).not_to_be_visible()

        page.reload()
        expect(page.locator(".driver-popover")).not_to_be_visible()

    def test_admin_advanced_onboarding_tour(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page
        reset_admin_onboarding_tours(page)
        page.goto(url_for("admin.dashboard", _external=True))

        start_admin_onboarding_from_dashboard(page)
        go_to_next_driver_step(page, "OSINT Source")
        go_to_next_driver_step(page, "OSINT Source table")
        go_to_next_driver_step(page, "Bot")
        go_to_next_driver_step(page, "Bot table")
        go_to_next_driver_step(page, "Scheduler")
        go_to_next_driver_step(page, "Scheduled jobs")
        go_to_next_driver_step(page, "Role")
        go_to_next_driver_step(page, "Role table")
        go_to_next_driver_step(page, "User")
        go_to_next_driver_step(page, "User table")
        go_to_next_driver_step(page, "Welcome tour complete")

        with expect_profile_post_response(page) as response_info:
            page.get_by_test_id("admin-onboarding-advanced-tour").click()

        assert response_info.value.ok, f"Expected 2xx status, but got {response_info.value.status}"
        expect_driver_step(page, "Report Item Type")
        go_to_next_driver_step(page, "Report item type table")
        go_to_next_driver_step(page, "Template")
        go_to_next_driver_step(page, "Template table")
        go_to_next_driver_step(page, "Product Type")
        go_to_next_driver_step(page, "Product type table")
        go_to_next_driver_step(page, "Publisher Preset")
        go_to_next_driver_step(page, "Publisher preset table")
        go_to_next_driver_step(page, "Word List")
        go_to_next_driver_step(page, "Word list table")

        with expect_profile_post_response(page) as advanced_response:
            page.get_by_role("button", name="Complete advanced tour").click()

        assert advanced_response.value.ok, f"Expected 2xx status, but got {advanced_response.value.status}"
        expect(page.locator(".driver-popover")).not_to_be_visible()
        page.reload()
        expect(page.locator(".driver-popover")).not_to_be_visible()

    @pytest.mark.e2e_full_stack
    def test_admin_dashboard(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page

        page.goto(url_for("admin.dashboard", _external=True))
        expect(page.locator("#dashboard")).to_be_visible()

        health_card = page.locator("div.bg-base-100.border").filter(has=page.get_by_text("System Health", exact=True)).first
        expect(health_card).to_be_visible()
        expect(health_card.get_by_text("Healthy", exact=True)).to_be_visible()
        for service, status in DASHBOARD_HEALTH_SERVICES.items():
            row = health_card.locator("div.flex.items-center.justify-between").filter(has_text=service).first
            expect(row).to_be_visible()
            expect(row).to_contain_text(status)

        queue_card = page.locator("div.bg-base-100.border").filter(has=page.get_by_role("link", name="Queue")).first
        expect(queue_card).to_be_visible()
        expect(queue_card).to_contain_text(DASHBOARD_BASELINE_QUEUE_TEXT_FRAGMENT)
        expect(queue_card).to_contain_text("tasks scheduled.")
        queue_card.get_by_role("link", name="Queue").click()

        expect(page).to_have_url(url_for("admin.scheduler", _external=True))
        expect(page.locator("#scheduler-dashboard")).to_be_visible()
        expect(page.get_by_test_id("scheduled-jobs")).to_be_visible()
        expect(page.locator("#scheduled-jobs-table-search")).to_be_visible()
        expect(page.locator("#scheduled-jobs-table")).to_contain_text("Page 1 of")

        page.goto(
            url_for(
                "admin.scheduler",
                page=2,
                limit=5,
                order="name_desc",
                search="collector",
                _external=True,
            )
        )
        with_htmx_wait(page, lambda: page.locator('.tab[data-tab="active"]').click())
        expect(page).to_have_url(url_for("admin.scheduler", tab="active", _external=True))
        expect(page.locator("#active-jobs-table-search")).to_have_value("")
        expect(page.locator("#active-jobs-table")).to_contain_text("No jobs currently running")

        with_htmx_wait(page, lambda: page.locator('.tab[data-tab="history"]').click())
        expect(page.locator("#execution-history-table")).to_be_visible()
        expect(page.locator("#history-tab .stats")).to_have_count(1)
        with_htmx_wait(page, lambda: page.locator('.tab[data-tab="scheduled"]').click())
        with_htmx_wait(page, lambda: page.locator('.tab[data-tab="history"]').click())
        expect(page.locator("#history-tab .stats")).to_have_count(1)

    def test_manual_news_item_invalid_language_shows_notification(self, logged_in_page: Page):
        page = logged_in_page

        page.goto(url_for("assess.get_news_item", news_item_id="0", _external=True))
        expect(page.get_by_role("heading", name="Create manual news item")).to_be_visible()
        create_news_item_url = url_for("assess.create_news_item", _external=True)

        page.get_by_role("textbox", name="Title *").fill("Invalid language test")
        page.get_by_role(
            "textbox",
            name="Link Providing a URL helps others trace the original source.",
        ).fill("http://blubb.xxx")
        page.get_by_role("textbox", name="Language ISO 639 language code").fill("xx")

        with page.expect_response(create_news_item_url) as response_info:
            page.get_by_role("button", name="Create news item").click()

        assert response_info.value.status == 400, f"Expected 400 status, but got {response_info.value.status}"
        expect(page.locator("#notification-bar")).to_contain_text("Invalid BCP 47 language tag")
        expect(page.locator("#news-item-form")).to_be_visible()
        dismiss_notifications(page)

    def test_admin_organizations(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page
        organization_name = f"test_org_{uuid.uuid4().hex[:6]}"
        page.goto(url_for("admin.organizations", _external=True))
        expect(page.get_by_test_id("organization-table")).to_be_visible()
        self.capture_screenshot(page, "./tests/playwright/screenshots/docs_organizations.png")

        page.get_by_test_id("new-organization-button").click()
        page.get_by_label("Name", exact=False).fill(organization_name)
        page.get_by_label("Description", exact=False).fill("Test description of an organization")
        page.get_by_label("Street", exact=False).fill("Test Street")
        page.get_by_label("City", exact=False).fill("Test City")
        page.get_by_label("ZIP", exact=False).fill("9999")
        page.get_by_label("Country", exact=False).fill("Test Country")
        self.highlight_element(page.locator("input[type='submit']")).click()
        self.assert_item_in_table(page, "organization-table", organization_name)

        self.open_table_item(page, "organization-table", organization_name)
        page.get_by_label("Description", exact=False).fill("Updated description of an organization")
        self.highlight_element(page.locator("input[type='submit']")).click()
        expect(page.get_by_role("row", name=organization_name)).to_contain_text("Updated description of an organization")

        self.delete_item(page, "organization-table", organization_name)

    def test_admin_user_management(
        self,
        logged_in_page: Page,
        forward_console_and_page_errors,
        test_user,
        test_user_list,
    ):
        page = logged_in_page
        username = f"test_user_{uuid.uuid4().hex[:6]}"

        def load_user_list():
            page.goto(url_for("admin.users", _external=True))
            expect(page.get_by_test_id("user-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_users.png")

        def add_user():
            page.get_by_test_id("new-user-button").click()

            expect(page.get_by_role("textbox", name="Username", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Username", exact=True).fill(username)
            expect(page.get_by_role("textbox", name="Name", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name", exact=True).fill("Test User")
            expect(page.get_by_role("textbox", name="Password", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Password", exact=True).fill("testasdfasdf")

            expect(page.locator('select[name="organization"]')).to_have_attribute("required", "")
            organization_value = page.locator('select[name="organization"] option:not([value=""])').first.get_attribute("value")
            assert organization_value is not None
            page.get_by_label("Organization").select_option(organization_value)
            roles_select = page.locator('select[name="roles[]"]')
            expect(roles_select).to_have_attribute("required", "")
            roles_select.select_option(label="User - Basic user role", force=True)

            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_user_add.png")
            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.users", _external=True))
            expect(page.get_by_role("link", name=username)).to_be_visible()

        def update_user():
            page.get_by_role("link", name=username).click()
            page.get_by_role("button", name="Generate Password").click()
            expect(page.get_by_role("textbox", name="Name", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name", exact=True).fill("Test User Updated")
            page.locator('input[type="submit"]').click()
            expect(page).to_have_url(url_for("admin.users", _external=True))
            expect(page.get_by_role("link", name="Test User Updated")).to_be_visible()

        def remove_user():
            self.delete_item(page, "user-table", username)

        def import_export_users():
            page.get_by_role("button", name="Import").click()
            page.get_by_role("button", name="Choose File").set_input_files(test_user)
            page.get_by_role("button", name="Submit").click()
            with page.expect_download() as download_info:
                page.get_by_role("link", name="Export").click()
            assert download_info.value is not None
            download_path = download_info.value.path()
            with open(test_user_list, "r") as f:
                imported_user_list_correct = json.load(f)
            with open(download_path, "r") as f:
                downloaded_content = json.load(f)
            assert imported_user_list_correct["version"] == downloaded_content["version"]
            assert sorted(imported_user_list_correct["data"], key=lambda item: item["username"]) == sorted(
                downloaded_content["data"], key=lambda item: item["username"]
            ), "Downloaded file content does not match uploaded file content"
            self.delete_item(page, "user-table", "Jane Smith")
            self.delete_item(page, "user-table", "John Doe")
            dismiss_notifications(page)

        load_user_list()
        add_user()
        update_user()
        remove_user()
        import_export_users()

    def test_admin_template_management(self, logged_in_page: Page):
        page = logged_in_page
        template_name = f"test_template_{uuid.uuid4().hex[:6]}"
        valid_template_content = """
          <html>
          <body>
              <h1>{{ title }}</h1>
              {% for item in items %}
                  <p>{{ item.name }}</p>
              {% endfor %}
          </body>
          </html>
        """.strip()

        invalid_template_content = """
          <html>
          <body>
              <h1>{{ title }}</h1>
              {% for item in items %}
                  <p>{{ item.name }}</p>

          </body>
          </html>
        """.strip()

        def load_template_list():
            page.goto(url_for("admin.template_data", _external=True))
            expect(page.get_by_test_id("template-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_templates.png")

        def add_template():
            page.get_by_test_id("new-template-button").click()
            expect(page.get_by_role("textbox", name="Filename", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Filename", exact=True).fill(template_name)
            page.locator("#editor").get_by_role("textbox").fill(valid_template_content)

            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_user_add.png")
            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.template_data", _external=True))
            expect(page.get_by_text(template_name)).to_be_visible()

        def update_template():
            page.get_by_role("link", name=template_name).click()
            page.locator("#editor").get_by_role("textbox").fill(invalid_template_content)
            page.locator('input[type="submit"]').click()
            expect(page).to_have_url(url_for("admin.template_data", _external=True))
            template_row = page.get_by_test_id("template-table").locator("tbody tr").filter(has_text=template_name)
            expect(template_row).to_contain_text("Invalid")

        def remove_template():
            self.delete_item(page, "template-table", template_name)

        load_template_list()
        add_template()
        update_template()
        remove_template()

    def test_admin_osint_workflow(
        self,
        logged_in_page: Page,
        forward_console_and_page_errors,
        test_osint_source,
        test_osint_icon_png,
    ):
        page = logged_in_page
        osint_source_name = f"test_source_{uuid.uuid4().hex[:6]}"

        def load_osint_sources():
            page.goto(url_for("admin.osint_sources", _external=True))
            expect(page.get_by_role("button", name="Curated sources")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_osint_sources.png")
            with_htmx_wait(page, lambda: page.get_by_role("radio", name="Show", exact=True).check())
            with_htmx_wait(page, lambda: page.get_by_role("button", name="Collect All", exact=True).click())
            expect(page.locator("#osint_source-table-container")).to_have_count(1)
            expect(page.get_by_test_id("osint_source-table").locator("tbody tr")).to_have_count(1)
            expect(page.get_by_role("radio", name="Show", exact=True)).to_be_checked()
            dismiss_notifications(page)
            with_htmx_wait(page, lambda: page.get_by_role("radio", name="Hide", exact=True).check())

        def load_and_search_curated_sources():
            page.get_by_role("button", name="Curated sources").click()
            expect(page.get_by_role("heading", name="Add curated OSINT sources")).to_be_visible()
            page.locator('input[name="list_names"][value="Austrian Public Sector"]').check()
            page.locator('input[name="list_names"][value="Cyber Threat Intelligence"]').check()
            page.get_by_test_id("load-curated-sources-button").click()
            osint_table = page.get_by_test_id("osint_source-table")
            all_rows = osint_table.locator("tbody tr")
            expect(all_rows).to_have_count(6)
            dismiss_notifications(page)

            with_htmx_wait(page, lambda: page.get_by_role("radio", name="Show").check())
            expect(page).to_have_url(url_for("admin.osint_sources", filter_manual="false", _external=True))
            expect(all_rows).to_have_count(7)

            manual_row = all_rows.filter(has=page.get_by_text("Manual", exact=True))
            with_htmx_wait(page, lambda: manual_row.locator('[data-testid^="action-collect-"]').click())
            expect(page.locator("#osint_source-table-container")).to_have_count(1)
            expect(all_rows).to_have_count(7)
            dismiss_notifications(page)

            with_htmx_wait(page, lambda: page.get_by_role("radio", name="Hide").check())
            expect(all_rows).to_have_count(6)

            first_source_name = osint_table.locator("[data-testid='osint_source-table_name']").first.inner_text().strip()
            page.get_by_placeholder("Search...").fill(first_source_name)
            expect(all_rows).to_have_count(1)
            expect(all_rows.first).to_contain_text(first_source_name)
            page.get_by_placeholder("Search...").fill("")
            expect(all_rows).to_have_count(6)

            osint_table.locator("thead").get_by_role("checkbox").check()
            delete_button = page.get_by_test_id("delete-osint_source-button")
            expect(delete_button).to_contain_text("Delete 6 sources")
            self.highlight_element(delete_button).click()
            force_checkbox = page.get_by_role("checkbox", name="Force Deletion of OSINT source and all its data")
            expect(force_checkbox).to_be_visible()
            force_checkbox.check()
            page.get_by_role("button", name="Delete").click()
            dismiss_notifications(page)
            expect(page.get_by_role("link", name="Reset Filter")).to_be_visible()

        def import_export_osint_sources():
            page.get_by_role("button", name="Import").click()
            page.get_by_role("button", name="Choose File").set_input_files(test_osint_source)
            page.get_by_role("button", name="Submit").click()
            with page.expect_download() as download_info:
                page.get_by_role("link", name="Export").click()
            assert download_info.value is not None
            download_path = download_info.value.path()
            with open(test_osint_source, "r") as f:
                original_content = json.load(f)
            with open(download_path, "r") as f:
                downloaded_content = json.load(f)
            assert original_content == downloaded_content, "Downloaded file content does not match uploaded file content"
            osint_table = page.get_by_test_id("osint_source-table")
            osint_table.locator("thead").get_by_role("checkbox").check()
            page.get_by_test_id("delete-osint_source-button").click()
            page.get_by_role("button", name="Delete").click()
            dismiss_notifications(page)

        def add_osint_sources():
            page.get_by_test_id("new-osint_source-button").click()
            expect(page.get_by_label("Name")).to_have_attribute("required", "")
            page.get_by_label("Name").fill(osint_source_name)
            page.get_by_label("Description").fill("Test description of an OSINT source")
            page.locator('input[name="rank"][value="4"]').check()
            feed_url_input = page.locator('input[name="parameters[FEED_URL]"]')
            self.select_dynamic_type_and_wait(page, "rss_collector", feed_url_input)
            expect(feed_url_input).to_have_attribute("required", "")
            feed_url_input.fill("http://example.com/feed")
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_osint_sources_add.png")
            dismiss_notifications(page)
            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page.locator("#osint_source-form")).to_be_visible()
            expect(page.get_by_label("Name")).to_have_value(osint_source_name)

        def update_osint_sources():
            form = page.locator("#osint_source-form").first
            expect(form).to_be_visible()
            detail_url = page.url
            page.get_by_role("textbox", name="Description", exact=True).fill("Unsaved source description")
            with_htmx_wait(page, lambda: page.get_by_role("button", name="Collect", exact=True).click())
            expect(page.locator("#notification-bar")).to_contain_text("scheduled")
            expect(page).to_have_url(detail_url)
            expect(page.locator("#osint_source-table-container")).to_have_count(0)
            expect(page.get_by_role("textbox", name="Description", exact=True)).to_have_value("Unsaved source description")
            dismiss_notifications(page)
            expect(form.locator('input[name="rank"][value="4"]')).to_be_checked()
            form.locator('input[name="rank"][value="2"]').check()
            feed_url_input = form.locator('input[name="parameters[FEED_URL]"]')
            expect(feed_url_input).to_have_attribute("required", "")
            feed_url_input.fill("http://example.com/updated-feed-url")
            page.get_by_label("Icon").set_input_files(test_osint_icon_png)

            form.evaluate("form => { form.noValidate = true; }")
            self.highlight_element(form.locator('input[type="submit"]')).click()
            expect(form).to_be_visible()
            expect(page.get_by_test_id("current-osint-icon")).to_be_visible()
            expect(form.locator('input[name="rank"][value="2"]')).to_be_checked()
            expect(page.get_by_label("Name")).to_have_value(osint_source_name)

            form = page.locator("#osint_source-form").first
            expect(form).to_be_visible()
            expect(form.locator('input[name="rank"][value="2"]')).to_be_checked()
            page.get_by_test_id("delete-osint-icon-on-save").check()

            form.evaluate("form => { form.noValidate = true; }")
            self.highlight_element(form.locator('input[type="submit"]')).click()
            expect(form).to_be_visible()
            expect(page.get_by_label("Name")).to_have_value(osint_source_name)
            expect(form.locator('input[name="rank"][value="2"]')).to_be_checked()
            expect(page.get_by_test_id("current-osint-icon")).to_have_count(0)

        def remove_osint_sources():
            page.goto(url_for("admin.osint_sources", _external=True))
            expect(page.get_by_role("link", name="http://example.com/updated-feed-url")).to_be_visible()
            self.delete_item(page, "osint_source-table", osint_source_name, force=True)

        load_osint_sources()
        load_and_search_curated_sources()
        import_export_osint_sources()
        add_osint_sources()
        update_osint_sources()
        remove_osint_sources()

    def test_admin_osint_source_group_management(
        self,
        logged_in_page: Page,
        forward_console_and_page_errors,
        test_batch_osint_sources,
    ):
        page = logged_in_page
        osint_group_name = f"test_osint_group_{uuid.uuid4().hex[:6]}"

        def load_osint_source_groups():
            page.goto(url_for("admin.osint_source_groups", _external=True))
            expect(page.get_by_test_id("osint_source_group-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_osint_source_groups.png")

        def add_osint_source_group():
            page.get_by_test_id("new-osint_source_group-button").click()
            expect(page.get_by_role("textbox", name="Name", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name", exact=True).fill(osint_group_name)
            page.get_by_role("textbox", name="Description", exact=True).fill("Test description of an OSINT source group")
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_osint_source_group_add.png")
            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.osint_source_groups", _external=True))
            expect(page.get_by_role("link", name=osint_group_name)).to_be_visible()

        def update_osint_source_group():
            page.get_by_role("link", name=osint_group_name).click()
            page.get_by_role("textbox", name="Description", exact=True).fill("Updated description of an OSINT source group")

            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.osint_source_groups", _external=True))
            expect(page.get_by_role("row", name=osint_group_name)).to_contain_text("Updated description of an OSINT source group")

        def remove_osint_source_group():
            self.delete_item(page, "osint_source_group-table", osint_group_name)

        def test_page_osint_sources():
            source_name = test_batch_osint_sources["sources"][0]["name"]
            page.goto(url_for("admin.osint_source_groups", _external=True))
            page.get_by_test_id("new-osint_source_group-button").click()
            form = page.locator("#osint_source_group-form")
            expect(form).to_be_visible()
            expect(form.locator("#osint_sources tbody input[type='checkbox'].checkbox-sm")).to_have_count(5)

            form.get_by_role("textbox", name="Search...").first.fill(source_name)
            source_row = form.locator("#osint_sources tbody tr").filter(has_text=source_name).first
            expect(source_row).to_be_visible()
            expect(source_row).to_contain_text(source_name)
            source_row.get_by_role("checkbox").check()
            expect(form.locator('input[type="hidden"][name="osint_sources[]"]')).to_have_count(1)

        load_osint_source_groups()
        add_osint_source_group()
        update_osint_source_group()
        remove_osint_source_group()
        test_page_osint_sources()

    def test_admin_role_management(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page

        role_name = f"test_role_{uuid.uuid4().hex[:6]}"

        def load_role_list():
            page.goto(url_for("admin.roles", _external=True))
            expect(page.get_by_test_id("role-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_roles.png")

        def add_role():
            page.get_by_test_id("new-role-button").click()
            expect(page.locator("#role-form")).to_be_visible()

            expect(page.get_by_role("textbox", name="Name", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name", exact=True).fill(role_name)
            expect(page.get_by_role("textbox", name="Description", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description", exact=True).fill("Test description of a role")
            expect(page.get_by_label("TLP Level")).to_have_attribute("required", "")
            page.get_by_label("TLP Level").select_option("green")

            page.locator("th").first.get_by_role("checkbox").check()

            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_roles_add.png")
            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.roles", _external=True))
            expect(page.get_by_role("link", name=role_name)).to_be_visible()

        def update_role():
            page.get_by_role("link", name=role_name).click()
            expect(page.locator("#role-form")).to_be_visible()

            expect(page.get_by_role("textbox", name="Description", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description", exact=True).fill("Updated description of a role")
            expect(page.get_by_label("TLP Level")).to_have_attribute("required", "")
            page.get_by_label("TLP Level").select_option("amber+strict")

            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.roles", _external=True))
            expect(page.get_by_role("row", name=role_name)).to_contain_text("Updated description of a role")

        def remove_role():
            self.delete_item(page, "role-table", role_name)

        load_role_list()
        add_role()
        update_role()
        remove_role()

    def test_admin_wordlist_management(self, logged_in_page: Page, forward_console_and_page_errors, test_wordlist):
        page = logged_in_page

        word_list_name = f"test_word_list_{uuid.uuid4().hex[:6]}"

        def load_word_list():
            page.goto(url_for("admin.word_lists", _external=True))
            expect(page.get_by_test_id("word_list-table-container")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_word_lists.png")

        def load_default_word_list():
            load_default_button = page.get_by_test_id("load-default-word_list-button")
            expect(load_default_button).to_be_visible()
            with_htmx_wait(page, lambda: load_default_button.click())
            with_htmx_wait(page, lambda: page.get_by_role("button", name="Update Wordlists", exact=True).click())
            expect(page.get_by_test_id("word_list-table-container")).to_have_count(1)
            expect(page.get_by_test_id("word_list-table").locator("tbody tr")).to_have_count(9)
            dismiss_notifications(page)
            page.get_by_role("row", name="Name Description Words Actions").get_by_role("checkbox").check()
            delete_button = page.get_by_test_id("delete-word_list-button")
            expect(delete_button).to_contain_text("Delete 9 Word List")
            self.highlight_element(delete_button).click()
            with_htmx_wait(page, lambda: page.get_by_role("button", name="Delete").click())
            dismiss_notifications(page)

        def add_word_list():
            with_htmx_wait(page, lambda: page.get_by_test_id("new-word_list-button").click())
            expect(page.locator("#word_list-form")).to_be_visible()

            expect(page.get_by_role("textbox", name="Name", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name", exact=True).fill(word_list_name)
            page.get_by_role("textbox", name="Description", exact=True).fill("Test description of a word list")
            page.get_by_role("textbox", name="Link", exact=True).fill("http://example.com")
            page.locator("input[name='usage[]'][value='COLLECTOR_INCLUDELIST']").check()

            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_word_list_add.png")
            self.highlight_element(page.get_by_role("button", name="Create Word List")).click()
            dismiss_notifications(page)
            expect(page.get_by_role("link", name=word_list_name)).to_be_visible()

        def update_word_list():
            page.get_by_role("link", name=word_list_name).click()
            expect(page.locator("#word_list-form")).to_be_visible()

            page.get_by_role("textbox", name="Description", exact=True).fill("Updated description of a word list")
            page.locator("input[name='usage[]'][value='TAGGING_BOT']").check()

            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page.get_by_role("link", name="Updated description of a word list")).to_be_visible()

        def remove_word_list():
            item_id = self.get_table_row_id_by_link_text(page, "word_list-table", word_list_name)
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)
            # expect(page.get_by_test_id("word_list-table").get_by_role("link", name=word_list_name)).not_to_be_visible() # TODO: Wordlist table not rendered afer last element is deleted

        def import_export_word_lists():
            with_htmx_wait(page, lambda: page.get_by_role("button", name="Import").click())
            page.get_by_role("button", name="Choose File").set_input_files(test_wordlist)
            with_htmx_wait(page, lambda: page.get_by_role("button", name="Submit").click())
            expect(page.get_by_test_id("word_list-table-container")).to_be_visible()
            expect(page.get_by_test_id("word_list-table_name").filter(has_text="Test wordlist")).to_be_visible()
            with page.expect_download() as download_info:
                page.get_by_role("link", name="Export").click()
            assert download_info.value is not None
            download_path = download_info.value.path()
            with open(test_wordlist, "r") as f:
                imported_user_list_correct = json.load(f)
            with open(download_path, "r") as f:
                downloaded_content = json.load(f)
            assert imported_user_list_correct == downloaded_content, "Downloaded file content does not match uploaded file content"
            self.delete_item(page, "word_list-table", "Test wordlist")
            dismiss_notifications(page)

        load_word_list()
        load_default_word_list()
        add_word_list()
        update_word_list()
        remove_word_list()
        import_export_word_lists()

    def test_admin_acls(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page
        acl_table = page.get_by_test_id("acl-table")

        def load_acls():
            page.goto(url_for("admin.acls", _external=True))
            expect(acl_table).to_be_visible()
            expect(page.get_by_test_id("new-acl-button")).to_be_visible()

        def test_acl_create():
            page.get_by_test_id("new-acl-button").click()
            acl_form = page.locator("#acl-form")
            expect(acl_form).to_be_visible()

            name_input = acl_form.locator('input[name="name"]')
            item_type_select = acl_form.locator('select[name="item_type"]')
            item_id_select = acl_form.locator('#item_ids select[name="item_id"]')
            roles_table = acl_form.locator("#roles-table")
            roles_widget = acl_form.locator("#dataTableDiv")

            expect(name_input).to_have_attribute("required", "")
            name_input.fill("Test ACL")
            expect(item_type_select).to_have_attribute("required", "")
            with_htmx_wait(page, lambda: item_type_select.select_option("osint_source_group"))
            expect(item_id_select).to_be_enabled()
            expect(item_id_select).to_have_attribute("required", "")

            acl_form.locator('input[name="enabled"][type="checkbox"]').set_checked(False)
            acl_form.locator('input[name="read_only"][type="checkbox"]').set_checked(False)
            admin_role_checkbox = roles_table.locator("tbody tr", has_text="Admin Administrator role").locator('input[type="checkbox"]')
            admin_role_value = admin_role_checkbox.get_attribute("value")
            assert admin_role_value is not None
            user_role_checkbox = roles_table.locator("tbody tr", has_text="User Basic user role").locator('input[type="checkbox"]')
            user_role_value = user_role_checkbox.get_attribute("value")
            assert user_role_value is not None
            admin_role_checkbox.click()
            expect(roles_widget.locator(f'input[type="hidden"][name="roles[]"][value="{admin_role_value}"]')).to_have_count(1)
            user_role_checkbox.click()
            expect(roles_widget.locator(f'input[type="hidden"][name="roles[]"][value="{user_role_value}"]')).to_have_count(1)
            page.get_by_role("button", name="Create ACL").click()

        def test_acl_update():
            page.get_by_role("link", name="Test ACL").click()
            acl_form = page.locator("#acl-form")
            expect(acl_form).to_be_visible()

            roles_table = acl_form.locator("#roles-table")
            roles_widget = acl_form.locator("#dataTableDiv")
            admin_role_checkbox = roles_table.locator("tbody tr", has_text="Admin Administrator role").locator('input[type="checkbox"]')
            admin_role_value = admin_role_checkbox.get_attribute("value")
            assert admin_role_value is not None
            expect(roles_widget.locator(f'input[type="hidden"][name="roles[]"][value="{admin_role_value}"]')).to_have_count(1)
            admin_role_checkbox.click()
            expect(roles_widget.locator(f'input[type="hidden"][name="roles[]"][value="{admin_role_value}"]')).to_have_count(0)
            name_input = acl_form.locator('input[name="name"]')
            expect(name_input).to_have_attribute("required", "")
            name_input.fill("Test ACL updated")
            acl_form.locator('input[name="enabled"][type="checkbox"]').set_checked(True)
            acl_form.locator('input[name="read_only"][type="checkbox"]').set_checked(True)
            page.get_by_role("button", name="Update ACL").click()

        def test_acl_delete():
            acl_row = acl_table.locator(
                "tbody tr",
                has=page.get_by_role("link", name="Test ACL updated", exact=True),
            ).first
            expect(acl_row).to_be_visible()
            item_id = self.get_table_row_id_by_link_text(page, "acl-table", "Test ACL updated")
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)
            expect(acl_row).not_to_be_visible()

        load_acls()
        test_acl_create()
        test_acl_update()
        test_acl_delete()

    def test_admin_attributes(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page

        def load_attributes():
            page.goto(url_for("admin.attributes", _external=True))
            expect(page.get_by_test_id("attribute-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_attributes.png")

        def test_attribute_create():
            page.get_by_role("link", name="Administration").click()

            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            page.get_by_test_id("admin-menu-Attribute").click()
            expect(page.get_by_role("row", name="Attachment Attachment")).to_be_visible()

            page.get_by_test_id("new-attribute-button").click()
            expect(page.get_by_role("heading", name="Create Attribute")).to_be_visible()

            expect(page.get_by_role("textbox", name="Name")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name").click()
            page.get_by_role("textbox", name="Name").fill("attribute number 5")
            expect(page.get_by_role("textbox", name="Description")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description").click()
            page.get_by_role("textbox", name="Description").fill("attr 5")
            page.get_by_role("textbox", name="Default Value").click()
            page.get_by_role("textbox", name="Default Value").fill("5")
            expect(page.locator('select[name="type"]')).to_have_attribute("required", "")
            page.get_by_label("Attribute Type Select an item").select_option("number")
            page.get_by_role("button", name="Create Attribute").click()
            expect(page.get_by_role("row", name="Attachment Attachment")).to_be_visible()

            page.get_by_test_id("new-attribute-button").click()
            expect(page.get_by_role("heading", name="Create Attribute")).to_be_visible()

            page.locator("#attribute-list").get_by_role("link", name="Attribute").click()
            expect(page.get_by_role("row", name="Attachment Attachment")).to_be_visible()

            page.get_by_test_id("admin-menu-Report Item Type").click()
            expect(page.get_by_role("row", name="CERT Report Example CERT")).to_be_visible()

            page.get_by_test_id("new-report_item_type-button").click()
            expect(page.get_by_role("heading", name="Create Report Item Type")).to_be_visible()

            expect(page.get_by_role("textbox", name="Title")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Title").click()
            page.get_by_role("textbox", name="Title").fill("report item type test 5")
            expect(page.get_by_role("textbox", name="Description")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description").click()
            page.get_by_role("textbox", name="Description").fill("atrr5")
            page.get_by_role("button", name="+ Add New Group").click()
            expect(page.get_by_role("spinbutton", name="Group Index")).to_be_visible()

            expect(page.get_by_role("textbox", name="Group Title")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Group Title").click()
            page.get_by_role("textbox", name="Group Title").fill("group1")
            page.get_by_role("textbox", name="Group Description").click()
            page.get_by_role("button", name="+ Add New Attribute").click()
            expect(page.get_by_role("group", name="Required")).to_be_visible()

            expect(page.get_by_role("textbox", name="Attribute Title")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Attribute Title").click()
            page.get_by_role("textbox", name="Attribute Title").fill("attr title text")
            expect(page.locator("select[name$='[attribute_id]']").first).to_have_attribute("required", "")
            page.get_by_label("Attribute Type * Select an").select_option(label="attribute number 5")
            page.get_by_role("textbox", name="Attribute Description").click()
            page.get_by_role("textbox", name="Attribute Description").fill("test 5")
            page.get_by_role("textbox", name="Attribute Description").dblclick()
            page.get_by_role("textbox", name="Attribute Description").fill("number 5")
            page.get_by_role("button", name="Create Report Item Type").click()
            expect(page.get_by_role("row", name="CERT Report Example CERT")).to_be_visible()

            page.get_by_role("link", name="Analyze").click()
            expect(page.get_by_role("row", name="Title Created Type Stories")).to_be_visible()

            page.get_by_test_id("new-report-button").click()
            expect(page.get_by_role("heading", name="Create Report")).to_be_visible()

            page.locator(".col-span-12 > .grid > div").first.click()
            expect(page.get_by_role("textbox", name="Title")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Title").fill("number 5 in report")
            page.get_by_test_id("report-type-select").select_option(label="report item type test 5")
            page.get_by_test_id("save-report").click()
            expect(page.get_by_role("heading", name="Update Report - number 5 in")).to_be_visible()
            expect(page.get_by_role("heading", name="group1")).to_be_visible()
            attr_field = page.get_by_role("spinbutton", name="attr title text")
            expect(attr_field).to_have_value("5")

        def test_attribute_update():
            page.get_by_role("link", name="Administration").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            page.get_by_test_id("admin-menu-Attribute").click()
            expect(page.get_by_role("row", name="Attachment Attachment")).to_be_visible()

            page.get_by_text("›").click()
            expect(page.get_by_role("row", name="Rich Text Rich Text Rich Edit")).to_be_visible()

            page.get_by_role("link", name="attribute number").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            expect(page.get_by_role("textbox", name="Name")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name").click()
            page.get_by_role("textbox", name="Name").fill("attribute number 6")
            expect(page.get_by_role("textbox", name="Description")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description").click()
            page.get_by_role("textbox", name="Description").fill("attr 6")
            page.get_by_role("textbox", name="Default Value").click()
            page.get_by_role("textbox", name="Default Value").fill("6")
            page.get_by_role("button", name="Update Attribute").click()
            expect(page.get_by_role("row", name="Attachment Attachment")).to_be_visible()

            page.get_by_role("link", name="Analyze").click()
            expect(page.get_by_role("row", name="number 5 in report")).to_be_visible()

            page.get_by_test_id("new-report-button").click()
            expect(page.get_by_role("heading", name="Create Report")).to_be_visible()

            page.get_by_role("textbox", name="Title").click()
            expect(page.get_by_role("textbox", name="Title")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Title").fill("update attr use")
            page.get_by_test_id("report-type-select").select_option(label="report item type test 5")
            page.get_by_test_id("save-report").click()
            attr_field = page.get_by_role("spinbutton", name="attr title text")
            expect(attr_field).to_have_value("6")

        def test_attribute_delete():
            page.get_by_role("link", name="Analyze").click()
            expect(page.get_by_role("row", name="update attr use")).to_be_visible()

            item_id = self.get_table_row_id_by_link_text(page, "report-table", "update attr use")
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)
            item_id = self.get_table_row_id_by_link_text(page, "report-table", "number 5 in report")
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)

            expect(page.get_by_role("row", name="Title Created Type Stories")).to_be_visible()

            page.get_by_role("link", name="Administration").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            page.get_by_test_id("admin-menu-Report Item Type").click()
            expect(page.get_by_role("row", name="CERT Report Example CERT")).to_be_visible()

            item_id = self.get_table_row_id_by_link_text(page, "report_item_type-table", "report item type test 5")
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)
            expect(page.get_by_role("row", name="CERT Report Example CERT")).to_be_visible()

            page.get_by_test_id("admin-menu-Attribute").click()
            expect(page.get_by_role("row", name="Attachment Attachment")).to_be_visible()

            page.get_by_text("›").click()
            expect(page.get_by_role("row", name="Rich Text Rich Text Rich Edit")).to_be_visible()

            item_id = self.get_table_row_id_by_link_text(page, "attribute-table", "attribute number 6")
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)

        load_attributes()
        test_attribute_create()
        test_attribute_update()
        test_attribute_delete()

    def test_admin_report_types(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page

        report_type_title = f"Test Report {uuid.uuid4().hex[:6]}"
        group_title = "Primary Group"
        attribute_title = "Primary Attribute"

        def load_report_types():
            page.goto(url_for("admin.report_item_types", _external=True))
            expect(page.get_by_test_id("report_item_type-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_report_types.png")

        def add_report_type():
            page.get_by_test_id("new-report_item_type-button").click()
            expect(page.locator("#report_item_type-form")).to_be_visible()

            expect(page.get_by_role("textbox", name="Title", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Title", exact=True).fill(report_type_title)
            expect(page.get_by_role("textbox", name="Description", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description", exact=True).fill("Test description of a report item type")

            page.get_by_role("button", name="+ Add New Group").click()
            group_container = page.locator("#attribute-group-0")
            expect(group_container).to_be_visible()
            expect(group_container.locator("input[name$='[title]']").first).to_have_attribute("required", "")
            group_container.locator("input[name$='[title]']").first.fill(group_title)
            group_container.locator("textarea[name$='[description]']").first.fill("Group description")

            group_container.get_by_role("button", name="+ Add New Attribute").click()
            attribute_container = page.locator("#attribute-items-container-0")
            first_attribute_title = attribute_container.locator("input[name='attribute_groups[0][attribute_group_items][0][title]']")
            first_attribute_index = attribute_container.locator("input[name='attribute_groups[0][attribute_group_items][0][index]']")
            expect(first_attribute_title).to_be_visible()
            expect(first_attribute_title).to_have_attribute("required", "")
            expect(first_attribute_index).to_have_value("0")
            first_attribute_title.fill(attribute_title)

            group_container.get_by_role("button", name="+ Add New Attribute").click()
            second_attribute_title_input = attribute_container.locator("input[name='attribute_groups[0][attribute_group_items][1][title]']")
            second_attribute_index = attribute_container.locator("input[name='attribute_groups[0][attribute_group_items][1][index]']")
            expect(second_attribute_index).to_have_value("1")
            second_attribute_title_input.fill("Secondary Attribute")

            attribute_select = attribute_container.locator("select[name$='[attribute_id]']").first
            expect(attribute_select).to_have_attribute("required", "")
            first_option_value = attribute_select.locator("option:not([disabled])").first.get_attribute("value")
            assert first_option_value, "Expected at least one attribute option"
            attribute_select.select_option(first_option_value)
            attribute_container.locator("select[name='attribute_groups[0][attribute_group_items][1][attribute_id]']").select_option(
                first_option_value
            )

            attribute_container.locator("input[name$='[description]']").first.fill("Attribute description")
            attribute_required = attribute_container.locator("input[type='checkbox'][name$='[required]']").first
            if not attribute_required.is_checked():
                attribute_required.check()

            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_report_types_add.png")
            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.report_item_types", _external=True))
            expect(page.get_by_role("link", name=report_type_title)).to_be_visible()

        def update_report_type():
            page.get_by_role("link", name=report_type_title).click()
            expect(page.locator("#report_item_type-form")).to_be_visible()

            expect(page.get_by_role("textbox", name="Description", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description", exact=True).fill("Updated description of a report item type")
            group_container = page.locator("#attribute-group-0")
            group_container.locator("textarea[name$='[description]']").first.fill("Updated group description")
            attribute_container = page.locator("#attribute-items-container-0")
            attribute_container.locator("input[name$='[description]']").first.fill("Updated attribute description")

            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.report_item_types", _external=True))
            row = page.get_by_role("row", name=report_type_title)
            expect(row).to_contain_text("Updated description of a report item type")

        def remove_report_type():
            self.delete_item(page, "report_item_type-table", report_type_title)

        load_report_types()
        add_report_type()
        update_report_type()
        remove_report_type()

    def test_admin_product_types(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page

        product_type_name = f"test_product_type_{uuid.uuid4().hex[:6]}"

        def load_product_types():
            page.goto(url_for("admin.product_types", _external=True))
            expect(page.get_by_test_id("product_type-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_product_types.png")

        def add_product_type():
            page.get_by_test_id("new-product_type-button").click()
            expect(page.locator("#product_type-form")).to_be_visible()

            expect(page.get_by_role("textbox", name="Title", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Title", exact=True).fill(product_type_name)
            page.get_by_role("textbox", name="Description", exact=True).fill("Test description of a product type")
            template_path_select = page.locator('select[name="parameters[TEMPLATE_PATH]"]')
            self.select_dynamic_type_and_wait(page, "html_presenter", template_path_select)
            expect(template_path_select).to_have_attribute("required", "")
            template_path_select.select_option("cert_at_daily_report.html")

            expect(page.locator('select[name="report_types[]"]')).to_have_attribute("required", "")
            page.get_by_role("searchbox", name="Select report types").click()
            page.get_by_role("option", name="CERT Report").click()

            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_product_type_add.png")
            page.get_by_role("searchbox", name="Select report types").press("Escape")
            self.highlight_element(page.locator('input[type="submit"]')).click()
            expect(page).to_have_url(url_for("admin.product_types", _external=True))
            expect(page.get_by_role("link", name=product_type_name)).to_be_visible()

        def update_product_type():
            page.get_by_role("link", name=product_type_name).click()
            expect(page.locator("#product_type-form")).to_be_visible()

            page.get_by_role("textbox", name="Description", exact=True).fill("Updated description of a product type")

            page.locator('input[type="submit"]').click()
            expect(page).to_have_url(url_for("admin.product_types", _external=True))
            expect(page.get_by_role("row", name=product_type_name)).to_contain_text("Updated description of a product type")

        def remove_product_type():
            self.delete_item(page, "product_type-table", product_type_name)

        load_product_types()
        add_product_type()
        update_product_type()
        remove_product_type()

    def test_admin_bot(self, logged_in_page: Page, forward_console_and_page_errors: None):
        page = logged_in_page
        bot_count = 0
        bot_name = f"test bot {uuid.uuid4().hex[:6]}"
        updated_bot_name = f"{bot_name} updated"

        def test_load_bots():
            nonlocal bot_count
            page.goto(url_for("admin.bots", _external=True))
            bot_table = page.get_by_test_id("bot-table")
            expect(bot_table).to_be_visible()
            bot_count = bot_table.locator("tbody tr").count()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_bots.png")

        def test_bot_create():
            page.get_by_test_id("new-bot-button").click()
            expect(page.get_by_role("heading", name="Create Bot")).to_be_visible()
            optional_parameters = page.get_by_test_id("optional-worker-parameters")

            expect(page.get_by_role("textbox", name="Name")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name").fill(bot_name)
            expect(page.get_by_role("textbox", name="Description")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Description").fill("test bot description")
            expect(page.get_by_role("spinbutton", name="Index")).to_have_attribute("required", "")
            prefilled_index = page.get_by_role("spinbutton", name="Index").input_value()
            assert prefilled_index
            expect(page.get_by_test_id("bot-index-availability")).to_contain_text(f"Index {prefilled_index} is available.")
            page.get_by_role("spinbutton", name="Index").fill("1")
            expect(page.get_by_test_id("bot-index-availability")).to_contain_text("Index 1 is already taken.")
            self.select_dynamic_type_and_wait(page, "analyst_bot", optional_parameters)
            optional_parameters.locator("summary").click()

            page.locator('input[name="parameters[ITEM_FILTER]"]').fill("1")
            page.locator('input[name="parameters[REGULAR_EXPRESSION]"]').fill(".*")
            page.locator('input[name="parameters[ATTRIBUTE_NAME]"]').fill("test_attribute")

            page.get_by_role("checkbox", name="run_after_collector").check()
            page.get_by_role("spinbutton", name="Index").fill("21")
            expect(page.get_by_test_id("bot-index-availability")).to_contain_text("Index 21 is available.")
            page.get_by_role("button", name="Create Bot").click()

        def test_bot_update():
            page.get_by_role("link", name=bot_name, exact=True).click()
            page.get_by_test_id("optional-worker-parameters").locator("summary").click()
            expect(page.locator('input[name="parameters[REFRESH_INTERVAL]"]')).to_be_visible()

            expect(page.get_by_role("textbox", name="Name", exact=True)).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name", exact=True).fill(updated_bot_name)
            expect(page.get_by_role("spinbutton", name="Index")).to_have_attribute("required", "")
            page.get_by_role("spinbutton", name="Index").fill("12")
            page.get_by_role("button", name="Update Bot").click()

            page.get_by_role("link", name=updated_bot_name).click()
            page.get_by_test_id("optional-worker-parameters").locator("summary").click()
            expect(page.locator('input[name="parameters[REFRESH_INTERVAL]"]')).to_be_visible()

            page.get_by_role("button", name="Update Bot").click()

        def test_remove_bot():
            bot_table = page.get_by_test_id("bot-table")
            all_rows = bot_table.locator("tbody tr")
            expect(all_rows).to_have_count(bot_count + 1)
            item_id = self.get_table_row_id_by_link_text(page, "bot-table", updated_bot_name)
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)
            dismiss_notifications(page)

        test_load_bots()
        test_bot_create()
        test_bot_update()
        test_remove_bot()

    def test_admin_connector_management(self, logged_in_page: Page, forward_console_and_page_errors):
        page = logged_in_page

        connector_name = f"test_connector_{uuid.uuid4().hex[:6]}"
        updated_connector_name = f"{connector_name} updated"

        connector_table = page.get_by_test_id("connector-table")

        def load_connectors():
            page.goto(url_for("admin.connectors", _external=True))
            expect(connector_table).to_be_visible()
            expect(page.get_by_test_id("new-connector-button")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_connectors.png")

        def add_connector():
            page.get_by_test_id("new-connector-button").click()
            expect(page.get_by_test_id("connector-form")).to_be_visible()
            url_input = page.locator('input[name="parameters[URL]"]')

            expect(page.get_by_role("textbox", name="Name")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name").fill(connector_name)
            self.select_dynamic_type_and_wait(page, "misp_connector", url_input)

            api_key_input = page.locator('input[name="parameters[API_KEY]"]')
            organisation_input = page.locator('input[name="parameters[ORGANISATION_ID]"]')
            expect(url_input).to_have_attribute("required", "")
            url_input.fill("test.url")
            expect(api_key_input).to_have_attribute("required", "")
            api_key_input.fill("11111")
            expect(organisation_input).to_have_attribute("required", "")
            organisation_input.fill("1")

            page.get_by_test_id("optional-worker-parameters").locator("summary").click()
            page.locator('input[name="parameters[SSL_CHECK]"][type="checkbox"]').set_checked(True)
            page.locator('input[name="parameters[SHARING_GROUP_ID]"]').fill("1")
            page.get_by_test_id("connector-submit-button").click()
            expect(page.get_by_test_id("connector-form")).to_have_count(0)
            expect(connector_table.get_by_role("link", name=connector_name, exact=True)).to_be_visible()

        def update_connector():
            page.get_by_role("link", name=connector_name).click()
            expect(page.get_by_test_id("connector-form")).to_be_visible()
            page.get_by_test_id("optional-worker-parameters").locator("summary").click()
            expect(page.locator('input[name="parameters[SSL_CHECK]"][type="checkbox"]')).to_be_visible()

            expect(page.get_by_role("textbox", name="Name")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name").fill(updated_connector_name)
            page.get_by_test_id("connector-submit-button").click()
            expect(page.get_by_test_id("connector-form")).to_have_count(0)
            expect(connector_table.get_by_role("link", name=updated_connector_name, exact=True)).to_be_visible()

        def remove_connector():
            connector_row = connector_table.locator(
                "tbody tr",
                has=page.get_by_role("link", name=updated_connector_name, exact=True),
            ).first
            expect(connector_row).to_be_visible()
            connector_row.get_by_role("checkbox").check()
            page.get_by_test_id("delete-connector-button").click()
            with_htmx_wait(page, lambda: page.locator(".swal2-confirm").click())
            expect(connector_row).not_to_be_visible()
            expect(page.locator("#connector-table-container")).to_have_count(1)

        load_connectors()
        add_connector()
        update_connector()
        remove_connector()

    @pytest.mark.parametrize("publisher_type", ["ftp", "sftp"])
    def test_publisher_presets(self, logged_in_page: Page, forward_console_and_page_errors_publisher_validation, publisher_type):
        page = logged_in_page
        host_key = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAABAgMEBQYHCAkKCwwNDg8QERITFBUWFxgZGhscHR4f test-server\n"

        def load_publisher_presets():
            page.goto(url_for("admin.publisher_presets", _external=True))
            expect(page.get_by_test_id("publisher_preset-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_publisher_presets.png")

        def publisher_presets_create():
            page.get_by_test_id("new-publisher_preset-button").click()
            expect(page.get_by_role("heading", name="Create Publisher Preset")).to_be_visible()
            ftp_url_input = page.locator(f'input[name="parameters[{publisher_type.upper()}_URL]"]')

            expect(page.get_by_role("textbox", name="Name")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name").fill("publisher preset test")
            self.select_dynamic_type_and_wait(page, f"{publisher_type}_publisher", ftp_url_input)
            expect(ftp_url_input).to_have_attribute("required", "")
            ftp_url_input.fill("sftp://user@example.test/" if publisher_type == "sftp" else "testurl")
            if publisher_type == "sftp":
                page.get_by_test_id("optional-worker-parameters").locator("summary").click()
                host_key_input = page.locator('textarea[name="parameters[HOST_KEY]"]')
                bypass = page.locator('input[name="parameters[ACCEPT_ANY_HOST_KEY]"][type="checkbox"]')
                expect(bypass).not_to_be_checked()
                page.get_by_role("button", name="Create Publisher Preset").click()
                expect(page.get_by_text("Provide a server host public key", exact=False).first).to_be_visible()
                optional = page.get_by_test_id("optional-worker-parameters")
                if not optional.evaluate("el => el.open"):
                    optional.locator("summary").click()
                page.get_by_label("Upload public key file").set_input_files(
                    {"name": "server.pub", "mimeType": "text/plain", "buffer": host_key.encode()}
                )
                expect(host_key_input).to_have_value(host_key)
            page.get_by_role("button", name="Create Publisher Preset").click()
            expect(page.get_by_role("link", name="publisher preset test", exact=True)).to_be_visible()

        def publisher_presets_update():
            page.get_by_role("link", name="publisher preset test").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()
            ftp_url_input = page.locator(f'input[name="parameters[{publisher_type.upper()}_URL]"]')

            ftp_url_input.click()
            expect(ftp_url_input).to_have_attribute("required", "")
            ftp_url_input.fill("sftp://user@example.test/reports/" if publisher_type == "sftp" else "testurl.com")
            if publisher_type == "sftp":
                page.get_by_test_id("optional-worker-parameters").locator("summary").click()
                host_key_input = page.locator('textarea[name="parameters[HOST_KEY]"]')
                expect(host_key_input).to_have_value(host_key)
                host_key_input.fill("")
                page.locator('input[name="parameters[ACCEPT_ANY_HOST_KEY]"][type="checkbox"]').check()
            page.get_by_role("textbox", name="Name").click()
            expect(page.get_by_role("textbox", name="Name")).to_have_attribute("required", "")
            page.get_by_role("textbox", name="Name").fill("publisher preset test updated")
            page.get_by_role("button", name="Update Publisher Preset").click()
            expect(page.get_by_role("row", name="publisher preset test updated")).to_be_visible()
            if publisher_type == "sftp":
                page.get_by_role("link", name="publisher preset test updated").click()
                page.get_by_test_id("optional-worker-parameters").locator("summary").click()
                expect(page.locator('input[name="parameters[ACCEPT_ANY_HOST_KEY]"][type="checkbox"]')).to_be_checked()
                expect(page.locator('textarea[name="parameters[HOST_KEY]"]')).to_have_value("")
                page.goto(url_for("admin.publisher_presets", _external=True))

        def publisher_presets_delete():
            publisher_table = page.get_by_test_id("publisher_preset-table")
            all_rows = publisher_table.locator("tbody tr")
            expect(all_rows).to_have_count(2)
            item_id = self.get_table_row_id_by_link_text(page, "publisher_preset-table", "publisher preset test updated")
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)
            expect(publisher_table.get_by_role("link", name="publisher preset test updated")).not_to_be_visible()
            expect(publisher_table.get_by_role("link", name="Taranis Publisher")).to_be_visible()
            expect(all_rows).to_have_count(1)

        load_publisher_presets()
        publisher_presets_create()
        publisher_presets_update()
        publisher_presets_delete()

    @pytest.mark.parametrize("destination", ["create", "admin"])
    @pytest.mark.parametrize("export_kind", ["assess", "admin", "admin_metadata", "news_item"])
    def test_story_file_import(self, logged_in_page, forward_console_and_page_errors, core_request_client, destination, export_kind):
        page = logged_in_page
        allow_requests_passthru()
        story_id = str(uuid.uuid4())
        title = f"File transfer {story_id}"
        items = [{"title": f"{title} item {index}", "content": "Transferred content", "osint_source_id": "manual"} for index in range(2)]
        core_request_client.post("/assess/import", json_data={"id": story_id, "title": title, "news_items": items})
        cleanup_ids = [story_id]
        try:
            if export_kind in ("assess", "news_item"):
                exported = core_request_client.json_request("GET", "/assess/stories/export", params={"story_ids": [story_id]})
                if export_kind == "news_item":
                    exported = exported["items"][0]["news_items"][0]
            else:
                exported = core_request_client.json_request(
                    "GET", "/settings/export-stories", params={"metadata": "true" if export_kind == "admin_metadata" else "false"}
                )
                exported = [story for story in exported if story["id"] == story_id]
            core_request_client.delete(f"/assess/stories/{story_id}")
            if destination == "create":
                page.goto(url_for("assess.get_news_item", news_item_id="0", _external=True))
                form = page.locator("form").filter(has=page.get_by_role("button", name="Create from file", exact=True))
                submit_url = url_for("assess.create_news_item", _external=True)
            else:
                page.goto(url_for("admin_settings.settings", _external=True))
                form = page.locator("#stories-import-form")
                submit_url = url_for("assess.import_stories", _external=True)
            form.locator('input[type="file"]').set_input_files(
                {"name": "export.json", "mimeType": "application/json", "buffer": json.dumps(exported).encode()}
            )
            with page.expect_response(submit_url) as response_info:
                form.get_by_role("button", name="Create from file" if destination == "create" else "Import Stories", exact=True).click()
            assert response_info.value.ok
            if destination == "create":
                expect(page).to_have_url(url_for("assess.assess", _external=True))
            else:
                expect(
                    page.get_by_text("Imported 1 news item successfully" if export_kind == "news_item" else "Imported 1 story successfully")
                ).to_be_visible()
                page.goto(url_for("assess.assess", _external=True))
            page.get_by_placeholder("Search stories").fill(title)
            with_htmx_wait(page, lambda: page.get_by_placeholder("Search stories").press("Enter"))
            card = page.locator("article", has=page.get_by_test_id("story-title").filter(has_text=title)).first
            expect(card).to_be_visible()
            imported_id = card.get_attribute("data-story-id")
            cleanup_ids.append(imported_id)
            imported = core_request_client.json_request("GET", f"/assess/stories/{imported_id}")
            assert len(imported["news_items"]) == (1 if export_kind == "news_item" else 2)
        finally:
            allow_requests_passthru()
            for cleanup_id in set(cleanup_ids):
                core_request_client.delete(f"/assess/stories/{cleanup_id}", raise_for_status=False)

    def test_admin_settings(self, logged_in_page, tmp_path, pre_seed_stories):
        page = logged_in_page
        settings_update_url = url_for("admin_settings.settings_action", action="settings", _external=True)
        settings_form = page.locator("#settings-container form#admin-settings-form")
        tlp_select = settings_form.get_by_test_id("settings-default-tlp-level").first
        collector_proxy_input = settings_form.get_by_test_id("settings-default-collector-proxy").first
        collector_interval_input = settings_form.get_by_test_id("settings-default-collector-interval").first
        rss_entry_limit_input = settings_form.get_by_test_id("settings-rss-collector-max-entries").first
        rss_entry_limit_warning = settings_form.get_by_test_id("settings-rss-collector-max-entries-warning").first
        story_conflict_input = settings_form.get_by_test_id("settings-default-story-conflict-retention").first
        news_conflict_input = settings_form.get_by_test_id("settings-default-news-item-conflict-retention").first
        onboarding_switch = settings_form.locator("#settings-onboarding-enabled").first
        settings_submit = settings_form.get_by_test_id("settings-submit").first
        stories_import_url = url_for("assess.import_stories", _external=True)

        def go_to_admin_settings():
            page.goto(url_for("admin_settings.settings", _external=True))
            expect(collector_interval_input).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_settings.png")

        def check_default_values():
            expect(tlp_select).to_have_attribute("required", "")
            expect(tlp_select).to_have_value("clear")
            expect(collector_proxy_input).to_be_empty()
            expect(collector_interval_input).to_have_attribute("required", "")
            expect(collector_interval_input).to_have_value("0 */8 * * *")
            expect(rss_entry_limit_input).to_have_value("42")
            expect(rss_entry_limit_warning).not_to_be_visible()
            expect(story_conflict_input).to_have_attribute("required", "")
            expect(story_conflict_input).to_have_value("200")
            expect(news_conflict_input).to_have_attribute("required", "")
            expect(news_conflict_input).to_have_value("200")
            expect(onboarding_switch).to_be_checked()

        def change_default_values():
            expect(collector_interval_input).to_be_visible()
            tlp_select.select_option("red")
            collector_proxy_input.fill("https://test")
            collector_interval_input.fill("0 */8 * * 1")
            rss_entry_limit_input.fill("101")
            expect(rss_entry_limit_warning).to_be_visible()
            rss_entry_limit_input.fill("19")
            expect(rss_entry_limit_warning).to_be_visible()
            story_conflict_input.fill("20")
            news_conflict_input.fill("21")
            with page.expect_response(settings_update_url) as response_info:
                settings_submit.click()
            assert response_info.value.ok, f"Expected 2xx status, but got {response_info.value.status}"
            expect(page.get_by_test_id("settings-default-tlp-level").first).to_have_value("red")

        def check_new_values():
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            expect(page.get_by_test_id("settings-default-tlp-level").first).to_have_value("red")
            expect(collector_proxy_input).to_have_value("https://test/")
            expect(collector_interval_input).to_have_value("0 */8 * * 1")
            expect(rss_entry_limit_input).to_have_value("19")
            expect(rss_entry_limit_warning).to_be_visible()
            expect(story_conflict_input).to_have_value("20")
            expect(news_conflict_input).to_have_value("21")

        def test_export_all_stories(story_list):
            export_btn = page.get_by_test_id("story-export-button")
            export_all_btn = page.get_by_test_id("story-export-dialog-button")
            export_dialog = page.locator("dialog[data-export-dialog]")

            # export all stories
            self.highlight_element(export_btn).click()
            expect(export_dialog).to_be_visible()
            with page.expect_download() as dl_info:
                self.highlight_element(export_all_btn).click()
            download = dl_info.value
            assert download is not None
            export_file = tmp_path / "settings_story_export.json"
            download.save_as(str(export_file))

            with open(export_file, "r", encoding="utf-8") as f:
                exported = json.load(f)

            # convert both exported stories and stories in story_list to a comparable format
            expected_stories = {
                (
                    item["story_id"],
                    remove_tz(item["published"]),
                    item["id"],
                    item["title"],
                    item["content"],
                )
                for item in story_list
            }

            received_stories = {
                (
                    item["id"],
                    remove_tz(item["created"]),
                    item["news_items"][0]["id"],
                    item["news_items"][0]["title"],
                    item["news_items"][0]["content"],
                )
                for item in exported
            }

            assert expected_stories == received_stories, "Exported stories do not match stories in DB"

            if export_dialog.is_visible():
                page.keyboard.press("Escape")
            expect(export_dialog).not_to_be_visible()
            return export_file

        def test_export_stories_metadata_time_filter(story_list):
            export_btn = page.get_by_test_id("story-export-button")
            export_meta_btn = page.get_by_test_id("story-export-dialog-with-metadata-button")
            time_from_input = page.get_by_test_id("story-export-time-from")
            time_to_input = page.get_by_test_id("story-export-time-to")
            export_dialog = page.locator("dialog[data-export-dialog]")

            time_from = "2024-05-01T00:00"
            time_to = "2024-06-01T00:00"

            self.highlight_element(export_btn).click()
            expect(export_dialog).to_be_visible()
            time_from_input.fill(time_from)
            time_to_input.fill(time_to)

            # export stories with metdata between time_from and time_to
            with page.expect_download() as dl_info:
                self.highlight_element(export_meta_btn).click()

            download = dl_info.value
            assert download is not None
            download_path = download.path()
            assert download_path is not None

            # check if query params in URL
            assert "timefrom=" in download.url
            assert "timeto=" in download.url
            assert "metadata=true" in download.url

            with open(download_path, "r", encoding="utf-8") as f:
                exported = json.load(f)

            assert all("attributes" in story for story in exported)
            timezone = ZoneInfo(export_dialog.locator("form[data-timezone]").get_attribute("data-timezone"))
            tf = datetime.fromisoformat(time_from).replace(tzinfo=timezone).astimezone(UTC).replace(tzinfo=None)
            tt = datetime.fromisoformat(time_to).replace(tzinfo=timezone).astimezone(UTC).replace(tzinfo=None)

            expected = {
                (
                    item["story_id"],
                    item["id"],
                    item["title"],
                    item["content"],
                    item["source"],
                    item["author"],
                    item["link"],
                    remove_tz(item["published"]),
                )
                for item in story_list
                if tf <= datetime.fromisoformat(remove_tz(item["published"])) <= tt
            }

            got = {
                (
                    story["id"],
                    ni["id"],
                    ni["title"],
                    ni["content"],
                    ni["source"],
                    ni["author"],
                    ni["link"],
                    remove_tz(story["created"]),
                )
                for story in exported
                for ni in story.get("news_items", [])
            }

            assert expected == got, "Exported stories with metadata do not match fixture stories within time filter"

            if export_dialog.is_visible():
                page.keyboard.press("Escape")
            expect(export_dialog).not_to_be_visible()

        def import_stories_from_json(export_file):
            with open(export_file, "r", encoding="utf-8") as f:
                import_payload = json.load(f)

            imported_story_title = f"Imported Story {uuid.uuid4().hex[:8]}"
            imported_story_id = str(uuid.uuid4())
            story_to_import = import_payload[0]
            story_to_import["id"] = imported_story_id
            story_to_import["title"] = imported_story_title

            for index, news_item in enumerate(story_to_import["news_items"], start=1):
                news_item["id"] = str(uuid.uuid4())
                news_item["story_id"] = imported_story_id
                news_item["title"] = f"{imported_story_title} News {index}"
                news_item["link"] = f"https://example.com/{imported_story_id}/{index}"
                news_item["osint_source_id"] = "manual"
                news_item.pop("hash", None)

            export_file.write_text(json.dumps([story_to_import]), encoding="utf-8")

            with page.expect_response(stories_import_url) as response_info:
                page.get_by_test_id("settings-story-import-file").set_input_files(str(export_file))
                page.get_by_test_id("settings-story-import-submit").click()
            assert response_info.value.ok, f"Expected 2xx status, but got {response_info.value.status}"

            page.goto(url_for("assess.assess", _external=True))
            expect(page.get_by_test_id("assess")).to_be_visible()
            page.get_by_placeholder("Search stories").fill(imported_story_title)
            page.get_by_placeholder("Search stories").press("Enter")
            imported_story = page.locator(
                "article",
                has=page.get_by_test_id("story-title").filter(has_text=imported_story_title),
            ).first
            expect(imported_story).to_be_visible()

        def revert_to_default_values():
            page.goto(url_for("admin_settings.settings", _external=True))
            tlp_select.select_option("clear")
            collector_proxy_input.fill("")
            expect(collector_interval_input).to_be_visible()
            collector_interval_input.fill("0 */8 * * *")
            rss_entry_limit_input.fill("42")
            story_conflict_input.fill("200")
            news_conflict_input.fill("200")
            with page.expect_response(settings_update_url) as response_info:
                settings_submit.click()
            assert response_info.value.ok, f"Expected 2xx status, but got {response_info.value.status}"

        def test_clear_cache() -> None:
            page.goto(url_for("admin_settings.settings", _external=True))
            page.get_by_role("button", name="Invalidate Cache").click()

        def test_onboarding_controls() -> None:
            reset_admin_onboarding_tours(page)
            page.goto(url_for("admin_settings.settings", _external=True))
            onboarding_switch.uncheck()
            with page.expect_response(settings_update_url) as response_info:
                settings_submit.click()
            assert response_info.value.ok, f"Expected 2xx status, but got {response_info.value.status}"

            page.goto(url_for("admin.dashboard", _external=True))
            expect(page.locator("#onboarding-root")).to_have_count(0)

            page.goto(url_for("admin.users", _external=True))
            page.get_by_role("link", name="admin", exact=True).click()
            page.locator("#user-onboarding-enabled").check()
            page.locator('input[type="submit"]').click()
            expect(page).to_have_url(url_for("admin.users", _external=True))

            page.goto(url_for("admin.dashboard", _external=True))
            expect(page.locator("#onboarding-root")).to_have_count(1)

            page.goto(url_for("admin_settings.settings", _external=True))
            onboarding_switch.check()
            with page.expect_response(settings_update_url) as response_info:
                settings_submit.click()
            assert response_info.value.ok, f"Expected 2xx status, but got {response_info.value.status}"

        go_to_admin_settings()
        check_default_values()
        change_default_values()
        check_new_values()
        exported_stories_file = test_export_all_stories(pre_seed_stories)
        test_export_stories_metadata_time_filter(pre_seed_stories)
        import_stories_from_json(exported_stories_file)
        test_onboarding_controls()
        revert_to_default_values()
        test_clear_cache()

    def test_open_api(self, logged_in_page: Page):
        page = logged_in_page
        page.goto(url_for("admin.dashboard", _external=True))
        with page.expect_popup() as openapi_info:
            self.highlight_element(page.get_by_role("link", name="OpenAPI")).click()
        openapi_page = openapi_info.value
        expect(openapi_page.locator("iframe").content_frame.locator(".info .title").first).to_contain_text("Taranis AI", timeout=15000)
