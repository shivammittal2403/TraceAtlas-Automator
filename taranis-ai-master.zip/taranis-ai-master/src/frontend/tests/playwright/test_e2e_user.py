import json
import re
import uuid

import pytest
from base_e2e_test import BaseE2ETest
from flask import url_for
from htmx_helpers import with_htmx_wait
from playwright.sync_api import Error, Page, expect

from tests.external_e2e import allow_requests_passthru
from tests.playwright.notification_helpers import dismiss_notifications


ASSESS_STORY_PAGE_SIZE = 20


@pytest.mark.e2e_user
@pytest.mark.e2e_ci
@pytest.mark.usefixtures("e2e_ci", "ensure_basic_user_permissions")
class TestEndToEndUser(BaseE2ETest):
    """End-to-end tests for the Taranis AI user interface."""

    CERT_REPORT_TYPE_LABEL = "CERT Report"
    ALL_ATTRIBUTE_REPORT_TYPE_LABEL = "Zzz_All Attribute Types Report"
    ALL_ATTRIBUTE_REQUIRED_REPORT_TYPE_LABEL = f"{ALL_ATTRIBUTE_REPORT_TYPE_LABEL} REQUIRED"

    @staticmethod
    def _get_assess_story_counts(page: Page) -> tuple[int, int]:
        story_count = page.get_by_test_id("assess_story_count")
        count_pattern = re.compile(r"(\d+)\s*/\s*(\d+)")
        expect(story_count).to_contain_text(count_pattern)
        count_text = story_count.inner_text()
        match = count_pattern.search(count_text)
        assert match, f"Unable to parse assess story count from: {count_text!r}"
        return int(match.group(1)), int(match.group(2))

    @staticmethod
    def _get_assess_selection_count(page: Page) -> int:
        count_text = page.get_by_test_id("assess_story_selection_count").inner_text()
        match = re.search(r"(\d+)\s+stories selected", count_text)
        assert match, f"Unable to parse assess story selection count from: {count_text!r}"
        return int(match.group(1))

    def test_login(self, taranis_frontend: Page):
        page = taranis_frontend
        page.context.clear_cookies()
        self.add_keystroke_overlay(page)

        page.goto(url_for("base.login", _external=True))
        expect(page).to_have_title("Taranis AI", timeout=5000)

        self.highlight_element(page.get_by_placeholder("Username"))
        page.get_by_placeholder("Username").fill("user")
        self.highlight_element(page.get_by_placeholder("Password"))
        page.get_by_placeholder("Password").fill("test")
        self.capture_screenshot(page, "./tests/playwright/screenshots/screenshot_login.png")
        self.highlight_element(page.get_by_test_id("login-button")).click()
        expect(page.locator("#dashboard")).to_be_visible()

    def test_analyze_navigation_without_javascript(self, non_admin_logged_in_page: Page):
        browser = non_admin_logged_in_page.context.browser
        assert browser is not None
        context = browser.new_context(java_script_enabled=False)
        context.add_cookies(non_admin_logged_in_page.context.cookies())
        page = context.new_page()

        try:
            page.goto(url_for("analyze.analyze", _external=True))
            expect(page.get_by_test_id("analyze")).to_be_visible()

            search = page.get_by_test_id("report-search-input")
            search.fill("missing report")
            with page.expect_navigation():
                search.press("Enter")
            expect(page).to_have_url(re.compile(r"search=missing(?:\+|%20)report"))
            expect(page.get_by_test_id("analyze")).to_be_visible()

            with page.expect_navigation():
                page.get_by_role("link", name="Title").click()
            expect(page).to_have_url(re.compile(r"order=title_asc"))

            with page.expect_navigation():
                page.get_by_role("link", name="New Report").click()
            expect(page.get_by_role("heading", name="Create Report")).to_be_visible()
        finally:
            context.close()

    def test_user_dashboard(self, non_admin_logged_in_page: Page, forward_console_and_page_errors_non_admin, stories_function_wrapper):
        page = non_admin_logged_in_page

        def test_dashboard_edit_settings(page: Page) -> None:
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            cards = page.get_by_test_id("dashboard-workflow-cards")
            expect(cards.locator(":scope > div")).to_have_count(4)
            assess = page.get_by_test_id("dashboard-assess-card")
            expect(assess).to_contain_text(re.compile(r"There are \d+ news items"))
            expect(assess).to_contain_text(re.compile(r"There are \d+ stories"))
            expect(assess).to_contain_text("This week")
            review = assess.get_by_role("link", name="Start analyst review")
            expect(review).to_have_attribute("title", "Review the current shift's unread Stories and continue through Report to Publish.")
            review.click()
            expect(page).to_have_url(re.compile(r"/analyst-review/start"))
            page.get_by_role("link", name="Dashboard", exact=True).click()

            page.locator("#dashboard").get_by_role("link", name="Assess").click()
            expect(page.get_by_test_id("assess_story_count")).to_be_visible()
            visible_count, total_count = self._get_assess_story_counts(page)
            assert total_count >= visible_count > 0
            assert visible_count == min(ASSESS_STORY_PAGE_SIZE, total_count)
            page.get_by_role("link", name="Dashboard").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            page.locator("#dashboard").get_by_role("link", name="Analyze").click()
            expect(page.get_by_test_id("new-report-button")).to_contain_text("New Report")
            page.get_by_role("link", name="Dashboard").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            page.locator("#dashboard").get_by_role("link", name="Publish").click()
            expect(page.get_by_test_id("new-product-button")).to_contain_text("New Product")
            page.get_by_role("link", name="Dashboard").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            page.get_by_role("link", name="Edit Dashboard").click()
            expect(page.get_by_role("group", name="Recent activity window")).to_be_visible()
            page.get_by_role("checkbox", name="dashboard[show_trending_clusters]").uncheck()
            page.get_by_role("checkbox", name="dashboard[show_charts]").uncheck()
            page.get_by_role("button", name="Update Dashboard Settings").click()
            expect(page.locator("#dashboard").get_by_text("Recently Active Tags")).not_to_be_visible()
            expect(page.get_by_role("main")).to_be_visible()
            page.get_by_role("link", name="Edit Dashboard").click()
            expect(page.get_by_role("group", name="Recent activity window")).to_be_visible()

            page.get_by_role("checkbox", name="dashboard[show_trending_clusters]").check()
            expect(page.get_by_role("checkbox", name="dashboard[show_trending_clusters]")).to_be_visible()
            page.get_by_role("checkbox", name="dashboard[show_charts]").check()
            page.get_by_role("button", name="Update Dashboard Settings").click()
            expect(page.locator("#dashboard")).to_contain_text("Recently Active Tags")
            expect(page.locator("#dashboard")).to_contain_text("counts show total matching stories")
            expect(page.locator("#dashboard")).to_contain_text("Location")

            expect(page.locator("#dashboard")).to_contain_text("Organization")
            expect(page.locator("#dashboard")).to_contain_text("Product")
            expect(page.locator("#dashboard")).to_contain_text("Person")

        def test_dashboard_entity_location_pagination(page: Page) -> None:
            page.get_by_role("link", name="Location").click()
            cluster_table = page.get_by_test_id("cluster-table")

            def click_pagination(label: str) -> None:
                with_htmx_wait(page, lambda: cluster_table.get_by_text(label).dispatch_event("click"))

            expect(page.get_by_test_id("country-chart")).to_be_visible()
            all_rows = cluster_table.locator("tbody tr")
            expect(all_rows.first).to_be_visible()
            expect(all_rows.first).to_contain_text("USA")
            expect(all_rows.first).to_contain_text("6")
            expect(all_rows).to_have_count(20)
            expect(all_rows.nth(19)).to_contain_text("Ambulanz")
            expect(all_rows.nth(19)).to_contain_text("1")
            footer = cluster_table.locator("tfoot")
            expect(footer).to_contain_text("Page 1 of 7")
            click_pagination("›")
            expect(cluster_table.get_by_role("row", name="Page 2")).to_be_visible()
            click_pagination("›")
            expect(cluster_table.get_by_role("row", name="Page 3")).to_be_visible()
            expect(footer).to_contain_text("Page 3 of 7")
            click_pagination("›")
            expect(cluster_table.get_by_role("row", name="Page 4")).to_be_visible()
            click_pagination("›")
            expect(cluster_table.get_by_role("row", name="Page 5")).to_be_visible()
            click_pagination("›")
            expect(cluster_table.get_by_role("row", name="Page 6")).to_be_visible()
            click_pagination("›")
            expect(footer).to_contain_text("Page 7 of 7")
            expect(all_rows).to_have_count(10)
            expect(all_rows.nth(9)).to_contain_text("zu Hause")
            expect(all_rows.nth(9)).to_contain_text("1")
            click_pagination("«")
            expect(footer).to_contain_text("Page 1 of 7")
            expect(cluster_table.locator("tbody")).to_contain_text("USA")
            cluster_table.get_by_role("combobox").click()
            with_htmx_wait(page, lambda: cluster_table.get_by_role("combobox").select_option("5"))
            expect(all_rows).to_have_count(5)
            expect(footer).to_contain_text("Page 1 of 26")

        page.goto(url_for("base.dashboard", _external=True))
        expect(page.locator("#dashboard")).to_be_visible()
        test_dashboard_edit_settings(page)
        test_dashboard_entity_location_pagination(page)

    def test_non_admin_direct_admin_attributes_shows_denied_state(
        self,
        non_admin_logged_in_page: Page,
        forward_console_and_page_errors_non_admin,
    ):
        page = non_admin_logged_in_page

        page.goto(url_for("admin.attributes", _external=True))

        expect(page.get_by_text("403 - Access denied")).to_be_visible()

        assert page.get_by_role("link", name="Administration").count() == 0
        assert page.get_by_test_id("attribute-table").count() == 0

    def test_user_profile(self, non_admin_logged_in_page: Page, forward_console_and_page_errors_non_admin, pre_seed_stories):
        page = non_admin_logged_in_page

        def go_to_user_profile():
            page.goto(url_for("user.settings", _external=True))
            expect(page.get_by_text("User", exact=True)).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/user_profile.png")

        def check_profile():
            expect(page.locator("#user-settings-form")).to_contain_text("Split view")
            expect(page.locator("#user-settings-form")).to_contain_text("Show charts")
            expect(page.locator("#user-settings-form")).to_contain_text("Infinite scroll")
            expect(page.locator("#user-settings-form")).to_contain_text("Compact view")
            expect(page.locator("#user-settings-form")).to_contain_text("Dark theme")
            expect(page.locator("#user-settings-form")).to_contain_text("Advanced story edit options")
            expect(page.locator("#user-settings-form")).to_contain_text("Language")
            expect(page.locator("#user-settings-form")).to_contain_text("End of shift")
            page.locator(".collapse > input").check()
            expect(page.locator("#user-password-form")).to_contain_text("Current password")
            expect(page.locator("#user-password-form")).to_contain_text("New password")
            expect(page.locator("#user-password-form")).to_contain_text("Confirm new password")
            expect(page.get_by_role("button", name="Update password")).to_be_visible()

        def change_password_fail():
            # Wrong current password
            page.get_by_role("textbox", name="Current password").fill("wrong-password")
            page.get_by_role("textbox", name="New password", exact=True).fill("test")
            page.get_by_role("textbox", name="Confirm new password").fill("test")
            page.get_by_role("button", name="Update password").click()
            expect(page.locator("#notification-bar")).to_contain_text("Old password is incorrect")

            # Mismatching new passwords
            page.get_by_role("textbox", name="Current password").fill("test")
            page.get_by_role("textbox", name="New password", exact=True).fill("test1")
            page.get_by_role("textbox", name="Confirm new password").fill("test")
            page.get_by_role("button", name="Update password").click()
            expect(page.locator("#notification-bar")).to_contain_text("New password and confirm password do not match")

        def change_password():
            page.get_by_role("textbox", name="Current password").fill("test")
            page.get_by_role("textbox", name="New password", exact=True).fill("test1")
            page.get_by_role("textbox", name="Confirm new password").fill("test1")
            page.get_by_role("button", name="Update password").click()
            expect(page.locator("#notification-bar")).to_contain_text("Password changed successfully")

        def test_user_profile_settings_adjustments():
            user_settings_url = url_for("user.settings", _external=True)

            page.get_by_role("checkbox", name="Infinite scroll Automatically").uncheck()
            page.get_by_role("checkbox", name="Compact view Use condensed").check()
            with page.expect_response(lambda response: response.request.method == "POST" and response.url == user_settings_url):
                page.get_by_role("button", name="Save changes").click()
            page.get_by_role("link", name="Assess").click()

            with_htmx_wait(page, lambda: page.get_by_role("link", name="Next").click())
            expect(page.locator("#assess-top-bar")).to_be_visible()
            expect(page.get_by_test_id("assess_story_count")).to_be_visible()
            expect(page.locator("#story-pagination")).to_contain_text("Page 2 of")
            page.wait_for_function("() => window.scrollY === 0")

            with_htmx_wait(page, page.go_back)
            expect(page.locator("#story-pagination")).to_contain_text("Page 1 of")

            with page.expect_navigation(wait_until="load"):
                page.get_by_role("checkbox", name="Compact view").uncheck()
            expect(page.get_by_test_id("assess")).to_be_visible()
            expect(page.get_by_test_id("user-menu-button")).to_have_count(1)

            page.get_by_test_id("user-menu-button").click()
            expect(page.get_by_role("link", name="Profile")).to_be_visible()

            page.get_by_role("link", name="User Settings").click()
            page.get_by_role("checkbox", name="Infinite scroll Automatically").check()
            page.get_by_role("checkbox", name="Compact view Use condensed").uncheck()
            with page.expect_response(lambda response: response.request.method == "POST" and response.url == user_settings_url):
                page.get_by_role("button", name="Save changes").click()

        def relog_in():
            page.get_by_test_id("user-menu-button").click()
            expect(page.get_by_role("link", name="Profile")).to_be_visible()

            page.get_by_role("link", name="Logout").click()
            expect(page.get_by_role("img", name="Taranis Logo")).to_be_visible()

            page.get_by_role("textbox", name="Username").fill("user")
            page.get_by_role("textbox", name="Username").press("Tab")
            page.get_by_role("textbox", name="Password").fill("test1")
            page.get_by_test_id("login-button").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

        def change_password_back():
            page.get_by_test_id("user-menu-button").click()
            expect(page.get_by_role("link", name="Profile")).to_be_visible()

            page.get_by_role("link", name="User Settings").click()
            expect(page.get_by_role("link", name="Taranis AI Logo")).to_be_visible()

            page.locator(".collapse > input").check()
            page.get_by_role("textbox", name="Current password").fill("test1")
            page.get_by_role("textbox", name="New password", exact=True).fill("test")
            page.get_by_role("textbox", name="New password", exact=True).press("Tab")
            page.get_by_role("textbox", name="Confirm new password").fill("test")
            page.get_by_role("button", name="Update password").click()
            expect(page.locator("#notification-bar")).to_contain_text("Password changed successfully")

        go_to_user_profile()
        check_profile()
        change_password_fail()
        change_password()
        test_user_profile_settings_adjustments()
        relog_in()
        change_password_back()

    def test_user_assess(self, non_admin_logged_in_page: Page, forward_console_and_page_errors_non_admin, pre_seed_stories):
        page = non_admin_logged_in_page

        def go_to_assess():
            page.goto(url_for("assess.assess", _external=True))
            expect(page.get_by_test_id("assess")).to_be_visible()
            expect(page.get_by_test_id("assess_story_count")).to_be_visible(timeout=30000)
            visible_count, total_count = self._get_assess_story_counts(page)
            assert total_count >= visible_count > 0
            self.capture_screenshot(page, "./tests/playwright/screenshots/user_assess.png")
            return total_count

        def access_story():
            target_title = pre_seed_stories[0]["title"]
            search = page.get_by_placeholder("Search stories")
            search.fill(target_title)
            expect(page.locator("#story-list article[data-story-id]")).to_have_count(1)
            with_htmx_wait(page, search.blur)

            story = page.locator("article", has=page.get_by_test_id("story-title").filter(has_text=target_title)).first
            expect(story).to_be_visible()
            story_id = story.get_attribute("data-story-id")
            assert story_id, "Expected story card to expose a story id"

            def story_card():
                return page.locator(f'article[data-story-id="{story_id}"]')

            menu = story_card().get_by_test_id("story-actions-menu")
            expect(menu).to_be_attached()
            expect(menu).to_be_visible()
            expect(menu).to_be_enabled()
            title = story_card().locator("h2[data-testid='story-title']").inner_text()
            edited_title = f"{title} edited title"

            story_card().get_by_test_id("toggle-summary").click()
            story_card().get_by_test_id("story-actions-menu").click()
            with_htmx_wait(page, story_card().get_by_test_id("toggle-read").click)
            story_card().get_by_test_id("story-actions-menu").click()
            with_htmx_wait(page, story_card().get_by_test_id("toggle-important").click)
            story_card().get_by_test_id("story-actions-menu").click()
            share_story = story_card().get_by_test_id("share-story")
            assess_url = page.url
            with_htmx_wait(page, share_story.click)
            dialog = page.locator("#share_story_to_connector_dialog")
            expect(dialog).to_be_visible()
            expect(page).to_have_url(assess_url)
            dialog.get_by_role("button", name="✕").click()
            story_card().get_by_test_id("open-detail-view").click()
            expect(page.get_by_test_id("story-title")).to_contain_text(title)
            page.get_by_test_id("edit-story").click()
            page.get_by_role("textbox", name="Title").fill(edited_title)
            page.get_by_role("textbox", name="Summary").fill("Test summary")
            page.get_by_role("textbox", name="Analyst comments").fill("Test analyst comment")
            news_item_card = page.locator("article[id^='news-item-card-']").first
            news_item_card.get_by_test_id("edit-newsitem-tags").click()
            expect(news_item_card.get_by_role("heading", name="News item tags")).to_be_in_viewport()
            news_item_card.get_by_test_id("news-item-tag-name-input").fill("tag name")
            news_item_card.get_by_test_id("news-item-tag-value-input").fill("tag value")
            news_item_card.get_by_role("button", name="Add tag").click()
            news_item_card.get_by_test_id("news-item-tag-name-input").nth(1).fill("tag 2")
            news_item_card.get_by_test_id("news-item-tag-value-input").nth(1).fill("value2")
            page.get_by_role("button", name="Save tags").click()
            page.get_by_role("button", name="Add attribute").click()
            page.get_by_test_id("attribute-key-input").nth(1).fill("attr")
            page.get_by_test_id("attribute-value-input").nth(1).fill("value attr")
            page.get_by_role("button", name="Save changes").click()
            page.get_by_role("link", name="Advanced").click()
            expect(page.get_by_role("complementary")).to_contain_text("Story status")
            page.get_by_text("Cybersecurity · Not Classified").click()
            expect(page.get_by_role("complementary")).to_contain_text("Cybersecurity · Not Classified")
            expect(page.get_by_role("complementary")).to_contain_text("AI assisted actions")
            expect(page.get_by_role("complementary")).to_contain_text("Generate summary & title")
            expect(page.get_by_role("complementary")).to_contain_text("Run sentiment analysis")
            expect(page.get_by_role("complementary")).to_contain_text("Cybersecurity classification")
            page.get_by_role("link", name="Return to story").click()
            expect(page.get_by_test_id("story-title")).to_contain_text(edited_title)

        def infinite_scroll_all_items(expected_total: int):
            page.goto(url_for("assess.assess", _external=True))

            expect(page.get_by_test_id("assess")).to_be_visible()
            initial_visible_count, initial_total = self._get_assess_story_counts(page)
            assert initial_total == expected_total
            assert initial_visible_count > 0
            final_visible_count = initial_visible_count
            for _ in range(6):
                load_more_button = page.locator("#infinite-scroll-trigger")
                if load_more_button.count() == 0:
                    break
                previous_card_count = page.locator("#story-list article[data-story-id]").count()
                load_more_button.dispatch_event("click")
                page.wait_for_function(
                    "previous => document.querySelectorAll('#story-list article[data-story-id]').length > previous",
                    arg=previous_card_count,
                )
                self.wait_for_htmx_settled(page)
                final_visible_count, final_total = self._get_assess_story_counts(page)
                assert final_total == expected_total
                assert final_visible_count >= initial_visible_count
                if final_visible_count >= expected_total:
                    break

            final_visible_count, final_total = self._get_assess_story_counts(page)
            assert final_total == expected_total
            assert final_visible_count >= expected_total

            caught_up_message = page.get_by_text("You're all caught up.")
            if caught_up_message.count():
                expect(caught_up_message).to_be_visible()

            expect(page.get_by_test_id("assess_story_selection_count")).to_be_hidden()
            page.get_by_role("button", name="Select all").click()
            expect(page.get_by_test_id("assess_story_selection_count")).to_contain_text("stories selected")
            selected_count = self._get_assess_selection_count(page)
            assert expected_total <= selected_count <= final_visible_count
            page.get_by_role("button", name="Clear selection Esc").click()
            expect(page.get_by_test_id("assess_story_selection_count")).to_be_hidden()

        total_count = go_to_assess()
        access_story()
        infinite_scroll_all_items(total_count)

        # Keep the primary selection and reuse it in the next clustering action.
        cards = page.locator("#story-list article[data-story-id]")
        primary_id, second_id, third_id = [cards.nth(i).get_attribute("data-story-id") for i in range(3)]
        page.get_by_test_id(f"story-card-{primary_id}").click()
        for secondary_id in (second_id, third_id):
            page.get_by_test_id(f"story-card-{secondary_id}").click()
            page.get_by_role("button", name="Cluster").click()
            expect(page.get_by_test_id("story-to-merge")).to_have_count(2)
            page.get_by_test_id("dialog-story-cluster-submit").click()
            expect(page.get_by_test_id("story-to-merge")).to_have_count(0)
            expect(page.get_by_test_id("assess_story_selection_count")).to_have_text("1 stories selected")
            expect(page.get_by_test_id(f"story-card-{primary_id}")).to_have_attribute("aria-selected", "true")
            expect(page.get_by_test_id(f"story-card-{secondary_id}")).to_have_count(0)

    def test_news_item_order(self, non_admin_logged_in_page, forward_console_and_page_errors_non_admin, core_request_client):
        page = non_admin_logged_in_page
        allow_requests_passthru()
        created_ids = []
        try:
            for index in range(2):
                suffix = str(uuid.uuid4())
                result = core_request_client.json_request(
                    "POST",
                    "/assess/news-items",
                    json_data={
                        "title": f"Ordered item {index}",
                        "content": f"Ordering test {suffix}",
                        "source": "manual",
                        "osint_source_id": "manual",
                        "link": f"https://example.invalid/{suffix}",
                    },
                )
                created_ids.append(result["story_id"])
            core_request_client.post("/assess/stories/group", json_data=created_ids)
            story_id = created_ids[0]
            page.goto(url_for("assess.story_edit", story_id=story_id, _external=True))
            order_panel = page.locator("#news-item-order")
            rows = order_panel.locator("[data-order-item]")
            expect(rows).to_have_count(2)
            original_order = rows.evaluate_all("rows => rows.map(row => row.dataset.orderItem)")
            page.get_by_role("textbox", name="Summary").fill("Unsaved analyst draft")
            rows.nth(1).locator("[data-order-handle]").drag_to(rows.nth(0).locator("[data-order-handle]"))
            expect(rows.first).to_have_attribute("data-order-item", original_order[1])
            order_panel.get_by_test_id("save-news-item-order").click()
            expect(page.locator("#news-item-order-status")).to_have_text("News item order saved")
            expect(page.get_by_role("textbox", name="Summary")).to_have_value("Unsaved analyst draft")
            page.reload()
            expect(rows.first).to_have_attribute("data-order-item", original_order[1])

            rows.first.get_by_role("button", name="down", exact=False).focus()
            page.keyboard.press("Enter")
            expect(rows.first).to_have_attribute("data-order-item", original_order[0])
            order_panel.get_by_test_id("save-news-item-order").click()
            expect(page.locator("#news-item-order-status")).to_have_text("News item order saved")

            allow_requests_passthru()
            core_request_client.put(
                f"/assess/stories/{story_id}/news-item-order",
                json_data={"news_item_ids": list(reversed(original_order)), "expected_news_item_ids": original_order},
            )
            rows.first.get_by_role("button", name="down", exact=False).click()
            with page.expect_response(lambda response: response.url.endswith("/news-item-order") and response.status == 409):
                order_panel.get_by_test_id("save-news-item-order").click()
            expect(page.locator("#news-item-order-status")).to_contain_text("News items changed")
            order_panel.get_by_role("button", name="Reload news items").click()
            expect(order_panel.get_by_test_id("save-news-item-order")).to_be_disabled()
            expect(rows.first).to_have_attribute("data-order-item", original_order[1])

            core_request_client.patch(
                f"/assess/stories/{story_id}",
                json_data={"attributes": [{"key": "rt_id", "value": "123"}]},
            )
            page.reload()
            expect(page.get_by_text("This story is read-only.", exact=True)).to_be_visible()
            expect(page.get_by_role("textbox", name="Summary")).to_be_disabled()
            expect(page.get_by_role("button", name="Save changes", exact=True)).to_be_disabled()
            expect(order_panel.get_by_test_id("save-news-item-order")).to_have_count(0)
            expect(order_panel.get_by_test_id("edit-newsitem-tags")).to_have_count(0)
        finally:
            allow_requests_passthru()
            for created_id in created_ids:
                core_request_client.delete(f"/assess/stories/{created_id}", raise_for_status=False)

    def test_story_export(
        self,
        non_admin_logged_in_page: Page,
        forward_console_and_page_errors_non_admin,
        pre_seed_stories,
        news_items_list: list[dict],
    ):
        page = non_admin_logged_in_page
        expected_story = news_items_list[0]
        expected_title = expected_story["title"]
        possible_story_titles = {expected_title, f"{expected_title} edited title"}
        expected_news_item_title = expected_story["title"]

        page.goto(url_for("assess.assess", _external=True))
        expect(page.get_by_test_id("assess")).to_be_visible()

        page.get_by_placeholder("Search stories").fill(expected_title)
        with_htmx_wait(page, lambda: page.get_by_placeholder("Search stories").press("Enter"))

        story = page.locator("article", has=page.get_by_test_id("story-title").filter(has_text=expected_title)).first
        expect(story).to_be_visible()
        story_title = story.get_by_test_id("story-title").inner_text()
        assert story_title in possible_story_titles
        story_id = story.get_attribute("data-story-id")
        assert story_id, "Expected story card to expose a story id"

        story = page.locator(f'article[data-story-id="{story_id}"]')

        actions_menu = story.get_by_test_id("story-actions-menu")
        share_story = story.get_by_test_id("share-story")
        actions_menu.focus()
        expect(actions_menu).to_be_focused()
        expect(share_story).to_be_visible()
        with_htmx_wait(page, share_story.click)

        dialog = page.locator("#share_story_to_connector_dialog")
        expect(dialog).to_be_visible()
        expect(dialog.get_by_role("link", name="Export to JSON")).to_be_visible()

        with page.expect_download() as download_info:
            dialog.get_by_role("link", name="Export to JSON").click()

        download = download_info.value
        assert download.suggested_filename.startswith("stories_export_")
        assert download.suggested_filename.endswith(".json")

        download_path = download.path()
        with open(download_path, "r", encoding="utf-8") as f:
            downloaded_content = json.load(f)

        assert downloaded_content["total_count"] == 1
        assert len(downloaded_content["items"]) == 1
        exported_story = downloaded_content["items"][0]
        assert exported_story["title"] in possible_story_titles
        assert len(exported_story["news_items"]) >= 1
        assert exported_story["news_items"][0]["title"] == expected_news_item_title
        assert "attributes" in exported_story
        assert any(attribute["key"] == "TLP" for attribute in exported_story["attributes"])
        assert not {"detail_view", "in_reports_count", "news_item_order", "can_edit"} & exported_story.keys()

    def test_user_analyze(
        self,
        non_admin_logged_in_page: Page,
        forward_console_and_page_errors_non_admin,
        pre_seed_report_stories,
        pre_seed_report_type_all_attribute_types_optional,
        pre_seed_report_type_all_attribute_types_required,
    ):
        page = non_admin_logged_in_page
        report_story_one, report_story_two = pre_seed_report_stories
        story_search_term = " ".join(report_story_one["title"].split()[:2])
        story_search_term_lower = story_search_term.lower()
        report_story_two_primary_link = report_story_two["news_items"][0]["link"]
        report_uuid = ""

        def go_to_analyze():
            page.goto(url_for("analyze.analyze", _external=True))
            expect(page.get_by_test_id("analyze")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/user_analyze.png")

        def open_assess_filtered(search_term: str):
            page.goto(url_for("assess.assess", _external=True, search=search_term))
            expect(page.get_by_test_id("assess")).to_be_visible(timeout=30000)
            expect(page.get_by_test_id("assess_story_count")).to_be_visible(timeout=30000)
            expect(page.get_by_placeholder("Search stories")).to_have_value(search_term, timeout=30000)

        def select_report_stories_from_assess(search_term: str):
            open_assess_filtered(search_term)

            first_story = page.get_by_test_id(f"story-card-{report_story_one['id']}")
            second_story = page.get_by_test_id(f"story-card-{report_story_two['id']}")
            expect(first_story).to_be_visible()
            expect(second_story).to_be_visible()

            first_story.click()
            expect(page.get_by_test_id("assess_story_selection_count")).to_contain_text("stories selected")
            assert self._get_assess_selection_count(page) == 1

            second_story.click()
            expect(page.get_by_test_id("assess_story_selection_count")).to_contain_text("stories selected")
            assert self._get_assess_selection_count(page) == 2
            expect(page.get_by_role("button", name="Cluster")).to_be_visible()

        def check_report_type_required():
            report_type = page.get_by_test_id("report-type-select")
            expect(report_type).to_have_attribute("required", "")
            page.get_by_test_id("save-report").click()
            expect(report_type).to_be_focused()
            assert report_type.evaluate("select => select.validity.valueMissing")
            expect(page.get_by_role("heading", name="Create Report")).to_be_visible()

        def check_report_view_layout_changes():
            page.get_by_test_id("new-report-button").click()
            expect(page.get_by_role("heading", name="Create Report")).to_be_visible()

            page.get_by_role("textbox", name="Title").fill("test title")
            check_report_type_required()
            page.get_by_test_id("report-type-select").select_option(label=self.CERT_REPORT_TYPE_LABEL)
            page.get_by_role("button", name="Stacked view").click()
            expect(page).to_have_url(re.compile(r"layout=stacked"))
            expect(page.get_by_role("textbox", name="Title")).to_have_value("test title")
            expect(page.get_by_test_id("report-type-select")).not_to_have_value("")
            page.get_by_role("button", name="Split view").click()
            expect(page).to_have_url(re.compile(r"layout=split"))
            expect(page.get_by_role("textbox", name="Title")).to_have_value("test title")
            expect(page.get_by_test_id("report-type-select")).not_to_have_value("")
            page.get_by_test_id("save-report").click()
            expect(page.get_by_role("button", name="Completed")).to_be_visible()
            expect(page.get_by_role("button", name="Incomplete")).to_be_visible()
            expect(page.get_by_test_id("report-new-product")).to_be_visible()
            expect(page.get_by_placeholder("Date")).to_be_visible()
            expect(page.get_by_placeholder("Timeframe")).to_be_visible()
            expect(page.get_by_placeholder("Handler", exact=True)).to_be_visible()
            expect(page.get_by_placeholder("CO-Handler")).to_be_visible()
            expect(page.get_by_role("searchbox", name="news")).to_be_visible()
            expect(page.get_by_role("searchbox", name="vulnerabilities")).to_be_visible()
            page.get_by_placeholder("Date").fill("today")
            page.get_by_placeholder("Timeframe").fill("last week")
            page.get_by_placeholder("Handler", exact=True).fill("me")
            page.get_by_placeholder("CO-Handler").fill("you")
            page.get_by_test_id("save-report").click()
            page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
            dismiss_notifications(page)
            page.get_by_placeholder("Date").fill("yesterday")
            page.get_by_role("button", name="Stacked view").click()
            expect(page).to_have_url(re.compile(r"layout=stacked"))
            expect(page.get_by_placeholder("Date")).to_have_value("yesterday")
            page.get_by_role("button", name="Split view").click()
            expect(page).to_have_url(re.compile(r"layout=split"))
            expect(page.get_by_placeholder("Date")).to_have_value("yesterday")
            expect(page.get_by_role("button", name="Completed")).to_be_visible()
            expect(page.get_by_role("button", name="Incomplete")).to_be_visible()
            expect(page.get_by_test_id("report-new-product")).to_be_visible()

        def delete_test_report():
            page.get_by_role("link", name="Analyze").click()
            item_id = self.get_table_row_id_by_link_text(page, "report-table", "test title")
            delete_button_test_id = f"action-delete-{item_id}"
            self.delete_table_row(page, delete_button_test_id)

        def create_report():
            select_report_stories_from_assess(story_search_term)
            page.get_by_role("button", name="Add to Report").click()
            page.get_by_test_id("new-report-button-dialog").click()
            page.get_by_role("textbox", name="Title").fill("Unsaved report from Assess")
            selected_stories = page.locator('#report_form input[name="stories[]"]')
            story_ids = selected_stories.evaluate_all("inputs => inputs.map(input => input.value)")
            assert story_ids
            check_report_type_required()
            expect(page.get_by_role("textbox", name="Title")).to_have_value("Unsaved report from Assess")
            assert selected_stories.evaluate_all("inputs => inputs.map(input => input.value)") == story_ids
            page.get_by_role("link", name="Analyze", exact=True).click()
            new_report_button = page.get_by_role("link", name="New Report")
            expect(new_report_button).to_be_visible()
            new_report_button.click()
            page.get_by_role("textbox", name="Title").fill("Test report")
            page.get_by_test_id("report-type-select").select_option(label=self.CERT_REPORT_TYPE_LABEL)
            expect(page.locator("#report_form")).to_contain_text("Attributes will be generated after the report item has been created.")
            expect(page.get_by_test_id("analyze").locator("section")).to_contain_text("No stories assigned to this report.")
            page.get_by_test_id("save-report").click()
            page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
            dismiss_notifications(page)
            page.get_by_placeholder("Date").fill("1.1.2000")
            page.get_by_placeholder("Timeframe").fill("January")
            page.get_by_placeholder("Handler", exact=True).fill("Kluger")
            page.get_by_placeholder("CO-Handler").fill("Mensch")
            page.get_by_test_id("save-report").click()
            report_uuid = page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
            dismiss_notifications(page)
            return report_uuid

        def check_report_list_filters():
            filter_prefix = f"filter-report-{uuid.uuid4().hex[:8]}"
            completed_title = f"{filter_prefix}-complete"
            incomplete_title = f"{filter_prefix}-incomplete"

            def delete_filtered_report(title: str):
                item_id = self.get_table_row_id_by_link_text(page, "report-table", title)
                self.delete_table_row(page, f"action-delete-{item_id}")
                dismiss_notifications(page)

                page.get_by_role("link", name="Analyze").click()
                refreshed_search = page.get_by_test_id("report-search-input")
                refreshed_search.fill(filter_prefix)
                expect(page).to_have_url(re.compile(rf"search={filter_prefix}"))
                expect(page.get_by_test_id("report-table").get_by_role("link", name=title, exact=True)).not_to_be_visible()

            def create_filter_report(title: str, report_type_label: str, completed: bool = False):
                page.get_by_role("link", name="Analyze").click()
                page.get_by_test_id("new-report-button").click()
                expect(page.get_by_role("heading", name="Create Report")).to_be_visible()
                page.get_by_role("textbox", name="Title").fill(title)
                page.get_by_test_id("report-type-select").select_option(label=report_type_label)
                page.get_by_test_id("save-report").click()
                dismiss_notifications(page)
                if completed:
                    page.get_by_role("button", name="Completed").click()
                    completed_class = page.get_by_role("button", name="Completed").get_attribute("class") or ""
                    assert "btn-active" in completed_class, f"Expected Completed button to be active, got {completed_class!r}"
                    dismiss_notifications(page)

            create_filter_report(completed_title, self.CERT_REPORT_TYPE_LABEL, completed=True)
            create_filter_report(incomplete_title, self.ALL_ATTRIBUTE_REPORT_TYPE_LABEL)

            page.get_by_role("link", name="Analyze").click()
            search_input = page.get_by_test_id("report-search-input")
            completed_filter = page.get_by_test_id("report-completed-filter")
            report_type_filter = page.get_by_test_id("report-type-filter")
            reset_button = page.get_by_test_id("reset-report-filters")

            search_input.fill(filter_prefix)
            self.wait_for_htmx_settled(page)
            expect(page).to_have_url(re.compile(rf"search={filter_prefix}"))
            expect(page.get_by_test_id("report-table").get_by_role("link", name=completed_title, exact=True)).to_be_visible()
            expect(page.get_by_test_id("report-table").get_by_role("link", name=incomplete_title, exact=True)).to_be_visible()

            with_htmx_wait(page, lambda: completed_filter.select_option("false"))
            expect(page).to_have_url(
                re.compile(rf"/analyze.*search={filter_prefix}.*completed=false|/analyze.*completed=false.*search={filter_prefix}")
            )
            expect(page.get_by_test_id("report-table").get_by_role("link", name=incomplete_title, exact=True)).to_be_visible()
            expect(page.get_by_test_id("report-table").get_by_role("link", name=completed_title, exact=True)).not_to_be_visible()

            with_htmx_wait(page, lambda: completed_filter.select_option("true"))
            expect(page.get_by_test_id("report-table").get_by_role("link", name=completed_title, exact=True)).to_be_visible()
            expect(page.get_by_test_id("report-table").get_by_role("link", name=incomplete_title, exact=True)).not_to_be_visible()

            with_htmx_wait(page, lambda: completed_filter.select_option(""))
            expect(page).to_have_url(re.compile(r"completed="))
            expect(page).to_have_url(re.compile(r"report_item_type_id="))
            report_type_filter = page.get_by_test_id("report-type-filter")
            expect(report_type_filter).to_have_value("")
            all_attribute_report_type_value = report_type_filter.evaluate(
                """(select, label) => {
                    const option = Array.from(select.options).find((item) => item.text.trim() === label);
                    return option ? option.value : null;
                }""",
                self.ALL_ATTRIBUTE_REPORT_TYPE_LABEL,
            )
            assert all_attribute_report_type_value is not None
            with_htmx_wait(page, lambda: report_type_filter.select_option(label=self.ALL_ATTRIBUTE_REPORT_TYPE_LABEL))
            expect(page).to_have_url(re.compile(rf"report_item_type_id={all_attribute_report_type_value}"))
            expect(page.get_by_test_id("report-table").get_by_role("link", name=incomplete_title, exact=True)).to_be_visible()
            expect(page.get_by_test_id("report-table").get_by_role("link", name=completed_title, exact=True)).not_to_be_visible()

            with_htmx_wait(page, lambda: reset_button.click())
            expect(search_input).to_have_value("")
            expect(completed_filter).to_have_value("")
            expect(report_type_filter).to_have_value("")
            expect(page).not_to_have_url(re.compile(r"(search=|completed=|report_item_type_id=)"))

            search_input.fill(filter_prefix)
            self.wait_for_htmx_settled(page)
            expect(page).to_have_url(re.compile(rf"search={filter_prefix}"))
            expect(page.get_by_test_id("report-table").get_by_role("link", name=completed_title, exact=True)).to_be_visible()
            expect(page.get_by_test_id("report-table").get_by_role("link", name=incomplete_title, exact=True)).to_be_visible()
            delete_filtered_report(completed_title)
            delete_filtered_report(incomplete_title)

        def add_stories_to_report():
            select_report_stories_from_assess(story_search_term)
            page.get_by_role("button", name="Add to Report").click()
            popup = page.get_by_label("Add Stories to report")
            popup.click()
            popup.get_by_text("Test report").click()
            page.locator("#share_story_to_report_dialog").get_by_role("button", name="Share").click()
            expect(page.get_by_text("In Reports").nth(1)).to_be_visible()
            expect(page.get_by_text("In Reports").nth(2)).to_be_visible()

        def verify_report_actions(report_uuid: str):
            def test_report_item_view():
                page.get_by_role("link", name="Analyze").click()
                page.get_by_role("link", name="Test report").click()
                expect(page.get_by_role("paragraph")).to_contain_text("test summary")

            def test_remove_story_from_report():
                page.get_by_role("link", name="Analyze").click()
                page.get_by_role("link", name="Test report").click()
                page.get_by_test_id(f"remove-story-{report_story_one['id']}").click()

            def test_story_in_report_assess_view():
                page.get_by_role("link", name="Assess").click()
                page.get_by_placeholder("Search stories").fill(story_search_term_lower)
                page.get_by_placeholder("Search stories").press("Enter")
                expect(page.get_by_test_id("assess").get_by_text("In Reports")).to_be_visible()  # only one should be in a report now

            def test_create_product_from_report():
                page.get_by_role("link", name="Analyze").click()
                page.get_by_test_id(f"action-edit-{report_uuid}").click()
                page.get_by_test_id("report-publish-button").click()
                expect(page.get_by_test_id("report-publish-dialog")).to_be_visible()
                page.get_by_test_id("report-new-product-button").click()
                expect(page.get_by_role("heading", name="Create Product")).to_be_visible()
                expect(page.get_by_text("Create Product").first).to_be_visible()

            def test_clone_and_delete_report():
                page.get_by_role("link", name="Analyze").click()
                report_links = page.get_by_test_id("report-table").get_by_role("link", name=re.compile(r"^Test report"))
                existing_report_count = report_links.count()
                existing_report_hrefs = {
                    href for href in report_links.evaluate_all("(links) => links.map((link) => link.getAttribute('href')).filter(Boolean)")
                }
                page.get_by_test_id(f"action-clone-report-{report_uuid}").click()
                expect(report_links).to_have_count(existing_report_count + 1)
                expect(page.locator("#report")).to_have_count(1)
                expect(page.locator("#report-table-container")).to_have_count(1)
                current_hrefs = report_links.evaluate_all("(links) => links.map((link) => link.getAttribute('href')).filter(Boolean)")
                new_hrefs = [href for href in current_hrefs if href not in existing_report_hrefs]
                assert len(new_hrefs) == 1
                clone_report_href = new_hrefs[0]
                cloned_report_uuid = clone_report_href.split("/")[-1]
                assert self.is_uuid7(cloned_report_uuid), f"Expected a valid UUIDv7, got {cloned_report_uuid}"
                cloned_report = page.get_by_test_id("report-table").locator(f'a[href="{clone_report_href}"]').first
                cloned_report_title = cloned_report.inner_text().strip()
                item_id = self.get_table_row_id_by_link_text(page, "report-table", cloned_report_title)
                delete_button_test_id = f"action-delete-{item_id}"
                self.delete_table_row(page, delete_button_test_id)
                expect(page.locator("#report")).to_have_count(1)
                expect(page.locator("#report-table-container")).to_have_count(1)
                page.get_by_role("link", name="Test report").click()
                expect(page.get_by_test_id("report-stories").get_by_role("link", name=report_story_two["title"])).to_be_visible()
                expect(page.get_by_test_id(f"story-link-{report_story_two['id']}")).to_contain_text(report_story_two_primary_link)
                report_uuid_2 = page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
                return report_uuid_2

            def cleanup_reports(report_uuid_2: str):
                page.get_by_role("link", name="Analyze").click()
                report_row = (
                    page.get_by_test_id("report-table")
                    .locator("tbody tr")
                    .filter(has=page.get_by_role("link", name="Test report", exact=True))
                )
                report_row.get_by_role("checkbox").check()
                page.get_by_test_id("delete-report-button").click()
                with_htmx_wait(page, lambda: page.locator(".swal2-confirm").click())
                expect(report_row).to_have_count(0)
                expect(page.locator("#report")).to_have_count(1)
                expect(page.locator("#report-table-container")).to_have_count(1)

            test_report_item_view()
            test_remove_story_from_report()
            test_story_in_report_assess_view()
            test_create_product_from_report()
            report_uuid_2 = test_clone_and_delete_report()
            cleanup_reports(report_uuid_2)

        def check_various_report_type_fields():
            def create_new_report():
                page.get_by_test_id("new-report-button").click()
                expect(page.get_by_role("heading", name="Create Report")).to_be_visible()
                page.get_by_role("textbox", name="Title").fill("all attr report")
                page.get_by_test_id("report-type-select").select_option(label=self.ALL_ATTRIBUTE_REPORT_TYPE_LABEL)
                page.get_by_test_id("save-report").click()
                page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
                dismiss_notifications(page)

                expect(page.get_by_role("searchbox", name="Related Story")).to_be_visible()
                expect(page.get_by_placeholder("STRING field")).to_be_visible()
                expect(page.get_by_placeholder("NUMBER field")).to_be_visible()
                expect(page.get_by_role("group", name="Boolean")).to_be_visible()
                expect(page.get_by_role("group", name="Confidentiality (Radio)")).to_be_visible()
                expect(page.get_by_text("Impact (Enum)")).to_be_visible()
                expect(page.get_by_role("heading", name="Narrative and Timing")).to_be_visible()
                expect(page.get_by_placeholder("TEXT field", exact=True)).to_be_visible()
                expect(page.get_by_placeholder("RICH_TEXT field")).to_be_visible()
                expect(page.get_by_role("textbox", name="Date", exact=True)).to_be_visible()
                expect(page.get_by_role("textbox", name="Time", exact=True)).to_be_visible()
                expect(page.get_by_role("textbox", name="Date Time")).to_be_visible()
                expect(page.get_by_role("textbox", name="Date", exact=True)).to_have_attribute("type", "date")
                expect(page.get_by_role("textbox", name="Time", exact=True)).to_have_attribute("type", "time")
                expect(page.get_by_role("textbox", name="Date Time")).to_have_attribute("type", "datetime-local")
                expect(page.get_by_label("TLP Level Clear Green Amber")).to_be_visible()
                expect(page.get_by_role("heading", name="Technical References and")).to_be_visible()
                expect(page.get_by_text('Unsupported attribute type "')).to_be_visible()
                expect(page.get_by_text("Attachment editing is not yet")).to_be_visible()
                expect(page.get_by_label("CPE Select an option")).to_be_visible()
                expect(page.get_by_placeholder("CVE field")).to_be_visible()
                expect(page.get_by_placeholder("CVSS field")).to_be_visible()
                page.get_by_test_id("save-report").click()
                expect(page.get_by_test_id("save-report")).to_be_visible()
                dismiss_notifications(page)

            def add_stories_to_new_report():
                select_report_stories_from_assess(story_search_term)
                page.get_by_role("button", name="Add to Report").click()
                popup = page.get_by_label("Add Stories to report")
                popup.click()
                popup.get_by_text("all attr report").click()
                page.locator("#share_story_to_report_dialog").get_by_role("button", name="Share").click()

            def set_report_fields():
                boolean_attribute = page.get_by_test_id("report-boolean-attribute-checkbox")
                page.get_by_role("link", name="Analyze").click()
                expect(page.get_by_role("row", name="all attr report")).to_be_visible()

                page.get_by_role("link", name="all attr report").click()
                page.locator(".choices__inner").click()
                page.get_by_role("option", name="Report Story 1 Add Story").click()
                expect(page.get_by_role("option", name="Report Story 1 Remove item:")).to_be_visible()
                page.locator(".choices__inner").click()
                page.get_by_role("option", name="Report Story 2 Add Story").click()
                page.keyboard.press("Escape")  # press esc  key to close the dropdown

                page.get_by_placeholder("STRING field").click()
                page.get_by_placeholder("STRING field").fill("string")
                page.get_by_placeholder("NUMBER field").click()
                page.get_by_placeholder("NUMBER field").fill("111")
                expect(boolean_attribute).to_be_visible()
                boolean_attribute.check()
                page.get_by_role("radio", name="UNRESTRICTED").check()
                page.get_by_label("Impact (Enum) Select an").select_option("Malicious code execution affecting CIA of the system")
                page.get_by_placeholder("TEXT field", exact=True).click()
                page.get_by_placeholder("TEXT field", exact=True).fill("text")
                page.get_by_placeholder("RICH_TEXT field").click()
                page.get_by_placeholder("RICH_TEXT field").fill("rich text")
                page.get_by_role("textbox", name="Date", exact=True).fill("2026-02-05")
                page.get_by_role("textbox", name="Time", exact=True).fill("11:11")
                page.get_by_role("textbox", name="Date Time").fill("2026-02-05T11:11")
                # page.get_by_label("TLP Level Clear Green Amber").select_option("red")
                page.locator("div").filter(has_text="Stories Remove all Report").nth(4).click()
                page.get_by_placeholder("CVE field").fill("CVE-2026-24888")
                page.get_by_placeholder("CVSS field").fill("1")
                page.get_by_test_id("save-report").click()
                expect(page.get_by_text("Used in attributes").nth(0)).to_be_visible()
                expect(page.get_by_text("Used in attributes").nth(1)).to_be_visible()
                dismiss_notifications(page)

            def empty_report_fields():
                boolean_attribute = page.get_by_test_id("report-boolean-attribute-checkbox")
                page.get_by_role("option", name="Report Story 1 Remove item:").get_by_role("button").click()
                page.get_by_role("option", name="Report Story 2 Remove item:").get_by_role("button").click()
                page.get_by_placeholder("STRING field").fill("")
                page.get_by_placeholder("NUMBER field").fill("")
                expect(boolean_attribute).to_be_visible()
                boolean_attribute.uncheck()
                page.get_by_role("radio", name="CLASSIFIED").check()
                page.get_by_label("Impact (Enum) Malicious code").select_option("Privilege escalation")
                page.get_by_placeholder("TEXT field", exact=True).fill("")
                page.get_by_placeholder("RICH_TEXT field").fill("")
                page.get_by_role("textbox", name="Date", exact=True).fill("")
                page.get_by_role("textbox", name="Time", exact=True).fill("")
                page.get_by_role("textbox", name="Date Time").fill("")
                page.get_by_label("TLP Level Clear Green Amber").select_option("clear")
                page.get_by_placeholder("CVE field").fill("")
                page.get_by_placeholder("CVSS field").fill("")
                page.get_by_test_id("save-report").click()
                expect(page.get_by_test_id("save-report")).to_be_visible()
                dismiss_notifications(page)

            def check_report_fields():
                boolean_attribute = page.get_by_test_id("report-boolean-attribute-checkbox")
                page.get_by_role("link", name="Analyze").click()
                expect(page.get_by_role("row", name="all attr report")).to_be_visible()

                page.get_by_role("link", name="all attr report").click()
                expect(page.get_by_role("textbox", name="Title")).to_have_value("all attr report")
                expect(page.get_by_role("option", name="Report Story 1 Remove item:")).not_to_be_visible()
                expect(page.get_by_placeholder("STRING field")).to_be_empty()
                expect(page.get_by_placeholder("NUMBER field")).to_be_empty()
                expect(boolean_attribute).not_to_be_checked()
                expect(page.get_by_role("radio", name="CLASSIFIED")).to_be_checked()
                expect(page.get_by_role("radio", name="UNRESTRICTED")).not_to_be_checked()
                expect(page.get_by_label("Impact (Enum) Malicious code")).to_have_value("Privilege escalation")
                expect(page.get_by_placeholder("TEXT field", exact=True)).to_be_empty()
                expect(page.get_by_placeholder("RICH_TEXT field")).to_be_empty()
                expect(page.get_by_role("textbox", name="Date", exact=True)).to_be_empty()
                expect(page.get_by_role("textbox", name="Time", exact=True)).to_be_empty()
                expect(page.get_by_role("textbox", name="Date Time")).to_be_empty()
                expect(page.get_by_label("TLP Level Clear Green Amber")).to_have_value("clear")
                expect(page.get_by_placeholder("CVE field")).to_be_empty()
                expect(page.get_by_placeholder("CVSS field")).to_be_empty()
                expect(page.locator("#report_form")).to_contain_text("Use the NVD CVSS calculator to determine the score.")
                page.get_by_test_id("save-report").click()
                expect(page.get_by_test_id("save-report")).to_be_visible()
                dismiss_notifications(page)

            def check_invalid_states():
                with pytest.raises(Error, match=r"Cannot type text"):
                    page.get_by_placeholder("NUMBER field").fill("aaa")
                page.get_by_placeholder("CVE field").fill("111")

                page.get_by_test_id("save-report").click()
                expect(page.get_by_text("Report item updated")).not_to_be_visible()
                page.get_by_placeholder("CVE field").fill("")

                page.get_by_placeholder("CVSS field").fill("a")
                page.get_by_test_id("save-report").click()
                expect(page.get_by_text("Report item updated")).not_to_be_visible()
                page.get_by_placeholder("CVSS field").fill("")

            def delete_new_report():
                page.get_by_role("link", name="Analyze").click()
                item_id = self.get_table_row_id_by_link_text(page, "report-table", "all attr report")
                delete_button_test_id = f"action-delete-{item_id}"
                self.delete_table_row(page, delete_button_test_id)
                dismiss_notifications(page)

            def create_new_report_required():
                page.get_by_test_id("new-report-button").click()
                expect(page.get_by_role("heading", name="Create Report")).to_be_visible()
                page.get_by_role("textbox", name="Title").fill("all attr report REQUIRED")
                page.get_by_test_id("report-type-select").select_option(label=self.ALL_ATTRIBUTE_REQUIRED_REPORT_TYPE_LABEL)
                page.get_by_test_id("save-report").click()
                page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
                dismiss_notifications(page)
                expect(page.get_by_role("searchbox", name="Related Story")).to_be_visible()
                expect(page.get_by_placeholder("STRING field*")).to_be_visible()
                expect(page.get_by_placeholder("NUMBER field*")).to_be_visible()
                expect(page.get_by_text("Boolean *")).to_be_visible()
                expect(page.get_by_text("Confidentiality (Radio) *")).to_be_visible()
                expect(page.get_by_text("Impact (Enum) *")).to_be_visible()
                expect(page.get_by_role("heading", name="Narrative and Timing")).to_be_visible()
                expect(page.get_by_placeholder("TEXT field*", exact=True)).to_be_visible()
                expect(page.get_by_placeholder("RICH_TEXT field*")).to_be_visible()
                expect(page.get_by_text("Date*")).to_be_visible()
                expect(page.get_by_text("Time*", exact=True)).to_be_visible()
                expect(page.get_by_text("Date Time*")).to_be_visible()
                expect(page.get_by_text("TLP Level *")).to_be_visible()
                expect(page.get_by_role("heading", name="Technical References and Artifacts")).to_be_visible()
                expect(page.get_by_text('Unsupported attribute type "LINK" is kept as read-only')).to_be_visible()
                expect(
                    page.get_by_text("Attachment editing is not yet available in this view. Existing data will be preserved on save.")
                ).to_be_visible()
                expect(page.get_by_role("textbox", name="CVE")).to_be_visible()
                expect(page.get_by_role("textbox", name="CVSS")).to_be_visible()

            def add_stories_to_new_report_required():
                select_report_stories_from_assess(story_search_term)
                page.get_by_role("button", name="Add to Report").click()
                popup = page.get_by_label("Add Stories to report")
                popup.click()
                popup.get_by_text("all attr report REQUIRED").click()
                page.locator("#share_story_to_report_dialog").get_by_role("button", name="Share").click()

            def set_report_fields_required():
                boolean_attribute = page.get_by_test_id("report-boolean-attribute-checkbox")
                page.get_by_role("link", name="Analyze").click()
                expect(page.get_by_role("row", name="all attr report REQUIRED")).to_be_visible()

                page.get_by_role("link", name="all attr report REQUIRED").click()
                page.locator(".choices__inner").click()
                page.get_by_role("option", name="Report Story 1 Add Story").click()
                expect(page.get_by_role("option", name="Report Story 1 Remove item:")).to_be_visible()
                page.keyboard.press("Escape")  # press esc  key to close the dropdown

                page.get_by_placeholder("STRING field*").click()
                page.get_by_placeholder("STRING field*").fill("string")
                page.get_by_placeholder("NUMBER field*").click()
                page.get_by_placeholder("NUMBER field*").fill("111")
                expect(boolean_attribute).to_be_visible()
                boolean_attribute.check()
                page.get_by_role("radio", name="UNRESTRICTED").check()
                page.get_by_label("Impact (Enum) * Select an").select_option("Malicious code execution affecting CIA of the system")
                page.get_by_placeholder("TEXT field*", exact=True).fill("text")
                page.get_by_placeholder("RICH_TEXT field*").fill("rich text")
                page.get_by_role("textbox", name="Date *", exact=True).fill("2026-02-05")
                page.get_by_role("textbox", name="Time *", exact=True).fill("11:11")
                page.get_by_role("textbox", name="Date Time *").fill("2026-02-05T11:11")
                page.get_by_label("TLP Level * Clear Green Amber").select_option("clear")
                page.locator("div").filter(has_text="Stories Remove all Report").nth(4).click()
                page.get_by_placeholder("CVE field*").fill("CVE-2026-24888")
                page.get_by_placeholder("CVSS field*").fill("1")
                dismiss_notifications(page)
                page.get_by_test_id("save-report").click()
                expect(page.get_by_test_id("save-report")).to_be_visible()
                dismiss_notifications(page)

            def check_invalid_states_required():
                with pytest.raises(Error, match=r"Cannot type text"):
                    page.get_by_placeholder("NUMBER field").fill("aaa")
                page.get_by_placeholder("CVE field").fill("111")

                page.get_by_test_id("save-report").click()
                expect(page.get_by_text("Report item updated")).not_to_be_visible()
                page.get_by_placeholder("CVE field*").fill("")

                page.get_by_placeholder("CVSS field*").fill("a")
                page.get_by_test_id("save-report").click()
                expect(page.get_by_text("Report item updated")).not_to_be_visible()
                page.get_by_placeholder("CVSS field*").fill("")

            def delete_new_report_required():
                page.get_by_role("link", name="Analyze").click()
                item_id = self.get_table_row_id_by_link_text(page, "report-table", "all attr report REQUIRED")
                delete_button_test_id = f"action-delete-{item_id}"
                self.delete_table_row(page, delete_button_test_id)
                dismiss_notifications(page)

            create_new_report()
            add_stories_to_new_report()
            set_report_fields()
            empty_report_fields()
            check_report_fields()
            check_invalid_states()
            delete_new_report()
            ####
            create_new_report_required()
            add_stories_to_new_report_required()
            set_report_fields_required()
            check_invalid_states_required()
            delete_new_report_required()

        go_to_analyze()
        check_report_view_layout_changes()
        delete_test_report()
        go_to_analyze()
        report_uuid = create_report()
        add_stories_to_report()
        check_report_list_filters()
        go_to_analyze()
        verify_report_actions(report_uuid)
        go_to_analyze()
        check_various_report_type_fields()

    def test_user_report_vanishes_with_higher_tlp(
        self,
        non_admin_logged_in_page: Page,
        forward_console_and_page_errors_non_admin,
        pre_seed_report_type_all_attribute_types_optional,
    ):
        page = non_admin_logged_in_page
        report_title = f"tlp_clear_report_{uuid.uuid4().hex[:8]}"

        page.goto(url_for("analyze.analyze", _external=True))
        expect(page.get_by_test_id("analyze")).to_be_visible()

        page.get_by_test_id("new-report-button").click()
        expect(page.get_by_role("heading", name="Create Report")).to_be_visible()
        page.get_by_role("textbox", name="Title").fill(report_title)
        page.get_by_test_id("report-type-select").select_option(label=self.ALL_ATTRIBUTE_REPORT_TYPE_LABEL)
        page.get_by_test_id("save-report").click()
        page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
        dismiss_notifications(page)

        page.get_by_label("TLP Level Clear Green Amber").select_option("clear")
        page.get_by_test_id("save-report").click()
        expect(page.get_by_label("TLP Level Clear Green Amber")).to_have_value("clear")
        dismiss_notifications(page)

        page.get_by_role("link", name="Analyze").click()
        self.assert_item_in_table(page, "report-table", report_title)

        self.open_table_item(page, "report-table", report_title)
        page.get_by_label("TLP Level Clear Green Amber").select_option("green")
        page.get_by_test_id("save-report").click()
        expect(page.get_by_test_id("analyze")).to_be_visible()

        page.get_by_role("link", name="Analyze").click()
        expect(page.get_by_test_id("analyze")).to_be_visible()
        self.assert_item_not_in_table(page, "report-table", report_title)

    def test_user_report_detail_is_forbidden_after_higher_tlp(
        self,
        non_admin_logged_in_page: Page,
        forward_console_and_page_errors_non_admin_report_forbidden,
        pre_seed_report_type_all_attribute_types_optional,
    ):
        page = non_admin_logged_in_page
        report_title = f"tlp_clear_report_detail_{uuid.uuid4().hex[:8]}"

        page.goto(url_for("analyze.analyze", _external=True))
        expect(page.get_by_test_id("analyze")).to_be_visible()

        page.get_by_test_id("new-report-button").click()
        expect(page.get_by_role("heading", name="Create Report")).to_be_visible()
        page.get_by_role("textbox", name="Title").fill(report_title)
        page.get_by_test_id("report-type-select").select_option(label=self.ALL_ATTRIBUTE_REPORT_TYPE_LABEL)
        page.get_by_test_id("save-report").click()
        page.get_by_test_id("report-id").inner_text().split("ID: ")[1]
        dismiss_notifications(page)

        page.get_by_label("TLP Level Clear Green Amber").select_option("clear")
        page.get_by_test_id("save-report").click()
        expect(page.get_by_label("TLP Level Clear Green Amber")).to_have_value("clear")
        dismiss_notifications(page)

        page.get_by_role("link", name="Analyze").click()
        self.assert_item_in_table(page, "report-table", report_title)
        self.open_table_item(page, "report-table", report_title)
        report_id = page.url.rstrip("/").split("/")[-1]

        page.get_by_label("TLP Level Clear Green Amber").select_option("green")
        page.get_by_test_id("save-report").click()
        expect(page.get_by_test_id("analyze")).to_be_visible()
        page.goto(url_for("analyze.report", report_id=report_id, _external=True))
        expect(page.get_by_text("403 - Access denied")).to_be_visible()

    def test_publish(self, non_admin_logged_in_page: Page, forward_console_and_page_errors_non_admin, stories_session_wrapper):
        page = non_admin_logged_in_page
        product_title = f"test_product_{str(uuid.uuid4())[:8]}"

        def load_product_list():
            page.goto(url_for("publish.publish", _external=True))
            expect(page.get_by_test_id("product-table")).to_be_visible()
            self.capture_screenshot(page, "./tests/playwright/screenshots/docs_products.png")

        def add_product():
            self.highlight_element(page.get_by_test_id("new-product-button")).click()
            expect(page.get_by_test_id("product-form")).to_be_visible()
            product_type_select = page.get_by_label("Product Type * Select an item")
            product_type_options = product_type_select.locator("option").evaluate_all(
                """options => options
                .filter(option => option.value)
                .map(option => ({ value: option.value, label: option.textContent?.trim() ?? "" }))"""
            )
            assert product_type_options, "No product type options available for product creation"
            self.highlight_element(product_type_select).select_option(product_type_options[0]["value"])

            self.highlight_element(page.get_by_placeholder("Title")).fill(product_title)
            page.get_by_placeholder("Description").fill("This is a test product.")
            self.highlight_element(page.get_by_test_id("save-product")).click()

        load_product_list()
        add_product()
        expect(page.get_by_test_id("copy-product")).to_be_visible()
        source_url = page.url
        product_type = page.locator("#product_type_id").input_value()

        page.get_by_test_id("copy-product").click()
        expect(page.get_by_role("heading", name="Create Product")).to_be_visible()
        expect(page.get_by_placeholder("Title")).to_have_value(f"{product_title} Copy")
        expect(page.get_by_placeholder("Description")).to_have_value("This is a test product.")
        expect(page.locator("#product_type_id")).to_have_value(product_type)
        expect(page.get_by_test_id("product-render")).to_have_count(0)
        load_product_list()
        expect(page.get_by_role("link", name=f"{product_title} Copy", exact=True)).to_have_count(0)

        page.goto(source_url)
        page.get_by_placeholder("Title").fill(f"{product_title} unsaved")
        page.once("dialog", lambda dialog: dialog.dismiss())
        page.get_by_test_id("copy-product").click()
        expect(page.get_by_placeholder("Title")).to_have_value(f"{product_title} unsaved")
        assert page.url == source_url
        page.once("dialog", lambda dialog: dialog.accept())
        page.get_by_test_id("copy-product").click()
        expect(page.get_by_placeholder("Title")).to_have_value(f"{product_title} Copy")
        page.get_by_placeholder("Title").fill(f"{product_title} reviewed")
        page.get_by_test_id("save-product").click()
        expect(page.get_by_role("heading", name=f"Update Product - {product_title} reviewed")).to_be_visible()
        expect(page.get_by_test_id("last-published-product-empty")).to_be_visible()
        assert page.url != source_url
        page.reload()
        expect(page.get_by_placeholder("Title")).to_have_value(f"{product_title} reviewed")
        page.goto(source_url)
        expect(page.get_by_placeholder("Title")).to_have_value(product_title)
