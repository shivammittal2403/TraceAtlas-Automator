import htmx from "htmx.org";
import "npm:htmx.org@^4.0.0/dist/ext/hx-alpine-compat.js";
import Alpine from "npm:alpinejs";

import Sortable from "npm:sortablejs";
import Choices from "npm:choices.js";
import Fuse from "npm:fuse.js";
import Swal from "npm:sweetalert2";
import { driver } from "npm:driver.js";
import { highlightSearchTerm } from "npm:highlight-search-term";

import "npm:choices.js/public/assets/styles/choices.min.css";
import "npm:sweetalert2/dist/sweetalert2.min.css";
import "npm:driver.js/dist/driver.css";

window.htmx = htmx;
window.Alpine = Alpine;

window.Sortable = Sortable;
window.Choices = Choices;
window.Fuse = Fuse;
window.Swal = Swal;
window.driver = driver;
window.highlightSearchTerm = highlightSearchTerm;

if (typeof Alpine.start === "function") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      Alpine.start();
    });
  } else {
    Alpine.start();
  }
}
