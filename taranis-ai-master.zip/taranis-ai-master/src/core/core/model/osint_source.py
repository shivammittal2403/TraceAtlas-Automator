import base64
import json
from collections.abc import Sequence
from datetime import UTC, datetime, timedelta
from io import BytesIO
from pathlib import Path
from typing import TYPE_CHECKING, Any

from models.admin import CronSpec, CuratedOSINTSourceCatalog, OSINTSourceUpdateModel
from models.admin import OSINTSource as OSINTSourceModel
from models.types import COLLECTOR_TYPES
from PIL import Image, ImageOps, UnidentifiedImageError
from sqlalchemy import String, and_, cast, func, literal
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Mapped, deferred, relationship
from sqlalchemy.sql import Select

from core.config import Config
from core.log import logger
from core.managers import queue_manager
from core.managers.data_manager import get_default_json
from core.managers.db_manager import db
from core.model.base_model import DB_INTEGER_MAX, UUID_STR_LENGTH, BaseModel
from core.model.role import TLPLevel
from core.model.role_based_access import ItemType, RoleBasedAccess
from core.model.settings import Settings
from core.model.task import Task as TaskModel
from core.model.word_list import WordList
from core.service.role_based_access import RBACQuery, RoleBasedAccessService
from core.service.worker_parameters import configured_parameters, effective_parameters, set_parameters


if TYPE_CHECKING:
    from core.model.news_item import NewsItem
    from core.model.user import User


COLLECTION_PERIODS = {
    "day": timedelta(days=1),
    "week": timedelta(days=7),
    "month": timedelta(days=30),
}
DEFAULT_COLLECTION_PERIOD = "week"
INVALID_COLLECTION_PERIOD_MESSAGE = "The period parameter must be day, week, or month"


class InvalidOSINTSourceIconError(ValueError):
    def __init__(self, public_message: str):
        super().__init__(public_message)
        self.public_message = public_message


class CuratedOSINTSourceSchedulingError(RuntimeError):
    pass


class CuratedOSINTSourceConflictError(ValueError):
    def __init__(self, source_name: str):
        self.public_message = (
            f'Cannot load curated lists: source "{source_name}" already exists with a different collector type. '
            "Rename the existing source and try again. No sources or groups were changed."
        )
        super().__init__(self.public_message)


class CollectorHTTPState(BaseModel):
    __tablename__ = "collector_http_state"

    osint_source_id: Mapped[str] = db.Column(
        db.String(UUID_STR_LENGTH), db.ForeignKey("osint_source.id", ondelete="CASCADE"), primary_key=True
    )
    url: Mapped[str] = db.Column(db.Text, nullable=False)
    etag: Mapped[str | None] = db.Column(db.Text, nullable=True)
    last_modified: Mapped[str | None] = db.Column(db.Text, nullable=True)

    def __init__(self, osint_source_id: str, url: str, etag: str | None = None, last_modified: str | None = None):
        self.osint_source_id = osint_source_id
        self.url = url
        self.etag = etag
        self.last_modified = last_modified

    @classmethod
    def update_from_task_result(cls, source_id: str, data: Any) -> None:
        if not isinstance(data, dict) or not isinstance(validators := data.get("http_validators"), dict):
            return
        url = validators.get("url")
        etag = validators.get("etag")
        last_modified = validators.get("last_modified")
        if (
            not isinstance(url, str)
            or not url
            or (etag is not None and not isinstance(etag, str))
            or (last_modified is not None and not isinstance(last_modified, str))
            or OSINTSource.get(source_id) is None
        ):
            return

        if state := db.session.get(cls, source_id):
            state.url = url
            state.etag = etag
            state.last_modified = last_modified
        else:
            db.session.add(cls(source_id, url, etag, last_modified))
        db.session.commit()

    def to_worker_dict(self) -> dict[str, str | None]:
        return {"url": self.url, "etag": self.etag, "last_modified": self.last_modified}


class OSINTSource(BaseModel):
    __tablename__ = "osint_source"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    key: Mapped[str | None] = db.Column(db.String(64), unique=True, nullable=True)
    name: Mapped[str] = db.Column(db.String(), nullable=False, unique=True)
    description: Mapped[str] = db.Column(db.String())
    rank: Mapped[int] = db.Column(db.Integer, nullable=False, default=0)

    type: Mapped[COLLECTOR_TYPES] = db.Column(db.Enum(COLLECTOR_TYPES))
    parameters: Mapped[dict[str, Any]] = db.Column(db.JSON, nullable=False, default=dict)
    groups: Mapped[list["OSINTSourceGroup"]] = relationship("OSINTSourceGroup", secondary="osint_source_group_osint_source")
    http_state: Mapped[CollectorHTTPState | None] = relationship(
        CollectorHTTPState, cascade="all, delete-orphan", passive_deletes=True, uselist=False
    )

    icon: Any = deferred(db.Column(db.LargeBinary))
    enabled: Mapped[bool] = db.Column(db.Boolean, default=True)
    news_items: Mapped[list["NewsItem"]] = relationship("NewsItem", back_populates="osint_source")
    _ALLOWED_ICON_FORMATS = frozenset({"GIF", "ICO", "PNG", "JPEG", "WEBP"})

    def __init__(
        self,
        name: str,
        description: str,
        type: str | COLLECTOR_TYPES,
        parameters=None,
        icon=None,
        enabled=True,
        id=None,
        rank: int = 0,
    ):
        payload = OSINTSourceModel.model_validate(
            {
                "id": id,
                "name": name,
                "description": description,
                "rank": rank,
                "type": type,
                "parameters": {} if parameters is None else parameters,
                "icon": icon,
                "enabled": enabled,
            }
        )

        try:
            self.id = self.normalize_uuid_id(payload.id)
        except ValueError:
            self.id = self.uuid7_str()
            self.key = str(payload.id)
        self.name = payload.name
        self.description = payload.description
        self.rank = payload.rank
        self.type = payload.type if payload.type is not None else COLLECTOR_TYPES.MANUAL_COLLECTOR
        if self.type == COLLECTOR_TYPES.PPN_COLLECTOR and Config.DISABLE_PPN_COLLECTOR:
            raise ValueError("PPN collector is disabled in this deployment")
        self.icon = None
        if payload.icon is not None:
            self.icon = self._parse_icon(payload.icon)
        self.enabled = True if payload.enabled is None else payload.enabled
        self.parameters = set_parameters(
            self.type,
            {},
            payload.parameters,
            patch=False,
            complete=self.enabled,
        )

    @classmethod
    def get(cls, item_id: str | None) -> "OSINTSource | None":
        if item_id is None:
            return None
        lookup_id = str(item_id)
        if osint_source := super().get(lookup_id):
            return osint_source
        try:
            normalized_id = cls.normalize_uuid_id(item_id)
        except (TypeError, ValueError):
            normalized_id = None
        if normalized_id and normalized_id != lookup_id and (osint_source := super().get(normalized_id)):
            return osint_source
        if lookup_id:
            return cls.get_by_key(lookup_id)
        return None

    @classmethod
    def create_manual_source(cls) -> "OSINTSource":
        if existing_manual := cls.get_by_key("manual"):
            return existing_manual

        return cls.add(
            {
                "id": "manual",
                "name": "Manual",
                "description": "Manual source",
                "rank": 0,
                "type": "MANUAL_COLLECTOR",
                "parameters": {},
            }
        )

    @classmethod
    def get_manual(cls) -> "OSINTSource":
        return cls.create_manual_source()

    @classmethod
    def get_by_key(cls, key: str) -> "OSINTSource | None":
        if not key:
            return None
        return cls.get_first(db.select(cls).filter_by(key=key))

    @property
    def tlp_level(self) -> TLPLevel:
        if value := self.parameters.get("TLP_LEVEL"):
            return TLPLevel(value)
        return TLPLevel(Settings.get_settings().get("default_tlp_level", TLPLevel.CLEAR.value))

    @property
    def status(self):
        if task_result := TaskModel.get_latest_matching(
            exact_ids={self.task_id},
            prefixes=[self.cron_run_prefix],
            task_name="collector_task",
            worker_id=self.id,
        ):
            return task_result.to_dict()
        return None

    @property
    def task_id(self):
        return f"collect_{self.type}_{self.id}"

    @property
    def cron_job_id(self) -> str:
        return f"osint_source_{self.id}"

    @property
    def cron_run_prefix(self) -> str:
        return f"cron_{self.cron_job_id}_"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OSINTSource":
        return cls.from_payload(OSINTSourceModel.model_validate(data))

    @classmethod
    def from_payload(cls, payload: OSINTSourceModel) -> "OSINTSource":
        return cls(**payload.model_dump(exclude={"status", "news_items_count", "collection_count", "collection_period"}))

    def to_detail_dict(self, collection_period: str = DEFAULT_COLLECTION_PERIOD) -> dict[str, Any]:
        from core.model.news_item import NewsItem

        collection_period = self.validate_collection_period(collection_period)
        window_end = self.utcnow()
        collection_count = db.session.execute(
            db.select(func.count())
            .select_from(NewsItem)
            .where(
                NewsItem.osint_source_id == self.id,
                NewsItem.collected >= window_end - COLLECTION_PERIODS[collection_period],
                NewsItem.collected <= window_end,
            )
        ).scalar_one()
        data = self.to_dict()
        data["news_items_count"] = self.get_news_items_count()
        data["collection_count"] = collection_count
        data["collection_period"] = collection_period
        return data

    def get_news_items_count(self) -> int:
        from core.model.news_item import NewsItem

        query = db.select(NewsItem).where(NewsItem.osint_source_id == self.id)
        return NewsItem.get_filtered_count(query)

    @staticmethod
    def validate_collection_period(period: Any = None) -> str:
        normalized_period = DEFAULT_COLLECTION_PERIOD if period is None else str(period)
        if normalized_period not in COLLECTION_PERIODS:
            raise ValueError(INVALID_COLLECTION_PERIOD_MESSAGE)
        return normalized_period

    @classmethod
    def get_for_api(
        cls,
        item_id: str,
        collection_period: str = DEFAULT_COLLECTION_PERIOD,
    ) -> tuple[dict[str, Any], int]:
        if item := cls.get(item_id):
            return item.to_detail_dict(collection_period), 200
        return {"error": f"{cls.__name__} not found"}, 404

    @classmethod
    def get_all_for_collector(cls) -> Sequence["OSINTSource"]:
        task_id_expr = func.concat(
            literal("collect_"),
            cast(cls.type, String()),
            literal("_"),
            cls.id,
        )

        query = (
            db.select(cls)
            .outerjoin(
                TaskModel,
                and_(
                    TaskModel.task == "collector_task",
                    TaskModel.id == task_id_expr,
                ),
            )
            .where(cls.type != COLLECTOR_TYPES.MANUAL_COLLECTOR)
            .where(cls.enabled.is_(True))
            .distinct(cls.id)
            .order_by(
                cls.id,
                TaskModel.last_success.asc().nulls_first(),
                TaskModel.last_run.asc().nulls_first(),
            )
        )
        if Config.DISABLE_PPN_COLLECTOR:
            query = query.where(cls.type != COLLECTOR_TYPES.PPN_COLLECTOR)
        return db.session.execute(query).scalars().all()

    @classmethod
    def get_all_for_api(cls, filter_args: dict[str, Any] | None, with_count: bool = False, user=None) -> tuple[dict[str, Any], int]:
        filter_args = dict(filter_args or {})
        filter_args["filter_manual"] = cls._filter_manual_enabled(filter_args.get("filter_manual", True))
        status_order = filter_args.get("order") in {"status_asc", "status_desc"}
        paginate_after_status = status_order and not cls._should_fetch_all(filter_args)
        query_args = {**filter_args, "fetch_all": "true"} if status_order else filter_args

        response, status_code = super().get_all_for_api(filter_args=query_args, with_count=with_count, user=user)
        items = response.get("items", [])
        if filter_args.get("order") == "status_asc":
            items.sort(key=lambda item: (item.get("status") or {}).get("status", ""))
        elif filter_args.get("order") == "status_desc":
            items.sort(key=lambda item: (item.get("status") or {}).get("status", ""), reverse=True)

        if paginate_after_status:
            limit = min(int(filter_args.get("limit", 20)), DB_INTEGER_MAX)
            offset = filter_args.get("offset")
            if offset is None:
                offset = max((int(filter_args.get("page", 1)) - 1) * limit, 0)
            else:
                offset = max(min(int(offset), DB_INTEGER_MAX), 0)
            response["items"] = items[offset : offset + limit]

        return response, status_code

    @classmethod
    def get_current_failure_count(cls) -> int:
        query = db.select(func.count()).select_from(cls).where(cls._latest_task_status() == "FAILURE")
        return db.session.execute(query).scalar_one()

    @classmethod
    def _latest_task_status(cls):
        task_id = func.concat(literal("collect_"), func.lower(cast(cls.type, String)), literal("_"), cls.id)
        cron_prefix = func.concat(literal("cron_osint_source_"), cls.id, literal("_%"))
        return (
            db.select(TaskModel.status)
            .where(
                TaskModel.task == "collector_task",
                db.or_(TaskModel.job_id == task_id, TaskModel.job_id.like(cron_prefix), TaskModel.worker_id == cls.id),
            )
            .order_by(TaskModel.last_run.desc(), TaskModel.last_success.desc(), TaskModel.job_id.desc())
            .limit(1)
            .correlate(cls)
            .scalar_subquery()
        )

    @staticmethod
    def _filter_manual_enabled(value: Any) -> bool:
        return str(value).strip().lower() not in {"", "false", "0", "off", "no"}

    @classmethod
    def get_filter_query_with_acl(cls, filter_args: dict, user) -> Select:
        query = cls.get_filter_query(filter_args)
        rbac = RBACQuery(user=user, resource_type=ItemType.OSINT_SOURCE)
        return RoleBasedAccessService.filter_query_with_acl(query, rbac)

    @classmethod
    def get_filter_query(cls, filter_args: dict) -> Select:
        query = db.select(cls)

        if search := filter_args.get("search"):
            query = query.where(
                db.or_(cls.name.ilike(f"%{search}%"), cls.description.ilike(f"%{search}%"), cast(cls.type, String).ilike(f"%{search}%"))
            )

        if source_type := filter_args.get("type"):
            query = query.where(cls.type == source_type)

        if enabled := filter_args.get("enabled"):
            query = query.where(cls.enabled.is_(enabled))

        if filter_args.get("filter_manual"):
            query = query.where(cls.type != COLLECTOR_TYPES.MANUAL_COLLECTOR)

        if str(filter_args.get("state") or "").strip().lower() == "failure":
            query = query.where(cls._latest_task_status() == "FAILURE")

        return query

    @classmethod
    def default_sort_column(cls) -> str:
        return "name_asc"

    def update_icon(self, icon: bytes | str):
        if icon_bytes := self._parse_icon(icon):
            self.icon = icon_bytes
        else:
            self.icon = None
        db.session.commit()

    def to_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data["parameters"] = configured_parameters(self.type, self.parameters)
        data["icon"] = base64.b64encode(self.icon).decode("utf-8") if self.icon else None
        if status := self.status:
            data["status"] = status
        return data

    def to_worker_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data.pop("icon", None)
        data["word_lists"] = []
        for group in self.groups:
            data["word_lists"].extend([word_list.to_dict() for word_list in group.word_lists if word_list])
        data["parameters"] = effective_parameters(self.type, self.parameters)
        if status := self.status:
            data["status"] = status
            result = status.get("result")
            result_data = result.get("data") if isinstance(result, dict) else None
            cursor = result_data.get("mastodon_cursor") if isinstance(result_data, dict) else None
            if self.type == COLLECTOR_TYPES.MASTODON_COLLECTOR and isinstance(cursor, dict):
                timeline = cursor.get("timeline")
                last_status_id = cursor.get("last_status_id")
                if isinstance(timeline, str) and timeline and isinstance(last_status_id, str) and last_status_id:
                    data["mastodon_cursor"] = {"timeline": timeline, "last_status_id": last_status_id}
        if self.http_state:
            data["http_validators"] = self.http_state.to_worker_dict()

        # Include refresh schedule for worker self-rescheduling
        data["refresh"] = self.get_schedule_with_default()
        if self.type == COLLECTOR_TYPES.RSS_COLLECTOR:
            data["rss_collector_max_entries"] = Settings.get_settings().get("rss_collector_max_entries", 42)

        return data

    @staticmethod
    def get_with_defaults(data) -> dict[str, Any]:
        params = data["parameters"]
        settings = Settings.get_settings()

        if params.get("USE_GLOBAL_PROXY"):
            data["parameters"]["PROXY_SERVER"] = settings.get("default_collector_proxy", "")

        return data

    def to_assess_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "key": self.key,
            "icon": base64.b64encode(self.icon).decode("utf-8") if self.icon else None,
            "name": self.name,
            "rank": self.rank,
            "type": self.type,
        }

    def get_schedule(self) -> str:
        """Return only the explicit REFRESH_INTERVAL; empty string if unset."""
        return self.parameters.get("REFRESH_INTERVAL", "")

    @staticmethod
    def get_default_schedule() -> str:
        """Global default collector interval from settings."""
        return Settings.get_settings().get("default_collector_interval", "0 */8 * * *")

    def get_schedule_with_default(self) -> str:
        """Return schedule with fallback to the global default when missing."""
        return self.get_schedule() or self.get_default_schedule()

    @classmethod
    def get_enabled_schedule_entries(cls, now: datetime | None = None) -> list[dict[str, Any]]:
        """Get schedule entries for all enabled OSINT sources.

        Note: All times are calculated in UTC for consistency across the system.
        """

        from core.managers import queue_manager as queue_manager_module
        from core.managers.queue_manager import QueueManager

        now = now or datetime.now(UTC).replace(tzinfo=None)
        schedule_entries: list[dict[str, Any]] = []

        sources = cls.get_all_for_collector()
        for source in sources:
            if not (cron_schedule := source.get_schedule_with_default()):
                continue

            try:
                task_result = TaskModel.get_latest_matching(
                    exact_ids={source.task_id},
                    prefixes=[source.cron_run_prefix],
                    task_name="collector_task",
                )

                schedule_entries.append(
                    QueueManager.build_cron_schedule_entry(
                        job_id=source.cron_job_id,
                        name=f"Collector: {source.name}",
                        queue="collectors",
                        cron_schedule=cron_schedule,
                        now=now,
                        source_id=source.id,
                        task_id=source.task_id,
                        last_run=task_result.last_run if task_result else None,
                        last_success=task_result.last_success if task_result else None,
                        last_status=task_result.status if task_result else None,
                        last_reason=queue_manager_module._task_result_reason(task_result),
                    )
                )
            except Exception as exc:
                logger.error(f"Failed to calculate next run for source {source.id}: {exc}")

        return schedule_entries

    @classmethod
    def add(cls, data):
        osint_source = cls.from_dict(data)
        db.session.add(osint_source)
        db.session.commit()
        osint_source.schedule_osint_source()
        return osint_source

    @classmethod
    def toggle_state(cls, source_id: str, state: str) -> tuple[dict, int]:
        osint_source = cls.get(source_id)
        if not osint_source:
            return {"error": "OSINT Source not found"}, 404

        if state == "enabled":
            logger.debug(f"Enabling OSINT Source: {osint_source.name}")
            if osint_source.type == COLLECTOR_TYPES.PPN_COLLECTOR and Config.DISABLE_PPN_COLLECTOR:
                return {"error": "PPN collector is disabled in this deployment"}, 400
            try:
                osint_source.parameters = set_parameters(osint_source.type, osint_source.parameters, {}, patch=True, complete=True)
            except (TypeError, ValueError):
                db.session.rollback()
                logger.warning("Cannot enable OSINT source %s because its parameters are invalid", osint_source.id, exc_info=True)
                return {"error": "Invalid OSINT Source payload"}, 400
            osint_source.enabled = True
            osint_source.schedule_osint_source()
        elif state == "disabled":
            logger.debug(f"Disabling OSINT Source: {osint_source.name}")
            osint_source.enabled = False
            osint_source.unschedule_osint_source()
        else:
            logger.warning(f"Unknown state {state} for OSINT Source: {osint_source.name}")
            return {"error": "Invalid state"}, 400

        db.session.commit()
        return {"message": "OSINT Source state updated", "id": osint_source.id}, 200

    @classmethod
    def update(cls, osint_source_id: str, data: dict[str, Any], *, patch: bool = False) -> "OSINTSource|None":
        osint_source = cls.get(osint_source_id)
        if not osint_source:
            return None
        validated_update = OSINTSourceUpdateModel.model_validate(data)
        update_fields = validated_update.model_fields_set

        if "type" in update_fields and validated_update.type is not None and validated_update.type != osint_source.type:
            raise ValueError("Worker type is immutable")
        target_enabled = (
            validated_update.enabled if "enabled" in update_fields and validated_update.enabled is not None else osint_source.enabled
        )
        if target_enabled and osint_source.type == COLLECTOR_TYPES.PPN_COLLECTOR and Config.DISABLE_PPN_COLLECTOR:
            raise ValueError("PPN collector is disabled in this deployment")
        target_parameters = osint_source.parameters
        if "parameters" in update_fields and validated_update.parameters is not None:
            target_parameters = set_parameters(
                osint_source.type,
                osint_source.parameters,
                validated_update.parameters,
                patch=patch,
                complete=target_enabled,
            )
        elif target_enabled:
            target_parameters = set_parameters(
                osint_source.type,
                osint_source.parameters,
                {},
                patch=True,
                complete=True,
            )
        parsed_icon = (
            osint_source._parse_icon(validated_update.icon) if "icon" in update_fields and validated_update.icon is not None else None
        )

        if "name" in update_fields and validated_update.name is not None:
            osint_source.name = validated_update.name
        if "description" in update_fields and validated_update.description is not None:
            osint_source.description = validated_update.description
        if "rank" in update_fields and validated_update.rank is not None:
            osint_source.rank = validated_update.rank
        if parsed_icon is not None:
            osint_source.icon = parsed_icon
        osint_source.enabled = target_enabled
        osint_source.parameters = target_parameters
        db.session.commit()

        if "parameters" in update_fields and validated_update.parameters is not None:
            queue_manager.queue_manager.purge_job_artifacts(exact_ids={f"source_preview_{osint_source_id}"})

        osint_source.schedule_osint_source()
        return osint_source

    def _parse_icon(self, icon: bytes | str) -> bytes:
        icon_bytes: bytes | None = None
        if isinstance(icon, bytes):
            icon_bytes = icon or None
        elif isinstance(icon, str):
            if not icon.strip():
                return b""
            icon_bytes = self.is_valid_base64(icon)
        if not icon_bytes:
            raise InvalidOSINTSourceIconError("Invalid icon payload provided; expected base64 string or bytes.")
        if len(icon_bytes) > Config.OSINT_SOURCE_ICON_MAX_BYTES:
            raise InvalidOSINTSourceIconError(f"Icon payload exceeds the maximum size of {Config.OSINT_SOURCE_ICON_MAX_BYTES} bytes.")
        return self._normalize_icon_image(icon_bytes)

    @classmethod
    def _normalize_icon_image(cls, icon_bytes: bytes) -> bytes:
        try:
            with Image.open(BytesIO(icon_bytes)) as image:
                image_format = image.format.upper() if image.format else None
                if image_format not in cls._ALLOWED_ICON_FORMATS:
                    raise InvalidOSINTSourceIconError(
                        f"Unsupported icon format: {image_format or 'UNKNOWN'}. Allowed formats: {', '.join(cls._ALLOWED_ICON_FORMATS)}."
                    )
                image.load()
                normalized = ImageOps.exif_transpose(image).convert("RGBA")
        except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
            logger.warning(f"Pillow decode failed for icon: {exc}")
            raise InvalidOSINTSourceIconError("Icon payload is not a valid image file.") from exc

        target_size = Config.OSINT_SOURCE_ICON_PIXELS
        normalized.thumbnail((target_size, target_size), Image.Resampling.LANCZOS)

        canvas = Image.new("RGBA", (target_size, target_size), (0, 0, 0, 0))
        offset = ((target_size - normalized.width) // 2, (target_size - normalized.height) // 2)
        canvas.paste(normalized, offset)

        output_format = Config.OSINT_SOURCE_ICON_FORMAT.upper()
        with BytesIO() as output:
            canvas.save(output, format=output_format)
            return output.getvalue()

    @classmethod
    def _probe_icon_image(cls, icon_bytes: bytes) -> None:
        cls._normalize_icon_image(icon_bytes)

    def update_parameters(self, parameters: dict[str, Any]):
        self.parameters = set_parameters(self.type, self.parameters, parameters, patch=True, complete=self.enabled)
        db.session.commit()

    @classmethod
    def delete(cls, source_id: str, force: bool = False) -> tuple[dict, int]:
        response, status = cls.delete_many([source_id], force=force)
        if status == 200:
            return {"message": "OSINT Source deleted", "id": response["ids"][0]}, status
        return response, status

    @classmethod
    def delete_many(cls, source_ids: list[str], force: bool = False) -> tuple[dict, int]:
        from core.managers import queue_manager
        from core.model.news_item import NewsItem
        from core.model.story import Story
        from core.service.misp_auto_update import cancel_misp_auto_update_jobs, refresh_misp_auto_update_jobs
        from core.service.news_item import NewsItemService

        if not source_ids:
            return {"error": "OSINT Source not found"}, 404
        sources_by_id: dict[str, OSINTSource] = {}
        for source_id in dict.fromkeys(source_ids):
            if not (source := cls.get(source_id)):
                return {"error": "OSINT Source not found"}, 404
            sources_by_id[source.id] = source
        source_ids = list(sources_by_id)
        sources = list(sources_by_id.values())
        if any(source.key == "manual" for source in sources):
            return {"error": "The manual source cannot be deleted"}, 400
        if not force and NewsItemService.has_related_news_items(source_ids):
            return {
                "error": "The OSINT source could not be deleted because related news items exist. Enable force deletion to delete the source and its related data."
            }, 409

        cleanup_jobs = [(source.cron_job_id, source.task_id, source.cron_run_prefix) for source in sources]
        affected_story_ids: list[str] = []
        deleted_story_ids: list[str] = []
        try:
            if force:
                news_item_table = db.metadata.tables.get("news_item")
                if news_item_table is not None:
                    affected_story_ids = list(
                        db.session.execute(
                            db.select(news_item_table.c.story_id).where(news_item_table.c.osint_source_id.in_(source_ids)).distinct()
                        )
                        .scalars()
                        .all()
                    )
                    db.session.execute(news_item_table.delete().where(news_item_table.c.osint_source_id.in_(source_ids)))
                deleted_story_ids = list(
                    db.session.execute(db.delete(Story).where(~db.exists().where(NewsItem.story_id == Story.id)).returning(Story.id))
                    .scalars()
                    .all()
                )
            for source in sources:
                db.session.delete(source)
            db.session.commit()
        except IntegrityError as e:
            db.session.rollback()
            logger.warning(f"IntegrityError: {e.orig}")
            return {"error": "Deleting OSINT Source failed"}, 500

        try:
            for cron_job_id, task_id, cron_run_prefix in cleanup_jobs:
                queue_manager.queue_manager.unregister_cron_job(cron_job_id)
                queue_manager.queue_manager.purge_job_artifacts(exact_ids={task_id}, prefixes=[cron_run_prefix])
        except Exception:
            db.session.rollback()
            logger.exception("Failed to clean up jobs after deleting OSINT sources")

        try:
            cancel_misp_auto_update_jobs(deleted_story_ids)
            if affected_story_ids:
                surviving_story_ids = db.session.execute(db.select(Story.id).where(Story.id.in_(affected_story_ids))).scalars().all()
                refresh_misp_auto_update_jobs(surviving_story_ids)
        except Exception:
            db.session.rollback()
            logger.exception("Failed to refresh MISP jobs after deleting OSINT sources")
        return {"message": "OSINT Sources deleted", "ids": source_ids}, 200

    @classmethod
    def schedule_all_osint_sources(cls):
        """Schedule all enabled OSINT sources using RQ"""
        sources = cls.get_all_for_collector()
        for source in sources:
            source.schedule_osint_source()
        logger.info(f"Scheduling for {len(sources)} OSINT Sources completed")

    def get_cron_spec(self) -> CronSpec:
        """Get the cron specification for this OSINT source"""
        return CronSpec(
            meta={
                "name": f"Collector: {self.name}",
                "task": "collector_task",
                "worker_id": self.id,
                "worker_type": self.type.value,
            },
            job_id=self.cron_job_id,
            cron=self.get_schedule_with_default(),
            func_path="collector_task",
            args=[self.id, False],
            queue_name="collectors",
        )

    def schedule_osint_source(self):
        """Schedule this OSINT source collection using RQ

        The scheduler process reads cron definitions from Redis.
        This method validates the source and upserts its cron definition.
        """
        from core.managers import queue_manager

        if self.type == COLLECTOR_TYPES.MANUAL_COLLECTOR:
            logger.warning(f"OSINT Source: {self.name} is a manual collector, skipping scheduling")
            return {"message": "Manual collector does not need to be scheduled"}, 200

        if not self.enabled:
            logger.warning(f"OSINT Source: {self.name} is disabled, skipping scheduling")
            return {"error": "OSINT Source is disabled", "id": f"{self.id}"}, 400

        return queue_manager.queue_manager.register_cron_job(self.get_cron_spec())

    def unschedule_osint_source(self):
        """Cancel scheduled collection for this OSINT source

        Removes the source cron definition from Redis.
        """
        from core.managers import queue_manager

        logger.info(f"Unscheduling {self.name}. Notifying cron scheduler...")
        return queue_manager.queue_manager.unregister_cron_job(self.cron_job_id)

    def to_export_dict(self, id_to_index_map: dict, export_args: dict) -> dict[str, Any]:
        export_dict: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "rank": self.rank,
            "type": self.type,
            "parameters": self.get_export_parameters(export_args.get("with_secrets", False)),
        }
        # test if source is in a group that is not default
        if export_args.get("with_groups", False) and any(group for group in self.groups if not group.default):
            export_dict["group_idx"] = id_to_index_map.get(self.id)

        return export_dict

    @classmethod
    def export_osint_sources(cls, export_args: dict | None = None) -> bytes:
        export_args = export_args or {}
        query = db.select(cls).where(cls.type != COLLECTOR_TYPES.MANUAL_COLLECTOR)
        if source_ids := export_args.get("source_ids", False):
            query = query.filter(cls.id.in_(source_ids))

        data = cls.get_filtered(query)
        if not data:
            return json.dumps({"error": "no sources found"}).encode("utf-8")

        id_to_index_map = {osint_source.id: idx for idx, osint_source in enumerate(data, 1)}
        sources = [osint_source.to_export_dict(id_to_index_map, export_args) for osint_source in data]
        export_data: dict[str, Any] = {
            "version": 4,
            "sources": sources,
        }
        if export_args.get("with_groups", False):
            groups = OSINTSourceGroup.get_all_without_default() or []
            export_data["groups"] = [group.to_export_dict(id_to_index_map) for group in groups]

        logger.debug(f"Exporting {len(sources)} sources")
        return json.dumps(export_data).encode("utf-8")

    def get_export_parameters(self, with_secrets: bool = False) -> dict[str, Any]:
        parameters = dict(self.parameters) if with_secrets else configured_parameters(self.type, self.parameters)
        if not with_secrets and parameters.get("PROXY_SERVER"):
            parameters["PROXY_SERVER"] = "<REDACTED>"
        return parameters

    @classmethod
    def parse_version_1(cls, data: list) -> list:
        for source in data:
            source["parameters"] = []
            for parameter in source.pop("parameter_values", []):
                source["parameters"].append({parameter["parameter"]["key"]: parameter["value"]})
            source["type"] = source.pop("collector")["type"]
        return data

    @staticmethod
    def normalize_rank(sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for source in sources:
            source["rank"] = source.get("rank", 0)
        return sources

    @staticmethod
    def normalize_use_feed_content_parameter(sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for source in sources:
            parameters = source.get("parameters")
            if not isinstance(parameters, dict):
                continue

            content_location_value = str(parameters.get("CONTENT_LOCATION", ""))
            has_use_feed_content = "USE_FEED_CONTENT" in parameters

            if not content_location_value and not has_use_feed_content:
                continue

            target_value = "true" if content_location_value and content_location_value.strip() else "false"
            parameters["USE_FEED_CONTENT"] = target_value

        return sources

    @staticmethod
    def normalize_use_feed_content_parameter_legacy(sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for source in sources:
            parameters = source.get("parameters")
            if not isinstance(parameters, list):
                continue

            content_location_value: str | None = None
            use_feed_content_index: int | None = None

            for idx, parameter in enumerate(parameters):
                if not isinstance(parameter, dict):
                    continue
                if "CONTENT_LOCATION" in parameter:
                    content_location_value = str(parameter.get("CONTENT_LOCATION", ""))
                if "USE_FEED_CONTENT" in parameter:
                    use_feed_content_index = idx

            if content_location_value is None and use_feed_content_index is None:
                continue

            target_value = "true" if content_location_value and content_location_value.strip() else "false"

            if use_feed_content_index is not None:
                parameters[use_feed_content_index]["USE_FEED_CONTENT"] = target_value
            else:
                parameters.append({"USE_FEED_CONTENT": target_value})

        return sources

    @staticmethod
    def convert_legacy_import_parameters(parameters: Any) -> Any:
        if not isinstance(parameters, list):
            return parameters

        converted: dict[str, Any] = {}
        for parameter in parameters:
            if not isinstance(parameter, dict) or len(parameter) != 1:
                return parameters
            key, value = next(iter(parameter.items()))
            converted[key] = value
        return converted

    @classmethod
    def convert_legacy_import_sources(cls, sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
        converted_sources = []
        for source in sources:
            converted_source = dict(source)
            converted_source["parameters"] = cls.convert_legacy_import_parameters(source.get("parameters"))
            converted_sources.append(converted_source)
        return converted_sources

    @classmethod
    def add_multiple_with_group(cls, sources, groups) -> list[str]:
        normalized_sources = []
        for source in sources:
            data = dict(source)
            idx = data.pop("group_idx", None)
            normalized_sources.append((idx, cls.from_dict(data)))

        index_to_source: dict[Any, OSINTSource] = {}
        items_to_schedule: list[OSINTSource] = []
        try:
            default_group = OSINTSourceGroup.get_default()
            for idx, item in normalized_sources:
                db.session.add(item)
                items_to_schedule.append(item)
                if default_group:
                    default_group.osint_sources.append(item)
                index_to_source[idx if idx is not None else item.id] = item

            for source_group in groups:
                group = dict(source_group)
                source_indexes = group.pop("osint_sources", [])
                imported_group = OSINTSourceGroup(**group)
                imported_group.osint_sources = [index_to_source[idx] for idx in source_indexes if idx in index_to_source]
                db.session.add(imported_group)
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise
        for item in items_to_schedule:
            item.schedule_osint_source()
        return [item.id for item in items_to_schedule]

    @classmethod
    def import_osint_sources(cls, file) -> list[str]:
        file_data = file.read()
        json_data = json.loads(file_data.decode("utf8"))
        return cls.import_osint_sources_from_json(json_data)

    @classmethod
    def import_osint_sources_from_json(cls, json_data) -> list[str]:
        groups = []
        if json_data["version"] == 1:
            data = cls.parse_version_1(json_data["data"])
            data = cls.normalize_rank(data)
            data = cls.normalize_use_feed_content_parameter_legacy(data)
            data = cls.convert_legacy_import_sources(data)
        elif json_data["version"] == 2:
            data = json_data["data"]
            data = cls.normalize_rank(data)
            data = cls.normalize_use_feed_content_parameter_legacy(data)
            data = cls.convert_legacy_import_sources(data)
        elif json_data["version"] == 3:
            data = json_data["sources"]
            groups = json_data.get("groups", [])
            data = cls.normalize_rank(data)
            data = cls.normalize_use_feed_content_parameter_legacy(data)
            data = cls.convert_legacy_import_sources(data)
        elif json_data["version"] == 4:
            data = json_data["sources"]
            groups = json_data.get("groups", [])
            data = cls.normalize_rank(data)
            data = cls.normalize_use_feed_content_parameter(data)
        else:
            raise ValueError("Unsupported version")

        ids = cls.add_multiple_with_group(data, groups)
        logger.debug(f"Imported {len(ids)} sources")
        return ids

    @staticmethod
    def get_curated_catalog() -> CuratedOSINTSourceCatalog:
        filename = "curated_osint_sources.json"
        catalog_path = Path(get_default_json(filename)) / filename
        with catalog_path.open(encoding="utf-8") as catalog_file:
            return CuratedOSINTSourceCatalog.model_validate(json.load(catalog_file))

    @classmethod
    def get_curated_list_summaries(cls) -> list[dict[str, Any]]:
        catalog = cls.get_curated_catalog()
        return [
            {
                "name": curated_list.name,
                "description": curated_list.description,
                "source_count": len(curated_list.sources),
            }
            for curated_list in catalog.lists
        ]

    @classmethod
    def load_curated_lists(cls, list_names: set[str]) -> dict[str, int | str]:
        catalog = cls.get_curated_catalog()
        catalog_lists = {curated_list.name: curated_list for curated_list in catalog.lists}
        if unknown_list_names := set(list_names) - catalog_lists.keys():
            raise ValueError(f"Unknown curated list names: {', '.join(sorted(unknown_list_names))}")

        selected_lists = [catalog_lists[name] for name in list_names]
        selected_source_names = {name for curated_list in selected_lists for name in curated_list.sources}
        catalog_sources = {source.name: source for source in catalog.sources}
        existing_sources = {
            source.name: source for source in db.session.execute(db.select(cls).where(cls.name.in_(selected_source_names))).scalars()
        }
        existing_groups = {
            group.name: group
            for group in db.session.execute(db.select(OSINTSourceGroup).where(OSINTSourceGroup.name.in_(list_names))).scalars()
        }
        resolved_sources: dict[str, OSINTSource] = {}
        created_sources: list[OSINTSource] = []

        try:
            for source_name in selected_source_names:
                source = existing_sources.get(source_name)
                if source is not None and source.type != catalog_sources[source_name].type:
                    raise CuratedOSINTSourceConflictError(source_name)
                if source is None:
                    source = cls.from_payload(catalog_sources[source_name])
                    db.session.add(source)
                    created_sources.append(source)
                resolved_sources[source_name] = source

            default_group = OSINTSourceGroup.get_default()
            if default_group:
                for source in created_sources:
                    if source not in default_group.osint_sources:
                        default_group.osint_sources.append(source)

            created_group_count = 0
            updated_group_count = 0
            for curated_list in selected_lists:
                group = existing_groups.get(curated_list.name)
                if group is None:
                    group = OSINTSourceGroup(name=curated_list.name, description=curated_list.description)
                    db.session.add(group)
                    created_group_count += 1
                else:
                    updated_group_count += 1

                for source_name in curated_list.sources:
                    source = resolved_sources[source_name]
                    if source not in group.osint_sources:
                        group.osint_sources.append(source)

            db.session.commit()
        except Exception:
            db.session.rollback()
            raise

        scheduling_failed = False
        for source in resolved_sources.values():
            if not source.enabled:
                continue
            try:
                if source.schedule_osint_source() is not True:
                    scheduling_failed = True
                    logger.error("Failed to schedule curated OSINT source %s", source.id)
            except Exception:
                scheduling_failed = True
                logger.exception("Failed to schedule curated OSINT source %s", source.id)

        if scheduling_failed:
            raise CuratedOSINTSourceSchedulingError

        return {
            "message": "Curated OSINT sources loaded successfully",
            "created_source_count": len(created_sources),
            "reused_source_count": len(selected_source_names) - len(created_sources),
            "created_group_count": created_group_count,
            "updated_group_count": updated_group_count,
        }

    @classmethod
    def get_all_for_assess_api(cls, user=None) -> tuple[dict[str, Any], int]:
        filter_args = {}
        query = cls.get_filter_query_with_acl(filter_args, user) if user else cls.get_filter_query(filter_args)
        if items := cls.get_filtered(query):
            return {"items": [item.to_assess_dict() for item in items]}, 200

        return {"items": []}, 200

    @classmethod
    def delete_all(cls) -> tuple[dict[str, Any], int]:
        # Clear the association table entries
        db.session.execute(db.delete(OSINTSourceGroupOSINTSource).where(OSINTSourceGroupOSINTSource.osint_source_id.in_(db.select(cls.id))))

        # Delete all rows from the OSINTSource table
        db.session.execute(db.delete(cls))
        db.session.commit()
        logger.debug(f"All {cls.__name__} deleted")
        return {"message": f"All {cls.__name__} deleted"}, 200


class OSINTSourceGroup(BaseModel):
    __tablename__ = "osint_source_group"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    key: Mapped[str | None] = db.Column(db.String(64), unique=True, nullable=True)
    name: Mapped[str] = db.Column(db.String(), nullable=False, unique=True)
    description: Mapped[str] = db.Column(db.String())
    default: Mapped[bool] = db.Column(db.Boolean(), default=False)

    osint_sources: Mapped[list["OSINTSource"]] = relationship(
        "OSINTSource",
        secondary="osint_source_group_osint_source",
        back_populates="groups",
    )
    word_lists: Mapped[list["WordList"]] = relationship("WordList", secondary="osint_source_group_word_list")

    def __init__(self, name, description="", osint_sources=None, default=False, word_lists=None, id=None):
        try:
            self.id = self.normalize_uuid_id(id)
        except ValueError:
            self.id = self.uuid7_str()
            self.key = str(id)
        self.name = name
        self.description = description
        self.default = default
        self.osint_sources = OSINTSource.get_bulk(osint_sources or []) or []
        self.word_lists = WordList.get_bulk(word_lists or [])

    @classmethod
    def get_all_without_default(cls):
        return cls.get_filtered(db.select(cls).filter(OSINTSourceGroup.default.is_(False)).order_by(db.asc(OSINTSourceGroup.name)))

    @classmethod
    def get_filter_query_with_acl(cls, filter_args: dict, user) -> Select:
        query = cls.get_filter_query(filter_args)
        rbac = RBACQuery(user=user, resource_type=ItemType.OSINT_SOURCE_GROUP)
        return RoleBasedAccessService.filter_query_with_acl(query, rbac)

    @classmethod
    def get_filter_query(cls, filter_args: dict) -> Select:
        query = db.select(cls)

        if search := filter_args.get("search"):
            query = query.where(db.or_(cls.name.ilike(f"%{search}%"), cls.description.ilike(f"%{search}%")))

        return query.order_by(db.asc(cls.name))

    def to_word_list_dict(self):
        flat_entry_list = []
        word_list_entries = [word_list.to_entry_dict() for word_list in self.word_lists if word_list]
        for sublist in word_list_entries:
            flat_entry_list.extend(sublist)
        return flat_entry_list, 200

    @classmethod
    def get_default(cls):
        return cls.get_first(db.select(cls).filter(OSINTSourceGroup.default))

    @classmethod
    def get(cls, item_id: str | None) -> "OSINTSourceGroup | None":
        if item_id is None:
            return None
        lookup_id = str(item_id)
        if osint_source_group := super().get(lookup_id):
            return osint_source_group
        try:
            normalized_id = cls.normalize_uuid_id(item_id)
        except (TypeError, ValueError):
            normalized_id = None
        if normalized_id and normalized_id != lookup_id and (osint_source_group := super().get(normalized_id)):
            return osint_source_group
        if lookup_id:
            return cls.get_by_key(lookup_id)
        return None

    @classmethod
    def get_by_key(cls, key: str | None) -> "OSINTSourceGroup | None":
        if not key:
            return None
        return cls.get_first(db.select(cls).filter_by(key=key))

    def to_export_dict(self, source_mapping: dict) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "osint_sources": [
                source_mapping[osint_source.id] for osint_source in self.osint_sources if osint_source and osint_source.id in source_mapping
            ],
        }

    def allowed_with_acl(self, user: "User | None", require_write_access) -> bool:
        if not RoleBasedAccess.is_enabled() or not user:
            return True

        query = RBACQuery(
            user=user, resource_id=self.id, resource_type=ItemType.OSINT_SOURCE_GROUP, require_write_access=require_write_access
        )

        return RoleBasedAccessService.user_has_access_to_resource(query)

    def to_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data["osint_sources"] = [osint_source.id for osint_source in self.osint_sources if osint_source]
        data["word_lists"] = [word_list.id for word_list in self.word_lists if word_list]
        return data

    @classmethod
    def delete(cls, osint_source_group_id: str, user: "User | None" = None) -> tuple[dict, int]:
        osint_source_group = cls.get(osint_source_group_id)
        if not osint_source_group:
            return {"error": "No Sourcegroup found"}, 404
        if osint_source_group.default is True:
            return {"error": "could_not_delete_default_group"}, 400

        if not osint_source_group.allowed_with_acl(user=user, require_write_access=True):
            return {"error": "User not allowed to update this group"}, 403

        db.session.delete(osint_source_group)
        db.session.commit()
        return {"message": "OSINT source group deleted"}, 200

    @classmethod
    def update(cls, osint_source_group_id: str, data: dict[str, Any], user: "User | None" = None) -> tuple[dict[str, str], int]:
        osint_source_group = cls.get(osint_source_group_id)
        if osint_source_group is None:
            return {"error": "OSINT Source Group not found"}, 404

        if not osint_source_group.allowed_with_acl(user=user, require_write_access=True):
            return {"error": "User not allowed to update this group"}, 403

        if name := data.get("name"):
            osint_source_group.name = name

        if description := data.get("description"):
            osint_source_group.description = description
        osint_sources = data.get("osint_sources", [])
        osint_source_group.osint_sources = OSINTSource.get_bulk(osint_sources)
        word_lists = data.get("word_lists", [])
        osint_source_group.word_lists = WordList.get_bulk(word_lists)
        db.session.commit()
        return {"message": "OSINT source group updated", "id": f"{osint_source_group.id}"}, 201

    def to_assess_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "key": self.key,
            "name": self.name,
        }

    @classmethod
    def get_all_for_assess_api(cls, user=None) -> tuple[dict[str, Any], int]:
        filter_args = {}
        query = cls.get_filter_query_with_acl(filter_args, user) if user else cls.get_filter_query(filter_args)
        if items := cls.get_filtered(query):
            return {"items": [item.to_assess_dict() for item in items]}, 200

        return {"items": []}, 404


class OSINTSourceGroupOSINTSource(BaseModel):
    osint_source_group_id = db.Column(
        db.String(UUID_STR_LENGTH), db.ForeignKey("osint_source_group.id", ondelete="SET NULL"), primary_key=True
    )
    osint_source_id = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("osint_source.id", ondelete="SET NULL"), primary_key=True)


class OSINTSourceGroupWordList(BaseModel):
    osint_source_group_id = db.Column(
        db.String(UUID_STR_LENGTH), db.ForeignKey("osint_source_group.id", ondelete="SET NULL"), primary_key=True
    )
    word_list_id = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("word_list.id", ondelete="SET NULL"), primary_key=True)
