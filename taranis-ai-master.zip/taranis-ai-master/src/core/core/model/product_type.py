import os
from typing import Any

from models.types import PRESENTER_TYPES
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Mapped, relationship
from sqlalchemy.sql.expression import Select

from core.log import logger
from core.managers.data_manager import (
    get_presenter_template_path,
    get_template_as_base64,
    validate_existing_presenter_template_id,
)
from core.managers.db_manager import db
from core.model.base_model import UUID_STR_LENGTH, BaseModel
from core.model.report_item_type import ReportItemType
from core.model.role_based_access import ItemType, RoleBasedAccess
from core.service.role_based_access import RBACQuery, RoleBasedAccessService
from core.service.worker_parameters import configured_parameters, effective_parameters, set_parameters


class ProductType(BaseModel):
    __tablename__ = "product_type"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    title: Mapped[str] = db.Column(db.String(64), unique=True, nullable=False)
    description: Mapped[str] = db.Column(db.String())
    type: Mapped[PRESENTER_TYPES] = db.Column(db.Enum(PRESENTER_TYPES))

    parameters: Mapped[dict[str, Any]] = db.Column(db.JSON, nullable=False, default=dict)
    report_types: Mapped[list["ReportItemType"]] = relationship("ReportItemType", secondary="product_type_report_type")

    def __init__(self, title, type, description="", parameters=None, report_types=None, id=None):
        self.id = self.normalize_uuid_id(id)
        self.title = title
        self.type = type
        self.description = description
        self.parameters = self._parse_parameters(type, parameters)
        if report_types:
            self.report_types = ReportItemType.get_bulk(report_types)

    def allowed_with_acl(self, user, require_write_access) -> bool:
        if not RoleBasedAccess.is_enabled() or not user:
            return True

        query = RBACQuery(user=user, resource_id=str(self.id), resource_type=ItemType.PRODUCT_TYPE, require_write_access=require_write_access)

        return RoleBasedAccessService.user_has_access_to_resource(query)

    @classmethod
    def get_filter_query(cls, filter_args: dict) -> Select:
        query = db.select(cls)

        if search := filter_args.get("search"):
            query = query.where(
                db.or_(
                    cls.title.ilike(f"%{search}%"),
                    cls.description.ilike(f"%{search}%"),
                    cls.type.ilike(f"%{search}%"),
                )
            )

        return query

    @classmethod
    def default_sort_column(cls) -> str:
        return "title_asc"

    @classmethod
    def filter_by_title(cls, title: str) -> "ProductType | None":
        try:
            return db.session.execute(db.select(cls).where(cls.title == title)).scalar_one_or_none()
        except SQLAlchemyError:
            logger.exception(f"Error filtering product types by title: {title}")
            return None

    @classmethod
    def get_filter_query_with_acl(cls, filter_args: dict, user) -> Select:
        query = cls.get_filter_query(filter_args)
        rbac = RBACQuery(user=user, resource_type=ItemType.PRODUCT_TYPE)
        return RoleBasedAccessService.filter_query_with_acl(query, rbac)

    @classmethod
    def get_all_for_api(cls, filter_args: dict | None, with_count: bool = False, user=None) -> tuple[dict[str, Any], int]:
        filter_args = filter_args or {}
        logger.debug(f"Filtering {cls.__name__} with {filter_args}")
        query = cls.get_filter_query_with_acl(filter_args, user) if user else cls.get_filter_query(filter_args)
        items = cls.get_filtered(query)
        if not items:
            return {"items": []}, 200
        if with_count:
            count = cls.get_filtered_count(query)
            return {"total_count": count, "items": cls.to_list(items)}, 200
        return {"items": cls.to_list(items)}, 200

    @classmethod
    def update(cls, product_type_id: str, data, user=None, *, patch: bool = False) -> tuple[dict, int]:
        product_type = cls.get(product_type_id)
        logger.debug(f"Updating {cls.__name__} with id {product_type_id} and data {data}")
        if not product_type:
            logger.error(f"Could not find product type with id {product_type_id}")
            return {"error": "Product type not found"}, 404
        if user and not product_type.allowed_with_acl(user, require_write_access=True):
            logger.error(f"User {user} does not have write access to product type {product_type_id}")
            return {"error": "User does not have write access to this product type"}, 403

        if "type" in data and PRESENTER_TYPES(data["type"]) != product_type.type:
            raise ValueError("Worker type is immutable")
        if "parameters" in data:
            product_type.parameters = cls._parse_parameters(
                product_type.type,
                data.get("parameters"),
                current=product_type.parameters,
                patch=patch,
            )

        if title := data.get("title"):
            product_type.title = title

        if "description" in data:
            product_type.description = data.get("description") or ""
        elif not patch:
            product_type.description = ""

        report_types = data.get("report_types", None)
        if report_types is not None:
            product_type.report_types = ReportItemType.get_bulk(report_types)
        db.session.commit()
        return {"message": "Product type updated", "id": product_type.id}, 200

    @staticmethod
    def _parse_parameters(
        worker_type: str,
        parameters,
        *,
        current: dict[str, Any] | None = None,
        patch: bool = False,
    ) -> dict[str, Any]:
        parsed_parameters = set_parameters(worker_type, current, parameters, patch=patch, complete=True)
        if template := parsed_parameters.get("TEMPLATE_PATH"):
            parsed_parameters["TEMPLATE_PATH"] = validate_existing_presenter_template_id(template)
        return parsed_parameters

    def to_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data["report_types"] = [report_type.id for report_type in self.report_types if report_type]
        data["parameters"] = configured_parameters(self.type, self.parameters)
        return data

    def to_worker_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data["parameters"] = effective_parameters(self.type, self.parameters)
        data["report_types"] = [report_type.id for report_type in self.report_types if report_type]
        return data

    def _get_template_path(self) -> str:
        # get value of parameter where parameter.parameter == "TEMPLATE_PATH"
        template_path = self.parameters.get("TEMPLATE_PATH", "")
        if not template_path:
            logger.debug("Product type has no TEMPLATE_PATH parameter")
            return ""
        return template_path

    def get_template(self) -> str:
        full_path = get_presenter_template_path(self._get_template_path())
        return full_path if os.path.isfile(full_path) else ""

    def get_detail_json(self):
        data = self.to_dict()
        if template := self.get_template():
            data["template"] = get_template_as_base64(os.path.basename(template))
        return data

    @classmethod
    def get_for_api(cls, item_id) -> tuple[dict[str, Any], int]:
        if item := cls.get(item_id):
            return item.get_detail_json(), 200
        return {"error": f"{cls.__name__} not found"}, 404

    @classmethod
    def get_by_type(cls, product_type: PRESENTER_TYPES) -> "ProductType|None":
        return cls.get_first(db.select(cls).filter_by(type=product_type))

    def get_mimetype(self) -> str:
        if self.type.startswith("image"):
            return "image/png"
        if self.type.startswith("pandoc"):
            data_format = self.parameters.get("CONVERT_TO")
            if data_format == "docx":
                return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            if data_format == "odt":
                return "application/vnd.oasis.opendocument.text"
        if self.type.startswith("pdf"):
            return "application/pdf"
        if self.type.startswith("html"):
            return "text/html"
        if self.type.startswith("text"):
            return "text/plain"
        if self.type.startswith("json"):
            return "application/json"
        if self.type.startswith("stix"):
            return "application/stix+json"
        return "application/octet-stream"

    @classmethod
    def delete(cls, product_id: str) -> tuple[dict[str, Any], int]:
        from core.model.product import Product

        product_type = cls.get(product_id)
        if not product_type:
            return {"error": "Product type not found"}, 404

        if Product.query.where(Product.product_type_id == product_id).first():
            return {"error": "Product type is used in a product"}, 409

        db.session.delete(product_type)
        db.session.commit()
        return {"message": "Product type deleted"}, 200


class ProductTypeReportType(BaseModel):
    product_type_id = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("product_type.id", ondelete="CASCADE"), primary_key=True)
    report_item_type_id = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("report_item_type.id"), primary_key=True)
