import base64
import binascii
import json
import uuid
from collections.abc import Sequence
from datetime import UTC, datetime
from enum import Enum
from typing import TYPE_CHECKING, Any, Self, TypeVar

from sqlalchemy import func
from sqlalchemy.orm import Mapped
from sqlalchemy.sql import Select

from core.log import logger
from core.managers.db_manager import db


T = TypeVar("T", bound="BaseModel")
DB_INTEGER_MAX = (2**63) - 1
UUID_STR_LENGTH = 36


class BaseModel(db.Model):
    __allow_unmapped__ = True
    __abstract__ = True

    if TYPE_CHECKING:
        id: Mapped[str]

    def __str__(self) -> str:
        return f"{self.__class__.__name__}"

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}"

    def update(self, item: dict[str, Any]) -> tuple[dict, int]:
        for key, value in item.items():
            if hasattr(self, key) and key != "id":
                setattr(self, key, value)

        db.session.commit()
        return {"message": f"{self.__class__.__name__} successfully updated"}, 200

    @staticmethod
    def utcnow() -> datetime:
        return datetime.now(UTC).replace(tzinfo=None)

    @staticmethod
    def uuid7_str() -> str:
        return str(uuid.uuid7())

    @staticmethod
    def normalize_uuid_id(value: Any | None) -> str:
        if value in (None, ""):
            return BaseModel.uuid7_str()
        if isinstance(value, uuid.UUID):
            return str(value)
        return str(uuid.UUID(str(value)))

    @staticmethod
    def as_utc_aware(value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)

    @classmethod
    def serialize_datetime(cls, value: datetime) -> str:
        return cls.as_utc_aware(value).isoformat()

    def to_dict(self) -> dict[str, Any]:
        table = getattr(self, "__table__", None)
        if table is None:
            return {}
        data = {c.name: getattr(self, c.name) for c in table.columns}
        for key, value in data.items():
            if isinstance(value, datetime):
                data[key] = self.serialize_datetime(value)
            elif isinstance(value, Enum):
                data[key] = value.value
        return data

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def delete(cls, id) -> tuple[dict[str, Any], int]:
        model_name = type.__getattribute__(cls, "__name__")
        if item := cls.get(id):
            db.session.delete(item)
            db.session.commit()
            return {"message": f"{model_name} deleted"}, 200
        logger.warning(f"{model_name} {id} not found")
        return {"error": f"{model_name} not found"}, 404

    @classmethod
    def add(cls, data) -> Self:
        item = cls.from_dict(data)
        db.session.add(item)
        db.session.commit()
        return item

    @classmethod
    def add_multiple(cls, json_data) -> list[Self]:
        items = cls.load_multiple(json_data)
        db.session.add_all(items)
        db.session.commit()
        return items

    @classmethod
    def delete_all(cls) -> tuple[dict[str, Any], int]:
        db.session.execute(db.delete(cls))
        db.session.commit()
        model_name = type.__getattribute__(cls, "__name__")
        logger.debug(f"All {model_name} deleted")
        return {"message": f"All {model_name} deleted"}, 200

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        return cls(**data)

    def to_detail_dict(self) -> dict[str, Any]:
        return self.to_dict()

    @classmethod
    def load_multiple(cls, json_data: list[dict[str, Any]]) -> list[Self]:
        return [cls.from_dict(data) for data in json_data]

    @classmethod
    def to_list(cls, objects: list[T] | Sequence[T]) -> list[dict[str, Any]]:
        return [obj.to_dict() for obj in objects]

    @classmethod
    def get(cls, item_id: str | None) -> Self | None:
        return None if item_id in (None, "") else db.session.get(cls, item_id)

    @classmethod
    def get_all_for_collector(cls) -> Sequence[Self] | None:
        return db.session.execute(db.select(cls)).scalars().all()

    @classmethod
    def get_bulk(cls, item_ids: list[str]) -> list[Self]:
        return list(db.session.execute(db.select(cls).filter(cls.id.in_(item_ids))).scalars().all())

    @classmethod
    def get_for_api(cls, item_id, **kwargs) -> tuple[dict[str, Any], int]:
        if item := cls.get(item_id):
            return item.to_detail_dict(), 200
        return {"error": f"{cls.__name__} not found"}, 404

    @classmethod
    def get_filter_query_with_acl(cls, filter_args: dict, user) -> Select:
        return cls.get_filter_query(filter_args)

    @classmethod
    def get_filter_query(cls, filter_args: dict) -> Select:
        query = db.select(cls)

        if search := filter_args.get("search"):
            query = query.filter(cls.id.ilike(f"%{search}%"))

        return query

    @classmethod
    def get_filtered(cls, query: Select) -> Sequence[Self] | None:
        return db.session.execute(query).scalars().all()

    @classmethod
    def get_first(cls, query: Select) -> Self | None:
        return db.session.execute(query).scalar()

    @classmethod
    def get_by_filter(cls, filter_args: dict) -> Sequence[Self] | None:
        return cls.get_filtered(cls.get_filter_query(filter_args))

    @classmethod
    def default_sort_column(cls) -> str:
        return ""

    @classmethod
    def _add_paging_to_query(cls, filter_args: dict[str, Any], query: Select) -> Select:
        page = int(filter_args.get("page", 1)) - 1
        limit = max(min(int(filter_args.get("limit", 20)), DB_INTEGER_MAX), 0)
        offset = filter_args.get("offset")
        if offset is None:
            offset = page * limit if limit and limit > 0 else None

        if offset is not None:
            query = query.offset(max(min(int(offset), DB_INTEGER_MAX), 0))
        if limit and limit > 0:
            query = query.limit(limit)

        return query

    @classmethod
    def _add_sorting_to_query(cls, filter_args: dict[str, Any], query: Select) -> Select:
        if sort := filter_args.get("sort", filter_args.get("order", cls.default_sort_column())):
            query = query.order_by(None)  # Remove any default ordering on the base query so caller-provided sort takes precedence.
            if "_" in sort:
                sort_column, sort_direction = sort.rsplit("_", 1)
            else:
                sort_column, sort_direction = sort, "asc"
            table = getattr(cls, "__table__", None)
            if table is not None and sort_column in table.columns:
                sort_attr = getattr(cls, sort_column)
                direction = sort_direction.lower()
                if direction == "desc":
                    query = query.order_by(sort_attr.desc())
                else:
                    query = query.order_by(sort_attr.asc())
            else:
                logger.warning(f"Sort column {sort_column} not found on {cls.__name__}; ignoring sort")
        return query

    @classmethod
    def get_all_for_api(
        cls,
        filter_args: dict[str, Any] | None,
        with_count: bool = False,
        user=None,
    ) -> tuple[dict[str, Any], int]:
        filter_args = filter_args or {}
        logger.debug(f"Filtering {cls.__name__} with {filter_args}")

        base_query = cls.get_filter_query_with_acl(filter_args, user) if user else cls.get_filter_query(filter_args)

        query = base_query
        if not cls._should_fetch_all(filter_args):
            query = cls._add_paging_to_query(filter_args, query)

        query = cls._add_sorting_to_query(filter_args, query)

        items = cls.get_filtered(query) or []
        if with_count:
            count = cls.get_filtered_count(base_query)
            return {"total_count": count, "items": cls.to_list(items)}, 200
        return {"items": cls.to_list(items)}, 200

    @classmethod
    def _should_fetch_all(cls, filter_args: dict[str, Any]) -> bool:
        return filter_args.get("fetch_all") == "true"

    @classmethod
    def get_filtered_count(cls, query: Select) -> int:
        count_query = db.select(func.count()).select_from(query).order_by(None).offset(None).limit(None)
        return db.session.execute(count_query).scalar() or 0

    @classmethod
    def get_count(cls) -> int:
        count_query = db.select(func.count()).select_from(cls)
        return db.session.execute(count_query).scalar() or 0

    def is_valid_base64(self, s) -> bytes | None:
        try:
            return base64.b64decode(s, validate=True)
        except (binascii.Error, TypeError, ValueError):
            return None
