import builtins
from datetime import datetime
from typing import Any

from models.types import COLLECTOR_TYPES, CONNECTOR_TYPES
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Mapped, deferred

from core.log import logger
from core.managers.db_manager import db
from core.model.base_model import UUID_STR_LENGTH, BaseModel
from core.model.news_item import NewsItem
from core.model.settings import Settings
from core.model.story import Story
from core.service.worker_parameters import configured_parameters, effective_parameters, set_parameters


class Connector(BaseModel):
    __tablename__ = "connector"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    name: Mapped[str] = db.Column(db.String(), nullable=False)
    description: Mapped[str] = db.Column(db.String())

    type: Mapped[CONNECTOR_TYPES] = db.Column(db.Enum(CONNECTOR_TYPES))
    parameters: Mapped[dict[str, Any]] = db.Column(db.JSON, nullable=False, default=dict)
    icon: Any = deferred(db.Column(db.LargeBinary))
    state: Mapped[int] = db.Column(db.SmallInteger, default=-1)
    last_collected: Mapped[datetime] = db.Column(db.DateTime, default=None)
    last_attempted: Mapped[datetime] = db.Column(db.DateTime, default=None)
    last_error_message: Mapped[str | None] = db.Column(db.String, default=None, nullable=True)

    def __init__(self, name: str, description: str, type: str | COLLECTOR_TYPES, parameters=None, icon=None, id=None):
        self.id = self.normalize_uuid_id(id)
        self.name = name
        self.description = description
        self.type = type if isinstance(type, CONNECTOR_TYPES) else CONNECTOR_TYPES(type.lower())
        if icon is not None and (icon_data := self.is_valid_base64(icon)):
            self.icon = icon_data

        self.parameters = set_parameters(self.type, {}, parameters, patch=False, complete=True)

    def to_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data["parameters"] = configured_parameters(self.type, self.parameters)
        return data

    def to_worker_dict(self) -> dict[str, Any]:
        data = super().to_dict()
        data["parameters"] = effective_parameters(self.type, self.parameters)
        if data["parameters"].get("USE_GLOBAL_PROXY"):
            data["parameters"]["PROXY_SERVER"] = Settings.get_settings().get("default_collector_proxy", "")
        return data

    def to_user_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "type": self.type.value if self.type else None,
        }

    @classmethod
    def get_all_for_user_api(cls, filter_args: dict[str, Any] | None, user=None) -> tuple[dict[str, Any], int]:
        filter_args = filter_args or {}
        logger.debug(f"Filtering {cls.__name__} for user API with {filter_args}")

        base_query = cls.get_filter_query_with_acl(filter_args, user) if user else cls.get_filter_query(filter_args)

        query = base_query
        if not cls._should_fetch_all(filter_args):
            query = cls._add_paging_to_query(filter_args, query)

        query = cls._add_sorting_to_query(filter_args, query)

        items = cls.get_filtered(query) or []
        count = cls.get_filtered_count(base_query)
        return {"total_count": count, "items": [item.to_user_dict() for item in items]}, 200

    @classmethod
    def add(cls, data):
        connector = cls.from_dict(data)
        db.session.add(connector)
        db.session.commit()
        connector.schedule_connector()
        return connector

    def schedule_connector(self):
        """TODO: Lower priority"""

    def unschedule_connector(self):
        """TODO: Lower priority"""

    @classmethod
    def update(cls, connector_id: str, data: dict, *, patch: bool = False) -> "Connector | None":
        connector = cls.get(connector_id)
        if not connector:
            return None
        if "type" in data and CONNECTOR_TYPES(data["type"]) != connector.type:
            raise ValueError("Worker type is immutable")
        if name := data.get("name"):
            connector.name = name
        if "description" in data:
            connector.description = data.get("description", "")
        elif not patch:
            connector.description = ""
        if "state" in data and data["state"] is not None:
            connector.state = data["state"]
        icon_str = data.get("icon")
        if icon_str is not None and (icon := connector.is_valid_base64(icon_str)):
            connector.icon = icon
        if "parameters" in data:
            connector.parameters = set_parameters(connector.type, connector.parameters, data.get("parameters"), patch=patch, complete=True)
        db.session.commit()
        connector.schedule_connector()
        return connector

    @classmethod
    def delete(cls, connector_id: str, force: bool = False) -> tuple[dict, int]:
        from core.model.story import StoryMispAutoUpdate
        from core.service.misp_auto_update import cancel_misp_auto_update_jobs

        if not (connector := cls.get(connector_id)):
            return {"error": "Connector not found"}, 404

        configured_story_ids = StoryMispAutoUpdate.get_story_ids(connector_id)
        try:
            connector.unschedule_connector()
            db.session.delete(connector)
            db.session.commit()
            cancel_misp_auto_update_jobs(configured_story_ids)
            return {"message": "Connector deleted", "id": connector.id}, 200
        except IntegrityError as e:
            logger.warning(f"IntegrityError: {e.orig}")
            return {"error": "Deleting Connector failed"}, 500

    @staticmethod
    def _update_last_change(model_class: builtins.type, data: dict[str, str]) -> tuple[dict[str, str], int]:
        if not data:
            return {"error": "No data provided"}, 400

        for object_id, target_value in data.items():
            if target_value not in ["internal", "external"]:
                return {"error": "Invalid last-change value"}, 400

            if instance := model_class.get(object_id):
                instance.last_change = target_value
                logger.debug(f"Updated last_change for {model_class.__name__} with ID {object_id} to {target_value}")

        db.session.commit()
        return {"message": "Last change status updated for"}, 200

    @staticmethod
    def update_news_item_last_change(data: dict[str, str]):
        return Connector._update_last_change(NewsItem, data)

    @staticmethod
    def update_story_last_change(data: dict[str, str]):
        return Connector._update_last_change(Story, data)
