from typing import Any

from models.cti import normalize_ioc_type, normalize_ioc_value
from sqlalchemy import or_
from sqlalchemy.orm import Mapped, relationship
from sqlalchemy.sql import Select

from core.log import logger
from core.managers.db_manager import db
from core.model.base_model import UUID_STR_LENGTH, BaseModel
from core.model.organization import Organization
from core.model.report_item import ReportItem


class Asset(BaseModel):
    __tablename__ = "asset"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    name: Mapped[str] = db.Column(db.String(), nullable=False)
    serial: Mapped[str] = db.Column(db.String())
    description: Mapped[str] = db.Column(db.String())

    asset_group_id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("asset_group.id"))
    asset_group: Mapped["AssetGroup"] = relationship("AssetGroup")

    asset_cpes: Mapped[list["AssetCpe"]] = relationship("AssetCpe", cascade="all, delete-orphan", back_populates="asset")
    asset_observables: Mapped[list["AssetObservable"]] = relationship("AssetObservable", cascade="all, delete-orphan", back_populates="asset")

    vulnerabilities: Mapped[list["AssetVulnerability"]] = relationship(
        "AssetVulnerability", cascade="all, delete-orphan", back_populates="asset"
    )
    vulnerabilities_count: Mapped[int] = db.Column(db.Integer, default=0)

    def __init__(self, name, serial, description, group=None, asset_cpes=None, asset_observables=None, vulnerabilities=None, id=None):
        self.id = self.normalize_uuid_id(id)
        self.name = name
        self.serial = serial
        self.description = description
        if group:
            self.asset_group_id = group if isinstance(group, str) else group.id
        else:
            self.asset_group_id = AssetGroup.get_default_group().id
        self.asset_cpes = [a for a in (AssetCpe.get(cpe) for cpe in asset_cpes) if a] if asset_cpes else []
        self.asset_observables = self._load_observables(asset_observables)
        self.vulnerabilities = [v for v in (AssetVulnerability.get(vuln) for vuln in vulnerabilities) if v] if vulnerabilities else []

    @staticmethod
    def _load_observables(observables: list[dict[str, Any]] | None) -> list["AssetObservable"]:
        loaded: dict[tuple[str, str], AssetObservable] = {}
        for observable in observables or []:
            if not isinstance(observable, dict):
                continue
            raw_type = str(observable.get("ioc_type") or "").strip()
            raw_value = str(observable.get("value") or "").strip()
            if not raw_type and not raw_value:
                continue
            item = AssetObservable(raw_type, raw_value)
            loaded.setdefault((item.ioc_type, item.value), item)
        return list(loaded.values())

    @classmethod
    def get_by_cpe(cls, cpes):
        if len(cpes) <= 0:
            return []

        return cls.get_filtered(
            db.select(cls).join(AssetCpe, cls.id == AssetCpe.asset_id).filter(db.or_(*[AssetCpe.value.like(cpe) for cpe in cpes])).distinct()
        )

    @classmethod
    def remove_vulnerability(cls, report_item_id):
        vulnerabilities = AssetVulnerability.get_by_report(report_item_id)
        if not vulnerabilities:
            return
        for vulnerability in vulnerabilities:
            vulnerability.asset.vulnerabilities_count -= 1  # type: ignore
            db.session.delete(vulnerability)

    def add_vulnerability(self, report_item):
        for vulnerability in self.vulnerabilities:
            if vulnerability.report_item.id == report_item.id:
                return

        vulnerability = AssetVulnerability(self.id, report_item.id)
        db.session.add(vulnerability)
        self.vulnerabilities_count += 1

    def update_vulnerabilities(self):
        cpes = [cpe.value for cpe in self.asset_cpes if cpe]
        report_item_ids = ReportItem.get_by_cpe(cpes)
        if not report_item_ids:
            return

        solved = [vulnerability.report_item_id for vulnerability in self.vulnerabilities if vulnerability.solved is True]
        self.vulnerabilities = []
        self.vulnerabilities_count = 0
        for report_item_id in report_item_ids:
            vulnerability = AssetVulnerability(self.id, report_item_id)
            if report_item_id in solved:
                vulnerability.solved = True
            else:
                self.vulnerabilities_count += 1
            self.vulnerabilities.append(vulnerability)

    @classmethod
    def solve_vulnerability(cls, organization: Organization, asset_id, report_item_id, solved) -> tuple[dict, int]:
        asset = cls.get(asset_id)
        if not asset:
            return {"error": "Asset Not Found"}, 404
        if not AssetGroup.access_allowed(organization, asset.asset_group_id):
            return {"error": "Access Denied"}, 403

        for vulnerability in asset.vulnerabilities:
            if vulnerability.report_item_id == report_item_id:
                if solved is not vulnerability.solved:
                    if solved:
                        asset.vulnerabilities_count -= 1
                    else:
                        asset.vulnerabilities_count += 1
                vulnerability.solved = solved
                db.session.commit()
                return {"message": "Asset vulnerability updated"}, 200

        return {"error": "Asset Vulnerability Not Found"}, 404

    @classmethod
    def get_filter_query(cls, filter_args: dict) -> Select:
        query = db.select(cls)

        if search := filter_args.get("search"):
            query = (
                query.outerjoin(AssetCpe, Asset.id == AssetCpe.asset_id)
                .outerjoin(AssetObservable, Asset.id == AssetObservable.asset_id)
                .filter(
                    or_(
                        Asset.name.ilike(f"%{search}%"),
                        Asset.description.ilike(f"%{search}%"),
                        Asset.serial.ilike(f"%{search}%"),
                        AssetCpe.value.ilike(f"%{search}%"),
                        AssetObservable.ioc_type.ilike(f"%{search}%"),
                        AssetObservable.value.ilike(f"%{search}%"),
                    )
                )
                .distinct()
            )

        if group_id := filter_args.get("group"):
            query = query.filter(Asset.asset_group_id == group_id)

        if vulnerable := filter_args.get("vulnerable"):
            if vulnerable == "true":
                query = query.filter(Asset.vulnerabilities_count > 0)
            else:
                query = query.filter(Asset.vulnerabilities_count == 0)

        if organization := filter_args.get("organization"):
            query = query.join(AssetGroup, Asset.asset_group_id == AssetGroup.id).filter(AssetGroup.organization == organization)

        return query

    def to_dict(self):
        data = super().to_dict()
        data["asset_cpes"] = [asset_cpe.id for asset_cpe in self.asset_cpes if asset_cpe]
        data["asset_observables"] = [observable.to_dict() for observable in self.asset_observables]
        data["vulnerabilities"] = [vulnerability.id for vulnerability in self.vulnerabilities]
        return data

    @classmethod
    def get_for_api(cls, item_id, organization: Organization) -> tuple[dict[str, Any], int]:
        if (item := cls.get(item_id)) and AssetGroup.access_allowed(organization, item.asset_group_id):
            return item.to_dict(), 200
        return {"error": f"{cls.__name__} not found"}, 404

    @classmethod
    def add(cls, organization: Organization, data) -> tuple[dict, int]:
        try:
            asset = cls.from_dict(data)
        except ValueError:
            logger.exception("Failed to add asset")
            return {"error": "Invalid asset data"}, 400
        if not AssetGroup.access_allowed(organization, asset.asset_group_id):
            return {"error": "Access Denied"}, 403

        db.session.add(asset)
        asset.update_vulnerabilities()
        db.session.commit()
        return {"message": "Asset added", "id": asset.id}, 201

    @classmethod
    def update(cls, organization: Organization, asset_id, data) -> tuple[dict, int]:
        asset = cls.get(asset_id)
        if not asset:
            return {"error": "Asset Not Found"}, 404

        if not AssetGroup.access_allowed(organization, asset.asset_group_id):
            return {"error": "Access Denied"}, 403
        try:
            for key, value in data.items():
                if key == "asset_observables":
                    asset.asset_observables = cls._load_observables(value)
                elif hasattr(asset, key) and key != "id":
                    setattr(asset, key, value)
        except ValueError:
            logger.exception("Failed to update asset")
            return {"error": "Invalid asset data"}, 400
        asset.update_vulnerabilities()
        db.session.commit()
        return {"message": "Asset updated", "id": asset.id}, 201

    @classmethod
    def delete(cls, organization: Organization, id) -> tuple[dict, int]:
        asset = cls.get(id)
        if not asset:
            return {"error": "Asset Not Found"}, 404

        if not AssetGroup.access_allowed(organization, asset.asset_group_id):
            return {"error": "Access Denied"}, 403

        db.session.delete(asset)
        db.session.commit()
        return {"message": "Asset deleted", "id": asset.id}, 200


class AssetVulnerability(BaseModel):
    __tablename__ = "asset_vulnerability"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    solved: Mapped[bool] = db.Column(db.Boolean, default=False)

    asset_id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("asset.id"))
    asset: Mapped["Asset"] = relationship("Asset", back_populates="vulnerabilities")

    report_item_id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("report_item.id"))
    report_item: Mapped["ReportItem"] = relationship("ReportItem")

    def __init__(self, asset_id, report_item_id):
        self.id = self.uuid7_str()
        self.asset_id = asset_id
        self.report_item_id = report_item_id

    @classmethod
    def get_by_report(cls, report_id):
        return cls.get_filtered(db.select(cls).filter_by(report_item_id=report_id))


class AssetObservable(BaseModel):
    __tablename__ = "asset_observable"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    ioc_type: Mapped[str] = db.Column(db.String(32), nullable=False)
    value: Mapped[str] = db.Column(db.String(2048), nullable=False)

    asset_id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("asset.id"))
    asset: Mapped["Asset"] = relationship("Asset", back_populates="asset_observables")

    def __init__(self, ioc_type, value, id=None):
        normalized_type = normalize_ioc_type(str(ioc_type or ""))
        if not normalized_type:
            raise ValueError("Observable type must be one of: cve, email, ip, domain, url, hash")
        normalized_value = normalize_ioc_value(str(value or ""), normalized_type)
        if not normalized_value:
            raise ValueError("Observable value is required")
        self.id = self.normalize_uuid_id(id)
        self.ioc_type = normalized_type
        self.value = normalized_value


class AssetGroup(BaseModel):
    __tablename__ = "asset_group"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    key: Mapped[str | None] = db.Column(db.String(64), unique=True, nullable=True)
    name: Mapped[str] = db.Column(db.String(), nullable=False)
    description: Mapped[str] = db.Column(db.String())

    organization_id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("organization.id"))
    organization: Mapped["Organization|None"] = relationship("Organization")

    def __init__(self, name, description, organization, id=None):
        try:
            self.id = self.normalize_uuid_id(id)
        except ValueError:
            self.id = self.uuid7_str()
            self.key = str(id)
        self.name = name
        self.description = description
        self.organization = Organization.get(organization) if isinstance(organization, str) else organization

    @classmethod
    def access_allowed(cls, organization: Organization, group_id: str) -> bool:
        if (default_group := cls.get_by_key("default")) and group_id == default_group.id:
            return True
        if group := cls.get(group_id):
            return group.organization == organization
        return False

    @classmethod
    def get_default_group(cls) -> "AssetGroup":
        if default_group := cls.get_by_key("default"):
            return default_group
        if org := Organization.find_by_name("Default Organization") or Organization.get_first(db.select(Organization)):
            return AssetGroup.add(
                {
                    "name": "Default",
                    "description": "Default group for uncategorized assets",
                    "organization": org,
                    "id": "default",
                }
            )
        raise RuntimeError("Default organization not found. Cannot create default asset group.")

    @classmethod
    def get(cls, item_id: str | None) -> "AssetGroup | None":
        if item_id is None:
            return None
        lookup_id = str(item_id)
        if asset_group := super().get(lookup_id):
            return asset_group
        try:
            normalized_id = cls.normalize_uuid_id(item_id)
        except (TypeError, ValueError):
            normalized_id = None
        if normalized_id and normalized_id != lookup_id and (asset_group := super().get(normalized_id)):
            return asset_group
        if lookup_id:
            return cls.get_by_key(lookup_id)
        return None

    @classmethod
    def get_by_key(cls, key: str | None) -> "AssetGroup | None":
        if not key:
            return None
        return cls.get_first(db.select(cls).filter_by(key=key))

    @classmethod
    def get_for_api(cls, item_id, organization: Organization) -> tuple[dict[str, Any], int]:
        if not cls.access_allowed(organization, item_id):
            return {"error": "Access denied"}, 403

        return super().get_for_api(item_id)

    @classmethod
    def get_filter_query(cls, filter_args: dict) -> Select:
        query = db.select(cls)

        if search := filter_args.get("search"):
            query = query.filter(
                or_(
                    AssetGroup.name.ilike(f"%{search}%"),
                    AssetGroup.description.ilike(f"%{search}%"),
                )
            )

        if organization := filter_args.get("organization"):
            query = query.filter_by(organization_id=organization.id)

        return query.order_by(db.asc(AssetGroup.name))

    @classmethod
    def delete(cls, organization: Organization, group_id):
        if group_id == "default":
            return {"error": "Cannot delete default group"}, 400
        if not cls.access_allowed(organization, group_id):
            return {"error": "Access denied"}, 403

        group = cls.get(group_id)
        db.session.delete(group)
        db.session.commit()

        return {"message": "Group deleted"}, 200

    @classmethod
    def update(cls, organization: Organization, group_id, data):
        if not cls.access_allowed(organization, group_id):
            return {"error": "Access denied"}, 403

        group = cls.get(group_id)
        if not group:
            return {"error": "Group not found"}, 404

        if name := data.get("name"):
            group.name = name
        if description := data.get("description"):
            group.description = description
        db.session.commit()
        return {"message": "Group updated"}, 200


class AssetCpe(BaseModel):
    __tablename__ = "asset_cpe"

    id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), primary_key=True, default=BaseModel.uuid7_str)
    value: Mapped[str] = db.Column(db.String())

    asset_id: Mapped[str] = db.Column(db.String(UUID_STR_LENGTH), db.ForeignKey("asset.id"))
    asset: Mapped["Asset"] = relationship("Asset")

    def __init__(self, value):
        self.id = self.uuid7_str()
        self.value = value
