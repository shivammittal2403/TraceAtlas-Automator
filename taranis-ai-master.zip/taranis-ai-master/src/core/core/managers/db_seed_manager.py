from copy import deepcopy
from typing import Any, cast

from sqlalchemy.engine import Engine
from sqlalchemy.orm import selectinload

from core.config import Config
from core.log import logger
from core.managers.db_enum_manager import sync_enum_with_db


def pre_seed():
    try:
        pre_seed_permissions()
        logger.debug("Permissions seeded")

        pre_seed_source_groups()
        logger.debug("Source groups seeded")

        pre_seed_manual_source()
        logger.debug("Manual source seeded")

        pre_seed_roles()
        logger.debug("Roles seeded")

        pre_seed_default_user()
        logger.debug("Default users seeded")

        pre_seed_attributes()
        logger.debug("Attributes seeded")

        pre_seed_report_items()
        logger.debug("Report items seeded")

        sync_presenter_templates()
        logger.debug("Presenter templates seeded")

        pre_seed_configured_defaults()
        logger.debug("Configured defaults seeded")

        pre_seed_default_publisher()
        logger.debug("Default publisher seeded")

        pre_seed_assets()
        logger.debug("Assets seeded")

    except Exception:
        logger.exception()
        logger.critical("Pre Seed failed")


def sync_enums(db_engine: Engine):
    from models.types import BOT_TYPES, COLLECTOR_TYPES, PRESENTER_TYPES, PUBLISHER_TYPES

    with db_engine.connect() as connection:
        if connection.dialect.name == "sqlite":
            return
        sync_enum_with_db(enum_type=BOT_TYPES, connection=connection, table_column="bot.type")
        sync_enum_with_db(enum_type=COLLECTOR_TYPES, connection=connection, table_column="osint_source.type")
        sync_enum_with_db(enum_type=PRESENTER_TYPES, connection=connection, table_column="product_type.type")
        sync_enum_with_db(enum_type=PUBLISHER_TYPES, connection=connection, table_column="publisher_preset.type")


def pre_seed_update(db_engine: Engine):
    from core.managers.pre_seed_data import bots, product_types, report_types
    from core.model.bot import Bot
    from core.model.product_type import ProductType
    from core.model.report_item import ReportItemType
    from core.model.settings import Settings

    pre_seed_source_groups()
    pre_seed_manual_source()
    sync_presenter_templates()
    cleanup_invalid_source_icons()
    migrate_refresh_intervals()
    migrate_use_feed_content()
    migrate_user_profiles()
    cleanup_empty_stories()
    migrate_missing_initial_revisions()
    cleanup_intelowl_email_enrichment_parameter()
    if db_engine.dialect.name == "postgresql":
        rebuild_story_search_vectors()

    pre_seed_attributes()

    pre_seed_default_publisher()

    for b in bots:
        b = cast(dict[str, Any], b)
        bot = Bot.filter_by_type(str(b["type"]))
        if not bot:
            b["enabled"] = False
            logger.debug(f"Adding new bot type '{b['type']}' in disabled state")
            Bot.add(b)

    for r in report_types:
        r = cast(dict[str, Any], r)
        rt = ReportItemType.filter_by_title(str(r["title"]))
        if not rt:
            ReportItemType.add(r)

    for p in product_types:
        p = _resolve_seed_product_type_report_types(p)
        pt = ProductType.filter_by_title(p["title"])
        if not pt:
            ProductType.add(p)

    Settings.initialize()


def cleanup_invalid_source_icons():
    from core.managers.db_manager import db
    from core.model.osint_source import OSINTSource

    sources = OSINTSource.get_all_for_collector() or []
    removed_icons = 0

    for source in sources:
        if icon_bytes := getattr(source, "icon", None):
            try:
                OSINTSource._probe_icon_image(icon_bytes)
            except ValueError:
                logger.warning(f"Removing invalid icon from OSINT source {source.id}")
                source.icon = None
                removed_icons += 1

    if removed_icons:
        db.session.commit()
        logger.info(f"Removed invalid icons from {removed_icons} OSINT sources")


def cleanup_intelowl_email_enrichment_parameter():
    from models.types import BOT_TYPES

    from core.managers.db_manager import db
    from core.model.bot import Bot

    changed = False
    for bot in Bot.get_all_by_type(BOT_TYPES.INTEL_OWL_BOT):
        if "INTEL_OWL_EMAIL_ENRICHMENT" in bot.parameters:
            bot.parameters = {key: value for key, value in bot.parameters.items() if key != "INTEL_OWL_EMAIL_ENRICHMENT"}
            changed = True
    if changed:
        db.session.commit()


def sync_presenter_templates():
    from core.managers.data_manager import sync_presenter_templates_to_data

    sync_presenter_templates_to_data()


def rebuild_story_search_vectors():
    from core.service.story import StoryService

    count = StoryService.rebuild_search_vectors()
    logger.info(f"Rebuilt search vectors for {count} stories")


def cleanup_empty_stories():
    from core.service.story import StoryService

    empty_stories = StoryService.delete_stories_with_no_items()
    logger.info(f"Deleted {empty_stories} empty stories")


def migrate_missing_initial_revisions(batch_size: int = 100):
    migrated_story_revisions = _migrate_missing_story_revisions(batch_size=batch_size)
    migrated_report_revisions = _migrate_missing_report_revisions(batch_size=batch_size)

    if migrated_story_revisions:
        logger.info(f"Backfilled initial revisions for {migrated_story_revisions} stories")
    if migrated_report_revisions:
        logger.info(f"Backfilled initial revisions for {migrated_report_revisions} reports")


def _migrate_missing_story_revisions(batch_size: int) -> int:
    from core.managers.db_manager import db
    from core.model.news_item import NewsItem
    from core.model.story import Story

    migrated = 0

    while stories := list(
        db.session.execute(
            db.select(Story)
            .options(
                selectinload(Story.attributes),
                selectinload(Story.news_items).selectinload(NewsItem.tags),
                selectinload(Story.news_items).selectinload(NewsItem.attributes),
            )
            .where(Story.revision == -1)
            .order_by(Story.id)
            .limit(batch_size)
        ).scalars()
    ):
        for story in stories:
            story.revision = 0
            story.record_revision(note="initial")
        db.session.commit()
        migrated += len(stories)

    return migrated


def _migrate_missing_report_revisions(batch_size: int) -> int:
    from core.managers.db_manager import db
    from core.model.news_item import NewsItem
    from core.model.report_item import ReportItem
    from core.model.story import Story

    migrated = 0

    while reports := list(
        db.session.execute(
            db.select(ReportItem)
            .options(
                selectinload(ReportItem.report_item_type),
                selectinload(ReportItem.attributes),
                selectinload(ReportItem.stories).selectinload(Story.news_items).selectinload(NewsItem.tags),
                selectinload(ReportItem.stories).selectinload(Story.news_items).selectinload(NewsItem.attributes),
            )
            .where(ReportItem.revision == -1)
            .order_by(ReportItem.id)
            .limit(batch_size)
        ).scalars()
    ):
        for report in reports:
            report.revision = 0
            report.record_revision(note="initial")
        db.session.commit()
        migrated += len(reports)

    return migrated


def migrate_user_profile(user_profile: dict, template: dict) -> dict:
    out = dict(user_profile)
    if end_of_shift := out.get("end_of_shift"):
        out["end_of_shift"] = f"{end_of_shift['hours']}:{end_of_shift['minutes']}" if isinstance(end_of_shift, dict) else end_of_shift
    for key, value in template.items():
        if (key in out and isinstance(value, dict) and not isinstance(out[key], dict)) or key not in out:
            out[key] = deepcopy(value)
        elif isinstance(value, dict):
            out[key] = migrate_user_profile(out[key], value)
    return out


def migrate_user_profiles():
    from core.model.settings import Settings
    from core.model.user import PROFILE_TEMPLATE, User

    profile_template = {
        **PROFILE_TEMPLATE,
        "onboarding_enabled": Settings.get_settings().get("onboarding_enabled", True),
    }
    users = User.get_all_for_collector() or []
    for user in users:
        current = user.profile if isinstance(user.profile, dict) else {}
        updated = migrate_user_profile(current, profile_template)
        if current != updated:
            logger.debug(f"Migrating user profile for user {user.name}")
            User.update_profile(user=user, data=updated)


def migrate_refresh_intervals():
    from core.model.osint_source import OSINTSource

    sources = OSINTSource.get_all_for_collector()

    for source in sources:
        try:
            interval = int(source.parameters.get("REFRESH_INTERVAL", ""))
        except ValueError:
            continue
        new_cron = convert_interval_to_cron(interval)
        logger.info(f"Updating OSINTSource {source.id}: {interval} minutes -> cron '{new_cron}'")
        source.update_parameters({"REFRESH_INTERVAL": new_cron})


def migrate_use_feed_content():
    from core.managers.db_manager import db
    from core.model.osint_source import OSINTSource

    rss_sources = OSINTSource.get_filtered(OSINTSource.get_filter_query({"type": "rss_collector"})) or []
    updated_sources = 0
    created_parameters = 0

    for source in rss_sources:
        content_location = source.parameters.get("CONTENT_LOCATION", "")
        use_feed_content = source.parameters.get("USE_FEED_CONTENT")

        # Only migrate sources that haven't been migrated yet and are not a boolean
        if use_feed_content in ["true", "false"]:
            continue

        target_value = "true" if content_location.strip() else "false"
        source.parameters = {**source.parameters, "USE_FEED_CONTENT": target_value}
        updated_sources += 1
        if use_feed_content is None:
            created_parameters += 1

    if updated_sources:
        db.session.commit()
        logger.info(f"Migrated USE_FEED_CONTENT for {updated_sources} OSINT sources ({created_parameters} parameters created)")


def convert_interval_to_cron(interval: int) -> str:
    if interval < 1:
        return "0 */8 * * *"
    if interval < 60:
        return f"*/{interval} * * * *"
    if interval < 1440:
        hours = interval // 60
        return "0 * * * *" if hours == 1 else f"0 */{hours} * * *"
    if interval <= 40000:
        days = interval // 1440
        return "0 4 0 * *" if days == 1 else f"0 4 */{days} * *"
    return "0 */8 * * *"


def pre_seed_source_groups():
    from core.model.osint_source import OSINTSourceGroup

    if not OSINTSourceGroup.get_by_key("default"):
        OSINTSourceGroup.add({"id": "default", "name": "Default", "description": "Default group for uncategorized sources", "default": True})


def pre_seed_manual_source():
    from core.model.osint_source import OSINTSource

    OSINTSource.create_manual_source()


def pre_seed_configured_defaults():
    from core.managers.db_manager import db
    from core.managers.pre_seed_data import bots, product_types
    from core.model.bot import RUN_AFTER_BOTS, Bot
    from core.model.product_type import ProductType

    seeded_bots = {bot_data["type"]: Bot.add(bot_data) for bot_data in bots}
    for bot_type, parent_types in {
        "IOC_BOT": ("WORDLIST_BOT",),
        "INTEL_OWL_BOT": ("IOC_BOT",),
        "NLP_BOT": ("IOC_BOT",),
        "SUMMARY_BOT": ("NLP_BOT", "STORY_BOT"),
    }.items():
        bot = seeded_bots[bot_type]
        bot.parameters = {
            **bot.parameters,
            RUN_AFTER_BOTS: ",".join(seeded_bots[parent_type].id for parent_type in parent_types),
        }
    Bot.validate_dependency_config()
    db.session.commit()

    for p in product_types:
        ProductType.add(_resolve_seed_product_type_report_types(p))


def pre_seed_default_publisher():
    from core.model.publisher_preset import PublisherPreset

    PublisherPreset.ensure_default_taranis()


def pre_seed_permissions():
    from core.managers.pre_seed_data import permissions
    from core.model.permission import Permission

    Permission.add_multiple(permissions)


def pre_seed_roles():
    from core.model.permission import Permission
    from core.model.role import Role, TLPLevel

    admin_permissions = Permission.get_all_ids()
    if not Role.filter_by_name("Admin"):
        Role.add(
            {
                "name": "Admin",
                "description": "Administrator role",
                "permissions": admin_permissions,
                "tlp_level": TLPLevel.RED,
            }
        )
    if not Role.filter_by_name("User"):
        default_user_permissions = [
            "ASSESS_ACCESS",
            "ASSESS_CREATE",
            "ASSESS_UPDATE",
            "ASSESS_DELETE",
            "ANALYZE_ACCESS",
            "ANALYZE_CREATE",
            "ANALYZE_UPDATE",
            "ANALYZE_DELETE",
            "BOT_EXECUTE",
            "PUBLISH_ACCESS",
            "PUBLISH_CREATE",
            "PUBLISH_UPDATE",
            "PUBLISH_DELETE",
            "PUBLISH_PRODUCT",
        ]
        Role.add(
            {
                "name": "User",
                "description": "Basic user role",
                "permissions": default_user_permissions,
            }
        )


def pre_seed_attributes():
    from core.managers.pre_seed_data import attrs_with_enum
    from core.model.attribute import Attribute

    base_attr = {
        "name": "Text",
        "description": "Simple text box",
        "type": "STRING",
    }

    attrs = [
        {"name": "Text", "description": "Simple text box", "type": "STRING"},
        {"name": "Text Area", "description": "Simple text area", "type": "TEXT"},
        {"name": "Number", "description": "Simple number box", "type": "NUMBER"},
        {"name": "TLP", "description": "Traffic Light Protocol", "type": "TLP"},
        {"name": "CPE", "description": "Common Platform Enumeration", "type": "CPE"},
        {"name": "CVSS", "description": "Common Vulnerability Scoring System", "type": "CVSS"},
        {"name": "CVE", "description": "Common Vulnerabilities and Exposures", "type": "CVE"},
        {"name": "Date", "description": "Date picker", "type": "DATE"},
        {"name": "Link", "description": "Link", "type": "LINK"},
        {"name": "Attachment", "description": "Attachment", "type": "ATTACHMENT"},
        {"name": "Rich Text", "description": "Rich Text", "type": "RICH_TEXT"},
        {"name": "Boolean", "description": "Boolean", "type": "BOOLEAN"},
        {"name": "Date Time", "description": "Date Time", "type": "DATE_TIME"},
        {"name": "Date", "description": "Date", "type": "DATE"},
        {"name": "Time", "description": "Time", "type": "TIME"},
        {"name": "Story", "description": "Story", "type": "STORY"},
    ]

    for attr in attrs + attrs_with_enum:
        if not Attribute.filter_by_name(attr["name"]):
            attr = {**base_attr, **attr}
            Attribute.add(attr)


def pre_seed_report_items():
    from core.managers.pre_seed_data import report_types
    from core.model.report_item_type import ReportItemType

    for report_type in report_types:
        if not ReportItemType.get_by_title(title=report_type["title"]):
            ReportItemType.add(report_type)


def _resolve_seed_product_type_report_types(product_type: dict) -> dict:
    from core.model.report_item_type import ReportItemType

    product_type_data = deepcopy(product_type)
    report_type_refs = product_type_data.get("report_types", [])
    resolved_report_type_ids = []

    for report_type_ref in report_type_refs:
        if report_type := ReportItemType.get_by_title(report_type_ref):
            resolved_report_type_ids.append(report_type.id)

    product_type_data["report_types"] = resolved_report_type_ids
    return product_type_data


def pre_seed_default_user():
    from core.model.organization import Organization
    from core.model.role import Role
    from core.model.user import User

    user_count = User.get_filtered_count(User.get_filter_query({}))
    if user_count > 0:
        return

    default_organization = Organization.find_by_name("Default Organization")
    if not default_organization:
        default_organization = Organization.add(
            {
                "name": "Default Organization",
                "description": "Default organization for initial users.",
            }
        )

    if (
        not User.find_by_name(username="admin")
        and not User.find_by_role_name(role_name="Admin")
        and (admin_role := Role.filter_by_name("Admin"))
    ):
        User.add(
            {
                "username": "admin",
                "name": "Default Admin",
                "roles": [admin_role.id],
                "organization": {"id": default_organization.id},
                "password": Config.PRE_SEED_PASSWORD_ADMIN,
            }
        )

    if not User.find_by_name(username="user"):
        user_role = Role.filter_by_name("User").id  # type: ignore
        User.add(
            {
                "username": "user",
                "name": "Default User",
                "roles": [user_role],
                "organization": {"id": default_organization.id},
                "password": Config.PRE_SEED_PASSWORD_USER,
            }
        )


def pre_seed_assets():
    from core.model.asset import AssetGroup
    from core.model.settings import Settings

    AssetGroup.get_default_group()
    Settings.initialize()
