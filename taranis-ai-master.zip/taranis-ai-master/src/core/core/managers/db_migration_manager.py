from typing import Literal

from yoyo import get_backend, read_migrations

from core.config import Config
from core.log import logger


def is_postgresql(uri: str) -> bool:
    return "postgresql" in uri


def perform_migration(action: Literal["migrate", "mark"]):
    if not is_postgresql(Config.SQLALCHEMY_DATABASE_URI):
        return

    backend = get_backend(Config.SQLALCHEMY_DATABASE_URI)
    migrations = read_migrations("migrations")

    with backend.lock():
        if action == "migrate":
            logger.info(f"Migrating Database: {Config.SQLALCHEMY_DATABASE_URI_MASK}")
            backend.apply_migrations(backend.to_apply(migrations))
            logger.info("Database migrations applied successfully.")
        elif action == "mark":
            backend.mark_migrations(migrations)
            logger.info("Migrations marked successfully.")
