from importlib import import_module
from pathlib import Path
from sqlite3 import Connection as SQLite3Connection

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import event, text
from sqlalchemy.engine import Engine, reflection

from core.log import logger
from core.managers.db_migration_manager import perform_migration
from core.managers.db_seed_manager import pre_seed, pre_seed_update, sync_enums


db: SQLAlchemy = SQLAlchemy()


def initial_database_setup(engine: Engine):
    import_module("core.model.chat")
    import_module("core.model.ioc")

    is_empty = is_db_empty(engine)
    db.metadata.create_all(bind=engine)
    setup_fts(engine)
    if is_empty:
        logger.debug("Create new Database")
        pre_seed()
        perform_migration("mark")
    else:
        perform_migration("migrate")
        sync_enums(engine)
        pre_seed_update(db.engine)

    db.session.remove()


def initialize(app: Flask, initial_setup: bool = True):
    logger.info(f"Connecting Database: {app.config.get('SQLALCHEMY_DATABASE_URI_MASK')}")
    db.init_app(app)

    if initial_setup:
        initial_database_setup(db.engine)
    logger.debug(f"DB Engine created with {db.engine.pool.status()}")


def setup_fts(engine: Engine):
    if db.engine.dialect.name != "postgresql":
        return
    with engine.begin() as conn:
        conn.execute(text(Path("core/sql/fulltext_search.sql").read_text(encoding="utf-8")))


def is_db_empty(engine: Engine) -> bool:
    inspector = reflection.Inspector.from_engine(engine)
    tables = inspector.get_table_names()
    return len(tables) == 0


@event.listens_for(Engine, "connect")
def set_sqlite_pragma(dbapi_connection, _connection_record):
    if isinstance(dbapi_connection, SQLite3Connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()
