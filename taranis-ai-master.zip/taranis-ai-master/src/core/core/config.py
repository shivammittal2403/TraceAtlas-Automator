import json
from datetime import UTC, datetime, timedelta
from typing import Annotated, Any, Literal
from urllib.parse import urlparse, urlunparse

from models.cache_contract import (
    CACHE_DEFAULT_TIMEOUT_DEFAULT,
    CACHE_ENABLED_DEFAULT,
    CACHE_KEY_PREFIX_DEFAULT,
)
from pydantic import Field, SecretStr, ValidationInfo, field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict


def mask_db_uri(uri: str) -> str:
    if not isinstance(uri, str) or not uri:
        return "<masked>"
    try:
        parsed = urlparse(uri)

        if parsed.password:
            netloc = f"{parsed.username}:***@{parsed.hostname}"
            if parsed.port:
                netloc += f":{parsed.port}"
        else:
            netloc = parsed.netloc

        return urlunparse((parsed.scheme, netloc, parsed.path, parsed.params, parsed.query, parsed.fragment))
    except ValueError:
        return "<masked>"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore", secrets_dir="/var/run")

    API_KEY: SecretStr = SecretStr("supersecret")
    APPLICATION_ROOT: str = "/"
    MODULE_ID: str = "Core"
    DEBUG: bool = False
    AUDIT_LOG_ENABLED: bool = True
    CHAT_ENABLED: bool = False

    JWT_SECRET_KEY: str = "supersecret"
    JWT_IDENTITY_CLAIM: str = "sub"
    JWT_ACCESS_TOKEN_EXPIRES: timedelta = timedelta(hours=4)
    JWT_DECODE_LEEWAY: int = 5
    JWT_TOKEN_LOCATION: list = ["headers", "cookies"]
    JWT_COOKIE_SUFFIX: Annotated[str, Field(pattern=r"^[A-Za-z0-9_-]*$")] = ""

    @property
    def JWT_ACCESS_COOKIE_NAME(self) -> str:
        return f"access_token_cookie{self.JWT_COOKIE_SUFFIX}"

    @property
    def JWT_ACCESS_CSRF_COOKIE_NAME(self) -> str:
        return f"csrf_access_token{self.JWT_COOKIE_SUFFIX}"

    @property
    def JWT_ACCESS_COOKIE_PATH(self) -> str:
        return self.APPLICATION_ROOT

    JWT_ACCESS_CSRF_COOKIE_PATH = JWT_ACCESS_COOKIE_PATH

    DB_URL: str = "localhost"
    DB_DATABASE: str = "taranis"
    DB_USER: str = "taranis"
    DB_PASSWORD: SecretStr = SecretStr("supersecret")
    SQLALCHEMY_SCHEMA: str = "postgresql+psycopg"
    SQLALCHEMY_ECHO: bool = False
    SQLALCHEMY_TRACK_MODIFICATIONS: bool = False
    SQLALCHEMY_DATABASE_URI: str = ""
    SQLALCHEMY_DATABASE_URI_MASK: str | None = None
    SQLALCHEMY_ENGINE_OPTIONS: dict[str, Any] = {}
    SQLALCHEMY_CONNECT_TIMEOUT: int = 10
    SQLALCHEMY_MAX_OVERFLOW: int = 10
    SQLALCHEMY_POOL_SIZE: int = 20
    SQLALCHEMY_POOL_TIMEOUT: Annotated[int | None, Field(gt=0)] = None
    SQLALCHEMY_POOL_RECYCLE: Annotated[int | None, Field(ge=-1)] = None
    COLORED_LOGS: bool = True
    BUILD_DATE: datetime = datetime.now(UTC)
    GIT_INFO: dict[str, str] | None = None
    DATA_FOLDER: str = "./taranis_data"  # When started with Docker, the path is /app/data
    REALTIME_ENABLED: bool = False
    CENTRIFUGO_API_URL: str = "http://centrifugo:9000"
    CENTRIFUGO_API_KEY: SecretStr = SecretStr("")
    CENTRIFUGO_CONNECT_PROXY_SECRET: SecretStr = SecretStr("")
    DISABLE_SCHEDULER: bool = False
    OTEL_EXPORTER_OTLP_ENDPOINT: str | None = None
    OTEL_SERVICE_NAME: str = "taranis-core"
    OTEL_METRIC_EXPORT_INTERVAL: Annotated[float, Field(gt=0)] = 60_000
    TARANIS_CORE_SENTRY_DSN: str | None = None
    SENTRY_ENABLE_LOGS: bool = False
    SENTRY_SEND_DEFAULT_PII: bool = False
    SENTRY_ENABLE_DB_QUERY_SOURCE: bool = False
    DISABLE_PPN_COLLECTOR: bool = True
    MAX_CONTENT_LENGTH: int = 50 * 1024 * 1024
    OSINT_SOURCE_ICON_MAX_BYTES: int = 5 * 1024 * 1024
    OSINT_SOURCE_ICON_PIXELS: int = 64
    OSINT_SOURCE_ICON_FORMAT: str = "PNG"

    @model_validator(mode="after")  # type: ignore
    def set_sqlalchemy_uri(self) -> "Settings":
        if not self.SQLALCHEMY_DATABASE_URI or len(self.SQLALCHEMY_DATABASE_URI) < 1:
            object.__setattr__(
                self,
                "SQLALCHEMY_DATABASE_URI",
                f"{self.SQLALCHEMY_SCHEMA}://{self.DB_USER}:{self.DB_PASSWORD.get_secret_value()}@{self.DB_URL}/{self.DB_DATABASE}",
            )
        if self.SQLALCHEMY_DATABASE_URI.startswith("sqlite:"):
            self.SQLALCHEMY_ENGINE_OPTIONS.update({"connect_args": {"timeout": self.SQLALCHEMY_CONNECT_TIMEOUT}})
        elif self.SQLALCHEMY_DATABASE_URI.startswith("postgresql"):
            self.SQLALCHEMY_ENGINE_OPTIONS.update({"connect_args": {"connect_timeout": self.SQLALCHEMY_CONNECT_TIMEOUT}})

        self.SQLALCHEMY_ENGINE_OPTIONS.setdefault("pool_pre_ping", True)

        update_payload = {
            "pool_size": self.SQLALCHEMY_POOL_SIZE,
            "max_overflow": self.SQLALCHEMY_MAX_OVERFLOW,
        }
        if self.SQLALCHEMY_POOL_TIMEOUT is not None:
            update_payload["pool_timeout"] = self.SQLALCHEMY_POOL_TIMEOUT
        if self.SQLALCHEMY_POOL_RECYCLE is not None:
            update_payload["pool_recycle"] = self.SQLALCHEMY_POOL_RECYCLE
        self.SQLALCHEMY_ENGINE_OPTIONS.update(update_payload)
        object.__setattr__(self, "SQLALCHEMY_DATABASE_URI_MASK", mask_db_uri(self.SQLALCHEMY_DATABASE_URI))
        return self

    @model_validator(mode="after")
    def validate_realtime_settings(self) -> "Settings":
        if not self.REALTIME_ENABLED:
            return self

        api_key = self.CENTRIFUGO_API_KEY.get_secret_value()
        proxy_secret = self.CENTRIFUGO_CONNECT_PROXY_SECRET.get_secret_value()
        if not api_key or not proxy_secret:
            raise ValueError("Centrifugo API and connect proxy secrets must be non-empty")
        existing_secrets = {self.API_KEY.get_secret_value(), self.JWT_SECRET_KEY}
        if api_key == proxy_secret or api_key in existing_secrets or proxy_secret in existing_secrets:
            raise ValueError("Centrifugo secrets must be distinct from each other and existing application secrets")
        return self

    TARANIS_AUTHENTICATOR: Literal["database", "openid", "external", "dev"] = "database"
    EXTERNAL_AUTH_USER: str = "X-REROUTE-USER"
    EXTERNAL_AUTH_ROLES: str = "X-REROUTE-ROLES"
    EXTERNAL_AUTH_NAME: str = "X-REROUTE-NAME"
    EXTERNAL_AUTH_ORGANIZATION: str = "X-REROUTE-ORGANIZATION"

    OPENID_CLIENT_ID: str | None = None
    OPENID_CLIENT_SECRET: str | None = None
    OPENID_LOGOUT_URL: str | None = None
    OPENID_METADATA_URL: str = "http://keycloak/realms/master/.well-known/openid-configuration"
    PRE_SEED_PASSWORD_ADMIN: str = "admin"
    PRE_SEED_PASSWORD_USER: str = "user"
    PRE_SEED_SETTINGS: Annotated[dict[str, Any], NoDecode] = Field(default_factory=dict, repr=False)

    @field_validator("PRE_SEED_SETTINGS", mode="before")
    @classmethod
    def parse_pre_seed_settings(cls, value: Any) -> Any:
        return json.loads(value) if isinstance(value, str) else value

    REDIS_URL: str = "redis://localhost:6379"
    REDIS_PASSWORD: SecretStr | None = None
    RQ_DEFAULT_JOB_TIMEOUT: int = 180
    TASK_HISTORY_RETENTION_DAYS: Annotated[int, Field(gt=0)] = 30
    CACHE_ENABLED: bool = CACHE_ENABLED_DEFAULT
    CACHE_DEFAULT_TIMEOUT: int = CACHE_DEFAULT_TIMEOUT_DEFAULT
    CACHE_KEY_PREFIX: str = CACHE_KEY_PREFIX_DEFAULT
    CACHE_REDIS_URL: str | None = None
    CACHE_REDIS_PASSWORD: SecretStr | None = None

    @field_validator("OTEL_EXPORTER_OTLP_ENDPOINT", "TARANIS_CORE_SENTRY_DSN", mode="before")
    def normalize_optional_telemetry_url(cls, value: str | None) -> str | None:
        if not value:
            return None
        return value.strip().rstrip("/") or None

    @field_validator("JWT_SECRET_KEY", "API_KEY", mode="before")
    def check_non_empty_string_or_secret(cls, v, info: ValidationInfo) -> str | SecretStr:
        value = v.get_secret_value() if isinstance(v, SecretStr) else v
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{info.field_name} must be a non-empty string")
        return v

    @field_validator("EXTERNAL_AUTH_USER", "EXTERNAL_AUTH_ROLES", "EXTERNAL_AUTH_NAME", "EXTERNAL_AUTH_ORGANIZATION", mode="before")
    def check_and_upper_auth_headers(cls, v, info: ValidationInfo) -> str:
        if not isinstance(v, str) or not v.strip():
            raise ValueError(f"{info.field_name} must be a non-empty string")
        return v.upper()

    @field_validator("APPLICATION_ROOT", mode="before")
    def ensure_start_and_end_slash(cls, v: str, info: ValidationInfo) -> str:
        if not v or v == "/":
            return "/"

        return f"/{v.strip('/')}/"


Config = Settings()
