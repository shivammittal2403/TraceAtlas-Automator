from flask import Blueprint, Flask, request
from flask.views import MethodView
from flask_jwt_extended import current_user

from core.config import Config
from core.log import logger
from core.managers.auth_manager import auth_required
from core.managers.decorators import validate_json
from core.managers.realtime_publisher import realtime_publisher
from core.model.news_item_conflict import NewsItemConflict
from core.model.story import Story
from core.model.story_conflict import StoryConflict
from core.service.cache_invalidation import SCOPE_ASSESS_VIEWS, SCOPE_STORY_REPORT_VIEWS, invalidate_frontend_cache_on_success
from core.service.news_item_conflict import NewsItemConflictService


class StoryConflicts(MethodView):
    @auth_required("ASSESS_ACCESS")
    def get(self, story_id=None):
        if story_id and (conflict := StoryConflict.conflict_store.get(story_id)):
            return conflict.to_dict(), 200
        conflicts = [conflict.to_dict() for conflict in StoryConflict.conflict_store.values()]
        return {"conflicts": conflicts}, 200

    @auth_required("ASSESS_UPDATE")
    @validate_json
    def put(self, story_id):
        if not request.json:
            return {"error": "Invalid JSON payload"}, 400
        if not story_id:
            return {"error": "No story_id provided"}, 400
        resolved_story = request.json.get("resolution", {})
        incoming_story_original = request.json.get("incoming_story_original", {})
        conflict = StoryConflict.conflict_store.get(story_id)
        if conflict is None:
            logger.error(f"No conflict found for story {story_id}")
            return {"error": "No conflict found"}, 404

        response, code = conflict.resolve(resolved_story, user=current_user)
        if code != 200:
            Story.add_or_update(incoming_story_original)
        else:
            NewsItemConflictService.reevaluate_conflicts()
        invalidate_frontend_cache_on_success(code, scopes=(SCOPE_ASSESS_VIEWS, SCOPE_STORY_REPORT_VIEWS), object_ids={"story": story_id})
        return response, code


class NewsItemConflicts(MethodView):
    @auth_required("ASSESS_ACCESS")
    def get(self):
        conflicts = [conflict.to_dict() for conflict in NewsItemConflict.conflict_store.values()]
        return {"items": conflicts}, 200

    @auth_required("ASSESS_CREATE")
    @validate_json
    def post(self):
        data_json = request.json
        if not data_json:
            return {"error": "No NewsItems in JSON Body"}, 422

        result, code = NewsItemConflictService.add_news_items_and_clear_from_store(data_json)
        if code != 200:
            return result, code

        realtime_publisher.assess_changed()
        invalidate_frontend_cache_on_success(code, scopes=(SCOPE_ASSESS_VIEWS, SCOPE_STORY_REPORT_VIEWS))
        return result, 200

    @auth_required("ASSESS_UPDATE")
    @validate_json
    def put(self):
        data = request.json
        if not data:
            return {"error": "Missing story_ids or news_item_ids"}, 400
        result, code = NewsItemConflictService.ingest_incoming_ungroup_internal_clear_store(data, current_user)
        if 200 <= code < 300:
            realtime_publisher.assess_changed()
        invalidate_frontend_cache_on_success(code, scopes=(SCOPE_ASSESS_VIEWS, SCOPE_STORY_REPORT_VIEWS))
        return result, code


class StoryInfo(MethodView):
    @auth_required("ASSESS_ACCESS")
    def get(self, story_id):
        if story := Story.get(story_id):
            is_misp_story = any(attribute.key == "misp_event_uuid" for attribute in story.attributes)
            news_item_data = [{"title": item.title, "id": item.id} for item in story.news_items if hasattr(item, "title")]
            return {
                "id": story.id,
                "title": story.title,
                "is_misp_story": is_misp_story,
                "news_item_count": len(story.news_items),
                "relevance": story.relevance,
                "news_item_data": news_item_data,
            }, 200
        return {"error": "Story not found"}, 404


class ConflictStore(MethodView):
    @auth_required("ASSESS_UPDATE")
    def post(self):
        StoryConflict.flush_store()
        NewsItemConflict.flush_store()
        logger.info("Cleared all conflicts from the store.")
        return {"message": "All conflicts cleared"}, 200


def initialize(app: Flask):
    conflicts_bp = Blueprint("connectors", __name__, url_prefix=f"{Config.APPLICATION_ROOT}api/connectors")

    conflicts_bp.add_url_rule("/conflicts/stories", view_func=StoryConflicts.as_view("story_conflicts"))
    conflicts_bp.add_url_rule("/conflicts/stories/<string:story_id>", view_func=StoryConflicts.as_view("story_conflict"))
    conflicts_bp.add_url_rule("/conflicts/news-items", view_func=NewsItemConflicts.as_view("news_item_conflicts"))
    conflicts_bp.add_url_rule("/story-summary/<string:story_id>", view_func=StoryInfo.as_view("story_summary"))
    conflicts_bp.add_url_rule("/conflicts/clear", view_func=ConflictStore.as_view("clear_conflicts"))

    app.register_blueprint(conflicts_bp)
