from flask import Blueprint, Flask, request
from flask.views import MethodView
from flask_jwt_extended import current_user, jwt_required

from core.config import Config
from core.model.user import User
from core.service.cache_invalidation import SCOPE_TRENDING_CLUSTERS, invalidate_frontend_cache_on_success


class UserInfo(MethodView):
    @jwt_required()
    def get(self):
        return current_user.to_detail_dict(), 200


class UserProfile(MethodView):
    @jwt_required()
    def get(self):
        return current_user.get_profile(), 200

    @jwt_required()
    def put(self):
        if not (json_data := request.json):
            return {"error": "No input data provided"}, 400
        response, status = User.update_profile(current_user, json_data)
        invalidate_frontend_cache_on_success(status, scopes=(SCOPE_TRENDING_CLUSTERS,), user_profiles=(current_user.username,))
        return response, status

    @jwt_required()
    def post(self):
        if not (json_data := request.json):
            return {"error": "No input data provided"}, 400
        response, status = User.update_profile(current_user, json_data)
        invalidate_frontend_cache_on_success(status, scopes=(SCOPE_TRENDING_CLUSTERS,), user_profiles=(current_user.username,))
        return response, status


def initialize(app: Flask):
    user_bp = Blueprint("user", __name__, url_prefix=f"{Config.APPLICATION_ROOT}api/users")

    user_bp.add_url_rule("/", view_func=UserInfo.as_view("user_info"))
    user_bp.add_url_rule("/profile", view_func=UserProfile.as_view("user_profile"))
    app.register_blueprint(user_bp)
