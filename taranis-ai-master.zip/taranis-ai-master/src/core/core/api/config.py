import base64
import binascii
import io
from typing import Any, ClassVar

from flask import Blueprint, Flask, jsonify, make_response, request, send_file
from flask.views import MethodView
from flask_jwt_extended import current_user
from models.admin import BotCreate, BotUpdate, CuratedOSINTSourceSelection
from models.admin import OSINTSource as OSINTSourceModel
from models.base import TaranisBaseModel
from psycopg.errors import NotNullViolation, UniqueViolation
from pydantic import ValidationError
from sqlalchemy.exc import IntegrityError

from core.config import Config
from core.log import logger
from core.managers import queue_manager
from core.managers.auth_manager import auth_required
from core.managers.data_manager import (
    InvalidPresenterTemplatePathError,
    delete_template,
    validate_presenter_template_id,
)
from core.managers.db_manager import db
from core.managers.decorators import extract_args
from core.model import (
    attribute,
    bot,
    connector,
    organization,
    osint_source,
    product_type,
    publisher_preset,
    report_item_type,
    role,
    role_based_access,
    task,
    user,
    word_list,
)
from core.model.permission import Permission
from core.service.cache_invalidation import invalidate_frontend_cache_on_success
from core.service.template_service import build_template_response, build_templates_list, create_or_update_template, validate_template_content
from core.service.worker_parameters import reveal_parameter


def handle_integrity_error(error: IntegrityError):
    db.session.rollback()
    orig = error.orig
    if isinstance(orig, UniqueViolation):
        constraint = orig.diag.constraint_name
        field = constraint.rsplit("_", 2)[-2] if constraint and "_" in constraint else None
        if field:
            return {"error": f"A record with this field: '{field}' already exists."}, 400
        return {"error": "A record with these values already exists."}, 400
    if isinstance(orig, NotNullViolation):
        column = getattr(orig.diag, "column_name", None)
        table = getattr(orig.diag, "table_name", None)
        if column and table:
            pretty_column = column.replace("_", " ")
            pretty_table = table.replace("_", " ")
            return {"error": f"Cannot set {pretty_column} to null because {pretty_table} still requires a value."}, 400
        if column:
            pretty_column = column.replace("_", " ")
            return {"error": f"A value for {pretty_column} is required."}, 400
        return {"error": "A required value is missing."}, 400
    logger.error("Unexpected database integrity failure in config API", exc_info=error)
    return {"error": "Database integrity error."}, 500


def handle_validation_error(error: ValidationError):
    db.session.rollback()
    return TaranisBaseModel.validation_error_response(error, prefix="Validation failed"), 400


def _invalidate_admin_cache(status_code: int) -> int:
    return invalidate_frontend_cache_on_success(status_code, full=True)


class DictionariesReload(MethodView):
    @auth_required("CONFIG_ATTRIBUTE_UPDATE")
    def post(self, dictionary_type: str):
        attribute.Attribute.load_dictionaries(dictionary_type)
        return {"message": "success"}, 200


class ACLEntries(MethodView):
    @auth_required("CONFIG_ACL_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, acl_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if acl_id:
            return role_based_access.RoleBasedAccess.get_for_api(acl_id)
        return role_based_access.RoleBasedAccess.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_ACL_CREATE")
    def post(self):
        acl = role_based_access.RoleBasedAccess.add(request.json)
        _invalidate_admin_cache(201)
        return jsonify({"message": "ACL created", "id": acl.id}), 201

    @auth_required("CONFIG_ACL_UPDATE")
    def put(self, acl_id: str | None = None):
        if acl_id is None:
            return {"error": "No acl_id provided"}, 400
        response, status = role_based_access.RoleBasedAccess.update(acl_id, request.json)
        _invalidate_admin_cache(status)
        return response, status

    @auth_required("CONFIG_ACL_DELETE")
    def delete(self, acl_id: str | None = None):
        if acl_id is None:
            return {"error": "No acl_id provided"}, 400
        response, status = role_based_access.RoleBasedAccess.delete(acl_id)
        _invalidate_admin_cache(status)
        return response, status


class Attributes(MethodView):
    @auth_required(["CONFIG_ATTRIBUTE_ACCESS"])
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, attribute_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if attribute_id:
            return attribute.Attribute.get_for_api(attribute_id)

        return attribute.Attribute.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_ATTRIBUTE_CREATE")
    def post(self):
        attribute_result = attribute.Attribute.add(request.json)
        _invalidate_admin_cache(201)
        return jsonify({"message": "Attribute added", "id": attribute_result.id}), 201

    @auth_required("CONFIG_ATTRIBUTE_UPDATE")
    def put(self, attribute_id: str | None = None):
        if attribute_id is None:
            return {"error": "No attribute_id provided"}, 400
        response, status = attribute.Attribute.update(attribute_id, request.json)
        _invalidate_admin_cache(status)
        return response, status

    @auth_required("CONFIG_ATTRIBUTE_DELETE")
    def delete(self, attribute_id: str | None = None):
        if attribute_id is None:
            return {"error": "No attribute_id provided"}, 400
        response, status = attribute.Attribute.delete(attribute_id)
        _invalidate_admin_cache(status)
        return response, status


class ReportItemTypesImport(MethodView):
    @auth_required("CONFIG_REPORT_TYPE_CREATE")
    def post(self):
        return {"error": "Not implemented"}, 400
        # if file := request.files.get("file"):
        #     if rts := report_item_type.ReportItemType.import_report_types(file):
        #         return {"report_types": [rt.id for rt in rts], "count": len(rts), "message": "Successfully imported report types"}
        #     return {"error": "Unable to import"}, 400
        # return {"error": "No file provided"}, 400


class ReportItemTypesExport(MethodView):
    @auth_required("CONFIG_REPORT_TYPE_ACCESS")
    def get(self):
        source_ids = request.args.getlist("ids")
        data = report_item_type.ReportItemType.export(source_ids)
        if data is None:
            return {"error": "Unable to export"}, 400
        return send_file(
            io.BytesIO(data),
            download_name="report_types_export.json",
            mimetype="application/json",
            as_attachment=True,
        )


class ReportItemTypes(MethodView):
    @auth_required("CONFIG_REPORT_TYPE_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, type_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if type_id:
            return report_item_type.ReportItemType.get_for_api(type_id)
        return report_item_type.ReportItemType.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_REPORT_TYPE_CREATE")
    def post(self):
        try:
            item = report_item_type.ReportItemType.add(request.json)
            _invalidate_admin_cache(201)
            return jsonify({"message": "Report item type added", "id": item.id}), 201
        except (IntegrityError, ValidationError):
            raise
        except Exception:
            logger.exception("Failed to add report item type")
            return {"error": "Failed to add report item type"}, 500

    @auth_required("CONFIG_REPORT_TYPE_UPDATE")
    def put(self, type_id: str | None = None):
        if type_id is None:
            return {"error": "No type_id provided"}, 400
        if item := report_item_type.ReportItemType.update(type_id, request.json):
            _invalidate_admin_cache(200)
            return jsonify({"message": "Report item type updated", "id": f"{item.id}"}), 200
        return {"error": "Report item type not found"}, 404

    @auth_required("CONFIG_REPORT_TYPE_DELETE")
    def delete(self, type_id: str | None = None):
        if type_id is None:
            return {"error": "No type_id provided"}, 400
        response, status = report_item_type.ReportItemType.delete(type_id)
        _invalidate_admin_cache(status)
        return response, status


class ProductTypes(MethodView):
    @auth_required("CONFIG_PRODUCT_TYPE_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, type_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if type_id:
            return product_type.ProductType.get_for_api(type_id)
        return product_type.ProductType.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_PRODUCT_TYPE_CREATE")
    def post(self):
        try:
            product = product_type.ProductType.add(request.json)
            _invalidate_admin_cache(201)
            return jsonify({"message": "Product type created", "id": product.id}), 201
        except InvalidPresenterTemplatePathError as e:
            db.session.rollback()
            logger.warning("Invalid product type template path: %s", e)
            return {"error": "Invalid presenter template path"}, 400
        except (IntegrityError, ValidationError):
            raise
        except ValueError as e:
            db.session.rollback()
            logger.warning("Invalid product type payload: %s", e)
            return {"error": "Invalid product type payload"}, 400
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating product type: {e}")
            return {"error": "Failed to create product type"}, 500

    @auth_required("CONFIG_PRODUCT_TYPE_UPDATE")
    def put(self, type_id: str | None = None):
        if type_id is None:
            return {"error": "No type_id provided"}, 400
        try:
            response, status = product_type.ProductType.update(type_id, request.json)
            _invalidate_admin_cache(status)
            return response, status
        except InvalidPresenterTemplatePathError as e:
            db.session.rollback()
            logger.warning("Invalid product type template path: %s", e)
            return {"error": "Invalid presenter template path"}, 400
        except (IntegrityError, ValidationError):
            raise
        except ValueError as e:
            db.session.rollback()
            logger.warning("Invalid product type update payload: %s", e)
            return {"error": "Invalid product type payload"}, 400
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating product type: {e}")
            return {"error": "Failed to update product type"}, 500

    @auth_required("CONFIG_PRODUCT_TYPE_UPDATE")
    def patch(self, type_id: str | None = None):
        if type_id is None:
            return {"error": "No type_id provided"}, 400
        try:
            response, status = product_type.ProductType.update(type_id, request.json or {}, patch=True)
            _invalidate_admin_cache(status)
            return response, status
        except (InvalidPresenterTemplatePathError, ValueError) as exc:
            db.session.rollback()
            logger.warning("Invalid product type patch payload: %s", exc)
            return {"error": "Invalid product type payload"}, 400

    @auth_required("CONFIG_PRODUCT_TYPE_DELETE")
    def delete(self, type_id: str | None = None):
        if type_id is None:
            return {"error": "No type_id provided"}, 400
        try:
            response, status = product_type.ProductType.delete(type_id)
            _invalidate_admin_cache(status)
            return response, status
        except (IntegrityError, ValidationError):
            raise
        except Exception as e:
            logger.error(f"Error deleting product type: {e}")
            return {"error": "Failed to delete product type"}, 500


class Permissions(MethodView):
    @auth_required("CONFIG_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, filter_args: dict[str, Any] | None = None):
        return Permission.get_all_for_api(filter_args, True)


class Roles(MethodView):
    @auth_required("CONFIG_ROLE_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, role_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if role_id:
            return role.Role.get_for_api(role_id)
        return role.Role.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_ROLE_CREATE")
    def post(self):
        new_role = role.Role.add(request.json)
        _invalidate_admin_cache(201)
        return jsonify({"message": "Role created", "id": new_role.id}), 201

    @auth_required("CONFIG_ROLE_UPDATE")
    def put(self, role_id: str | None = None):
        if role_id is None:
            return {"error": "No role_id provided"}, 400
        if data := request.json:
            response, status = role.Role.update(role_id, data)
            _invalidate_admin_cache(status)
            return response, status
        return {"error": "No data provided"}, 400

    @auth_required("CONFIG_ROLE_DELETE")
    def delete(self, role_id: str | None = None):
        if role_id is None:
            return {"error": "No role_id provided"}, 400
        if user.UserRole.has_assigned_user(role_id):
            logger.warning(f"Role {role_id} cannot be deleted, it has assigned users")
            return {"error": "Role cannot be deleted, it has assigned users"}, 400
        response, status = role.Role.delete(role_id)
        _invalidate_admin_cache(status)
        return response, status


class Templates(MethodView):
    @auth_required("CONFIG_PRODUCT_TYPE_ACCESS")
    def get(self, template_path: str | None = None):
        if template_path:
            return jsonify(build_template_response(template_path).model_dump()), 200

        # List all templates
        items = [item.model_dump() for item in build_templates_list(request.args.get("order"))]
        return jsonify({"items": items, "total_count": len(items)}), 200

    @auth_required("CONFIG_PRODUCT_TYPE_CREATE")
    def post(self, template_path: str | None = None):
        # Use shared logic for create/update
        if not request.json:
            return {"error": "No data provided"}, 400
        template_name = request.json.get("name")
        base64_content = request.json.get("content")
        response, status = create_or_update_template(template_name, base64_content)
        _invalidate_admin_cache(status)
        return make_response(jsonify(response), status)

    @auth_required("CONFIG_PRODUCT_TYPE_CREATE")
    def put(self, template_path: str | None = None):
        if not template_path:
            return {"error": "No template_path provided"}, 400
        # Use shared logic for create/update
        if not request.json:
            return {"error": "No data provided"}, 400
        base64_content = request.json.get("content")
        response, status = create_or_update_template(template_path, base64_content)
        _invalidate_admin_cache(status)
        return make_response(jsonify(response), status)

    @auth_required("CONFIG_PRODUCT_TYPE_DELETE")
    def delete(self, template_path: str | None = None):
        if not template_path:
            return {"error": "No template_path provided"}, 400
        try:
            validate_presenter_template_id(template_path)
        except ValueError as e:
            logger.warning("Invalid presenter template path: %s", e)
            return {"error": "Invalid presenter template path"}, 400
        if delete_template(template_path):
            _invalidate_admin_cache(200)
            return jsonify({"message": "Template deleted", "path": template_path}), 200
        return {"error": "Could not delete template"}, 500


class TemplateValidation(MethodView):
    """Endpoint for validating Jinja2 templates without saving them."""

    @auth_required("CONFIG_PRODUCT_TYPE_ACCESS")
    def post(self):
        """Validate a Jinja2 template without saving it."""
        if not request.json:
            return {"error": "No data provided"}, 400

        template_content = request.json.get("content")
        if not template_content:
            return {"error": "No template content provided"}, 400

        try:
            # Decode base64 content if needed
            if request.json.get("is_base64", False):
                try:
                    template_content = base64.b64decode(template_content, validate=True).decode("utf-8")
                except (binascii.Error, UnicodeDecodeError) as e:
                    logger.error("Failed to decode template content: %s", e)
                    return {"error": "Failed to decode content"}, 400

            validation_result = validate_template_content(template_content)
            return {
                "is_valid": validation_result["is_valid"],
                "error_message": validation_result.get("error_message", ""),
                "error_type": validation_result.get("error_type", ""),
                "message": "Template is valid" if validation_result["is_valid"] else "Template has validation errors",
            }, 200

        except Exception as e:
            logger.error(f"Error validating template: {e}")
            return {"error": "Validation failed"}, 500


class Organizations(MethodView):
    @auth_required("CONFIG_ORGANIZATION_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, organization_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if organization_id:
            return organization.Organization.get_for_api(organization_id)
        return organization.Organization.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_ORGANIZATION_CREATE")
    def post(self):
        org = organization.Organization.add(request.json)
        _invalidate_admin_cache(201)
        return jsonify({"message": "Organization created", "id": org.id}), 201

    @auth_required("CONFIG_ORGANIZATION_UPDATE")
    def put(self, organization_id: str | None = None):
        if organization_id is None:
            return {"error": "No organization_id provided"}, 400
        response, status = organization.Organization.update(organization_id, request.json)
        _invalidate_admin_cache(status)
        return response, status

    @auth_required("CONFIG_ORGANIZATION_DELETE")
    def delete(self, organization_id: str | None = None):
        if organization_id is None:
            return {"error": "No organization_id provided"}, 400
        response, status = organization.Organization.delete(organization_id)
        _invalidate_admin_cache(status)
        return response, status


class UsersImport(MethodView):
    @auth_required("CONFIG_USER_UPDATE")
    def post(self):
        user_list = request.json
        if not isinstance(user_list, list):
            return {"error": "Invalid data format"}, 400
        result = user.User.import_users(user_list)
        if result["count"]:
            _invalidate_admin_cache(200)
        return jsonify(result), 200


class UsersExport(MethodView):
    @auth_required("CONFIG_USER_ACCESS")
    def get(self):
        user_ids = request.args.getlist("ids")
        data = user.User.export(user_ids)
        if data is None:
            return {"error": "Unable to export"}, 400
        return send_file(
            io.BytesIO(data),
            download_name="users_export.json",
            mimetype="application/json",
            as_attachment=True,
        )


class Users(MethodView):
    @auth_required("CONFIG_USER_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, user_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if user_id:
            return user.User.get_for_api(user_id)
        return user.User.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_USER_CREATE")
    def post(self):
        try:
            new_user = user.User.add(request.json)
            _invalidate_admin_cache(201)
            return jsonify({"message": "User created", "id": new_user.id}), 201
        except (IntegrityError, ValidationError):
            raise
        except Exception:
            logger.exception("Could not create user")
            return {"error": "Could not create user"}, 400

    @auth_required("CONFIG_USER_UPDATE")
    def put(self, user_id: str | None = None):
        if user_id is None:
            return {"error": "No user_id provided"}, 400
        try:
            response, status = user.User.update(user_id, request.json)
            _invalidate_admin_cache(status)
            return response, status
        except (IntegrityError, ValidationError):
            raise
        except Exception:
            logger.exception("Could not update user %s", user_id)
            return {"error": "Could not update user"}, 400

    @auth_required("CONFIG_USER_DELETE")
    def delete(self, user_id: str | None = None):
        if user_id is None:
            return {"error": "No user_id provided"}, 400
        try:
            response, status = user.User.delete(user_id)
            _invalidate_admin_cache(status)
            return response, status
        except (IntegrityError, ValidationError):
            raise
        except Exception:
            logger.exception("Could not delete user %s", user_id)
            return {"error": "Could not delete user"}, 400


class Bots(MethodView):
    @auth_required("CONFIG_BOT_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all", "state")
    def get(self, bot_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if bot_id:
            return bot.Bot.get_for_api(bot_id)
        return bot.Bot.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_BOT_UPDATE")
    def put(self, bot_id: str | None = None):
        if bot_id is None:
            return {"error": "No bot_id provided"}, 400
        if not (update_data := request.json):
            return {"error": "No update data passed"}, 400
        try:
            update_data = BotUpdate.model_validate(update_data).model_dump(exclude_unset=True, exclude_none=False)
            if updated_bot := bot.Bot.update(bot_id, update_data):
                logger.debug(f"Successfully updated {updated_bot}")
                _invalidate_admin_cache(200)
                return jsonify({"message": "Bot updated", "id": f"{updated_bot.id}"}), 200
        except bot.BotIndexConflictError:
            return {"error": bot.BotIndexConflictError.public_message}, 400
        except (TypeError, ValueError) as e:
            db.session.rollback()
            logger.warning("Invalid bot update payload: %s", e)
            return {"error": "Invalid bot update payload"}, 400
        return {"error": "Bot not found"}, 404

    @auth_required("CONFIG_BOT_UPDATE")
    def patch(self, bot_id: str | None = None):
        if bot_id is None:
            return {"error": "No bot_id provided"}, 400
        try:
            update_data = request.json if request.json is not None else {}
            update_data = BotUpdate.model_validate(update_data).model_dump(exclude_unset=True, exclude_none=False)
            if updated_bot := bot.Bot.update(bot_id, update_data, patch=True):
                _invalidate_admin_cache(200)
                return {"message": "Bot updated", "id": updated_bot.id}, 200
        except bot.BotIndexConflictError:
            return {"error": bot.BotIndexConflictError.public_message}, 400
        except (TypeError, ValueError) as exc:
            db.session.rollback()
            logger.warning("Invalid bot patch payload: %s", exc)
            return {"error": "Invalid bot update payload"}, 400
        return {"error": "Bot not found"}, 404

    @auth_required("CONFIG_BOT_CREATE")
    def post(self):
        data = request.json or {}
        index = None
        try:
            data = BotCreate.model_validate(data).model_dump()
            if (index := data.get("index")) is not None and bot.Bot.index_exists(index):
                return {"error": bot.BotIndexConflictError.public_message}, 400
            new_bot = bot.Bot.add(data)
            _invalidate_admin_cache(201)
            return jsonify({"message": "Bot created", "id": new_bot.id}), 201
        except IntegrityError:
            db.session.rollback()
            if index is not None and bot.Bot.index_exists(index):
                return {"error": bot.BotIndexConflictError.public_message}, 400
            raise
        except (TypeError, ValueError) as e:
            logger.warning("Invalid bot create payload: %s", e)
            return {"error": "Invalid bot create payload"}, 400

    @auth_required("CONFIG_BOT_DELETE")
    def delete(self, bot_id: str | None = None):
        if bot_id is None:
            return {"error": "No bot_id provided"}, 400
        response, status = bot.Bot.delete(bot_id)
        _invalidate_admin_cache(status)
        return response, status


class BotExecute(MethodView):
    @auth_required("BOT_EXECUTE")
    def post(self, bot_id: str):
        return queue_manager.queue_manager.execute_bot_task(bot_id, user_id=current_user.id)


class BotDagPreview(MethodView):
    @auth_required("CONFIG_BOT_ACCESS")
    def post(self):
        try:
            return bot.Bot.get_dag_preview(request.json or {}), 200
        except (TypeError, ValueError) as exc:
            logger.warning("Invalid bot DAG preview payload: %s", exc)
            return {"error": "Invalid bot DAG preview payload"}, 400


class QueueStatus(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    def get(self):
        return queue_manager.queue_manager.get_queue_status()


class QueueTasks(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    def get(self):
        return queue_manager.queue_manager.get_queued_tasks()


class ActiveJobs(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    @extract_args("search", "page", "limit", "order")
    def get(self, filter_args: dict[str, Any]):
        return queue_manager.queue_manager.get_active_jobs(filter_args)


class FailedJobs(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    @extract_args("search", "page", "limit", "order")
    def get(self, filter_args: dict[str, Any]):
        return queue_manager.queue_manager.get_failed_jobs(filter_args)


class WorkerStats(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    def get(self):
        return queue_manager.queue_manager.get_worker_stats()


class AdminMenuBadges(MethodView):
    @auth_required("CONFIG_ACCESS")
    def get(self):
        response = jsonify(task.Task.get_admin_menu_badges())
        response.cache_control.private = True
        response.cache_control.max_age = 300
        return response


class CronJobs(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    def get(self):
        return queue_manager.queue_manager.get_cron_job_configs()


class Schedule(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    @extract_args("search", "page", "limit", "order")
    def get(self, filter_args: dict[str, Any], task_id: str | None = None):
        try:
            if task_id:
                return queue_manager.queue_manager.get_scheduled_job(task_id)

            return queue_manager.queue_manager.get_scheduled_jobs(filter_args)
        except Exception:
            logger.exception("Failed to get schedules")
            return {"error": "Failed to get schedules"}, 500


class Connectors(MethodView):
    @auth_required("CONFIG_CONNECTOR_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, connector_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if connector_id:
            return connector.Connector.get_for_api(connector_id)
        return connector.Connector.get_all_for_api(filter_args=filter_args, with_count=True)

    @auth_required("CONFIG_CONNECTOR_CREATE")
    def post(self):
        try:
            if source := connector.Connector.add(request.json):
                _invalidate_admin_cache(201)
                return jsonify({"id": source.id, "message": "Connector created successfully"}), 201
        except ValueError as exc:
            db.session.rollback()
            logger.warning("Invalid connector create payload: %s", exc)
        return {"error": "Connector could not be created"}, 400

    @auth_required("CONFIG_CONNECTOR_UPDATE")
    def put(self, connector_id: str | None = None):
        if connector_id is None:
            return {"error": "No connector_id provided"}, 400
        if not (update_data := request.json):
            return {"error": "No update data passed"}, 400
        try:
            if source := connector.Connector.update(connector_id, update_data):
                _invalidate_admin_cache(200)
                return {"message": "Connector updated", "id": source.id}, 200
        except ValueError as e:
            db.session.rollback()
            logger.warning("Invalid connector update payload: %s", e)
            return {"error": "Invalid connector update payload"}, 400
        return {"error": "Connector not found"}, 404

    @auth_required("CONFIG_CONNECTOR_DELETE")
    def delete(self, connector_id: str | None = None):
        if connector_id is None:
            return {"error": "No connector_id provided"}, 400
        # TODO: Implement force delete logic if needed
        response, status = connector.Connector.delete(connector_id)
        _invalidate_admin_cache(status)
        return response, status

    @auth_required("CONFIG_CONNECTOR_UPDATE")
    def patch(self, connector_id: str | None = None):
        if connector_id is None:
            return {"error": "No connector_id provided"}, 400
        if not request.json:
            return {"error": "No data provided"}, 400
        if state := request.json.get("state"):
            update_data = {"state": state}
        else:
            update_data = request.json
        try:
            if source := connector.Connector.update(connector_id, update_data, patch=True):
                _invalidate_admin_cache(200)
                return {"message": "Connector updated", "id": source.id}, 200
        except ValueError as e:
            db.session.rollback()
            logger.warning("Invalid connector patch payload: %s", e)
            return {"error": "Invalid connector update payload"}, 400
        return {"error": "Connector not found"}, 404


class ConnectorsPull(MethodView):
    @auth_required("CONFIG_CONNECTOR_UPDATE")
    def post(self, connector_id: str):
        """Trigger collection of stories from the external system."""
        try:
            collected_stories = queue_manager.queue_manager.pull_from_connector(connector_id=connector_id, user_id=current_user.id)

            return {"message": "Stories successfully collected.", "data": collected_stories}, 200
        except Exception:
            logger.exception("Failed to pull stories from connector %s", connector_id)
            return {"error": "Failed to pull stories from connector"}, 500


class OSINTSources(MethodView):
    @auth_required("CONFIG_OSINT_SOURCE_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "type", "fetch_all", "filter_manual", "state", "period")
    def get(self, source_id: str | None = None, filter_args: dict[str, Any] | None = None):
        filter_args = filter_args or {}
        if source_id:
            try:
                collection_period = osint_source.OSINTSource.validate_collection_period(filter_args.get("period"))
            except ValueError:
                return {"error": osint_source.INVALID_COLLECTION_PERIOD_MESSAGE}, 400
            return osint_source.OSINTSource.get_for_api(source_id, collection_period)
        return osint_source.OSINTSource.get_all_for_api(filter_args=filter_args, with_count=True)

    @auth_required("CONFIG_OSINT_SOURCE_CREATE")
    def post(self):
        try:
            if source := osint_source.OSINTSource.add(request.json):
                _invalidate_admin_cache(201)
                return {"id": source.id, "message": "OSINT source created successfully"}, 201
        except ValidationError as exc:
            return {"error": OSINTSourceModel.format_validation_errors(exc)}, 400
        except osint_source.InvalidOSINTSourceIconError as exc:
            logger.warning("Invalid OSINT source icon payload: %s", exc)
            return {"error": exc.public_message}, 400
        except ValueError as exc:
            db.session.rollback()
            logger.warning("Invalid OSINT source payload: %s", exc)
            return {"error": "Invalid OSINT source payload"}, 400
        return {"error": "OSINT source could not be created"}, 400

    @auth_required("CONFIG_OSINT_SOURCE_UPDATE")
    def put(self, source_id: str | None = None):
        if source_id is None:
            return {"error": "No source_id provided"}, 400
        if not (update_data := request.json):
            return {"error": "No update data passed"}, 400
        try:
            if source := osint_source.OSINTSource.update(source_id, update_data):
                _invalidate_admin_cache(200)
                return {"message": "OSINT Source updated", "id": source.id}, 200
        except ValidationError as exc:
            return {"error": OSINTSourceModel.format_validation_errors(exc)}, 400
        except osint_source.InvalidOSINTSourceIconError as e:
            logger.warning("Invalid OSINT source icon payload: %s", e)
            return {"error": e.public_message}, 400
        except ValueError as e:
            db.session.rollback()
            logger.warning("Invalid OSINT source update payload: %s", e)
            return {"error": "Invalid OSINT source payload"}, 400
        return {"error": "OSINT Source not found"}, 404

    @auth_required("CONFIG_OSINT_SOURCE_DELETE")
    def delete(self, source_id: str | None = None):
        source_ids = [source_id] if source_id is not None else request.args.getlist("ids")
        if not source_ids:
            return {"error": "No source_id provided"}, 400
        force_value = request.args.get("force")
        if force_value not in {None, "true", "false"}:
            return {"error": "The force parameter must be true or false"}, 400
        force = force_value == "true"

        if source_id is not None:
            response, status = osint_source.OSINTSource.delete(source_id, force=force)
            _invalidate_admin_cache(status)
            return response, status

        response, status = osint_source.OSINTSource.delete_many(source_ids, force=force)
        _invalidate_admin_cache(status)
        return response, status

    @auth_required("CONFIG_OSINT_SOURCE_UPDATE")
    def patch(self, source_id: str | None = None):
        if source_id is None:
            return {"error": "No source_id provided"}, 400
        data = dict(request.json or {})
        state = data.pop("state", None)
        if state is not None and state not in {"enabled", "disabled"}:
            return {"error": "Invalid state"}, 400
        if state and not data:
            logger.debug(f"Toggling OSINT source {source_id} to state {state}")
            response, status = osint_source.OSINTSource.toggle_state(source_id, state)
            _invalidate_admin_cache(status)
            return response, status
        if state:
            data["enabled"] = state == "enabled"
        try:
            if source := osint_source.OSINTSource.update(source_id, data, patch=True):
                _invalidate_admin_cache(200)
                return {"message": "OSINT Source updated", "id": source.id}, 200
        except (ValidationError, ValueError) as exc:
            db.session.rollback()
            logger.warning("Invalid OSINT source patch payload: %s", exc)
            return {"error": "Invalid OSINT source payload"}, 400
        return {"error": "OSINT Source not found"}, 404


class OSINTSourceCollect(MethodView):
    @auth_required("CONFIG_OSINT_SOURCE_UPDATE")
    def post(self, source_id: str | None = None):
        if source_id:
            if source := osint_source.OSINTSource.get(source_id):
                return queue_manager.queue_manager.collect_osint_source(source_id, task_id=source.task_id, user_id=current_user.id)
            return {"error": "OSINT Source not found"}, 404
        return queue_manager.queue_manager.collect_all_osint_sources(user_id=current_user.id)


class OSINTSourcePreview(MethodView):
    @auth_required("CONFIG_OSINT_SOURCE_UPDATE")
    def get(self, source_id: str):
        return self.get_osint_source_preview_response(source_id, user_id=current_user.id)

    @classmethod
    def get_osint_source_preview_response(cls, source_id: str, user_id: str | None = None):
        task_id = f"source_preview_{source_id}"

        if result := task.Task.get(task_id):
            return result.to_dict(), 200
        preview_result, status = queue_manager.queue_manager.get_task(task_id)
        if status == 202:
            return preview_result, status
        if user_id is None:
            return queue_manager.queue_manager.preview_osint_source(source_id)
        return queue_manager.queue_manager.preview_osint_source(source_id, user_id=user_id)

    @auth_required("CONFIG_OSINT_SOURCE_UPDATE")
    def post(self, source_id: str):
        return queue_manager.queue_manager.preview_osint_source(source_id, user_id=current_user.id)


class OSINTSourcesExport(MethodView):
    @auth_required("CONFIG_OSINT_SOURCE_ACCESS")
    def get(self):
        source_ids = request.args.getlist("ids")
        with_groups = request.args.get("groups", default=False, type=bool)
        with_secrets = request.args.get("secrets", default=False, type=bool)
        export_args = {"source_ids": source_ids, "with_groups": with_groups, "with_secrets": with_secrets}
        data = osint_source.OSINTSource.export_osint_sources(export_args)
        if data is None:
            return {"error": "Unable to export"}, 400
        return send_file(
            io.BytesIO(data),
            download_name="osint_sources_export.json",
            mimetype="application/json",
            as_attachment=True,
        )


class OSINTSourcesImport(MethodView):
    @auth_required("CONFIG_OSINT_SOURCE_CREATE")
    def post(self):
        try:
            sources = None
            if file := request.files.get("file"):
                sources = osint_source.OSINTSource.import_osint_sources(file)
            if json_data := request.get_json(silent=True):
                sources = osint_source.OSINTSource.import_osint_sources_from_json(json_data)
        except ValidationError as exc:
            return {"error": OSINTSourceModel.format_validation_errors(exc)}, 400
        except (KeyError, TypeError, ValueError):
            logger.exception("Invalid OSINT source import")
            return {"error": "Invalid source import"}, 400
        if sources is None:
            logger.error("Failed to import OSINT sources")
            return {"error": "Unable to import"}, 400
        _invalidate_admin_cache(200)
        return {"sources": sources, "count": len(sources), "message": "Successfully imported sources"}


class CuratedOSINTSourceLists(MethodView):
    @auth_required("CONFIG_OSINT_SOURCE_ACCESS")
    def get(self):
        try:
            return {"items": osint_source.OSINTSource.get_curated_list_summaries()}
        except (OSError, ValueError, ValidationError):
            logger.exception("Invalid curated OSINT source catalog")
            return {"error": "Curated OSINT source catalog is unavailable"}, 500

    @auth_required("CONFIG_OSINT_SOURCE_CREATE")
    def post(self):
        try:
            selection = CuratedOSINTSourceSelection.model_validate(request.get_json(silent=True) or {})
            response = osint_source.OSINTSource.load_curated_lists(selection.list_names)
        except ValidationError:
            return {"error": "Select at least one valid curated source list"}, 400
        except osint_source.CuratedOSINTSourceSchedulingError:
            _invalidate_admin_cache(200)
            return {"error": "Curated OSINT sources were saved but could not be scheduled; retry loading the selected lists"}, 503
        except osint_source.CuratedOSINTSourceConflictError as exc:
            logger.info("Curated OSINT source load rejected: %s", exc.public_message)
            return {"error": exc.public_message}, 409
        except IntegrityError:
            raise
        except ValueError:
            logger.exception("Invalid curated OSINT source selection or catalog")
            return {"error": "Invalid curated OSINT source selection"}, 400
        except OSError:
            logger.exception("Unable to read curated OSINT source catalog")
            return {"error": "Curated OSINT source catalog is unavailable"}, 500
        except Exception:
            logger.exception("Failed to load curated OSINT sources")
            return {"error": "Unable to load curated OSINT sources"}, 500

        _invalidate_admin_cache(200)
        return response


class OSINTSourceGroups(MethodView):
    @auth_required("CONFIG_OSINT_SOURCE_GROUP_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, group_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if group_id:
            return osint_source.OSINTSourceGroup.get_for_api(group_id)
        return osint_source.OSINTSourceGroup.get_all_for_api(filter_args=filter_args, with_count=True)

    @auth_required("CONFIG_OSINT_SOURCE_GROUP_CREATE")
    def post(self):
        source_group = osint_source.OSINTSourceGroup.add(request.json)
        _invalidate_admin_cache(200)
        return jsonify({"id": source_group.id, "message": "OSINT source group created successfully"}), 200

    @auth_required("CONFIG_OSINT_SOURCE_GROUP_UPDATE")
    def put(self, group_id: str | None = None):
        if group_id is None:
            return {"error": "No group_id provided"}, 400
        if not (data := request.json):
            return {"error": "No data provided"}, 400
        response, status = osint_source.OSINTSourceGroup.update(group_id, data)
        _invalidate_admin_cache(status)
        return response, status

    @auth_required("CONFIG_OSINT_SOURCE_GROUP_DELETE")
    def delete(self, group_id: str | None = None):
        if group_id is None:
            return {"error": "No group_id provided"}, 400
        response, status = osint_source.OSINTSourceGroup.delete(group_id)
        _invalidate_admin_cache(status)
        return response, status


class PublisherPresets(MethodView):
    @auth_required("CONFIG_PUBLISHER_ACCESS")
    @extract_args("search", "page", "limit", "sort", "order", "fetch_all")
    def get(self, preset_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if preset_id:
            return publisher_preset.PublisherPreset.get_for_api(preset_id)
        return publisher_preset.PublisherPreset.get_all_for_api(filter_args, True)

    @auth_required("CONFIG_PUBLISHER_CREATE")
    def post(self):
        try:
            pub_result = publisher_preset.PublisherPreset.add(request.json)
            _invalidate_admin_cache(200)
            return jsonify({"id": pub_result.id, "message": "Publisher preset created successfully"}), 200
        except ValueError as exc:
            db.session.rollback()
            logger.warning("Invalid publisher preset create payload: %s", exc)
            return {"error": "Invalid publisher preset payload"}, 400

    @auth_required("CONFIG_PUBLISHER_UPDATE")
    def put(self, preset_id: str | None = None):
        if preset_id is None:
            return {"error": "No preset_id provided"}, 400
        try:
            response, status = publisher_preset.PublisherPreset.update(preset_id, request.json)
            _invalidate_admin_cache(status)
            return response, status
        except ValueError as exc:
            db.session.rollback()
            logger.warning("Invalid publisher preset update payload: %s", exc)
            return {"error": "Invalid publisher preset payload"}, 400

    @auth_required("CONFIG_PUBLISHER_UPDATE")
    def patch(self, preset_id: str | None = None):
        if preset_id is None:
            return {"error": "No preset_id provided"}, 400
        try:
            response, status = publisher_preset.PublisherPreset.update(preset_id, request.json or {}, patch=True)
            _invalidate_admin_cache(status)
            return response, status
        except ValueError as exc:
            db.session.rollback()
            logger.warning("Invalid publisher preset patch payload: %s", exc)
            return {"error": "Invalid publisher preset payload"}, 400

    @auth_required("CONFIG_PUBLISHER_DELETE")
    def delete(self, preset_id: str | None = None):
        if preset_id is None:
            return {"error": "No preset_id provided"}, 400
        response, status = publisher_preset.PublisherPreset.delete(preset_id)
        _invalidate_admin_cache(status)
        return response, status


class WordLists(MethodView):
    @auth_required("CONFIG_WORD_LIST_ACCESS")
    @extract_args("search", "usage", "with_entries", "page", "limit", "sort", "order", "fetch_all")
    def get(self, word_list_id: str | None = None, filter_args: dict[str, Any] | None = None):
        if word_list_id:
            return word_list.WordList.get_for_api(word_list_id)
        return word_list.WordList.get_all_for_api(filter_args=filter_args, with_count=True)

    @auth_required("CONFIG_WORD_LIST_CREATE")
    def post(self):
        wordlist = word_list.WordList.add(request.json)
        _invalidate_admin_cache(200)
        return jsonify({"id": wordlist.id, "message": "Word list created successfully"}), 200

    @auth_required("CONFIG_WORD_LIST_DELETE")
    def delete(self, word_list_id: str | None = None):
        if word_list_id is None:
            return {"error": "No word_list_id provided"}, 400
        try:
            response, status = word_list.WordList.delete(word_list_id)
            _invalidate_admin_cache(status)
            return response, status
        except (IntegrityError, ValidationError):
            raise
        except Exception:
            logger.exception(f"Failed to delete word list {word_list_id}")
            return {"error": "Could not delete word list"}, 400

    @auth_required("CONFIG_WORD_LIST_UPDATE")
    def put(self, word_list_id: str | None = None):
        if word_list_id is None:
            return {"error": "No word_list_id provided"}, 400
        if data := request.json:
            response, status = word_list.WordList.update(word_list_id, data)
            _invalidate_admin_cache(status)
            return response, status
        return {"error": "No data provided"}, 400


class WordListImport(MethodView):
    @auth_required("CONFIG_WORD_LIST_UPDATE")
    def post(self):
        try:
            wls = None
            if file := request.files.get("file"):
                wls = word_list.WordList.import_word_lists(file)
            if json_data := request.get_json(silent=True):
                wls = word_list.WordList.import_word_lists_from_json(json_data)
            if wls is None:
                logger.error("Failed to import Word Lists")
                return {"error": "Unable to import Word Lists"}, 400

            for wl in wls:
                queue_manager.queue_manager.gather_word_list(wl.id, user_id=current_user.id)

            _invalidate_admin_cache(200)
            return {"word_lists": [wl.id for wl in wls], "count": len(wls), "message": "Successfully imported word lists"}
        except ValueError as exc:
            logger.warning(f"Invalid word list import payload: {exc}")
            return {"error": "Invalid word list import payload"}, 400
        except IntegrityError:
            raise
        except Exception:
            logger.exception("Exception occurred during Word List import")
            return {"error": "Unable to import Word Lists"}, 500


class WordListExport(MethodView):
    @auth_required("CONFIG_WORD_LIST_UPDATE")
    def get(self):
        word_list_ids = request.args.getlist("ids")
        data = word_list.WordList.export(word_list_ids)
        if data is None:
            return {"error": "Unable to export word lists"}, 400
        return send_file(
            io.BytesIO(data),
            download_name="word_list_export.json",
            mimetype="application/json",
            as_attachment=True,
        )


class WordListGather(MethodView):
    @auth_required("CONFIG_WORD_LIST_UPDATE")
    def post(self, word_list_id: str | None = None):
        if not word_list_id:
            return queue_manager.queue_manager.gather_all_word_lists(user_id=current_user.id)
        return queue_manager.queue_manager.gather_word_list(word_list_id, user_id=current_user.id)


class WorkerInstances(MethodView):
    @auth_required("CONFIG_WORKER_ACCESS")
    def get(self):
        return queue_manager.queue_manager.ping_workers()


class ParameterSecrets(MethodView):
    _RESOURCES: ClassVar[dict[str, tuple[type, str]]] = {
        "sources": (osint_source.OSINTSource, "CONFIG_OSINT_SOURCE_UPDATE"),
        "bots": (bot.Bot, "CONFIG_BOT_UPDATE"),
        "connectors": (connector.Connector, "CONFIG_CONNECTOR_UPDATE"),
        "product-types": (product_type.ProductType, "CONFIG_PRODUCT_TYPE_UPDATE"),
        "publisher-presets": (publisher_preset.PublisherPreset, "CONFIG_PUBLISHER_UPDATE"),
    }

    @auth_required(
        [
            "CONFIG_OSINT_SOURCE_UPDATE",
            "CONFIG_BOT_UPDATE",
            "CONFIG_CONNECTOR_UPDATE",
            "CONFIG_PRODUCT_TYPE_UPDATE",
            "CONFIG_PUBLISHER_UPDATE",
        ]
    )
    def post(self, resource: str, resource_id: str, parameter: str):
        if not (resource_config := self._RESOURCES.get(resource)):
            return {"error": "Unknown parameter resource"}, 404
        model, permission = resource_config
        permissions = set(current_user.get_permissions())
        if permission not in permissions and "ALL" not in permissions:
            return {"error": "forbidden"}, 403
        if not (item := model.get(resource_id)):
            return {"error": "Parameter resource not found"}, 404
        try:
            value = reveal_parameter(item.type, item.parameters, parameter)
        except ValueError:
            logger.warning("Invalid parameter secret reveal request", exc_info=True)
            return {"error": "Invalid parameter secret request"}, 400
        response = jsonify({"value": value})
        response.cache_control.no_store = True
        response.cache_control.private = True
        response.headers["Pragma"] = "no-cache"
        return response, 200


def build_config_blueprint(name: str) -> Blueprint:
    config_bp = Blueprint(name, __name__, url_prefix=f"{Config.APPLICATION_ROOT}api/{name}")
    config_bp.register_error_handler(IntegrityError, handle_integrity_error)
    config_bp.register_error_handler(ValidationError, handle_validation_error)
    crud_methods = ["GET", "PUT", "DELETE"]
    crud_patch_methods = ["GET", "PUT", "DELETE", "PATCH"]

    config_bp.add_url_rule("/acls", view_func=ACLEntries.as_view(f"{name}_acls"))
    config_bp.add_url_rule("/acls/<string:acl_id>", view_func=ACLEntries.as_view(f"{name}_acl"), methods=crud_methods)
    config_bp.add_url_rule("/attributes", view_func=Attributes.as_view(f"{name}_attributes"))
    config_bp.add_url_rule("/attributes/<string:attribute_id>", view_func=Attributes.as_view(f"{name}_attribute"), methods=crud_methods)
    config_bp.add_url_rule("/bots", view_func=Bots.as_view(f"{name}_bots_config"), methods=["GET", "POST"])
    config_bp.add_url_rule("/bots/<string:bot_id>", view_func=Bots.as_view(f"{name}_bot_config"), methods=crud_patch_methods)
    config_bp.add_url_rule("/bots/dag-preview", view_func=BotDagPreview.as_view(f"{name}_bot_dag_preview"))
    config_bp.add_url_rule("/bots/<string:bot_id>/execute", view_func=BotExecute.as_view(f"{name}_bot_execute"))
    config_bp.add_url_rule(
        "/dictionaries-reload/<string:dictionary_type>", view_func=DictionariesReload.as_view(f"{name}_dictionaries_reload")
    )
    config_bp.add_url_rule("/organizations", view_func=Organizations.as_view(f"{name}_organizations"))
    config_bp.add_url_rule(
        "/organizations/<string:organization_id>",
        view_func=Organizations.as_view(f"{name}_organization"),
        methods=crud_methods,
    )
    config_bp.add_url_rule("/osint-sources", view_func=OSINTSources.as_view(f"{name}_osint_sources"), methods=["GET", "POST", "DELETE"])
    config_bp.add_url_rule("/sources", view_func=OSINTSources.as_view(f"{name}_sources"), methods=["GET", "POST"])
    config_bp.add_url_rule(
        "/osint-sources/<string:source_id>", view_func=OSINTSources.as_view(f"{name}_osint_source"), methods=crud_patch_methods
    )
    config_bp.add_url_rule("/sources/<string:source_id>", view_func=OSINTSources.as_view(f"{name}_source"), methods=crud_patch_methods)
    config_bp.add_url_rule("/osint-sources/<string:source_id>/collect", view_func=OSINTSourceCollect.as_view(f"{name}_osint_source_collect"))
    config_bp.add_url_rule("/osint-sources/collect", view_func=OSINTSourceCollect.as_view(f"{name}_osint_sources_collect"))
    config_bp.add_url_rule("/osint-sources/<string:source_id>/preview", view_func=OSINTSourcePreview.as_view(f"{name}_osint_source_preview"))
    config_bp.add_url_rule("/osint-source-groups", view_func=OSINTSourceGroups.as_view(f"{name}_osint_source_groups_config"))
    config_bp.add_url_rule(
        "/osint-source-groups/<string:group_id>", view_func=OSINTSourceGroups.as_view(f"{name}_osint_source_group"), methods=crud_methods
    )
    config_bp.add_url_rule("/export-osint-sources", view_func=OSINTSourcesExport.as_view(f"{name}_osint_sources_export"))
    config_bp.add_url_rule("/import-osint-sources", view_func=OSINTSourcesImport.as_view(f"{name}_osint_sources_import"))
    config_bp.add_url_rule(
        "/curated-osint-source-lists",
        view_func=CuratedOSINTSourceLists.as_view(f"{name}_curated_osint_source_lists"),
        methods=["GET", "POST"],
    )
    config_bp.add_url_rule("/permissions", view_func=Permissions.as_view(f"{name}_permissions"))
    config_bp.add_url_rule("/product-types", view_func=ProductTypes.as_view(f"{name}_product_types_config"), methods=["GET", "POST"])
    config_bp.add_url_rule(
        "/product-types/<string:type_id>", view_func=ProductTypes.as_view(f"{name}_product_type"), methods=crud_patch_methods
    )
    config_bp.add_url_rule("/templates", view_func=Templates.as_view(f"{name}_templates"))
    config_bp.add_url_rule("/templates/<string:template_path>", view_func=Templates.as_view(f"{name}_template"))
    config_bp.add_url_rule("/templates/validate", view_func=TemplateValidation.as_view(f"{name}_template_validation"))
    config_bp.add_url_rule("/publishers-presets", view_func=PublisherPresets.as_view(f"{name}_publishers_presets"), methods=["GET", "POST"])
    config_bp.add_url_rule(
        "/publishers-presets/<string:preset_id>", view_func=PublisherPresets.as_view(f"{name}_publishers_preset"), methods=crud_patch_methods
    )
    config_bp.add_url_rule("/publisher-presets", view_func=PublisherPresets.as_view(f"{name}_publisher_presets"), methods=["GET", "POST"])
    config_bp.add_url_rule(
        "/publisher-presets/<string:preset_id>", view_func=PublisherPresets.as_view(f"{name}_publisher_preset"), methods=crud_patch_methods
    )
    config_bp.add_url_rule("/report-item-types", view_func=ReportItemTypes.as_view(f"{name}_report_item_types"))
    config_bp.add_url_rule(
        "/report-item-types/<string:type_id>", view_func=ReportItemTypes.as_view(f"{name}_report_item_type"), methods=crud_methods
    )
    config_bp.add_url_rule("/export-report-item-types", view_func=ReportItemTypesExport.as_view(f"{name}_report_item_types_export"))
    config_bp.add_url_rule("/import-report-item-types", view_func=ReportItemTypesImport.as_view(f"{name}_report_item_types_import"))
    config_bp.add_url_rule("/roles", view_func=Roles.as_view(f"{name}_roles"))
    config_bp.add_url_rule("/roles/<string:role_id>", view_func=Roles.as_view(f"{name}_role"), methods=crud_methods)
    config_bp.add_url_rule("/users", view_func=Users.as_view(f"{name}_users"))
    config_bp.add_url_rule("/users-import", view_func=UsersImport.as_view(f"{name}_users_import"))
    config_bp.add_url_rule("/users-export", view_func=UsersExport.as_view(f"{name}_users_export"))
    config_bp.add_url_rule("/users/<string:user_id>", view_func=Users.as_view(f"{name}_user"), methods=crud_methods)
    config_bp.add_url_rule("/word-lists", view_func=WordLists.as_view(f"{name}_word_lists"))
    config_bp.add_url_rule("/word-lists/<string:word_list_id>", view_func=WordLists.as_view(f"{name}_word_list"), methods=crud_methods)
    config_bp.add_url_rule("/word-lists/gather/<string:word_list_id>", view_func=WordListGather.as_view(f"{name}_word_list_gather"))
    config_bp.add_url_rule("/word-lists/gather", view_func=WordListGather.as_view(f"{name}_word_list_gather_all"))
    config_bp.add_url_rule("/export-word-lists", view_func=WordListExport.as_view(f"{name}_word_list_export"))
    config_bp.add_url_rule("/import-word-lists", view_func=WordListImport.as_view(f"{name}_word_list_import"))
    config_bp.add_url_rule("/workers", view_func=WorkerInstances.as_view(f"{name}_workers"))
    config_bp.add_url_rule("/workers/cron-jobs", view_func=CronJobs.as_view(f"{name}_cron_jobs"))
    config_bp.add_url_rule("/workers/schedule", view_func=Schedule.as_view(f"{name}_queue_schedule_config"))
    config_bp.add_url_rule("/workers/tasks", view_func=QueueTasks.as_view(f"{name}_queue_tasks"))
    config_bp.add_url_rule("/workers/queue-status", view_func=QueueStatus.as_view(f"{name}_queue_status"))
    config_bp.add_url_rule("/workers/active", view_func=ActiveJobs.as_view(f"{name}_active_jobs"))
    config_bp.add_url_rule("/workers/failed", view_func=FailedJobs.as_view(f"{name}_failed_jobs"))
    config_bp.add_url_rule("/workers/stats", view_func=WorkerStats.as_view(f"{name}_worker_stats"))
    config_bp.add_url_rule("/admin-menu-badges", view_func=AdminMenuBadges.as_view(f"{name}_admin_menu_badges"))
    config_bp.add_url_rule("/schedule", view_func=Schedule.as_view(f"{name}_queue_schedule"))
    config_bp.add_url_rule("/schedule/<string:task_id>", view_func=Schedule.as_view(f"{name}_queue_schedule_task"))
    config_bp.add_url_rule(
        "/parameter-secrets/<string:resource>/<string:resource_id>/<string:parameter>/reveal",
        view_func=ParameterSecrets.as_view(f"{name}_parameter_secret_reveal"),
    )
    config_bp.add_url_rule("/connectors", view_func=Connectors.as_view(f"{name}_connectors"), methods=["GET", "POST"])
    config_bp.add_url_rule("/connectors/<string:connector_id>", view_func=Connectors.as_view(f"{name}_connector"), methods=crud_patch_methods)
    config_bp.add_url_rule("/connectors/<string:connector_id>/pull", view_func=ConnectorsPull.as_view(f"{name}_connector_collect"))

    return config_bp


def initialize(app: Flask):
    config_bp = build_config_blueprint("config")
    admin_bp = build_config_blueprint("admin")

    app.register_blueprint(config_bp)
    app.register_blueprint(admin_bp)
