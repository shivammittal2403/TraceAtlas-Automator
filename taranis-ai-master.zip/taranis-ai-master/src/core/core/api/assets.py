from flask import Flask, jsonify, request
from flask.views import MethodView
from flask_jwt_extended import current_user

from core.config import Config
from core.managers.auth_manager import auth_required
from core.managers.decorators import extract_args
from core.model import asset
from core.service.cache_invalidation import invalidate_frontend_cache_on_success
from core.service.cti import CTIService


class AssetGroups(MethodView):
    @auth_required("ASSETS_ACCESS")
    @extract_args("search", "page", "limit", "order", "fetch_all")
    def get(self, group_id=None, filter_args=None):
        if group_id:
            return asset.AssetGroup.get_for_api(group_id, current_user.organization)

        filter_args = filter_args or {}
        filter_args["organization"] = current_user.organization
        return asset.AssetGroup.get_all_for_api(filter_args=filter_args, with_count=True, user=current_user)

    @auth_required("ASSETS_CONFIG")
    def post(self):
        data = request.json
        if not data:
            return {"error": "No data provided"}, 400
        data["organization"] = current_user.organization
        asset_result = asset.AssetGroup.add(data)
        invalidate_frontend_cache_on_success(201, models=("asset_group",))
        return jsonify({"message": "Asset Group added", "id": asset_result.id}), 201

    @auth_required("ASSETS_CONFIG")
    def delete(self, group_id: str | None = None):
        if not group_id:
            return {"error": "No group_id provided"}, 400
        response, status = asset.AssetGroup.delete(current_user.organization, group_id)
        invalidate_frontend_cache_on_success(status, models=("asset_group",))
        return response, status

    @auth_required("ASSETS_CONFIG")
    def put(self, group_id: str | None = None):
        if not group_id:
            return {"error": "No group_id provided"}, 400
        response, status = asset.AssetGroup.update(current_user.organization, group_id, request.json)
        invalidate_frontend_cache_on_success(status, models=("asset_group",))
        return response, status


class Assets(MethodView):
    @auth_required("ASSETS_ACCESS")
    @extract_args("search", "vulnerable", "group", "page", "limit", "order", "fetch_all")
    def get(self, asset_id=None, filter_args=None):
        if asset_id:
            return asset.Asset.get_for_api(asset_id, current_user.organization)
        filter_args = filter_args or {}
        filter_args["organization"] = current_user.organization
        return asset.Asset.get_all_for_api(filter_args=filter_args, with_count=True, user=current_user)

    @auth_required("ASSETS_CREATE")
    def post(self):
        if not (data := request.json):
            return {"error": "No data provided"}, 400
        response, status = asset.Asset.add(current_user.organization, data)
        invalidate_frontend_cache_on_success(status, models=("asset",))
        return jsonify(response), status

    @auth_required("ASSETS_CREATE")
    def put(self, asset_id: str | None = None):
        if asset_id is None:
            return {"error": "No asset_id provided"}, 400
        response, status = asset.Asset.update(current_user.organization, asset_id, request.json)
        invalidate_frontend_cache_on_success(status, models=("asset",), object_ids={"asset": asset_id})
        return response, status

    @auth_required("ASSETS_CREATE")
    def delete(self, asset_id: str | None = None):
        if asset_id is None:
            return {"error": "No asset_id provided"}, 400
        response, status = asset.Asset.delete(current_user.organization, asset_id)
        invalidate_frontend_cache_on_success(status, models=("asset",), object_ids={"asset": asset_id})
        return response, status


class AssetCTI(MethodView):
    @auth_required("ASSETS_ACCESS")
    def get(self, asset_id: str):
        return CTIService.get_asset_cti(asset_id, current_user)


class AssetsCTI(MethodView):
    @auth_required("ASSETS_ACCESS")
    def get(self):
        return CTIService.get_assets_cti(current_user)


class AssetVulnerability(MethodView):
    @auth_required("ASSETS_CREATE")
    def put(self, asset_id, vulnerability_id):
        data = request.json or {}
        if "solved" not in data:
            return {"message": "Missing solved field"}, 400
        response, status = asset.Asset.solve_vulnerability(current_user.organization, asset_id, vulnerability_id, data["solved"])
        invalidate_frontend_cache_on_success(status, models=("asset",), object_ids={"asset": asset_id})
        return response, status


def initialize(app: Flask):
    base_route = f"{Config.APPLICATION_ROOT}api"
    app.add_url_rule(f"{base_route}/assets", view_func=Assets.as_view("assets"))
    app.add_url_rule(f"{base_route}/assets/cti", view_func=AssetsCTI.as_view("assets_cti"))
    app.add_url_rule(f"{base_route}/assets/<string:asset_id>", view_func=Assets.as_view("asset"), methods=["GET", "PUT", "DELETE"])
    app.add_url_rule(f"{base_route}/assets/<string:asset_id>/cti", view_func=AssetCTI.as_view("asset_cti"))
    app.add_url_rule(
        f"{base_route}/assets/<string:asset_id>/vulnerabilities/<string:vulnerability_id>",
        view_func=AssetVulnerability.as_view("asset_vulnerability"),
    )
    app.add_url_rule(f"{base_route}/asset-groups", view_func=AssetGroups.as_view("asset_groups"))
    app.add_url_rule(
        f"{base_route}/asset-groups/<string:group_id>",
        view_func=AssetGroups.as_view("asset_group"),
        methods=["GET", "PUT", "DELETE"],
    )
