from flask import Blueprint, Flask, send_from_directory
from flask.views import MethodView

from core.config import Config
from core.managers.data_manager import get_default_json


class DefaultWordLists(MethodView):
    def get(self):
        return send_from_directory(get_default_json("default_word_lists.json"), "default_word_lists.json")


class OpenAPI3(MethodView):
    def get(self):
        return send_from_directory("static", "openapi3_1.yaml")


def initialize(app: Flask):
    static_bp = Blueprint("static", __name__, url_prefix=f"{Config.APPLICATION_ROOT}api/static")

    static_bp.add_url_rule("/default_word_lists.json", view_func=DefaultWordLists.as_view("default_word_lists"))
    static_bp.add_url_rule("/openapi3_1.yaml", view_func=OpenAPI3.as_view("openapi3"))

    app.register_blueprint(static_bp)
