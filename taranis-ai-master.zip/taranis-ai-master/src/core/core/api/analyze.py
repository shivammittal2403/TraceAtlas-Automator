from flask import Blueprint, Flask, abort, jsonify, make_response, request
from flask.views import MethodView
from flask_jwt_extended import current_user

from core.api.utils import request_id_list
from core.config import Config
from core.log import logger
from core.managers import asset_manager, queue_manager
from core.managers.auth_manager import auth_required
from core.managers.realtime_publisher import realtime_publisher
from core.managers.report_item_lock_service import report_item_lock_service
from core.model import report_item, report_item_type
from core.model.revision import ReportRevision
from core.service.cache_invalidation import SCOPE_PUBLISH_VIEWS, SCOPE_REPORT_VIEWS, invalidate_frontend_cache_on_success
from core.service.cti import CTIService
from core.service.product import ProductService
from core.service.report_publish_workflow import ReportPublishWorkflowService


class ReportTypes(MethodView):
    @auth_required("ANALYZE_ACCESS")
    def get(self):
        return report_item_type.ReportItemType.get_all_for_user_api(user=current_user)


class ReportStories(MethodView):
    @auth_required("ANALYZE_ACCESS")
    def get(self, report_item_id: str):
        return report_item.ReportItem.get_story_ids(report_item_id)

    @auth_required("ANALYZE_UPDATE")
    def put(self, report_item_id: str):
        request_data = request.json
        if not isinstance(request_data, list):
            logger.warning("No data in request")
            return {"error": "No data in request"}, 400
        response, status = report_item.ReportItem.set_stories(report_item_id, request_data, current_user)
        invalidate_frontend_cache_on_success(
            status,
            scopes=(SCOPE_REPORT_VIEWS,),
            object_ids={"report": report_item_id},
        )
        return make_response(jsonify(response), status)

    @auth_required("ANALYZE_UPDATE")
    def post(self, report_item_id: str):
        request_data = request.json
        if not isinstance(request_data, list):
            logger.warning("No data in request")
            return {"error": "No data in request"}, 400
        response, status = report_item.ReportItem.add_stories(report_item_id, request_data, current_user)
        invalidate_frontend_cache_on_success(
            status,
            scopes=(SCOPE_REPORT_VIEWS,),
            object_ids={"report": report_item_id},
        )
        return make_response(jsonify(response), status)


class ReportItem(MethodView):
    @auth_required("ANALYZE_ACCESS")
    def get(self, report_item_id: str | None = None):
        if report_item_id:
            return report_item.ReportItem.get_for_api(report_item_id, current_user)
        filter_keys = ["search", "completed", "range", "order", "group", "page", "limit", "story_id", "report_item_type_id"]
        filter_args: dict[str, str | int] = {k: v for k, v in request.args.items() if k in filter_keys}

        return report_item.ReportItem.get_all_for_api(filter_args=filter_args, with_count=True, user=current_user)

    @auth_required("ANALYZE_CREATE")
    def post(self):
        try:
            if not request.json:
                logger.debug("No data in request")
                return {"error": "No data in request"}, 400
            new_report_item, status = report_item.ReportItem.add(request.json, current_user)
            if status != 200 or not isinstance(new_report_item, report_item.ReportItem):
                return make_response(jsonify(new_report_item), status)
        except Exception as ex:
            logger.exception("Error adding report item: %s", ex)
            return {"error": "Error adding report item"}, 400
        if status == 401:
            return abort(401, "Unauthorized")
        if status == 200 and new_report_item:
            asset_manager.report_item_changed(new_report_item)
            realtime_publisher.report_item_changed(new_report_item.id, current_user.organization_id, "created")
            invalidate_frontend_cache_on_success(status, scopes=(SCOPE_REPORT_VIEWS,))

        return make_response(
            jsonify({"message": "New report item created", "id": new_report_item.id, "report": new_report_item.to_detail_dict()}), status
        )

    @auth_required("ANALYZE_UPDATE")
    def put(self, report_item_id: str | None = None):
        if not report_item_id:
            return {"error": "No report_item_id provided"}, 400
        request_data = request.json
        if not request_data:
            logger.debug("No data in request")
            return {"error": "No data in request"}, 400
        updated_report, status = report_item.ReportItem.update_report_item(report_item_id, request_data, current_user)
        if status == 200:
            realtime_publisher.report_item_changed(report_item_id, current_user.organization_id)
            ProductService.autopublish_product(report_item_id, user_id=current_user.id)
            invalidate_frontend_cache_on_success(
                status,
                scopes=(SCOPE_REPORT_VIEWS, SCOPE_PUBLISH_VIEWS),
                object_ids={"report": report_item_id},
            )

        return make_response(jsonify({"message": "Report item updated", "id": updated_report.get("id"), "report": updated_report}), status)

    @auth_required("ANALYZE_DELETE")
    def delete(self, report_item_id: str | None = None):
        if not report_item_id:
            return {"error": "No report_item_id provided"}, 400
        selected_report = report_item.ReportItem.get(report_item_id)
        if selected_report is None:
            return {"error": "Report not found"}, 404
        if not selected_report.access_allowed(current_user, require_write_access=True):
            return {"error": "User is not allowed to delete report"}, 403
        result, code = report_item.ReportItem.delete(report_item_id)
        if code == 200:
            realtime_publisher.report_item_changed(report_item_id, current_user.organization_id, "deleted")
            invalidate_frontend_cache_on_success(
                code,
                scopes=(SCOPE_REPORT_VIEWS,),
                object_ids={"report": report_item_id},
            )
        return make_response(jsonify(result), code)


class ReportItemCTI(MethodView):
    @auth_required("ANALYZE_ACCESS")
    def get(self, report_item_id: str):
        return CTIService.get_report_cti(report_item_id, current_user)


class ReportItemPublishProduct(MethodView):
    @auth_required(["ANALYZE_CREATE", "PUBLISH_CREATE", "PUBLISH_PRODUCT"])
    def post(self):
        required_permissions = {"ANALYZE_CREATE", "PUBLISH_CREATE", "PUBLISH_PRODUCT"}
        user_permissions = set(current_user.get_permissions()) if current_user else set()
        if not required_permissions.issubset(user_permissions):
            return {"error": "forbidden"}, 403
        response, status = ReportPublishWorkflowService.create_and_publish(request.json, current_user)
        return make_response(jsonify(response), status)


class ReportBotActions(MethodView):
    @auth_required("ANALYZE_UPDATE")
    def post(self):
        payload = request.get_json(silent=True) or {}
        bot_id = payload.get("bot_id")
        if not bot_id:
            return {"error": "No bot_id provided"}, 400
        report_ids = request_id_list(payload, "report_id", "report_ids")
        if not report_ids:
            return {"error": "No report_id provided"}, 400
        for report_id in report_ids:
            report = report_item.ReportItem.get(report_id)
            if not report or not report.access_allowed(current_user, require_write_access=True):
                return {"error": "User does not have write access to all requested reports"}, 403

        response, code = queue_manager.queue_manager.execute_bot_task(
            bot_id=bot_id,
            filter={"report_ids": report_ids},
            user_id=current_user.id,
        )
        invalidate_frontend_cache_on_success(code, scopes=(SCOPE_REPORT_VIEWS,))
        return response, code


class CloneReportItem(MethodView):
    @auth_required("ANALYZE_CREATE")
    def post(self, report_item_id: str):
        try:
            result, status = report_item.ReportItem.clone(report_item_id, current_user)
        except Exception as ex:
            logger.exception("Error cloning report item: %s", ex)
            return {"error": "Error cloning report item"}, 400
        if status == 200:
            realtime_publisher.report_item_changed(result["id"], current_user.organization_id, "created")
            invalidate_frontend_cache_on_success(status, scopes=(SCOPE_REPORT_VIEWS,))

        return make_response(jsonify(result), status)


class ReportItemLocks(MethodView):
    @auth_required("ANALYZE_UPDATE")
    def get(self, report_item_id: str):
        return jsonify(report_item_lock_service.to_report_item_json(report_item_id))


class ReportItemLock(MethodView):
    @auth_required("ANALYZE_UPDATE")
    def put(self, report_item_id: str):
        user = current_user
        if not user:
            return abort(401, "User not found")
        try:
            response, status = report_item_lock_service.lock(report_item_id, user.id, user.organization_id)
            return make_response(jsonify(response), status)
        except Exception as ex:
            logger.exception("Failed to lock report item %s: %s", report_item_id, ex)
            return {"error": "Failed to lock report item"}, 500

    @auth_required("ANALYZE_UPDATE")
    def delete(self, report_item_id: str):
        user = current_user
        if not user:
            return abort(401, "User not found")
        try:
            response, status = report_item_lock_service.unlock(report_item_id, user.organization_id)
            return make_response(jsonify(response), status)
        except Exception as ex:
            logger.exception("Failed to unlock report item %s: %s", report_item_id, ex)
            return {"error": "Failed to unlock report item"}, 500


class ReportItemRevisions(MethodView):
    @auth_required("ANALYZE_ACCESS")
    def get(self, report_item_id: str):
        """Get all revisions for a report item"""
        from core.managers.db_manager import db

        access_response, access_status = report_item.ReportItem.get_for_api(report_item_id, current_user)
        if access_status != 200:
            return make_response(jsonify(access_response), access_status)

        revisions = (
            db.session.execute(
                db.select(ReportRevision).filter(ReportRevision.report_item_id == report_item_id).order_by(ReportRevision.revision.desc())
            )
            .scalars()
            .all()
        )

        return {
            "total_count": len(revisions),
            "items": [
                {
                    "id": rev.id,
                    "revision": rev.revision,
                    "created_at": rev.created_at.isoformat() if rev.created_at else None,
                    "created_by": rev.created_by.username if rev.created_by else None,
                    "created_by_id": rev.created_by_id,
                    "note": rev.note,
                }
                for rev in revisions
            ],
        }, 200


class ReportItemRevisionData(MethodView):
    @auth_required("ANALYZE_ACCESS")
    def get(self, report_item_id: str, revision_number: int):
        """Get data for a specific revision"""
        from core.managers.db_manager import db

        access_response, access_status = report_item.ReportItem.get_for_api(report_item_id, current_user)
        if access_status != 200:
            return access_response, access_status

        if revision := db.session.execute(
            db.select(ReportRevision)
            .filter(ReportRevision.report_item_id == report_item_id)
            .filter(ReportRevision.revision == revision_number)
        ).scalar_one_or_none():
            return {
                "id": revision.id,
                "revision": revision.revision,
                "created_at": revision.created_at.isoformat() if revision.created_at else None,
                "created_by": revision.created_by.username if revision.created_by else None,
                "created_by_id": revision.created_by_id,
                "note": revision.note,
                "data": revision.data,
            }, 200

        return {"error": "Revision not found"}, 404


def initialize(app: Flask):
    analyze_bp = Blueprint("analyze", __name__, url_prefix=f"{Config.APPLICATION_ROOT}api/analyze")

    analyze_bp.add_url_rule("/report-types", view_func=ReportTypes.as_view("report_types"))
    analyze_bp.add_url_rule("/report-items", view_func=ReportItem.as_view("report_items"))
    analyze_bp.add_url_rule(
        "/report-items/publish-product",
        view_func=ReportItemPublishProduct.as_view("report_items_publish_product"),
    )
    analyze_bp.add_url_rule("/report-items/botactions", view_func=ReportBotActions.as_view("report_bot_actions"))
    analyze_bp.add_url_rule("/reports", view_func=ReportItem.as_view("reports"))
    analyze_bp.add_url_rule(
        "/report-items/<string:report_item_id>",
        view_func=ReportItem.as_view("report_item"),
        methods=["GET", "PUT", "DELETE"],
    )
    analyze_bp.add_url_rule("/report-items/<string:report_item_id>/cti", view_func=ReportItemCTI.as_view("report_item_cti"))
    analyze_bp.add_url_rule(
        "/report/<string:report_item_id>",
        view_func=ReportItem.as_view("report"),
        methods=["GET", "PUT", "DELETE"],
    )
    analyze_bp.add_url_rule("/report-items/<string:report_item_id>/clone", view_func=CloneReportItem.as_view("clone_report_item"))
    analyze_bp.add_url_rule("/report-items/<string:report_item_id>/stories", view_func=ReportStories.as_view("report_stories"))
    analyze_bp.add_url_rule("/report-items/<string:report_item_id>/locks", view_func=ReportItemLocks.as_view("report_item_locks"))
    analyze_bp.add_url_rule("/report-items/<string:report_item_id>/lock", view_func=ReportItemLock.as_view("report_item_lock"))
    analyze_bp.add_url_rule("/report-items/<string:report_item_id>/revisions", view_func=ReportItemRevisions.as_view("report_item_revisions"))
    analyze_bp.add_url_rule(
        "/report-items/<string:report_item_id>/revisions/<int:revision_number>",
        view_func=ReportItemRevisionData.as_view("report_item_revision_data"),
    )

    app.register_blueprint(analyze_bp)
