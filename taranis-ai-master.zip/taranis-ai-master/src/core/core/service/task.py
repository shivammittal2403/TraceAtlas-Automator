from datetime import UTC, datetime, timedelta
from typing import Any

from models.task import Task as TaskResponseModel
from models.task import TaskHistoryResponse, TaskResult, TaskSubmission, UserTaskFilter, UserTaskList

from core.config import Config
from core.log import logger
from core.managers.realtime_publisher import realtime_publisher
from core.model.osint_source import CollectorHTTPState
from core.model.product import Product
from core.model.task import Task as TaskModel
from core.model.token_blacklist import TokenBlacklist
from core.model.word_list import WordList
from core.service import cache_invalidation as cache_invalidation_module
from core.service.misp_auto_update import refresh_misp_auto_update_jobs
from core.service.misp_story_sync import handle_misp_connector_result
from core.service.news_item_tag import NewsItemTagService


TAGGING_BOTS = {"WORDLIST_BOT", "IOC_BOT", "NLP_BOT", "TAGGING_BOT"}


class TaskService:
    @staticmethod
    def get_task(task_id: str) -> tuple[dict[str, Any], int]:
        if result := TaskModel.get(task_id):
            validated = TaskResponseModel.model_validate(result.to_dict())
            return validated.model_dump(mode="json", exclude_none=False), 200
        return {"status": "PENDING"}, 404

    @staticmethod
    def get_tasks(filter_args: dict[str, Any] | None = None, user: Any = None) -> tuple[dict[str, Any], int]:
        result, status = TaskModel.get_all_for_api(filter_args=filter_args, with_count=True, user=user)
        if status != 200:
            return result, status

        result.update(TaskModel.get_task_statistics())
        validated = TaskHistoryResponse.model_validate(result)
        return validated.model_dump(mode="json", exclude_none=False), status

    @staticmethod
    def get_user_tasks(user_id: str, filters: UserTaskFilter) -> tuple[dict[str, Any], int]:
        result, status = TaskModel.get_user_tasks_for_api(user_id, filters)
        if status != 200:
            return result, status
        validated = UserTaskList.model_validate(result)
        return validated.model_dump(mode="json", exclude_none=False), status

    @staticmethod
    def delete_task(task_id: str) -> tuple[dict[str, Any], int]:
        task = TaskModel.get(task_id)
        task_kind = TaskService._resolve_task_kind(task.job_id, task.task) if task else None
        worker_id = task.worker_id if task else None
        result, status = TaskModel.delete(task_id)
        if status == 200:
            cache_invalidation_module.cache_invalidation_service.invalidate_model("admin_menu_badges")
            if task_kind == "collector_task":
                cache_invalidation_module.cache_invalidation_service.invalidate_model("osint_source", worker_id)
            elif task_kind == "bot_task":
                cache_invalidation_module.cache_invalidation_service.invalidate_model("bot", worker_id)
        return result, status

    @staticmethod
    def cleanup_history() -> tuple[dict[str, Any], int]:
        retention_days = Config.TASK_HISTORY_RETENTION_DAYS
        cutoff = datetime.now(UTC).replace(tzinfo=None) - timedelta(days=retention_days)
        deleted = TaskModel.delete_older_than_last_run(cutoff)
        return {
            "message": "Task history cleanup completed",
            "deleted": deleted,
            "cutoff": cutoff.isoformat(),
            "retention_days": retention_days,
        }, 200

    @classmethod
    def save_task_result(cls, submission: TaskSubmission) -> tuple[dict[str, Any], int]:
        task_kind = cls._resolve_task_kind(submission.id, submission.task)
        result_payload = submission.result.model_dump(mode="json", exclude_none=False)
        payload: dict[str, Any] = {
            "id": submission.id,
            "result": result_payload,
            "status": submission.status,
        }
        if submission.task is not None:
            payload["task"] = submission.task
        if submission.user_id is not None:
            payload["user_id"] = submission.user_id
        if submission.worker_id is not None:
            payload["worker_id"] = submission.worker_id
        if submission.worker_type is not None:
            payload["worker_type"] = submission.worker_type

        result, _ = TaskModel.add_or_update(payload)
        if task_kind == "collector_task" and submission.worker_id:
            CollectorHTTPState.update_from_task_result(submission.worker_id, result_payload.get("data"))
        if (
            submission.user_id
            and submission.task == "collector_preview"
            and submission.id.startswith("source_preview_")
            and submission.status in {"PREVIEW", "FAILURE"}
        ):
            realtime_publisher.osint_source_preview_finished(
                submission.id.removeprefix("source_preview_"),
                submission.user_id,
                submission.status,
            )
        if submission.status in {"SUCCESS", "WARNING"} and submission.result is not None:
            cls._handle_success_result(submission)
        elif task_kind in {"collector_task", "bot_task"}:
            cache_invalidation_module.cache_invalidation_service.invalidate_model("admin_menu_badges")
            if task_kind == "collector_task":
                cache_invalidation_module.cache_invalidation_service.invalidate_model("osint_source", submission.worker_id)
            elif task_kind == "bot_task":
                cache_invalidation_module.cache_invalidation_service.invalidate_model("bot", submission.worker_id)
        validated = TaskResponseModel.model_validate(result)
        return validated.model_dump(mode="json", exclude_none=False), 200

    @staticmethod
    def _resolve_task_kind(task_id: str, task_name: str | None) -> str | None:
        task_name = task_name or ""

        if task_name == "gather_word_list" or task_id.startswith("gather_word_list"):
            return "gather_word_list"
        if task_name == "cleanup_token_blacklist" or task_id.startswith("cleanup_token_blacklist"):
            return "cleanup_token_blacklist"
        if task_name == "cleanup_task_history" or task_id.startswith("cleanup_task_history"):
            return "cleanup_task_history"
        if task_name == "presenter_task" or task_id.startswith("presenter_task"):
            return "presenter_task"
        if task_name == "collector_task" or task_name.startswith("collect_") or task_id.startswith("collect_"):
            return "collector_task"
        if task_name == "bot_task" or task_name.startswith("bot_") or task_id.startswith("bot"):
            return "bot_task"
        return "connector_task" if task_name == "connector_task" else None

    @classmethod
    def _handle_success_result(cls, submission: TaskSubmission) -> None:
        cache_invalidation_module.invalidate_frontend_cache_on_success(200, full=True)
        task_kind = cls._resolve_task_kind(submission.id, submission.task)
        if not task_kind:
            return

        if task_kind == "cleanup_token_blacklist":
            check_time = datetime.now(UTC).replace(tzinfo=None) - Config.JWT_ACCESS_TOKEN_EXPIRES
            TokenBlacklist.delete_older(check_time)
            return

        if task_kind == "collector_task":
            logger.info(
                f"Collector task {submission.id} completed with result: {submission.result.model_dump(mode='json', exclude_none=False)}"
            )
            cache_invalidation_module.cache_invalidation_service.invalidate_model("osint_source", submission.worker_id)
            return

        result_data = cls._get_result_dict_data(submission.result)
        if task_kind == "connector_task":
            if result_data is None:
                logger.error("Invalid connector task result payload")
                return
            handle_misp_connector_result(result_data)
            realtime_publisher.assess_changed()
            cache_invalidation_module.invalidate_frontend_cache_on_success(
                200,
                scopes=(
                    cache_invalidation_module.SCOPE_ASSESS_VIEWS,
                    cache_invalidation_module.SCOPE_STORY_REPORT_VIEWS,
                    cache_invalidation_module.SCOPE_SCHEDULE,
                ),
            )
            return

        if task_kind == "gather_word_list":
            if result_data is None:
                logger.error("Invalid gather_word_list result payload")
                return
            WordList.update_word_list(**result_data)
            return

        if task_kind == "presenter_task":
            cls._handle_presenter_result(result_data, submission.user_id)
            return

        if task_kind == "bot_task":
            cls._handle_bot_result(submission, result_data)

    @staticmethod
    def _handle_presenter_result(result_data: dict[str, Any] | None, user_id: str | None) -> None:
        if result_data is None:
            logger.error("Invalid presenter task result payload")
            return

        product_id = result_data.get("product_id")
        rendered_product = result_data.get("render_result")
        render_revision = result_data.get("render_revision")

        if not isinstance(product_id, str) or not isinstance(rendered_product, str) or not isinstance(render_revision, str):
            logger.error(f"Product {product_id} not found or no render result")
            return

        _, status = Product.update_render_for_id(product_id, rendered_product, render_revision)
        if status == 200 and user_id:
            realtime_publisher.product_rendered(product_id, user_id, "completed")

    @staticmethod
    def _handle_bot_result(submission: TaskSubmission, result_data: dict[str, Any] | None) -> None:
        worker_type = submission.worker_type or ""
        worker_id = submission.worker_id or "UNKNOWN_ID"
        if result_data is None:
            logger.error("Invalid bot task result payload")
            return

        bot_result = result_data.get("result")
        if not isinstance(bot_result, dict):
            logger.error("Invalid bot task result data payload")
            return

        affected_story_ids = set()
        if worker_type in TAGGING_BOTS:
            affected_story_ids = NewsItemTagService.set_found_bot_tags(bot_result, actor="bot")

        if worker_type == "INTEL_OWL_BOT":
            TaskService._handle_intelowl_bot_result(bot_result, worker_id)
        else:
            affected_story_ids.update(
                NewsItemTagService.set_worker_execution_attribute(worker_type=worker_type, worker_id=worker_id, found_tags=bot_result)
            )

        refresh_misp_auto_update_jobs(affected_story_ids)

        if result_data.get("trigger_dependents", True):
            from core.managers import queue_manager

            filter_data = result_data.get("filter")
            queue_manager.queue_manager.schedule_bot_dependents(
                worker_id,
                filter_data if isinstance(filter_data, dict) else None,
                user_id=submission.user_id,
            )

    @staticmethod
    def _handle_intelowl_bot_result(bot_result: dict[str, Any], worker_id: str) -> None:
        from core.model.ioc import IOC

        enrichments = bot_result.get("enrichments") or []
        if not isinstance(enrichments, list):
            logger.error("Invalid IntelOwl enrichment payload from worker %s", worker_id)
            return
        IOC.upsert_many([item for item in enrichments if isinstance(item, dict)])

    @staticmethod
    def _get_result_dict_data(result: TaskResult) -> dict[str, Any] | None:
        return result.data if isinstance(result.data, dict) else None
