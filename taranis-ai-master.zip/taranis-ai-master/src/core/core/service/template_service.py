import base64
import binascii
from typing import TypedDict

from jinja2 import DebugUndefined, TemplateSyntaxError, UndefinedError
from jinja2.sandbox import ImmutableSandboxedEnvironment
from pydantic import BaseModel

from core.log import logger
from core.managers.data_manager import (
    InvalidPresenterTemplatePathError,
    get_template_content,
    list_templates,
    save_template_content,
)


type TemplateContent = str | bytes | bytearray | memoryview | None


class ValidationStatus(TypedDict):
    is_valid: bool
    error_message: str
    error_type: str


class TemplateResponse(BaseModel):
    name: str
    content: str | None
    validation_status: ValidationStatus


def create_or_update_template(template_name, base64_content):
    """
    Shared logic for creating or updating a template.
    Decodes base64 content, validates, and saves the template.
    Returns a tuple: (response_dict, status_code)
    """
    if not template_name or not base64_content:
        return {"error": "Missing template name or content"}, 400

    # Decode content
    try:
        template_content = base64.b64decode(base64_content, validate=True).decode("utf-8")
    except (binascii.Error, UnicodeDecodeError) as e:
        logger.error("Failed to decode template content: %s", e)
        return {"error": "Failed to decode content"}, 400

    # Validate
    validation_status = validate_template_content(template_content)

    # Store in file
    try:
        save_template_content(template_name, template_content)
    except InvalidPresenterTemplatePathError:
        return {"error": "Invalid presenter template path"}, 400
    except OSError:
        logger.exception("Failed to save template %s", template_name)
        return {"error": "Failed to save template"}, 500

    response = {
        "message": "Template updated or created",
        "path": template_name,
        "validation_status": validation_status,
    }
    if not validation_status["is_valid"]:
        response["warning"] = f"Template saved but has validation errors: {validation_status['error_message']}"
    return response, 200


def validate_template_content(template_content: str) -> ValidationStatus:
    """
    Validate Jinja2 template content with comprehensive validation.

    Performs both syntax parsing and render testing to catch template errors.
    Uses DebugUndefined to provide better error messages for undefined variables.

    Args:
        template_content (str): The template string to validate

    Returns:
        dict: {
            "is_valid": bool,
            "error_message": str,  # Empty string if valid
            "error_type": str      # Empty string if valid
        }
    """
    if not template_content or not template_content.strip():
        return {"is_valid": False, "error_message": "Template file is empty.", "error_type": "EmptyFile"}

    try:
        # Create Jinja2 environment with DebugUndefined for better error messages
        env = ImmutableSandboxedEnvironment(autoescape=False, undefined=DebugUndefined)

        # Compile and attempt to render with empty context
        template = env.from_string(template_content)
        try:
            template.render({})
        except UndefinedError:
            # Ignore undefined variable errors - these are expected with empty context
            pass
        except Exception:
            # Catch other rendering errors (e.g., filter errors, logic errors)
            logger.exception("Template render validation failed")
            return {"is_valid": False, "error_message": "Template render validation failed.", "error_type": "TemplateRenderError"}

        # Template is valid
        return {"is_valid": True, "error_message": "", "error_type": ""}

    except TemplateSyntaxError:
        return {
            "is_valid": False,
            "error_message": "Expected an expression in template syntax.",
            "error_type": "TemplateSyntaxError",
        }
    except Exception:
        logger.exception("Template validation failed")
        return {"is_valid": False, "error_message": "Template validation failed.", "error_type": "TemplateValidationError"}


def _build_validation_and_content(content: TemplateContent) -> tuple[str | None, ValidationStatus]:
    """Normalize template content and compute the API-ready payload fields."""
    if content is None:
        return None, {"is_valid": False, "error_message": "Template file not found.", "error_type": "NotFound"}

    if isinstance(content, str):
        text = content
    elif isinstance(content, (bytes, bytearray, memoryview)):
        try:
            text = bytes(content).decode("utf-8")
        except UnicodeDecodeError:
            return None, {"is_valid": False, "error_message": "Template file is not valid UTF-8.", "error_type": "UnicodeDecodeError"}
    else:
        return None, {"is_valid": False, "error_message": "Template file not found.", "error_type": "NotFound"}

    if not text.strip():
        return "", {"is_valid": False, "error_message": "Template file is empty.", "error_type": "EmptyFile"}

    return base64.b64encode(text.encode("utf-8")).decode("utf-8"), validate_template_content(text)


def _build_template_response(template_name: str, content: TemplateContent) -> TemplateResponse:
    encoded_content, validation_status = _build_validation_and_content(content)
    return TemplateResponse(name=template_name, content=encoded_content, validation_status=validation_status)


def build_template_response(template_path: str) -> TemplateResponse:
    """Return a template payload with name, base64 content, and validation status."""
    return _build_template_response(template_path, get_template_content(template_path))


def build_templates_list(order: str | None = None) -> list[TemplateResponse]:
    """Return API payloads for every stored presenter template."""
    items = [_build_template_response(template_name, get_template_content(template_name)) for template_name in list_templates()]
    if order in {"name_asc", "name_desc"}:
        items.sort(key=lambda item: item.name.casefold(), reverse=order == "name_desc")
    return items
