import uuid
from contextlib import suppress

import pytest
from sqlalchemy.exc import SQLAlchemyError


@pytest.fixture(scope="session")
def cleanup_sources(app):
    with app.app_context():
        from core.model.osint_source import OSINTSource

        source_data = {
            "id": str(uuid.uuid7()),
            "description": "This is a test source",
            "name": "Test Source",
            "rank": 0,
            "parameters": {"FEED_URL": "https://url/feed.xml"},
            "type": "rss_collector",
        }

        # Ensure we start without any dangling sources from previous runs that reuse this name
        existing_sources = OSINTSource.get_by_filter({"search": source_data["name"]}) or []
        for existing in existing_sources:
            if existing.id != source_data["id"]:
                OSINTSource.delete(existing.id, force=True)

        yield source_data

        with suppress(SQLAlchemyError):
            if OSINTSource.get(source_data["id"]):
                OSINTSource.delete(source_data["id"])


@pytest.fixture(scope="session")
def cleanup_connector(app):
    with app.app_context():
        from core.model.connector import Connector

        connector_data = {
            "id": str(uuid.uuid4()),
            "name": f"Test Connector {uuid.uuid4().hex[:8]}",
            "description": "Test connector",
            "type": "misp_connector",
            "parameters": {
                "URL": "https://misp.example.test",
                "API_KEY": "super-secret-api-key",
                "ORGANISATION_ID": "1",
            },
        }

        if not Connector.get(connector_data["id"]):
            Connector.add(connector_data)

        yield connector_data

        with suppress(SQLAlchemyError):
            if Connector.get(connector_data["id"]):
                Connector.delete(connector_data["id"])


@pytest.fixture(scope="session")
def cleanup_source_groups(app):
    with app.app_context():
        from core.model.osint_source import OSINTSourceGroup

        source_group_data = {
            "id": str(uuid.uuid7()),
            "name": "Test Group",
            "description": "This is a test group",
        }

        yield source_group_data

        with suppress(SQLAlchemyError):
            if OSINTSourceGroup.get(source_group_data["id"]):
                OSINTSourceGroup.delete(source_group_data["id"])


@pytest.fixture(scope="session")
def cleanup_word_lists(app):
    with app.app_context():
        from core.model.word_list import WordList

        word_list_data = {
            "id": str(uuid.uuid7()),
            "name": "Test word list name",
            "description": "Desc of word lists",
            "usage": ["TAGGING_BOT"],
            "link": "this.is.a.test.url.rocks",
            "entries": [],
        }

        yield word_list_data

        with suppress(SQLAlchemyError):
            if WordList.get(word_list_data["id"]):
                WordList.delete(word_list_data["id"])


@pytest.fixture(scope="session")
def cleanup_user(app):
    with app.app_context():
        from core.model.organization import Organization
        from core.model.role import Role
        from core.model.user import User

        organization = Organization.find_by_name("Default Organization")
        role = Role.filter_by_name("User")

        user_data = {
            "id": str(uuid.uuid7()),
            "username": "testuser",
            "name": "Test User",
            "organization": organization.id if organization else None,
            "roles": [role.id] if role else [],
            "password": "testpassword",
        }

        yield user_data

        with suppress(SQLAlchemyError):
            if User.get(user_data["id"]):
                User.delete(user_data["id"])


@pytest.fixture(scope="session")
def cleanup_role(app):
    with app.app_context():
        from core.model.role import Role

        role_data = {
            "id": str(uuid.uuid7()),
            "name": "testrole",
            "description": "Test Role",
            "permissions": ["ANALYZE_ACCESS", "ANALYZE_CREATE", "ANALYZE_DELETE"],
        }

        yield role_data

        with suppress(SQLAlchemyError):
            if Role.get(role_data["id"]):
                Role.delete(role_data["id"])


@pytest.fixture(scope="session")
def cleanup_organization(app):
    with app.app_context():
        from core.model.organization import Organization

        organization_data = {
            "id": str(uuid.uuid7()),
            "name": "testOrg",
            "description": "Test Organization",
            "address": {"street": "testStreet", "city": "testCity"},
        }

        yield organization_data

        with suppress(SQLAlchemyError):
            if Organization.get(organization_data["id"]):
                Organization.delete(organization_data["id"])


@pytest.fixture(scope="session")
def cleanup_bot(app):
    with app.app_context():
        from core.model.bot import Bot

        bot_data = {
            "id": str(uuid.uuid7()),
            "name": "testBot",
            "description": "test Bot",
            "type": "tagging_bot",
            "parameters": {"REGULAR_EXPRESSION": r"\btest\b", "RUN_AFTER_COLLECTOR": "true"},
        }

        yield bot_data

        with suppress(SQLAlchemyError):
            if Bot.get(bot_data["id"]):
                Bot.delete(bot_data["id"])


@pytest.fixture(scope="session")
def cleanup_report_item_type(app):
    with app.app_context():
        from core.managers.db_manager import db
        from core.model.attribute import Attribute
        from core.model.report_item_type import ReportItemType

        attribute = Attribute.get_first(db.select(Attribute))
        if attribute is None:
            raise ValueError("No seeded attribute found")

        report_type_data = {
            "id": str(uuid.uuid7()),
            "title": "Test Report Type",
            "description": "This is a test report type",
            "attribute_groups": [
                {
                    "index": 0,
                    "title": "Test Attribute Group",
                    "description": "This is a test attribute group",
                    "attribute_group_items": [
                        {
                            "index": 0,
                            "attribute_id": attribute.id,
                            "title": "Test Attribute Group Item",
                            "description": "This is a test attribute group item",
                            "required": False,
                        }
                    ],
                }
            ],
        }

        yield report_type_data

        with suppress(SQLAlchemyError):
            if ReportItemType.get(report_type_data["id"]):
                ReportItemType.delete(report_type_data["id"])


@pytest.fixture(scope="session")
def cleanup_product_types(app):
    with app.app_context():
        from core.model.product_type import ProductType

        product_type_data = {
            "id": str(uuid.uuid7()),
            "type": "pdf_presenter",
            "parameters": {"TEMPLATE_PATH": "pdf_template.html"},
            "title": "Test Product type",
            "description": "Product type desc",
        }

        yield product_type_data

        with suppress(SQLAlchemyError):
            if ProductType.get(product_type_data["id"]):
                ProductType.delete(product_type_data["id"])


@pytest.fixture(scope="session")
def cleanup_acls(app):
    with app.app_context():
        from core.model.role_based_access import RoleBasedAccess

        rbac_data = {
            "id": str(uuid.uuid7()),
            "name": "test_acl_unique",
            "description": "Test ACL",
            "item_type": "word_list",
            "item_id": "acl_id",
            "roles": [],
        }

        yield rbac_data

        with suppress(SQLAlchemyError):
            if RoleBasedAccess.get(rbac_data["id"]):
                RoleBasedAccess.delete(rbac_data["id"])


@pytest.fixture(scope="session")
def cleanup_publisher_preset(app):
    with app.app_context():
        from core.model.publisher_preset import PublisherPreset

        publisher_presets = {
            "id": str(uuid.uuid7()),
            "name": "test_publisher_preset",
            "description": "Test ACL",
            "type": "ftp_publisher",
            "parameters": {"FTP_URL": "ftp_url_entry"},
        }

        yield publisher_presets

        with suppress(SQLAlchemyError):
            if PublisherPreset.get(publisher_presets["id"]):
                PublisherPreset.delete(publisher_presets["id"])


@pytest.fixture(scope="session")
def cleanup_attribute(app):
    with app.app_context():
        from core.model.attribute import Attribute

        attribute_data = {
            "id": str(uuid.uuid7()),
            "name": "Attribute name",
            "description": "Simple attribute desc",
            "type": "STRING",
            "default_value": "2234",
        }

        yield attribute_data

        with suppress(SQLAlchemyError):
            if Attribute.get(attribute_data["id"]):
                Attribute.delete(attribute_data["id"])
