import uuid
from unittest.mock import Mock

from tests.application.support.api_test_base import BaseTest


class TestAssessApi(BaseTest):
    base_uri = "/api/assess"

    def test_order_saves_without_changing_content_and_rejects_stale_or_invalid_requests(self, client, auth_header, session):
        from core.managers.db_manager import db
        from tests.application.support.builders import build_news_item_payload, create_story

        story = create_story(news_items=[build_news_item_payload() for _ in range(3)])
        original_ids = [item.id for item in story.ordered_news_items]
        desired_ids = list(reversed(original_ids))
        before = (story.title, story.updated, story.revision, story.last_change)
        endpoint = f"/api/assess/stories/{story.id}/news-item-order"
        payload = {"news_item_ids": desired_ids, "expected_news_item_ids": original_ids}

        response = client.put(endpoint, headers=auth_header, json=payload)
        assert response.status_code == 200
        db.session.expire_all()
        assert [item.id for item in story.ordered_news_items] == desired_ids
        assert (story.title, story.updated, story.revision, story.last_change) == before
        detail = client.get(f"/api/assess/stories/{story.id}", headers=auth_header).get_json()
        assert [item["id"] for item in detail["news_items"]] == desired_ids
        assert "news_item_order" not in story.to_worker_dict()

        assert client.put(endpoint, headers=auth_header, json=payload).status_code == 409
        for invalid in (desired_ids[:-1], [desired_ids[0]] * 3, [*desired_ids[:-1], "foreign-item"]):
            response = client.put(endpoint, headers=auth_header, json={"news_item_ids": invalid, "expected_news_item_ids": desired_ids})
            assert response.status_code == 400
        assert [item.id for item in story.ordered_news_items] == desired_ids

    def test_get_OSINTSourceGroupsAssess(self, client, fake_source, auth_header):
        """
        This test queries the OSINTSourceGroupsAssess authenticated.
        It expects a valid data and a valid status-code
        """
        response = self.assert_get_ok(client, "osint-source-group-list", auth_header)
        assert response.get_json()["items"][0]["key"] == "default"

    def test_get_OSINTSourcesList(self, client, fake_source, auth_header):
        """
        This test queries the OSINTSourcesList authenticated.
        It expects 1 OSINTSource ("manual") returned
        """
        response = self.assert_get_ok(client, "osint-sources-list", auth_header)
        items = response.get_json()["items"]
        assert len(items) >= 1
        item_keys = [item["key"] for item in items]
        assert "manual" in item_keys

    def test_worker_story_creation_and_persistence(self, client, misp_story_from_news_items_id, auth_header):
        story_id, input_data = misp_story_from_news_items_id

        response = client.get(f"/api/assess/story/{story_id}", headers=auth_header)
        assert response.status_code == 200
        story = response.get_json()

        expected_attributes = sorted(input_data["attributes"] + [{"key": "TLP", "value": "clear"}], key=lambda d: d["key"])
        actual_attributes = sorted(story["attributes"], key=lambda d: d["key"])

        assert story["title"] == input_data["title"]
        assert actual_attributes == expected_attributes
        assert len(story["news_items"]) == len(input_data["news_items"])

        from core.model.story import Story

        story = Story.get(story_id)
        original_ids = [item.id for item in story.ordered_news_items]
        desired_ids = list(reversed(original_ids))
        self.assert_put_ok(
            client,
            f"/stories/{story_id}/news-item-order",
            {"news_item_ids": desired_ids, "expected_news_item_ids": original_ids},
            auth_header,
        )
        payload = story.to_worker_dict()
        payload["news_items"].reverse()
        payload["news_item_order"] = original_ids
        payload["summary"] = "Updated upstream"
        result, status = Story.add_or_update(payload)
        assert status == 200, result
        updated = self.assert_get_ok(client, f"/story/{story_id}", auth_header).get_json()
        assert [item["id"] for item in updated["news_items"]] == desired_ids
        assert updated["summary"] == "Updated upstream"

    def test_get_connectors(self, client, auth_header, assess_connector):
        response = self.assert_get_ok(client, "connectors", auth_header)
        items = {item["id"]: item for item in response.get_json()["items"]}
        connector = items[assess_connector["id"]]

        assert response.get_json()["total_count"] >= 1
        assert connector["id"] == assess_connector["id"]
        assert connector["name"] == assess_connector["name"]
        assert connector["description"] == assess_connector["description"]
        assert connector["type"] == assess_connector["type"]
        assert "parameters" not in connector

    def test_get_connectors_clamps_oversized_limit(self, client, auth_header, assess_connector):
        response = client.get("/api/assess/connectors?limit=9223372036854775808", headers=auth_header)
        self.assert_json_ok(response)

        items = {item["id"]: item for item in response.get_json()["items"]}
        assert response.get_json()["total_count"] >= 1
        assert assess_connector["id"] in items

    def test_get_connectors_clamps_negative_paging_values(self, client, auth_header, assess_connector):
        response = client.get("/api/assess/connectors?page=-461168601842738790&offset=-461168601842738790", headers=auth_header)
        self.assert_json_ok(response)

        items = {item["id"]: item for item in response.get_json()["items"]}
        assert response.get_json()["total_count"] >= 1
        assert assess_connector["id"] in items

    def test_dashboard_cluster_size_desc_breaks_ties_by_name(self, client, auth_header, session):
        payloads = [
            {"id": str(uuid.uuid7()), "title": "Cluster 1", "content": "Cluster 1", "link": "https://example.invalid/cluster-1"},
            {"id": str(uuid.uuid7()), "title": "Cluster 2", "content": "Cluster 2", "link": "https://example.invalid/cluster-2"},
            {"id": str(uuid.uuid7()), "title": "Cluster 3", "content": "Cluster 3", "link": "https://example.invalid/cluster-3"},
            {"id": str(uuid.uuid7()), "title": "Cluster 4", "content": "Cluster 4", "link": "https://example.invalid/cluster-4"},
        ]

        news_item_ids = []
        for payload in payloads:
            response = client.post("/api/assess/news-items", json=payload, headers=auth_header)
            assert response.status_code == 200
            news_item_ids.append(response.get_json()["news_item_ids"][0])

        assert (
            client.put(
                f"/api/assess/news-items/{news_item_ids[0]}/tags",
                json=[{"name": "Zulu", "tag_type": "Location"}],
                headers=auth_header,
            ).status_code
            == 200
        )
        assert (
            client.put(
                f"/api/assess/news-items/{news_item_ids[1]}/tags",
                json=[{"name": "Alpha", "tag_type": "Location"}],
                headers=auth_header,
            ).status_code
            == 200
        )
        assert (
            client.put(
                f"/api/assess/news-items/{news_item_ids[2]}/tags",
                json=[{"name": "Bravo", "tag_type": "Location"}],
                headers=auth_header,
            ).status_code
            == 200
        )
        assert (
            client.put(
                f"/api/assess/news-items/{news_item_ids[3]}/tags",
                json=[{"name": "Bravo", "tag_type": "Location"}],
                headers=auth_header,
            ).status_code
            == 200
        )

        response = client.get("/api/dashboard/cluster/Location?limit=3&order=size_desc", headers=auth_header)
        assert response.status_code == 200

        items = response.get_json()["items"]
        assert items == [
            {"name": "Bravo", "size": 2},
            {"name": "Alpha", "size": 1},
            {"name": "Zulu", "size": 1},
        ]


class TestAssessNewsItems(BaseTest):
    base_uri = "/api/assess"

    def test_post_AddNewsItem(self, client, cleanup_news_item, auth_header):
        from core.model.news_item import NewsItem

        response = self.assert_get_ok(client, "news-items", auth_header)
        assert len(response.get_json()["items"]) == 0, f"No news items should exist, found {response.get_json()['items']}"

        response = self.assert_post_ok(client, "news-items", cleanup_news_item, auth_header)
        response_json = response.get_json()
        assert uuid.UUID(response_json["story_id"], version=4)

        news_item_id = response_json["news_item_ids"][0]
        item_response = self.assert_get_ok(client, f"news-items/{news_item_id}", auth_header)
        news_item = item_response.get_json()

        assert news_item["id"] == cleanup_news_item["id"]
        assert news_item["title"] == "Test News Item 13"
        assert news_item["content"] == "CVE-2020-1234 - Test Story 1"
        assert news_item["link"] == "https://url/13%20path?q=a%20b"
        assert news_item["published"] == "2023-08-01T15:01:04.801998+00:00"
        assert news_item["collected"] == "2023-08-01T15:01:04.802015+00:00"
        assert news_item["hash"] == NewsItem.get_hash(title="Test News Item 13", link="https://url/13%20path?q=a%20b")
        assert news_item["updated"] != cleanup_news_item["updated"]

    def test_add_single_news_item_uses_source_rank_for_story_relevance(self, app, cleanup_ranked_news_item):
        from core.model.story import Story

        with app.app_context():
            response, status = Story.add_single_news_item(dict(cleanup_ranked_news_item))
            assert status == 200

            story = Story.get(response["story_id"])
            assert story is not None
            assert story.relevance == 4

    def test_post_AddManualNewsItem_keeps_story_relevance_zero(self, client, cleanup_manual_news_item, auth_header):
        response = self.assert_post_ok(client, "news-items", cleanup_manual_news_item, auth_header)
        story_id = response.get_json()["story_id"]

        story_response = self.assert_get_ok(client, f"story/{story_id}", auth_header)
        assert story_response.get_json()["relevance"] == 0

    def test_post_news_item_fetch_uses_simple_web_collector_payload(self, client, auth_header, admin_user, monkeypatch):
        captured = {}

        def fake_fetch_and_create_story(parameters, user_id=None):
            captured["parameters"] = parameters
            captured["user_id"] = user_id
            return {"story_ids": ["story-1"], "news_item_ids": ["news-1"], "message": "1 News items added successfully"}, 200

        monkeypatch.setattr("core.api.assess.StoryService.fetch_and_create_story", fake_fetch_and_create_story)

        payload = {
            "id": "manual",
            "type": "simple_web_collector",
            "parameters": {"WEB_URL": "https://example.com/story", "XPATH": "//article"},
        }

        response = client.post(self.concat_url("news-items/fetch"), json=payload, headers=auth_header)

        assert response.status_code == 200
        assert response.get_json()["story_ids"] == ["story-1"]
        assert captured["parameters"] == payload
        assert captured["user_id"] == admin_user.id

    def test_post_news_item_fetch_rejects_non_object_parameters(self, client, auth_header):
        response = client.post(
            self.concat_url("news-items/fetch"),
            json={"id": "manual", "type": "simple_web_collector", "parameters": "not-an-object"},
            headers=auth_header,
        )

        assert response.status_code == 400
        assert response.get_json()["error"] == "A valid http or https URL is required"

    def test_get_NewsItems(self, client, cleanup_news_item, auth_header):
        response = self.assert_get_ok(client, "news-items", auth_header)
        assert len(response.get_json()["items"]) == 1
        assert response.get_json()["items"][0]["id"] == cleanup_news_item["id"]

    def test_get_NewsItem(self, client, cleanup_news_item, auth_header):
        response = self.assert_get_ok(client, f"news-items/{cleanup_news_item['id']}", auth_header)
        assert response.get_json()["id"] == cleanup_news_item["id"]

    def test_put_NewsItem_tags_updates_news_item_and_story_union(self, client, cleanup_news_item, auth_header):
        item_id = cleanup_news_item["id"]
        item_response = client.get(f"/api/assess/news-items/{item_id}", headers=auth_header)
        if item_response.status_code == 404:
            create_response = self.assert_post_ok(client, "news-items", cleanup_news_item, auth_header)
            story_id = create_response.get_json()["story_id"]
        else:
            story_id = item_response.get_json()["story_id"]

        tag_name = f"endpoint-tag-{uuid.uuid4().hex}"
        response = self.assert_put_ok(
            client,
            f"news-items/{item_id}/tags",
            [{"name": tag_name, "tag_type": "endpoint"}],
            auth_header,
        )
        assert response.get_json()["message"] == "News item tags updated"

        item_response = self.assert_get_ok(client, f"news-items/{item_id}", auth_header)
        assert item_response.get_json()["tags"] == [{"name": tag_name, "tag_type": "endpoint"}]

        story_response = self.assert_get_ok(client, f"story/{story_id}", auth_header)
        story_tags = {tag["name"]: tag["tag_type"] for tag in story_response.get_json()["tags"]}
        assert story_tags[tag_name] == "endpoint"

        response = client.put(f"{self.base_uri}/news-items/{item_id}/tags", json="not-valid", headers=auth_header)
        assert response.status_code == 400

        response = client.put(
            f"{self.base_uri}/news-items/{item_id}/tags",
            json=[{"name": "bad-tag", "tag_type": 123}],
            headers=auth_header,
        )
        assert response.status_code == 400

        item_response = self.assert_get_ok(client, f"news-items/{item_id}", auth_header)
        assert item_response.get_json()["tags"] == [{"name": tag_name, "tag_type": "endpoint"}]

        clear_response = self.assert_put_ok(client, f"news-items/{item_id}/tags", [], auth_header)
        assert clear_response.get_json()["message"] == "News item tags updated"

        item_response = self.assert_get_ok(client, f"news-items/{item_id}", auth_header)
        assert item_response.get_json()["tags"] == []

        story_response = self.assert_get_ok(client, f"story/{story_id}", auth_header)
        story_tags = {tag["name"]: tag["tag_type"] for tag in story_response.get_json()["tags"]}
        assert tag_name not in story_tags

    def test_put_NewsItem(self, client, cleanup_news_item, auth_header):
        from core.model.news_item import NewsItem

        update_payload = {
            "title": "<i>Updated News Item</i>",
            "content": "<div>Updated content</div>",
            "link": "https://url/updated path?q=c d",
            "language": "de",
            "published": "2024-01-01T00:00:00+02:00",
        }

        response = self.assert_put_ok(client, f"news-items/{cleanup_news_item['id']}", update_payload, auth_header)
        assert response.get_json()["news_item_id"] == cleanup_news_item["id"]

        item_response = self.assert_get_ok(client, f"news-items/{cleanup_news_item['id']}", auth_header)
        news_item = item_response.get_json()

        assert news_item["title"] == "Updated News Item"
        assert news_item["content"] == "Updated content"
        assert news_item["link"] == "https://url/updated%20path?q=c%20d"
        assert news_item["language"] == "de"
        assert news_item["published"] == "2023-12-31T22:00:00+00:00"
        assert news_item["hash"] == NewsItem.get_hash(title="Updated News Item", link="https://url/updated%20path?q=c%20d")

    def test_delete_NewsItem(self, client, cleanup_news_item, auth_header):
        response = self.assert_delete_ok(client, f"news-items/{cleanup_news_item['id']}", auth_header)
        assert response.get_json()["id"] == cleanup_news_item["id"]
        assert response.get_json()["message"] == "News Item deleted"


class TestAssessStories(BaseTest):
    base_uri = "/api/assess"

    def test_analyst_review_snapshot_contains_only_current_unread_stories(self, app, client, stories, auth_header):
        from datetime import timedelta

        from core.managers.db_manager import db
        from core.model.story import Story

        with app.app_context():
            current_unread = Story.get(stories[0])
            current_read = Story.get(stories[1])
            old_unread = Story.get(stories[2])
            assert current_unread and current_read and old_unread

            original_values = {item.id: (item.created, item.read) for item in (current_unread, current_read, old_unread)}
            now = Story.utcnow()
            current_unread.created = now
            current_unread.read = False
            current_read.created = now
            current_read.read = True
            old_unread.created = now - timedelta(days=2)
            old_unread.read = False
            db.session.commit()

        try:
            response = client.get(self.concat_url("analyst-review/snapshot"), headers=auth_header)

            assert response.status_code == 200
            assert response.get_json() == {"story_ids": [stories[0]]}
        finally:
            with app.app_context():
                for story_id, (created, read) in original_values.items():
                    story = Story.get(story_id)
                    assert story
                    story.created = created
                    story.read = read
                db.session.commit()

    def test_analyst_review_add_is_one_atomic_story_and_report_update(
        self,
        app,
        client,
        stories,
        cleanup_report_item,
        auth_header,
        monkeypatch,
    ):
        from core.managers.db_manager import db
        from core.model.report_item import ReportItem
        from core.model.story import Story

        report_id = str(uuid.uuid7())
        monkeypatch.setattr("core.service.analyst_review.ReportStorySyncService.refresh_auto_update_jobs", lambda _stories: None)

        with app.app_context():
            report, status = ReportItem.add(cleanup_report_item | {"id": report_id})
            assert status == 200
            assert isinstance(report, ReportItem)

            story = Story.get(stories[0])
            assert story
            original_status = (story.read, story.important, story.last_change)
            story.read = False
            story.important = True
            db.session.commit()
            story_revision = story.revision
            report_revision = report.revision

        try:
            response = client.post(
                self.concat_url("analyst-review/actions"),
                json={"action": "add", "story_id": stories[0], "report_id": report_id},
                headers=auth_header,
            )

            assert response.status_code == 200
            with app.app_context():
                story = Story.get(stories[0])
                report = ReportItem.get(report_id)
                assert story and report
                assert story.read is True
                assert story.important is False
                assert story in report.stories
                assert story.revision == story_revision + 1
                assert report.revision == report_revision + 1
        finally:
            with app.app_context():
                if ReportItem.get(report_id):
                    ReportItem.delete(report_id)
                story = Story.get(stories[0])
                assert story
                story.read, story.important, story.last_change = original_status
                db.session.commit()

    def test_analyst_review_add_rolls_back_every_change_when_report_revision_fails(
        self,
        app,
        client,
        stories,
        cleanup_report_item,
        auth_header,
        monkeypatch,
    ):
        from core.managers.db_manager import db
        from core.model.report_item import ReportItem
        from core.model.story import Story

        report_id = str(uuid.uuid7())
        monkeypatch.setattr("core.service.analyst_review.ReportStorySyncService.refresh_auto_update_jobs", lambda _stories: None)

        with app.app_context():
            report, status = ReportItem.add(cleanup_report_item | {"id": report_id})
            assert status == 200
            assert isinstance(report, ReportItem)

            story = Story.get(stories[0])
            assert story
            original_status = (story.read, story.important, story.last_change)
            story.read = False
            story.important = True
            db.session.commit()
            story_revision = story.revision
            report_revision = report.revision

        def fail_report_revision(*_args, **_kwargs):
            raise RuntimeError("revision failure")

        monkeypatch.setattr("core.model.revision.ReportRevision.create_from_report", fail_report_revision)

        try:
            response = client.post(
                self.concat_url("analyst-review/actions"),
                json={"action": "add", "story_id": stories[0], "report_id": report_id},
                headers=auth_header,
            )

            assert response.status_code == 500
            assert response.get_json() == {"error": "Failed to apply analyst review action"}
            with app.app_context():
                story = Story.get(stories[0])
                report = ReportItem.get(report_id)
                assert story and report
                assert story.read is False
                assert story.important is True
                assert story not in report.stories
                assert story.revision == story_revision
                assert report.revision == report_revision
        finally:
            with app.app_context():
                if ReportItem.get(report_id):
                    ReportItem.delete(report_id)
                story = Story.get(stories[0])
                assert story
                story.read, story.important, story.last_change = original_status
                db.session.commit()

    def test_import_story_payload(self, client, auth_header):
        imported_story_id = str(uuid.uuid4())
        imported_news_item_id = str(uuid.uuid4())
        payload = [
            {
                "id": imported_story_id,
                "title": f"Imported Story {imported_story_id[:8]}",
                "news_items": [
                    {
                        "id": imported_news_item_id,
                        "story_id": imported_story_id,
                        "osint_source_id": "manual",
                        "title": "Imported News Item",
                        "content": "Imported story content",
                        "link": f"https://example.com/{imported_news_item_id}",
                    }
                ],
            }
        ]

        response = self.assert_post_ok(client, "import", payload, auth_header)

        imported = response.get_json()["imported_stories"]
        assert len(imported) == 1
        assert imported[0]["id"] == imported_story_id

        cleanup_response = client.delete(f"/api/assess/story/{imported_story_id}", headers=auth_header)
        assert cleanup_response.status_code < 300

    def test_story_creation(self, client, stories, auth_header, fake_source):
        """
        This test queries the stories authenticated.
        It expects all the fields from the stories fixture to be mapped correctly
        """
        response = self.assert_get_ok(client, f"story/{stories[0]}", auth_header)
        first_story = response.get_json()
        assert first_story["id"] == stories[0]
        assert first_story["title"] == "Mobile World Congress 2023"
        assert first_story["attributes"] == [{"key": "TLP", "value": "clear"}]
        assert first_story["last_change"] == f"collector_rss_collector_{fake_source}"

    def test_patch_story_publishes_realtime_invalidation(self, client, stories, auth_header, monkeypatch):
        assess_changed = Mock()
        monkeypatch.setattr("core.api.assess.realtime_publisher.assess_changed", assess_changed)
        story_url = f"/api/assess/stories/{stories[0]}"
        original_read = client.get(story_url, headers=auth_header).get_json()["read"]

        try:
            response = client.patch(story_url, json={"read": not original_read}, headers=auth_header)

            assert response.status_code == 200
            assess_changed.assert_called_once_with()
        finally:
            client.patch(story_url, json={"read": original_read}, headers=auth_header)

    def test_get_stories(self, client, stories, auth_header):
        """
        This test queries the stories authenticated.
        It expects a valid data and a valid status-code
        """
        response = self.assert_get_ok(client, "stories", auth_header)
        assert response.get_json()["counts"]["total_count"] == 3
        assert response.get_json()["items"][0]["id"] in stories

        response = client.get("/api/assess/stories?search=notexistent", headers=auth_header)
        assert response.status_code == 200
        assert len(response.get_json()["items"]) == 0

        response = client.get("/api/assess/stories?notexistent=notexist", headers=auth_header)
        assert response.get_json()["counts"]["total_count"] > 0

        response = client.get("/api/assess/stories?read=true", headers=auth_header)
        assert len(response.get_json()["items"]) == 0

        response = client.get("/api/assess/stories?relevant=true", headers=auth_header)
        assert len(response.get_json()["items"]) == 0

        response = client.get("/api/assess/stories?in_report=true", headers=auth_header)
        assert len(response.get_json()["items"]) == 0

        response = client.get("/api/assess/stories?range=DAY", headers=auth_header)
        assert response.status_code == 200

        response = client.get("/api/assess/stories?sort=DATE_DESC", headers=auth_header)
        assert response.get_json()["counts"]["total_count"] > 0

        response = client.get("/api/assess/stories?offset=1", headers=auth_header)
        assert len(response.get_json()["items"]) == 2

        response = client.get("/api/assess/stories?limit=1", headers=auth_header)
        assert len(response.get_json()["items"]) == 1

    def test_get_stories_include_revision_count(self, client, stories, auth_header):
        response = self.assert_get_ok(client, "stories", auth_header)
        items = {item["id"]: item for item in response.get_json()["items"]}

        assert "revision_count" in items[stories[0]]
        assert items[stories[0]]["revision_count"] > 0

        response = client.get("/api/assess/stories?no_count=true", headers=auth_header)
        assert response.status_code == 200
        items = {item["id"]: item for item in response.get_json()["items"]}

        assert "revision_count" in items[stories[0]]
        assert items[stories[0]]["revision_count"] > 0

    def test_bulk_story_update_returns_404_for_unknown_story(self, client, stories, auth_header):
        response = client.post(
            "/api/assess/stories/bulk_action",
            json={"story_ids": ["missing-story", stories[0]], "payload": {"read": True}},
            headers=auth_header,
        )

        assert response.status_code == 404
        assert response.get_json() == {"error": "Story not found"}

    def test_delete_story(self, client, stories, auth_header):
        response = self.assert_delete_ok(client, f"story/{stories[0]}", auth_header)

        response = client.get("/api/assess/stories", headers=auth_header)
        total_count = response.get_json()["counts"]["total_count"]
        assert total_count == 2

    def test_story_revision_endpoints_enforce_read_access(self, client, auth_header, monkeypatch):
        def fake_get_for_api(_story_id: str, _user=None):
            return {"error": "forbidden"}, 403

        monkeypatch.setattr("core.api.assess.story.Story.get_for_api", fake_get_for_api)

        list_response = client.get("/api/assess/stories/story-1/revisions", headers=auth_header)
        assert list_response.status_code == 403
        assert list_response.get_json() == {"error": "forbidden"}

        detail_response = client.get("/api/assess/stories/story-1/revisions/1", headers=auth_header)
        assert detail_response.status_code == 403
        assert detail_response.get_json() == {"error": "forbidden"}


class TestAssessStoriesGrouping(BaseTest):
    base_uri = "/api/assess"

    def test_group_stories(self, client, stories, auth_header, admin_user, fake_source):
        """
        This test groups the stories authenticated.
        """
        from core.model.story import Story

        admin_actor = Story.last_change_for_user(admin_user)

        # Check initial state
        response = self.assert_get_ok(client, f"/story/{stories[0]}", auth_header)
        response_json = response.get_json()
        assert response_json["id"] == stories[0]
        assert response_json["last_change"] == f"collector_rss_collector_{fake_source}"

        # Check main action
        response = self.assert_put_ok(client, "/stories/group", [stories[0], stories[1]], auth_header)
        assert response.get_json()["message"] == "Clustering Stories successful"
        assert response.get_json()["id"] == stories[0]

        # Check action result
        response = self.assert_get_ok(client, f"/story/{stories[0]}", auth_header)
        response_json = response.get_json()
        assert response_json["id"] == stories[0]
        assert len(response_json["news_items"]) == 2
        assert response_json["last_change"] == admin_actor

        # Check the manual story that is supposed to stay unchanged
        response = self.assert_get_ok(client, f"/story/{stories[2]}", auth_header)
        response_json = response.get_json()
        assert response_json["news_items"][0]["id"] == "04129597-592d-45cb-9a80-3218108b29a1"
        assert response_json["news_items"][0]["osint_source_key"] == "manual"
        assert response_json["last_change"] == "internal"
        assert response_json["news_items"][0]["last_change"] == "internal", "manual news item's last_change should be internal"

        response = self.assert_get_ok(client, "stories", auth_header)
        assert response.get_json()["counts"]["total_count"] == 2

    def test_ungroup_stories(self, client, stories, auth_header, admin_user, fake_source):
        """
        This test ungroups the stories authenticated.
        """
        from core.model.story import Story

        admin_actor = Story.last_change_for_user(admin_user)

        self.assert_put_ok(client, "/stories/ungroup", [stories[0]], auth_header)
        response = self.assert_get_ok(client, "stories", auth_header)
        assert response.get_json()["counts"]["total_count"] == 3

        assert response.get_json()["items"][0]["last_change"] == admin_actor
        assert response.get_json()["items"][0]["news_items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"
        assert response.get_json()["items"][1]["last_change"] == admin_actor
        assert response.get_json()["items"][1]["news_items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"

        # Check last_change for a manual news item
        assert response.get_json()["items"][2]["news_items"][0]["id"] == "04129597-592d-45cb-9a80-3218108b29a1"
        assert response.get_json()["items"][2]["news_items"][0]["osint_source_key"] == "manual"
        assert response.get_json()["items"][2]["last_change"] == "internal"
        assert response.get_json()["items"][2]["news_items"][0]["last_change"] == "internal", (
            "manual news item's last_change should be internal"
        )

    def test_ungroup_story_assigned_to_report_uses_membership_table(self, app, client, cleanup_report_item, fake_source, auth_header):
        from copy import deepcopy

        from core.managers.db_manager import db
        from core.model.report_item import ReportItem
        from core.model.story import Story
        from tests.application.support.builders import build_news_item_payload, build_story_payload

        report_id = str(uuid.uuid7())
        story_id = None
        report_payload = deepcopy(cleanup_report_item)
        report_payload["id"] = report_id
        report_payload["title"] = "Report Ungroup Membership"

        try:
            with app.app_context():
                story_payload = build_story_payload(news_items=[build_news_item_payload(source_id=fake_source)])
                result, status = Story.add(story_payload)
                assert status == 200
                story_id = result["story_id"]
                report_payload["stories"] = [story_id]
                report, status = ReportItem.add(report_payload)
                assert status == 200
                story = Story.get(story_id)
                assert story is not None
                story.remove_attributes([f"report_{report.id}"])
                db.session.commit()

            response = client.put(f"{self.base_uri}/stories/ungroup", json=[story_id], headers=auth_header)
            assert response.status_code == 400
            assert response.get_json()["error"] == "Story is assigned to a report"
        finally:
            with app.app_context():
                if ReportItem.get(report_id):
                    ReportItem.delete(report_id)
                if story_id and (story := Story.get(story_id)):
                    for item in story.news_items[:]:
                        db.session.delete(item)
                    db.session.delete(story)
                    db.session.commit()


class TestAssessUngroupNewsItem(BaseTest):
    base_uri = "/api/assess"

    def test_ungroup_single_news_item(self, client, stories, auth_header):
        """
        This test ungroups (removes) a single news item from a story with a only 1 item.
        The existing story ID should be removed and the news item should get a new story ID.
        """

        response = self.assert_put_ok(client, "/news-items/ungroup", ["0a129597-592d-45cb-9a80-3218108b29a0"], auth_header)
        assert response.get_json()["message"] == "Successfully ungrouped 1 items from their story"
        assert response.get_json()["new_stories_ids"] not in stories

        response = client.get(f"/api/assess/story/{stories[1]}", headers=auth_header)
        assert response.status_code == 404


class TestAssessUngroupBigStory(BaseTest):
    base_uri = "/api/assess"

    def test_creation_of_full_story_with_multiple_items(self, client, full_story_with_multiple_items_id, auth_header, fake_source):
        """
        This test creates a full story with multiple news items.
        It expects the story to be created with the correct ID and last_change set to internal.
        """
        full_story_id, _ = full_story_with_multiple_items_id

        response = self.assert_get_ok(client, f"/story/{full_story_id}", auth_header)
        assert response.get_json()["id"] == full_story_id
        assert len(response.get_json()["news_items"]) == 2
        assert response.get_json()["last_change"] == f"collector_rss_collector_{fake_source}"
        assert response.get_json()["news_items"][0]["id"] == "90f0d9ec-70e7-45cf-8919-6ae2c02a4d88"
        assert response.get_json()["news_items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"
        assert response.get_json()["news_items"][1]["id"] == "c2a1c55c-6e7e-41de-8ad1-bda321f2f56b"
        assert response.get_json()["news_items"][1]["last_change"] == f"collector_rss_collector_{fake_source}"
        assert len(response.get_json()["attributes"]) == 4
        assert len(response.get_json()["tags"]) == 3

    def test_story_tags_are_deduped_from_news_item_tags(self, client, full_story_with_multiple_items_id, auth_header):
        full_story_id, _ = full_story_with_multiple_items_id
        response = self.assert_get_ok(client, f"/story/{full_story_id}", auth_header)
        news_items = response.get_json()["news_items"]
        assert len(news_items) == 2

        shared_tag = f"shared-{uuid.uuid4().hex}"
        first_tag = f"first-{uuid.uuid4().hex}"
        second_tag = f"second-{uuid.uuid4().hex}"
        self.assert_put_ok(
            client,
            f"news-items/{news_items[0]['id']}/tags",
            [{"name": shared_tag, "tag_type": "shared"}, {"name": first_tag, "tag_type": "one"}],
            auth_header,
        )
        self.assert_put_ok(
            client,
            f"news-items/{news_items[1]['id']}/tags",
            {shared_tag: "shared", second_tag: "two"},
            auth_header,
        )

        response = self.assert_get_ok(client, f"/story/{full_story_id}", auth_header)
        story_tags = {tag["name"]: tag["tag_type"] for tag in response.get_json()["tags"]}
        assert story_tags == {first_tag: "one", second_tag: "two", shared_tag: "shared"}

    def test_ungroup_story_with_multiple_news_items(self, client, full_story_with_multiple_items_id, auth_header, admin_user, fake_source):
        from core.managers.db_manager import db
        from core.model.story import Story

        """
        This test ungroups (removes) a single news item from a story with multiple items.
        The existing story ID should be kept with the first item and the other news item should get a new story ID.
        """
        full_story_id, _ = full_story_with_multiple_items_id
        admin_actor = Story.last_change_for_user(admin_user)

        response = self.assert_put_ok(client, "/news-items/ungroup", ["c2a1c55c-6e7e-41de-8ad1-bda321f2f56b"], auth_header)
        new_story_id = response.get_json()["new_stories_ids"][0]
        assert response.get_json()["message"] == "Successfully ungrouped 1 items from their story"
        assert new_story_id != full_story_id

        # db.session.expunge_all() made visible a wrong db.session.commit() order - where the commit came too early - before all changes were made.
        # Without this, this problem was not visible and only occured in the real deployment.
        db.session.expunge_all()

        # Original story should still exist and change last_change property to internal
        response = self.assert_get_ok(client, f"/story/{full_story_id}", auth_header)
        assert response.get_json()["id"] == full_story_id
        assert response.get_json()["last_change"] == admin_actor, "after an item was removed, property should track the user"
        assert len(response.get_json()["news_items"]) == 1
        assert response.get_json()["news_items"][0]["id"] == "90f0d9ec-70e7-45cf-8919-6ae2c02a4d88"
        assert response.get_json()["news_items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"

        # New story should be created with the news item and have last_change set to internal
        response = self.assert_get_ok(client, f"/story/{new_story_id}", auth_header)
        assert response.get_json()["last_change"] == admin_actor
        assert len(response.get_json()["news_items"]) == 1
        assert response.get_json()["news_items"][0]["id"] == "c2a1c55c-6e7e-41de-8ad1-bda321f2f56b"
        assert response.get_json()["news_items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"


class TestStoryNewsItemStatus(BaseTest):
    base_uri = "/api/assess"

    def test_story_news_item_status(self, client, stories, auth_header, fake_source):
        response = self.assert_get_ok(client, "stories", auth_header)
        assert response.get_json()["counts"]["total_count"] == 3

        assert response.get_json()["items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"
        assert response.get_json()["items"][0]["news_items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"
        assert response.get_json()["items"][1]["last_change"] == f"collector_rss_collector_{fake_source}"
        assert response.get_json()["items"][1]["news_items"][0]["last_change"] == f"collector_rss_collector_{fake_source}"

        assert response.get_json()["items"][2]["last_change"] == "internal", "manual should be internal"
        assert response.get_json()["items"][2]["news_items"][0]["id"] == "04129597-592d-45cb-9a80-3218108b29a1"
        assert response.get_json()["items"][2]["news_items"][0]["osint_source_key"] == "manual"
        assert response.get_json()["items"][2]["news_items"][0]["last_change"] == "internal", (
            "manual news item's last_change should be internal"
        )
