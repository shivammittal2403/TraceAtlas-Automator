import json
from datetime import datetime
from typing import Any, Literal

from pydantic import AliasChoices, ConfigDict, Field, ValidationInfo, field_validator, model_validator
from pydantic import BaseModel as PydanticBaseModel

from models.base import TaranisBaseModel


class CronTaskSpec(TaranisBaseModel):
    queue_name: str
    func_path: str
    cron: str | None = None
    interval: int | None = None
    args: list[Any] = Field(default_factory=list)
    kwargs: dict[str, Any] = Field(default_factory=dict)
    job_options: dict[str, Any] = Field(default_factory=dict)
    meta: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def normalize_scheduler_payload(cls, value: Any):
        if not isinstance(value, dict):
            return value

        normalized = dict(value)
        normalized["queue_name"] = normalized.get("queue_name") or normalized.get("queue")
        normalized["func_path"] = normalized.get("func_path") or normalized.get("func") or normalized.get("task")
        normalized["cron"] = normalized.get("cron") or None
        normalized["interval"] = None if normalized.get("interval") in ("", None) else normalized.get("interval")
        normalized["args"] = list(normalized.get("args") or [])
        normalized["kwargs"] = dict(normalized.get("kwargs") or {})
        normalized["job_options"] = dict(normalized.get("job_options") or {})
        normalized["meta"] = dict(normalized.get("meta") or {})
        return normalized

    @model_validator(mode="after")
    def validate_schedule_definition(self):
        has_cron = bool(self.cron)
        has_interval = self.interval is not None
        if has_cron == has_interval:
            raise ValueError("CronTaskSpec must provide exactly one of cron or interval")
        return self


class TaskResult(TaranisBaseModel):
    message: str
    reason: str | None = None
    retryable: bool = False
    data: Any = None


class UserTaskResult(TaranisBaseModel):
    model_config = ConfigDict(extra="ignore")

    message: str
    reason: str | None = None
    retryable: bool = False


class Task(TaranisBaseModel):
    """Task execution result model"""

    _core_endpoint = "/tasks"
    _model_name = "task"
    _pretty_name = "Task"
    _cache_timeout = 1

    id: str
    job_id: str | None = None
    task: str | None = None
    user_id: str | None = None
    worker_id: str | None = None
    worker_type: str | None = None
    result: TaskResult | None = None
    status: str | None = None
    last_run: datetime | None = None
    last_success: datetime | None = None


class UserTask(TaranisBaseModel):
    _core_endpoint = "/tasks/user"
    _model_name = "user_task"
    _pretty_name = "User Task"
    _cache_timeout = 1

    model_config = ConfigDict(extra="ignore")

    id: str
    job_id: str | None = None
    task: str | None = None
    worker_id: str | None = None
    worker_type: str | None = None
    result: UserTaskResult
    status: str
    last_run: datetime


class UserTaskList(TaranisBaseModel):
    model_config = ConfigDict(extra="ignore")

    items: list[UserTask] = Field(default_factory=list)
    total_count: int = 0


class UserTaskFilter(TaranisBaseModel):
    search: str | None = None
    page: int = 1
    limit: int = 20
    order: Literal[
        "worker_type_asc",
        "worker_type_desc",
        "status_asc",
        "status_desc",
        "last_run_asc",
        "last_run_desc",
    ] = "last_run_desc"

    @field_validator("search", mode="before")
    @classmethod
    def normalize_search(cls, value: Any) -> str | None:
        search = str(value or "").strip()
        return search or None

    @field_validator("page", "limit", mode="before")
    @classmethod
    def normalize_positive_int(cls, value: Any, info: ValidationInfo) -> int:
        default = 1 if info.field_name == "page" else 20
        try:
            parsed_value = int(value)
        except (TypeError, ValueError):
            return default
        return parsed_value if parsed_value > 0 else default

    @field_validator("order", mode="before")
    @classmethod
    def normalize_order(cls, value: Any) -> str:
        allowed_orders = {
            "worker_type_asc",
            "worker_type_desc",
            "status_asc",
            "status_desc",
            "last_run_asc",
            "last_run_desc",
        }
        return str(value) if value in allowed_orders else "last_run_desc"


class TaskSubmission(TaranisBaseModel):
    _core_endpoint = "/tasks"
    _model_name = "task_submission"
    _pretty_name = "Task Submission"

    model_config = ConfigDict(extra="forbid", populate_by_name=True, coerce_numbers_to_str=False)

    id: str = Field(min_length=1, validation_alias=AliasChoices("id", "task_id"), serialization_alias="id")
    task: str | None = None
    user_id: str | None = None
    worker_id: str | None = None
    worker_type: str | None = None
    result: TaskResult
    status: str = Field(min_length=1)

    @field_validator("id", "status", mode="after")
    @classmethod
    def strip_required_fields(cls, value: str) -> str:
        if stripped := value.strip():
            return stripped
        else:
            raise ValueError("Field cannot be empty")

    @field_validator("task", mode="after")
    @classmethod
    def normalize_task_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        stripped = value.strip()
        return stripped or None

    @field_validator("result", mode="before")
    @classmethod
    def ensure_json_serializable_result(cls, value: Any) -> Any:
        if isinstance(value, PydanticBaseModel):
            value = value.model_dump(mode="json", exclude_none=False)
        try:
            json.dumps(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("result must be JSON serializable") from exc
        return value


class TaskHistoryStats(TaranisBaseModel):
    user_id: str | None = None
    worker_id: str | None = None
    worker_type: str | None = None
    last_run: str | None = None
    last_success: str | None = None
    last_run_display: str | None = None
    last_success_display: str | None = None
    successes: int = 0
    warnings: int = 0
    failures: int = 0
    total: int = 0
    success_pct: int = 0
    status_badge: dict[str, str] | None = None


class TaskHistoryTotals(TaranisBaseModel):
    successes: int = 0
    warnings: int = 0
    failures: int = 0
    overall_success_rate: int = 0


class TaskHistoryResponse(TaranisBaseModel):
    _core_endpoint = "/tasks"
    _cache_timeout = 1
    _model_name = "task_history_response"
    _pretty_name = "Task History Response"

    items: list[Task] = Field(default_factory=list)
    total_count: int = 0
    task_stats: dict[str, TaskHistoryStats] = Field(default_factory=dict)
    totals: TaskHistoryTotals = Field(default_factory=TaskHistoryTotals)
