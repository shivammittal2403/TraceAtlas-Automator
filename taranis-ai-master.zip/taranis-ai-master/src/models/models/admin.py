from datetime import UTC, datetime
from typing import Annotated, Any, Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import (
    AnyUrl,
    BeforeValidator,
    Field,
    PastDatetime,
    SecretStr,
    StrictBool,
    StrictInt,
    StrictStr,
    TypeAdapter,
    field_serializer,
    field_validator,
    model_validator,
)

from models.base import TaranisBaseModel
from models.task import CronTaskSpec, Task
from models.types import (
    BOT_TYPES,
    COLLECTOR_TYPES,
    CONNECTOR_TYPES,
    PRESENTER_TYPES,
    PUBLISHER_TYPES,
    AttributeType,
    ItemType,
    TLPLevel,
)


def _utcnow() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def _normalize_datetime(value: datetime | None) -> datetime | None:
    if value is None or value.tzinfo is None or value.utcoffset() is None:
        return value
    return value.astimezone(UTC).replace(tzinfo=None)


class ExportStoriesQuery(TaranisBaseModel):
    timefrom: PastDatetime | None = None
    timeto: PastDatetime | None = None
    metadata: bool = False

    @field_validator("timefrom", "timeto", mode="before")
    @classmethod
    def empty_string_to_none(cls, value):
        return None if value == "" else value

    @field_validator("timefrom", "timeto", mode="after")
    @classmethod
    def normalize_utc_naive(cls, value: PastDatetime | None) -> datetime | None:
        return _normalize_datetime(value)

    @model_validator(mode="after")
    def set_timeto_default(self):
        if self.timefrom and self.timeto and self.timeto < self.timefrom:
            raise ValueError("To must be on or after From")
        if self.timefrom and self.timeto is None:
            self.timeto = _utcnow()
        return self


class Job(TaranisBaseModel):
    _core_endpoint = "/config/schedule"
    _cache_timeout = 1
    _model_name = "job"
    _pretty_name = "Scheduler"

    id: str | None = None
    name: str
    trigger: str | None = None
    kwargs: str | None = None
    next_run_time: str | None = None
    queue: str | None = None
    type: Literal["scheduled", "cron"] | None = None
    schedule: str | None = None
    status: str | None = None
    started_at: str | None = None
    failed_at: str | None = None
    error: str | None = None
    previous_run_time: str | None = None
    last_run: str | None = None
    last_success: str | None = None
    last_run_display: str | None = None
    last_run_relative: str | None = None
    status_badge: dict[str, str] | None = None
    is_overdue: bool | None = None


class ActiveJob(Job):
    _core_endpoint = "/config/workers/active"
    _cache_timeout = 1
    _model_name = "active_job"


class FailedJob(Job):
    _core_endpoint = "/config/workers/failed"
    _cache_timeout = 1
    _model_name = "failed_job"


class QueueStatus(TaranisBaseModel):
    _core_endpoint = "/config/workers/tasks"
    _cache_timeout = 1
    _model_name = "queue_status"

    name: str
    messages: int = 0


class WorkerStats(TaranisBaseModel):
    _core_endpoint = "/config/workers/stats"
    _cache_timeout = 1
    _model_name = "worker_stats"
    _pretty_name = "Worker Stats"

    total_workers: int = 0
    busy_workers: int = 0
    idle_workers: int = 0


class AdminMenuBadges(TaranisBaseModel):
    _core_endpoint = "/config/admin-menu-badges"
    _cache_timeout = 300
    _model_name = "admin_menu_badges"
    _pretty_name = "Admin Menu Badges"

    osint_source: int = 0
    bot: int = 0


class CronSpec(CronTaskSpec):
    job_id: str


class Address(TaranisBaseModel):
    city: str = ""
    country: str = ""
    street: str = ""
    zip: str = ""


class Organization(TaranisBaseModel):
    _core_endpoint = "/config/organizations"
    _model_name = "organization"

    id: str | None = None
    name: str = ""
    description: str | None = ""
    address: Address = Field(default_factory=Address)


class Permission(TaranisBaseModel):
    _core_endpoint = "/config/permissions"
    _model_name = "permission"
    id: str | None = None
    code: str | None = None
    name: str
    description: str = ""


class ACL(TaranisBaseModel):
    _core_endpoint = "/config/acls"
    _model_name = "acl"
    _pretty_name = "ACL"

    id: str | None = None
    name: str = ""
    description: str | None = ""
    item_type: ItemType | None = None
    item_id: str | None = None

    roles: list[str] = Field(default_factory=list)

    read_only: bool = True
    enabled: bool = True


class Role(TaranisBaseModel):
    _core_endpoint = "/config/roles"
    _model_name = "role"
    _pretty_name = "Role"

    id: str | None = None
    name: str = ""
    description: str | None = ""
    permissions: list[str] = Field(default_factory=list)
    tlp_level: TLPLevel | None = None


class User(TaranisBaseModel):
    _core_endpoint = "/config/users"
    _model_name = "user"

    id: str | None = None
    name: str
    organization: dict | str
    permissions: list[str] | None = None
    profile: dict | None = None
    roles: list[str] | list[dict] = Field(default_factory=list)
    username: str = ""
    password: SecretStr | None = None
    last_login: datetime | None = None

    @field_serializer("password", when_used="json")
    def dump_secret(self, v):
        return v.get_secret_value() if isinstance(v, SecretStr) else v

    @field_validator("profile", mode="after")
    @classmethod
    def normalize_onboarding_enabled(cls, profile: dict | None) -> dict | None:
        if not profile or "onboarding_enabled" not in profile:
            return profile
        value = profile["onboarding_enabled"]
        if isinstance(value, str) and value.lower() in {"true", "false"}:
            return {**profile, "onboarding_enabled": value.lower() == "true"}
        return profile


class TaranisConfig(TaranisBaseModel):
    default_collector_proxy: AnyUrl | Literal[""] = ""
    default_collector_interval: str = ""
    rss_collector_max_entries: int = Field(default=42, ge=1)
    default_bot_lookback_days: int = Field(default=7, ge=0)
    default_tlp_level: TLPLevel = TLPLevel.CLEAR
    default_story_conflict_retention: str = "200"
    default_news_item_conflict_retention: str = "200"
    default_timezone: str | None = None
    onboarding_enabled: bool = True
    chat_llm_api_format: Literal["responses", "chat_completions"] = "responses"
    chat_llm_base_url: str = ""
    chat_llm_api_key: str = Field(default="", repr=False)
    chat_llm_api_key_configured: bool = Field(default=False, exclude=True)
    chat_llm_api_key_clear: bool = False
    chat_llm_model: str = ""
    chat_llm_timeout: int = Field(default=120, gt=0)
    chat_max_stories: int = Field(default=5, gt=0, le=20)

    @field_validator("default_timezone", mode="after")
    @classmethod
    def validate_default_timezone(cls, value: str | None) -> str | None:
        timezone_name = (value or "").strip()
        if not timezone_name:
            return None
        try:
            ZoneInfo(timezone_name)
        except ZoneInfoNotFoundError as exc:
            raise ValueError(f"Invalid timezone: {timezone_name}") from exc
        return timezone_name


class Settings(TaranisBaseModel):
    _core_endpoint = "/settings/settings"
    _model_name = "settings"
    _pretty_name = "Settings"
    _cache_timeout = 30
    id: str | None = Field(default=None, frozen=True, exclude=True)
    settings: TaranisConfig = Field(default_factory=TaranisConfig)


class WordListEntry(TaranisBaseModel):
    value: str
    category: str | None = None
    description: str | None = None


class WordList(TaranisBaseModel):
    _core_endpoint = "/config/word-lists"
    _model_name = "word_list"
    _pretty_name = "Word List"

    id: str | None = None
    name: str
    description: str | None = ""
    usage: list[str] = Field(default_factory=list)
    link: str = ""
    entries: list[WordListEntry] | None = Field(default_factory=list)


class OSINTSource(TaranisBaseModel):
    _core_endpoint = "/config/osint-sources"
    _model_name = "osint_source"
    _pretty_name = "OSINT Source"
    _parameter_patch = True

    id: str | None = None
    key: str | None = None
    name: str
    description: str = ""
    rank: int = Field(default=0, ge=0, le=5)
    type: COLLECTOR_TYPES | None = None
    parameters: dict[str, Any] | None = Field(default_factory=dict)

    icon: str | None = None
    enabled: bool | None = True
    news_items_count: int | None = None
    collection_count: int | None = None
    collection_period: Literal["day", "week", "month"] | None = None
    status: Task | None = None


class OSINTSourceUpdateModel(TaranisBaseModel):
    name: str | None = None
    description: str | None = None
    rank: int | None = Field(default=None, ge=0, le=5)
    type: COLLECTOR_TYPES | None = None
    parameters: dict[str, Any] | None = None
    icon: str | None = None
    enabled: bool | None = None


class OSINTSourceGroup(TaranisBaseModel):
    _core_endpoint = "/config/osint-source-groups"
    _model_name = "osint_source_group"
    _pretty_name = "OSINT Source Group"

    id: str | None = None
    key: str | None = None
    name: str
    description: str = ""
    default: bool = False

    osint_sources: list[str] = Field(default_factory=list)
    word_lists: list[str] = Field(default_factory=list)


class CuratedOSINTSourceList(TaranisBaseModel):
    name: str
    description: str = ""
    sources: list[str] = Field(min_length=1)


class CuratedOSINTSourceCatalog(TaranisBaseModel):
    version: Literal[1]
    sources: list[OSINTSource]
    lists: list[CuratedOSINTSourceList]

    @model_validator(mode="after")
    def validate_catalog_references(self):
        source_names = [source.name for source in self.sources]
        list_names = [curated_list.name for curated_list in self.lists]
        if len(source_names) != len(set(source_names)):
            raise ValueError("Curated source names must be unique")
        if len(list_names) != len(set(list_names)):
            raise ValueError("Curated list names must be unique")
        if any(len(curated_list.sources) != len(set(curated_list.sources)) for curated_list in self.lists):
            raise ValueError("Curated source names must be unique within a list")

        known_source_names = set(source_names)
        if unknown_source_names := {
            source_name for curated_list in self.lists for source_name in curated_list.sources if source_name not in known_source_names
        }:
            raise ValueError(f"Unknown curated source names: {', '.join(sorted(unknown_source_names))}")
        return self


class CuratedOSINTSourceSelection(TaranisBaseModel):
    list_names: set[str] = Field(min_length=1)


class ProductType(TaranisBaseModel):
    _core_endpoint = "/config/product-types"
    _model_name = "product_type"
    _pretty_name = "Product Type"
    _parameter_patch = True

    id: str | None = None
    title: str
    description: str = ""
    type: PRESENTER_TYPES
    parameters: dict[str, Any] | None = Field(default_factory=dict)
    report_types: list[str] = Field(default_factory=list)
    status: Task | None = None


class PublisherPreset(TaranisBaseModel):
    _core_endpoint = "/config/publisher-presets"
    _model_name = "publisher_preset"
    _pretty_name = "Publisher Preset"
    _parameter_patch = True

    id: str | None = None
    name: str
    type: PUBLISHER_TYPES
    description: str | None = ""
    parameters: dict[str, Any] | None = Field(default_factory=dict)
    status: Task | None = None


class ReportItemAttribute(TaranisBaseModel):
    id: str | None = None
    attribute: dict[str, str] | None = None
    attribute_id: str | None = None
    attribute_group_id: str | None = None
    title: str | None = None
    description: str | None = None
    index: int | None = None
    required: bool | None = None
    value: str | None = None
    type: str | None = None


class ReportItemAttributeGroup(TaranisBaseModel):
    id: str | None = None
    title: str | None = None
    description: str | None = None
    index: int | None = None
    attribute_group_items: list[ReportItemAttribute] = Field(default_factory=list)


class ReportItemType(TaranisBaseModel):
    _core_endpoint = "/config/report-item-types"
    _model_name = "report_item_type"
    _pretty_name = "Report Item Type"

    id: str | None = None
    title: str
    description: str = ""
    attribute_groups: list[ReportItemAttributeGroup] | None = Field(default_factory=list)


class Template(TaranisBaseModel):
    _core_endpoint = "/config/templates"
    _model_name = "template"
    _pretty_name = "Template"

    name: str
    content: str | None = None
    validation_status: dict | None = None

    @property
    def id(self) -> str:
        """Use the filename for shared admin view routes and table actions."""
        return getattr(self, "name", "0")


class AttributeEnum(TaranisBaseModel):
    id: str | None = None
    index: int | None = None
    value: str | None = None
    description: str | None = None
    imported: bool | None = None
    attribute_id: str | None = None


class Attribute(TaranisBaseModel):
    _core_endpoint = "/config/attributes"
    _model_name = "attribute"
    _pretty_name = "Attribute"

    id: str | None = None
    name: str
    description: str = ""
    type: AttributeType
    default_value: str = ""
    attribute_enums: list[AttributeEnum] = Field(default_factory=list)


type BotIndex = Annotated[int, BeforeValidator(TypeAdapter(StrictInt | StrictStr).validate_python)]


class BotInput(TaranisBaseModel):
    name: str = ""
    description: str = ""
    index: BotIndex | None = None
    enabled: StrictBool = True
    parameters: dict[str, Any] | None = Field(default_factory=dict)

    @field_validator("index", mode="before")
    @classmethod
    def empty_index_to_none(cls, value):
        return None if value == "" else value


class BotUpdate(BotInput):
    type: BOT_TYPES | None = None


class BotCreate(BotInput):
    id: str | None = None
    name: str
    type: BOT_TYPES


class Bot(BotCreate):
    _core_endpoint = "/config/bots"
    _model_name = "bot"
    _pretty_name = "Bot"
    _parameter_patch = True

    enabled: bool = True
    status: Task | None = None


class Connector(TaranisBaseModel):
    _core_endpoint = "/config/connectors"
    _model_name = "connector"
    _pretty_name = "Connector"
    _parameter_patch = True

    id: str | None = None
    name: str
    description: str = ""
    type: CONNECTOR_TYPES | None = Field(default=None)
    index: int | None = None
    parameters: dict[str, Any] | None = Field(default_factory=dict)
    icon: str | None = None
    status: Task | None = None
