#!/usr/bin/env bun

import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const repoRoot = join(scriptDir, '../..');
const fixtureDir = join(repoRoot, 'test/fixtures/differential');
const manifestPath = join(scriptDir, 'fixtures/v3014-behavior-fixtures.json');
const pdfPath = join(fixtureDir, 'v3014-behavior-v1.pdf');
const malformedPath = join(fixtureDir, 'v3014-malformed-v1.pdf');
const write = process.argv.includes('--write');

const sha256 = (bytes: Uint8Array): string =>
  createHash('sha256').update(bytes).digest('hex');

function buildPdf(): Buffer {
  const pageStreams = [
    ['PAGE_ONE_ALPHA', 'Needle at start. cat catalog CAT.'],
    ['PAGE_TWO_BETA', 'prefix Needle suffix', 'Caf\\351 r\\351sum\\351'],
    ['PAGE_THREE_GAMMA', 'needle tail NEEDLE'],
  ].map(
    (lines) =>
      `BT\n/F1 12 Tf\n72 720 Td\n${lines
        .map((line, index) => `${index === 0 ? '' : '0 -18 Td\n'}(${line}) Tj`)
        .join('\n')}\nET\n`
  );

  const objects = new Map<number, string>([
    [
      1,
      '<< /Type /Catalog /Pages 2 0 R /PageLabels 13 0 R /MarkInfo 14 0 R /Outlines 15 0 R /Names 18 0 R /AcroForm 23 0 R >>',
    ],
    [2, '<< /Type /Pages /Kids [3 0 R 5 0 R 7 0 R] /Count 3 /MediaBox [0 0 612 792] /CropBox [20 30 580 760] /Rotate 90 /UserUnit 2 >>'],
    [
      3,
      '<< /Type /Page /Parent 2 0 R /UserUnit 2 /Resources << /Font << /F1 9 0 R >> >> /Contents 4 0 R /Annots [11 0 R] >>',
    ],
    [4, `<< /Length ${Buffer.byteLength(pageStreams[0]!, 'latin1')} >>\nstream\n${pageStreams[0]}endstream`],
    [
      5,
      '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 9 0 R >> >> /Contents 6 0 R >>',
    ],
    [6, `<< /Length ${Buffer.byteLength(pageStreams[1]!, 'latin1')} >>\nstream\n${pageStreams[1]}endstream`],
    [
      7,
      '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 9 0 R >> >> /Contents 8 0 R >>',
    ],
    [8, `<< /Length ${Buffer.byteLength(pageStreams[2]!, 'latin1')} >>\nstream\n${pageStreams[2]}endstream`],
    [9, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'],
    [
      10,
      '<< /Title (Parity Corpus V1) /Author (Sylphx Oracle) /Subject (TS 3.0.14 behavioral contract) /Keywords (parity multipage search) /Creator (fixture-generator-v1) /Producer (fixture-generator-v1) >>',
    ],
    [
      11,
      '<< /Type /Annot /Subtype /Link /Contents (  Linked note  ) /Rect [100 200 50 150] /A << /S /URI /URI (https://example.com/a) >> >>',
    ],
    [12, '<< /Type /Annot /Subtype /Text /Contents () /Rect [1 2 1 2] >>'],
    [13, '<< /Nums [0 << /S /D /P (P-) >> 1 << /S /r /St 4 >> 2 << /S /A /St 27 >>] >>'],
    [14, '<< /Marked true /Suspects false /UserProperties true >>'],
    [15, '<< /Type /Outlines /First 16 0 R /Last 16 0 R /Count 2 >>'],
    [
      16,
      '<< /Title (External docs) /Parent 15 0 R /First 17 0 R /Last 17 0 R /Count 1 /F 3 /C [0.25 0.5 0.75] /A << /S /URI /URI (https://example.com/docs) >> >>',
    ],
    [17, '<< /Title (Page three) /Parent 16 0 R /Dest [7 0 R /Fit] >>'],
    [18, '<< /EmbeddedFiles 19 0 R >>'],
    [19, '<< /Names [(source.csv) 20 0 R (evidence) 28 0 R] >>'],
    [20, '<< /Type /Filespec /F (source.csv) /UF (source.csv) /Desc (Source data) /EF << /F 21 0 R /UF 21 0 R >> >>'],
    [21, '<< /Type /EmbeddedFile /Length 19 >>\nstream\nname,value\nalpha,1\nendstream'],
    [22, '<< /Type /Annot /Subtype /Widget /FT /Tx /T (customer_name) /V (Ada Lovelace) /DV () /Rect [72 635 260 660] /P 3 0 R /F 4 >>'],
    [23, '<< /Fields [22 0 R 24 0 R 26 0 R 27 0 R] >>'],
    [24, '<< /FT /Tx /T (profile) /V (Grace Hopper) /DV (Unknown) /Ff 3 /Kids [25 0 R] >>'],
    [25, '<< /Type /Annot /Subtype /Widget /Parent 24 0 R /Rect [72 500 260 525] /P 5 0 R >>'],
    [26, '<< /Type /Annot /Subtype /Widget /FT /Btn /T (consent) /V /Yes /AS /Yes /Rect [72 450 90 468] /P 5 0 R >>'],
    [27, '<< /Type /Annot /Subtype /Widget /FT /Ch /T (tier) /V (gold) /DV (silver) /Ff 2 /Rect [72 400 200 425] /P 7 0 R >>'],
    [28, '<< /Type /Filespec /UF (C:\\\\reports\\\\report.txt) /EF << /UF 29 0 R >> >>'],
    [29, '<< /Type /EmbeddedFile /Length 5 >>\nstream\nhelloendstream'],
  ]);

  const chunks: Buffer[] = [Buffer.from('%PDF-1.4\n%\xe2\xe3\xcf\xd3\n', 'latin1')];
  const offsets = [0];
  let length = chunks[0]!.length;
  for (let id = 1; id <= objects.size; id += 1) {
    offsets[id] = length;
    const chunk = Buffer.from(`${id} 0 obj\n${objects.get(id)}\nendobj\n`, 'latin1');
    chunks.push(chunk);
    length += chunk.length;
  }
  const xrefOffset = length;
  const xref = [
    `xref\n0 ${objects.size + 1}\n`,
    '0000000000 65535 f \n',
    ...offsets.slice(1).map((offset) => `${String(offset).padStart(10, '0')} 00000 n \n`),
    `trailer\n<< /Size ${objects.size + 1} /Root 1 0 R /Info 10 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`,
  ].join('');
  chunks.push(Buffer.from(xref, 'ascii'));
  return Buffer.concat(chunks);
}

const files = [
  { path: pdfPath, bytes: buildPdf() },
  { path: malformedPath, bytes: Buffer.from('%PDF-1.4\n%not-a-valid-pdf-structure\n') },
];
const manifest = {
  schemaVersion: 1,
  generator: relative(repoRoot, fileURLToPath(import.meta.url)),
  fixtures: files.map(({ path, bytes }) => ({
    path: relative(repoRoot, path),
    bytes: bytes.length,
    sha256: sha256(bytes),
  })),
};
const manifestBytes = Buffer.from(`${JSON.stringify(manifest, null, 2)}\n`);

if (write) {
  mkdirSync(fixtureDir, { recursive: true });
  mkdirSync(dirname(manifestPath), { recursive: true });
  for (const file of files) writeFileSync(file.path, file.bytes);
  writeFileSync(manifestPath, manifestBytes);
  console.error(`wrote ${files.length} fixtures and ${relative(repoRoot, manifestPath)}`);
  process.exit(0);
}

const mismatches: string[] = [];
for (const file of files) {
  if (!existsSync(file.path) || !readFileSync(file.path).equals(file.bytes)) {
    mismatches.push(relative(repoRoot, file.path));
  }
}
if (!existsSync(manifestPath) || !readFileSync(manifestPath).equals(manifestBytes)) {
  mismatches.push(relative(repoRoot, manifestPath));
}
if (mismatches.length > 0) {
  throw new Error(`behavior fixtures are stale or missing: ${mismatches.join(', ')}; run with --write`);
}
console.log(`v3.0.14 behavior fixtures: OK (${files.length})`);
