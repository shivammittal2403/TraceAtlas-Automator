'use client';
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

interface BiasPieChartProps {
  data: Record<string, number | Record<string, number>>;
  height?: number;
  isDarkMode?: boolean;
  geminiPoliticalLean?: string | null;
}

// Named color map — each bias label gets a consistent color regardless of chart order
const BIAS_COLORS: Record<string, string> = {
  'left': '#3b82f6',          // blue
  'left-center': '#60a5fa',   // lighter blue
  'center': '#22c55e',        // green
  'right-center': '#f97316',  // orange
  'right': '#ef4444',         // red
  'pro-science': '#10b981',   // teal
  'conspiracy-pseudoscience': '#7c3aed', // purple
  'satire': '#ec4899',        // pink
  'state-media': '#f59e0b',   // amber
  'state-media-soft': '#fcd34d', // light amber
  'unlisted': '#6b7280',      // grey
  'no_sources': '#374151',    // dark grey
  'no matches': '#374151',
};

// Fallback palette for labels not in the named map
const FALLBACK_DARK = ['#1d4ed8', '#2563eb', '#1e40af', '#1e3a8a'];
const FALLBACK_LIGHT = ['#991b1b', '#b91c1c', '#7f1d1d', '#450a0a'];

function resolveColor(name: string, index: number, isDarkMode: boolean): string {
  const key = name.toLowerCase().replace(/_/g, '-');
  if (BIAS_COLORS[key]) return BIAS_COLORS[key];
  const fallback = isDarkMode ? FALLBACK_DARK : FALLBACK_LIGHT;
  return fallback[index % fallback.length];
}

const BiasPieChart: React.FC<BiasPieChartProps> = ({ data, height = 430, isDarkMode = true, geminiPoliticalLean }) => {
  // Strip internal meta fields (_counts, _total) — these are not chart slices
  const chartData = Object.entries(data)
    .filter(([key, val]) => !key.startsWith('_') && typeof val === 'number' && (val as number) > 0)
    .map(([name, value]) => ({ name, value: value as number }));

  const counts: Record<string, number> = (data['_counts'] as any) || {};
  const total: number = (data['_total'] as any) || 0;

  const accentColor = isDarkMode ? '#3b82f6' : '#dc2626';
  const textColor = isDarkMode ? '#60a5fa' : '#991b1b';

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    const entry = payload[0];
    const label = entry.name;
    const pct: number = typeof entry.value === 'number' ? entry.value : 0;
    const count = counts[label] ?? null;
    return (
      <div style={{
        backgroundColor: isDarkMode ? '#000' : '#fff',
        border: `1px solid ${accentColor}`,
        padding: '10px 14px',
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: '13px',
        color: isDarkMode ? '#fff' : '#1e3a8a',
      }}>
        <div style={{ fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 4 }}>{label}</div>
        <div>{pct.toFixed(1)}% of sources</div>
        {count != null && total > 0 && (
          <div style={{ opacity: 0.75 }}>{count} of {total} verified sources</div>
        )}
      </div>
    );
  };

  return (
    <div className="w-full flex flex-col">
      <ResponsiveContainer width="100%" height={height}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={(height / 2) - 40}
            fill="#8884d8"
            dataKey="value"
            stroke={isDarkMode ? '#000' : '#fff'}
            strokeWidth={2}
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={resolveColor(entry.name, index, isDarkMode)} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend
            verticalAlign="bottom"
            align="center"
            layout="horizontal"
            wrapperStyle={{
              color: textColor,
              fontSize: '0.75rem',
              paddingTop: '16px',
              fontFamily: 'JetBrains Mono, monospace',
              textTransform: 'uppercase',
            }}
          />
        </PieChart>
      </ResponsiveContainer>

      {/* AI political lean signal — shown below chart when Gemini provided an assessment */}
      {geminiPoliticalLean && (
        <div
          className="mt-3 px-4 py-3 text-xs font-mono leading-relaxed"
          style={{
            border: `1px solid ${isDarkMode ? '#1d4ed8' : '#dc2626'}`,
            backgroundColor: isDarkMode ? 'rgba(29,78,216,0.08)' : 'rgba(220,38,38,0.05)',
            color: isDarkMode ? '#93c5fd' : '#7f1d1d',
          }}
        >
          <span
            className="uppercase font-black tracking-widest mr-2"
            style={{ color: isDarkMode ? '#3b82f6' : '#dc2626' }}
          >
            AI POLITICAL SIGNAL:
          </span>
          {geminiPoliticalLean}
        </div>
      )}
    </div>
  );
};

export default BiasPieChart;
