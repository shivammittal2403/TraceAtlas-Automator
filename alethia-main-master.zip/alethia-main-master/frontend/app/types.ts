export interface Source {
  title: string;
  link: string;
  source: string;
}

export interface APIResult {
  image_url: string;
  total_matches: number;
  earliest_date: string;
  image_description: string;
  biases: {
    [key: string]: number;
  };
  source_clusters: {
    [domain: string]: string[];
  };
  reverse_search_links?: any[];
  candidate_sources?: any[];
  event_context_sources?: any[];
  image_first_impression?: string | null;
  exif_data?: any;
  geoclip_analysis?: {
    points: {
      match: number;
      lat: number;
      lon: number;
      confidence: number;
    }[];
    polygon: {
      match: number;
      lat: number;
      lon: number;
      confidence: number;
    }[];
    clusters?: {
      points: {
        match: number;
        lat: number;
        lon: number;
        confidence: number;
      }[];
      count: number;
      center: {
        lat: number;
        lon: number;
        confidence: number;
      };
      average_confidence: number;
    }[];
    primary_cluster?: {
      points: {
        match: number;
        lat: number;
        lon: number;
        confidence: number;
      }[];
      count: number;
      center: {
        lat: number;
        lon: number;
        confidence: number;
      };
      average_confidence: number;
    } | null;
    map_mode?: 'majority_point' | 'polygon';
    average_confidence: number;
    confidence_percent: number;
    confidence_level: string;
  } | null;
  location_analysis?: {
    selected_source: 'exif' | 'geoclip' | 'gemini' | 'none';
    label: string;
    reason: string;
    gps_display?: string;
    selected_coordinates?: { lat: number; lon: number; confidence?: number } | null;
    geoclip_coordinates?: { lat: number; lon: number; confidence?: number } | null;
    geoclip_used: boolean;
    geoclip_probability?: number;
    geoclip_confidence_percent?: number;
    device_location?: {
      display?: string;
      coordinates?: { lat: number; lon: number } | null;
      available: boolean;
    };
    gemini_location?: {
      name?: string;
      lat?: number | null;
      lon?: number | null;
      confidence?: string;
      evidence_type?: string;
    } | null;
    gemini_coordinates?: { lat: number; lon: number } | null;
    location_sources?: string[];
  };
  gemini_subject_category?: string | null;
  gemini_key_phrases?: string[];
  gemini_is_screenshot?: boolean;
  gemini_political_lean?: string | null;
  gemini_location?: {
    name?: string;
    lat?: number | null;
    lon?: number | null;
    confidence?: string;
    evidence_type?: string;
  } | null;
  gemini_ai_generation_signals?: string[];
  source_validation?: SourceValidationResult | null;
  source_verification?: SourceVerificationResult | null;
  ai_analysis?: {
    verdict?: string;
    ai_id_confidence?: number;
    human_confidence?: number;
    deepfake_confidence?: number;
    nsfw_is_detected?: boolean;
    scores?: {
      ai_generated?: number;
      human?: number;
      deepfake?: number;
    };
  };
}

export interface SourceAnalysis {
  title: string;
  url: string;
  domain: string;
  category: string;
  confidence: number;
  summary: string;
  relevance: string;
}

export interface SourceContextResult {
  overall_category: string;
  why_it_matters: string;
  source_analyses: SourceAnalysis[];
  overview: string;
}

export interface SourceValidationResult {
  validated_sources: {
    link: string;
    title: string;
    domain: string;
    status: 'relevant' | 'uncertain' | 'irrelevant';
    confidence: number;
    reason: string;
    remove_recommended: boolean;
  }[];
  summary: string;
}

export interface SourceVerificationResult {
  summary: {
    checked: number;
    confirmed: number;
    probable: number;
    not_confirmed: number;
    uncertain: number;
    failed: number;
    retained?: number;
    candidates_received?: number;
  };
  sources: {
    link: string;
    title: string;
    domain: string;
    provider: string;
    provider_result_url?: string;
    page_fetch_status: string;
    page_title?: string;
    meta_description?: string;
    candidate_image_count: number;
    best_candidate_image?: string | null;
    image_present: 'confirmed' | 'probable' | 'provider_asserted' | 'provider_visual_match' | 'not_confirmed' | 'uncertain';
    visual_similarity?: number | null;
    hash_distance?: number | null;
    hash_method?: string | null;
    provider_attestation?: string;
    evidence_summary: string;
  }[];
  retained_sources?: any[];
  error?: string;
}
