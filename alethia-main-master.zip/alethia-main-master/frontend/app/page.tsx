'use client';
import React, { useState, useEffect, useRef, use } from 'react';
import { 
  Scan, 
  ShieldCheck, 
  Aperture, 
  Map, 
  PieChart, 
  Search, 
  Activity, 
  Layers,
  Upload,
  ArrowRight,
  Check,
  X,
  Globe,
  Cpu,
  Sun,
  Moon,
  MessageCircle,
  Send,
  Sparkles,
  Download,
  FileText
} from 'lucide-react';
import BiasPieChart from './biasPieChart';
import SourceList from './sourceList';
import logo from './alethia_logo_vector_claude.svg';
import SkeletonLoader from './components/SkeletonLoader';
import TopBar from './components/TopBar';
import { APIResult, SourceContextResult, SourceValidationResult } from './types';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://127.0.0.1:8000';

type PipelineStatus = 'pending' | 'running' | 'complete' | 'warning' | 'failed';

type PipelineEvent = {
  stage: string;
  status: PipelineStatus;
  message?: string;
  meta?: Record<string, any>;
  timestamp?: string;
};

type ChatMessage = {
  role: 'user' | 'assistant';
  content: string;
};

const PIPELINE_STAGES = [
  { id: 'upload', label: 'Upload', icon: Upload },
  { id: 'cloudinary', label: 'Public URL', icon: Globe },
  { id: 'google_reverse', label: 'Google', icon: Search },
  { id: 'google_lens', label: 'Lens', icon: Aperture },
  { id: 'bing_reverse', label: 'Bing', icon: Search },
  { id: 'yandex_reverse', label: 'Yandex', icon: Search },
  { id: 'reverse_collect', label: 'Sources', icon: Layers },
  { id: 'source_verification', label: 'Verify Images', icon: ShieldCheck },
  { id: 'serp_processing', label: 'Clustering', icon: PieChart },
  { id: 'exif', label: 'EXIF', icon: ShieldCheck },
  { id: 'geoclip', label: 'GeoCLIP', icon: Map },
  { id: 'ai_or_not', label: 'AI Check', icon: Cpu },
  { id: 'gemini', label: 'AI Report', icon: Sparkles },
  { id: 'source_validation', label: 'Validate', icon: Check },
];

// Helper function to format bytes into a readable string (KB, MB, etc.)
function formatBytes(bytes: number, decimals = 2) {
  if (bytes === 0) return '0 Bytes';
  if (!bytes) return 'No Data Found';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];

  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Helper function to get the earliest date from multiple sources
function getEarliestDate(serpDateStr?: string, exifDateStr?: string): string {
  const dates: Date[] = [];

  // Parse SERP date (e.g., "2023-01-15")
  if (serpDateStr) {
    const date = new Date(serpDateStr);
    if (!isNaN(date.getTime())) {
      dates.push(date);
    }
  }

  // Parse EXIF date (e.g., "2023:01:15 10:30:00")
  if (exifDateStr) {
    const formattedExifDate = exifDateStr.replace(/(\d{4}):(\d{2}):(\d{2})/, '$1-$2-$3');
    const date = new Date(formattedExifDate);
    if (!isNaN(date.getTime())) {
      dates.push(date);
    }
  }

  if (dates.length === 0) return '--';

  const earliest = new Date(Math.min.apply(null, dates.map(d => d.getTime())));
  
  return earliest.toLocaleDateString('en-CA'); // YYYY-MM-DD format
}

/**
 * Helper to render the AI analysis text with blue-underlined headers
 */
function renderNarrativeAnalysis(text: string, isDarkMode: boolean) {
  if (!text) return null;

  const accentTextNarrative = isDarkMode ? 'text-blue-500' : 'text-red-600';
  const borderNarrative = isDarkMode ? 'border-blue-500/50' : 'border-red-600/50';

  const lines = text.split('\n');
  
  return lines.map((line, index) => {
    const trimmedLine = line.trim();
    
    const isMarkdownHeader = trimmedLine.startsWith('###');
    const isColonHeader = /^[A-Z\s]{3,}:/.test(trimmedLine);
    
    if (isMarkdownHeader || isColonHeader) {
      let headerText = trimmedLine.replace(/^###\s*/, '').trim();
      let headerLabel = headerText;
      let headerValue = "";

      if (headerText.includes(':')) {
        const parts = headerText.split(':');
        headerLabel = parts[0].trim();
        headerValue = parts.slice(1).join(':').trim();
      }

      return (
        <div key={index} className="mt-8 mb-4">
          <span className={`${accentTextNarrative} font-black border-b-2 ${borderNarrative} uppercase tracking-[0.2em] text-xl pb-1 inline-block`}>
            {headerLabel} {headerValue && <span className={`ml-3 ${accentTextNarrative}`}>{headerValue}</span>}
          </span>
        </div>
      );
    }

    const isBulletLine = trimmedLine.startsWith('- ') || trimmedLine.startsWith('• ');
    if (isBulletLine) {
      const bulletContent = trimmedLine.substring(2).trim();
      return (
        <div key={index} className="flex items-start gap-3 mb-2">
          <span className={`${accentTextNarrative} font-black mt-1 text-xl leading-none`}>
            •
          </span>
          <span className="flex-1 text-xl">{bulletContent}</span>
        </div>
      );
    }

    // Normal text lines
    return (
      <div key={index} className={trimmedLine === '' ? 'h-3' : 'mb-1 text-xl'}>
        {line}
      </div>
    );
  });
}

function PipelineLoader({
  isDarkMode,
  events,
}: {
  isDarkMode: boolean;
  events: PipelineEvent[];
}) {
  const statusByStage = events.reduce<Record<string, PipelineEvent>>((acc, event) => {
    acc[event.stage] = event;
    return acc;
  }, {});
  const completedCount = PIPELINE_STAGES.filter((stage) => ['complete', 'warning', 'failed'].includes(statusByStage[stage.id]?.status || '')).length;
  const accent = isDarkMode ? 'blue' : 'red';
  const completedColor = isDarkMode ? 'text-blue-100' : 'text-red-700';
  const runningColor = isDarkMode ? 'text-blue-300' : 'text-red-700';
  const pendingColor = isDarkMode ? 'text-zinc-600' : 'text-slate-400';
  const stageGeometry = PIPELINE_STAGES.map((stage, index) => {
    const angle = (index / PIPELINE_STAGES.length) * Math.PI * 2 - Math.PI / 2;
    const radius = 40;
    const unitX = Math.cos(angle);
    const unitY = Math.sin(angle);
    const nodeX = 50 + unitX * radius;
    const nodeY = 50 + unitY * radius;
    return {
      stage,
      angle,
      nodeX,
      nodeY,
    };
  });
  const overallProgress = Math.round((completedCount / PIPELINE_STAGES.length) * 100);

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center px-8 py-20 ${isDarkMode ? 'bg-[#00050a]' : 'bg-slate-50'}`}>
      <div className="relative w-full max-w-5xl aspect-square max-h-[760px]">
        <div className="absolute left-1/2 top-1/2 h-44 w-44 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center rounded-full">
          <svg className="absolute inset-[-18px] h-[calc(100%+36px)] w-[calc(100%+36px)] -rotate-90" viewBox="0 0 120 120" aria-hidden="true">
            <circle cx="60" cy="60" r="55" fill="none" stroke={isDarkMode ? '#18181b' : '#e2e8f0'} strokeWidth="3" />
            <circle
              cx="60"
              cy="60"
              r="55"
              fill="none"
              stroke={isDarkMode ? '#3b82f6' : '#dc2626'}
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray={`${overallProgress * 3.455} 345.5`}
              className="transition-all duration-700"
            />
          </svg>
          <img
            src={logo.src}
            alt="Alethia"
            className={`h-28 w-auto object-contain ${isDarkMode ? 'drop-shadow-[0_0_22px_rgba(59,130,246,0.42)]' : 'drop-shadow-[0_0_18px_rgba(220,38,38,0.3)]'}`}
          />
        </div>

        {stageGeometry.map(({ stage, nodeX, nodeY }) => {
          const event = statusByStage[stage.id];
          const status = event?.status || 'pending';
          const Icon = stage.icon;
          const activeClass = status === 'complete' ? completedColor : status === 'running' ? runningColor : status === 'warning' ? 'text-amber-300' : status === 'failed' ? 'text-red-300' : pendingColor;
          const ringColor = status === 'warning' ? '#f59e0b' : status === 'failed' ? '#ef4444' : status === 'complete' || status === 'running' ? (isDarkMode ? '#3b82f6' : '#dc2626') : (isDarkMode ? '#27272a' : '#cbd5e1');
          const nodeProgress = status === 'complete' || status === 'warning' || status === 'failed' ? 100 : status === 'running' ? 62 : 0;

          return (
            <div key={stage.id}>
              <div
                className={`absolute -translate-x-1/2 -translate-y-1/2 w-28 h-28 flex flex-col items-center justify-center gap-2 transition-all duration-500 ${activeClass} ${status === 'running' ? 'animate-pulse' : ''}`}
                style={{ left: `${nodeX}%`, top: `${nodeY}%` }}
                title={event?.message || stage.label}
              >
                <svg className="absolute inset-[-5px] h-[calc(100%+10px)] w-[calc(100%+10px)] -rotate-90" viewBox="0 0 100 100" aria-hidden="true">
                  <circle cx="50" cy="50" r="48" fill="none" stroke={isDarkMode ? '#18181b' : '#e2e8f0'} strokeWidth="2" />
                  <circle
                    cx="50"
                    cy="50"
                    r="48"
                    fill="none"
                    stroke={ringColor}
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray={`${nodeProgress * 3.015} 301.5`}
                    className="transition-all duration-700"
                  />
                </svg>
                <Icon className="h-6 w-6" />
                <span className="text-[10px] font-mono uppercase tracking-[0.16em] font-black text-center px-2 leading-tight">{stage.label}</span>
                <span className="text-[9px] font-mono uppercase opacity-70">{status}</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="w-full max-w-3xl mt-8">
        <div className={`h-2 w-full ${isDarkMode ? 'bg-zinc-900' : 'bg-slate-200'}`}>
          <div
            className={`h-full ${accent === 'blue' ? 'bg-blue-500' : 'bg-red-500'} transition-all duration-500`}
            style={{ width: `${Math.round((completedCount / PIPELINE_STAGES.length) * 100)}%` }}
          />
        </div>
        <div className={`mt-5 text-center font-mono uppercase tracking-[0.25em] text-xs font-black ${isDarkMode ? 'text-blue-300' : 'text-red-700'}`}>
          {events[events.length - 1]?.message || 'Preparing forensic pipeline'}
        </div>
      </div>
    </div>
  );
}

function GeoClipRegionMap({
  analysis,
  isDarkMode,
}: {
  analysis: APIResult['geoclip_analysis'];
  isDarkMode: boolean;
}) {
  const mapRef = useRef<HTMLDivElement>(null);
  const points = analysis?.points || [];
  const hasMajorityPoint = analysis?.map_mode === 'majority_point' && analysis.primary_cluster?.center;
  const displayPoints = (hasMajorityPoint
    ? [
        {
          match: 0,
          lat: analysis!.primary_cluster!.center.lat,
          lon: analysis!.primary_cluster!.center.lon,
          confidence: analysis!.primary_cluster!.average_confidence,
        },
        ...points.filter((point) => !analysis!.primary_cluster!.points.some((clusterPoint) => clusterPoint.match === point.match)),
      ]
    : points) as { match: number; lat: number; lon: number; confidence: number }[];
  const polygon = analysis?.polygon?.length ? analysis.polygon : points;

  useEffect(() => {
    let mapInstance: any;
    let cancelled = false;

    const ensureLeaflet = async () => {
      if (!(window as any).L) {
        if (!document.querySelector('link[data-leaflet-css="true"]')) {
          const link = document.createElement('link');
          link.rel = 'stylesheet';
          link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          link.setAttribute('data-leaflet-css', 'true');
          document.head.appendChild(link);
        }
        await new Promise<void>((resolve, reject) => {
          const existing = document.querySelector('script[data-leaflet-js="true"]') as HTMLScriptElement | null;
          if (existing) {
            existing.addEventListener('load', () => resolve(), { once: true });
            existing.addEventListener('error', () => reject(new Error('Unable to load map library.')), { once: true });
            return;
          }
          const script = document.createElement('script');
          script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          script.async = true;
          script.setAttribute('data-leaflet-js', 'true');
          script.onload = () => resolve();
          script.onerror = () => reject(new Error('Unable to load map library.'));
          document.body.appendChild(script);
        });
      }
    };

    const buildMap = async () => {
      if (!points.length) return;
      await ensureLeaflet();
      if (cancelled || !mapRef.current) return;
      const L = (window as any).L;
      mapRef.current.innerHTML = '';
      mapInstance = L.map(mapRef.current, {
        zoomControl: true,
        scrollWheelZoom: true,
        attributionControl: true,
      });
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(mapInstance);

      const bounds = L.latLngBounds([]);
      if (!hasMajorityPoint && polygon.length >= 3) {
        const polygonLayer = L.polygon(
          polygon.map((point) => [point.lat, point.lon]),
          {
            color: isDarkMode ? '#60a5fa' : '#dc2626',
            fillColor: isDarkMode ? '#3b82f6' : '#ef4444',
            fillOpacity: 0.22,
            weight: 2,
          }
        ).addTo(mapInstance);
        bounds.extend(polygonLayer.getBounds());
      }

      displayPoints.forEach((point) => {
        const marker = L.circleMarker([point.lat, point.lon], {
          radius: point.match === 0 ? 9 : 7,
          color: isDarkMode ? '#dbeafe' : '#ffffff',
          fillColor: point.match === 0 ? '#facc15' : isDarkMode ? '#60a5fa' : '#dc2626',
          fillOpacity: 0.95,
          weight: 2,
        }).addTo(mapInstance);
        marker.bindTooltip(
          `${point.match === 0 ? 'Majority cluster' : `Match ${point.match}`}<br/>${point.lat.toFixed(6)}, ${point.lon.toFixed(6)}<br/>Confidence ${(point.confidence * 100).toFixed(2)}%`,
          { sticky: true }
        );
        marker.on('click', () => mapInstance.flyTo([point.lat, point.lon], 11));
        bounds.extend([point.lat, point.lon]);
      });

      if (bounds.isValid()) {
        mapInstance.fitBounds(bounds.pad(hasMajorityPoint ? 0.18 : 0.28), { maxZoom: hasMajorityPoint ? 12 : 10 });
        setTimeout(() => mapInstance.invalidateSize(), 100);
      }
    };

    buildMap();

    return () => {
      cancelled = true;
      if (mapInstance) mapInstance.remove();
    };
  }, [analysis, isDarkMode, hasMajorityPoint, displayPoints, polygon]);

  if (!points.length) return null;

  return (
    <div className={`absolute inset-0 overflow-hidden ${isDarkMode ? 'bg-[#02070d]' : 'bg-slate-100'}`}>
      <div ref={mapRef} className={`absolute inset-0 h-full w-full ${isDarkMode ? '[&_.leaflet-tile]:brightness-75' : ''}`} />
    </div>
  );
}

type LocationAnalysis = APIResult['location_analysis'];

function MultiSourceMap({
  locationAnalysis,
  geoclipAnalysis,
  isDarkMode,
}: {
  locationAnalysis: LocationAnalysis;
  geoclipAnalysis: APIResult['geoclip_analysis'];
  isDarkMode: boolean;
}) {
  const mapRef = useRef<HTMLDivElement>(null);

  // Collect all pins across all three sources
  const pins: { lat: number; lon: number; type: 'exif' | 'gemini' | 'geoclip'; label: string }[] = [];

  const dev = locationAnalysis?.device_location;
  if (dev?.available && dev.coordinates?.lat != null && dev.coordinates?.lon != null) {
    pins.push({ lat: dev.coordinates.lat, lon: dev.coordinates.lon, type: 'exif', label: `Device GPS\n${dev.display || ''}` });
  }

  const gem = locationAnalysis?.gemini_coordinates;
  const gemLoc = locationAnalysis?.gemini_location;
  if (gem?.lat != null && gem?.lon != null) {
    pins.push({ lat: gem.lat, lon: gem.lon, type: 'gemini', label: `AI-inferred: ${gemLoc?.name || 'unknown'}\nConfidence: ${gemLoc?.confidence || ''}` });
  }

  // GeoCLIP: use primary cluster center or all points
  const geoclipPoints: { lat: number; lon: number; conf: number }[] = [];
  if (locationAnalysis?.geoclip_used && geoclipAnalysis) {
    const center = geoclipAnalysis.primary_cluster?.center;
    if (center) {
      geoclipPoints.push({ lat: center.lat, lon: center.lon, conf: center.confidence });
    } else {
      (geoclipAnalysis.points || []).slice(0, 5).forEach(p => geoclipPoints.push({ lat: p.lat, lon: p.lon, conf: p.confidence }));
    }
  }

  const hasAnyLocation = pins.length > 0 || geoclipPoints.length > 0;

  useEffect(() => {
    if (!hasAnyLocation) return;
    let mapInstance: any;
    let cancelled = false;

    const ensureLeaflet = async () => {
      if (!(window as any).L) {
        if (!document.querySelector('link[data-leaflet-css="true"]')) {
          const link = document.createElement('link');
          link.rel = 'stylesheet';
          link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          link.setAttribute('data-leaflet-css', 'true');
          document.head.appendChild(link);
        }
        await new Promise<void>((resolve, reject) => {
          const existing = document.querySelector('script[data-leaflet-js="true"]') as HTMLScriptElement | null;
          if (existing) { existing.addEventListener('load', () => resolve(), { once: true }); return; }
          const script = document.createElement('script');
          script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          script.async = true;
          script.setAttribute('data-leaflet-js', 'true');
          script.onload = () => resolve();
          script.onerror = () => reject(new Error('Unable to load map library.'));
          document.body.appendChild(script);
        });
      }
    };

    const buildMap = async () => {
      await ensureLeaflet();
      if (cancelled || !mapRef.current) return;
      const L = (window as any).L;
      mapRef.current.innerHTML = '';
      mapInstance = L.map(mapRef.current, { zoomControl: true, scrollWheelZoom: true, attributionControl: true });
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, attribution: '&copy; OpenStreetMap contributors',
      }).addTo(mapInstance);

      const bounds = L.latLngBounds([]);

      // EXIF pin — blue dashed ring
      pins.filter(p => p.type === 'exif').forEach(p => {
        const marker = L.circleMarker([p.lat, p.lon], {
          radius: 12, color: '#3b82f6', fillColor: 'transparent',
          fillOpacity: 0, weight: 3, dashArray: '6,4',
        }).addTo(mapInstance);
        marker.bindTooltip(`📍 ${p.label}`, { sticky: true });
        bounds.extend([p.lat, p.lon]);
      });

      // Gemini pin — solid orange
      pins.filter(p => p.type === 'gemini').forEach(p => {
        const marker = L.circleMarker([p.lat, p.lon], {
          radius: 10, color: '#f97316', fillColor: '#f97316',
          fillOpacity: 0.9, weight: 3,
        }).addTo(mapInstance);
        marker.bindTooltip(`🤖 ${p.label}`, { sticky: true });
        bounds.extend([p.lat, p.lon]);
      });

      // GeoCLIP dots — yellow with confidence label
      geoclipPoints.forEach((p, i) => {
        const marker = L.circleMarker([p.lat, p.lon], {
          radius: 7, color: '#fbbf24', fillColor: '#fbbf24',
          fillOpacity: 0.85, weight: 2,
        }).addTo(mapInstance);
        marker.bindTooltip(`📡 GeoCLIP ${i === 0 ? '(primary)' : `match ${i + 1}`}\n${(p.conf * 100).toFixed(1)}% confidence`, { sticky: true });
        bounds.extend([p.lat, p.lon]);
      });

      if (bounds.isValid()) {
        mapInstance.fitBounds(bounds.pad(0.25), { maxZoom: 12 });
        setTimeout(() => mapInstance.invalidateSize(), 100);
      }
    };

    buildMap();
    return () => { cancelled = true; if (mapInstance) mapInstance.remove(); };
  }, [locationAnalysis, geoclipAnalysis, isDarkMode, hasAnyLocation, pins, geoclipPoints]);

  if (!hasAnyLocation) return null;

  return (
    <div className={`absolute inset-0 overflow-hidden ${isDarkMode ? 'bg-[#02070d]' : 'bg-slate-100'}`}>
      <div ref={mapRef} className={`absolute inset-0 h-full w-full ${isDarkMode ? '[&_.leaflet-tile]:brightness-75' : ''}`} />
    </div>
  );
}

const CATEGORY_META: Record<string, { label: string; color: string; lightColor: string }> = {
  famous_artwork:     { label: 'Famous Artwork',      color: '#a855f7', lightColor: '#7e22ce' },
  news_event:         { label: 'News Event',          color: '#3b82f6', lightColor: '#1d4ed8' },
  historical:         { label: 'Historical',          color: '#f59e0b', lightColor: '#b45309' },
  political:          { label: 'Political',           color: '#ef4444', lightColor: '#b91c1c' },
  location_landmark:  { label: 'Location / Landmark', color: '#22c55e', lightColor: '#15803d' },
  personal:           { label: 'Personal / Private',  color: '#6b7280', lightColor: '#374151' },
  possibly_synthetic: { label: 'Possibly AI-Generated', color: '#f97316', lightColor: '#c2410c' },
  screenshot:         { label: 'Screenshot',          color: '#14b8a6', lightColor: '#0f766e' },
  unknown:            { label: 'Unknown',             color: '#6b7280', lightColor: '#374151' },
};

function ImageClassificationPanel({
  category,
  firstImpression,
  keyPhrases,
  isScreenshot,
  aiGenerationSignals,
  isDarkMode,
}: {
  category?: string | null;
  firstImpression?: string | null;
  keyPhrases?: string[];
  isScreenshot?: boolean;
  aiGenerationSignals?: string[];
  isDarkMode: boolean;
}) {
  const meta = CATEGORY_META[category || 'unknown'] || CATEGORY_META['unknown'];
  const badgeColor = isDarkMode ? meta.color : meta.lightColor;

  return (
    <div className={`mb-8 border ${isDarkMode ? 'border-blue-900/30 bg-blue-950/10' : 'border-red-100 bg-red-50'}`}>
      {/* Screenshot warning banner */}
      {isScreenshot && (
        <div className="flex items-center gap-2 px-4 py-2 text-xs font-mono font-black uppercase tracking-widest"
          style={{ backgroundColor: '#78350f', color: '#fef3c7' }}>
          ⚠ Screenshot detected — the depicted image may differ from what is being analyzed
        </div>
      )}

      <div className="p-5">
        {/* Category badge + first impression */}
        <div className="flex items-start gap-3 mb-3">
          {category && category !== 'unknown' && (
            <span
              className="shrink-0 text-[10px] font-mono font-black uppercase tracking-widest px-2 py-1 rounded-sm mt-0.5"
              style={{ backgroundColor: badgeColor + '22', color: badgeColor, border: `1px solid ${badgeColor}55` }}
            >
              {meta.label}
            </span>
          )}
          {firstImpression && (
            <p className={`text-sm leading-relaxed ${isDarkMode ? 'text-blue-100' : 'text-slate-800'}`}>
              {firstImpression}
            </p>
          )}
        </div>

        {/* AI generation signals */}
        {aiGenerationSignals && aiGenerationSignals.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-1">
            <span className={`text-[10px] font-mono uppercase tracking-widest font-black mr-1 ${isDarkMode ? 'text-orange-400' : 'text-orange-700'}`}>AI signals:</span>
            {aiGenerationSignals.map((sig, i) => (
              <span key={i} className="text-[10px] font-mono px-2 py-0.5 rounded-sm"
                style={{ backgroundColor: '#f97316' + '22', color: '#f97316', border: '1px solid #f9731655' }}>
                {sig}
              </span>
            ))}
          </div>
        )}

        {/* Key phrase chips */}
        {keyPhrases && keyPhrases.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {keyPhrases.map((phrase, i) => (
              <span key={i}
                className={`text-[11px] font-mono px-2 py-0.5 rounded-sm uppercase tracking-wide ${
                  isDarkMode ? 'bg-blue-950/60 text-blue-300 border border-blue-800/40' : 'bg-red-50 text-red-800 border border-red-200'
                }`}>
                {phrase}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMoreSources, setIsLoadingMoreSources] = useState(false);
  const [nextSourceStart, setNextSourceStart] = useState(20);
  const [result, setResult] = useState<APIResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showTopBar, setShowTopBar] = useState(true);
  
  // New states
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [sourceContext, setSourceContext] = useState<SourceContextResult | null>(null);
  const [sourceValidation, setSourceValidation] = useState<SourceValidationResult | null>(null);
  const [isAnalyzingSources, setIsAnalyzingSources] = useState(false);
  const [isValidatingSources, setIsValidatingSources] = useState(false);
  const [chatQuestion, setChatQuestion] = useState('');
  const [chatAnswer, setChatAnswer] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isAskingReport, setIsAskingReport] = useState(false);
  const [pipelineEvents, setPipelineEvents] = useState<PipelineEvent[]>([]);
  const [showSkeletonPhase, setShowSkeletonPhase] = useState(false);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [exportingFormat, setExportingFormat] = useState<'png' | 'pdf' | null>(null);
  const [showCandidateSources, setShowCandidateSources] = useState(false);
  
  // Ref for hidden file input
  const fileInputRef = useRef<HTMLInputElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Sync theme class to body for scrollbar styling
    if (!isDarkMode) {
      document.body.classList.add('light-theme');
    } else {
      document.body.classList.remove('light-theme');
    }
  }, [isDarkMode]);

  useEffect(() => {
    let lastScrollY = window.scrollY;

    const handleScroll = () => {
      if (window.scrollY > lastScrollY && window.scrollY > 100) {
        setShowTopBar(false);
      } else {
        setShowTopBar(true);
      }
      lastScrollY = window.scrollY;
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const handleFileChange = (selectedFile: File | null) => {
    if (selectedFile) {
      setFile(selectedFile);
      handleUpload(selectedFile);
    }
  };

  const handleUpload = async (fileToUpload: File) => {
    setIsLoading(true);
    setResult(null);
    setError(null);
    setIsDescriptionExpanded(false); // Reset description state
    setShowCandidateSources(false);
    setSourceContext(null);
    setSourceValidation(null);
    setChatQuestion('');
    setChatAnswer('');
    setChatMessages([]);
    setPipelineEvents([]);
    setShowSkeletonPhase(false);

    const formData = new FormData();
    formData.append('file', fileToUpload);
    const progressId = crypto.randomUUID();
    const progressStream = new EventSource(`${API_BASE_URL}/search/progress/${progressId}`);

    progressStream.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data) as PipelineEvent;
        setPipelineEvents((previous) => [...previous, data]);
        if (data.stage === 'response' && data.status === 'complete') {
          setShowSkeletonPhase(true);
        }
      } catch (parseError) {
        console.warn('Progress event parse failed:', parseError);
      }
    };

    progressStream.onerror = () => {
      progressStream.close();
    };

    try {
      const response = await fetch(`${API_BASE_URL}/search/image?progress_id=${encodeURIComponent(progressId)}`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        let detail = `Upload failed with status ${response.status}`;
        try {
          const errData = await response.json();
          detail = errData.detail || detail;
        } catch {
          const text = await response.text();
          detail = text || detail;
        }
        throw new Error(detail);
      }

      const data = await response.json();
      console.log('API Response:', data);
      setResult(data);
      setSourceValidation(data.source_validation || null);
      setNextSourceStart(20);
    } catch (err: any) {
      console.error('Upload Error:', err);
      const message = err?.message === 'Failed to fetch'
        ? `Unable to reach Alethia backend at ${API_BASE_URL}. Confirm Uvicorn is running and did not crash during analysis.`
        : err.message;
      setError(message);
    } finally {
      progressStream.close();
      setIsLoading(false);
      setShowSkeletonPhase(false);
    }
  };

  const handleReset = () => {
    setFile(null);
    setResult(null);
    setError(null);
    setNextSourceStart(20);
    setSourceContext(null);
    setSourceValidation(null);
    setChatQuestion('');
    setChatAnswer('');
    setChatMessages([]);
    setPipelineEvents([]);
    setShowSkeletonPhase(false);
    setShowCandidateSources(false);
  };

  const mergeSourceClusters = (
    existing: Record<string, string[]> = {},
    incoming: Record<string, string[]> = {}
  ) => {
    const merged: Record<string, string[]> = { ...existing };
    Object.entries(incoming).forEach(([domain, links]) => {
      const currentLinks = merged[domain] || [];
      merged[domain] = Array.from(new Set([...currentLinks, ...links]));
    });
    return merged;
  };

  const handleLoadMoreSources = async () => {
    if (!result?.image_url || isLoadingMoreSources) return;

    setIsLoadingMoreSources(true);
    setError(null);

    try {
      const params = new URLSearchParams({
        image_url: result.image_url,
        provider: 'google_reverse_image',
        start: String(nextSourceStart),
      });
      const response = await fetch(`${API_BASE_URL}/search/image/more?${params.toString()}`);

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.detail || 'Unable to load more sources');
      }

      const data = await response.json();
      setResult((prev) => {
        if (!prev) return prev;
        const nextLinks = [
          ...(prev.reverse_search_links || []),
          ...(data.reverse_search_links || []),
        ];
        return {
          ...prev,
          reverse_search_links: nextLinks,
          total_matches: nextLinks.length || prev.total_matches,
          source_clusters: mergeSourceClusters(prev.source_clusters, data.source_clusters),
        };
      });
      setNextSourceStart(data.next?.start || nextSourceStart + 10);
    } catch (err: any) {
      console.error('Load More Sources Error:', err);
      setError(err.message);
    } finally {
      setIsLoadingMoreSources(false);
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  const handleAnalyzeSources = async () => {
    if (!result || isAnalyzingSources) return;

    setIsAnalyzingSources(true);
    setError(null);

    try {
      const response = await fetch(`${API_BASE_URL}/analysis/source-context`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ report: result, max_sources: 12 }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.detail || 'Unable to analyze source context');
      }

      const data = await response.json();
      setSourceContext(data);
    } catch (err: any) {
      console.error('Source Context Error:', err);
      setError(err.message);
    } finally {
      setIsAnalyzingSources(false);
    }
  };

  const handleValidateSources = async () => {
    if (!result || isValidatingSources) return;

    setIsValidatingSources(true);
    setError(null);

    try {
      const response = await fetch(`${API_BASE_URL}/analysis/source-validation`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          report: result,
          source_context: sourceContext?.source_analyses || [],
          max_sources: 60,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.detail || 'Unable to validate sources');
      }

      const data = await response.json();
      setSourceValidation(data);
    } catch (err: any) {
      console.error('Source Validation Error:', err);
      setError(err.message);
    } finally {
      setIsValidatingSources(false);
    }
  };

  const handleAskReport = async () => {
    if (!result || !chatQuestion.trim() || isAskingReport) return;

    const question = chatQuestion.trim();
    setIsAskingReport(true);
    setError(null);
    const nextMessages: ChatMessage[] = [...chatMessages, { role: 'user', content: question }];
    setChatMessages(nextMessages);

    try {
      const response = await fetch(`${API_BASE_URL}/analysis/report-chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          report: result,
          question,
          source_context: sourceContext?.source_analyses || [],
          history: nextMessages.slice(-8),
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.detail || 'Unable to answer report question');
      }

      const data = await response.json();
      const answer = data.answer || '';
      setChatAnswer(answer);
      setChatMessages((previous) => [...previous, { role: 'assistant', content: answer }]);
      setChatQuestion('');
    } catch (err: any) {
      console.error('Report Chat Error:', err);
      setChatMessages((previous) => [...previous, { role: 'assistant', content: `Unable to answer right now: ${err.message}` }]);
      setError(err.message);
    } finally {
      setIsAskingReport(false);
    }
  };

  const downloadBlob = (blob: Blob, fileName: string) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(url);
  };

  const buildExportDocument = () => {
    const reportElement = reportRef.current;
    if (!reportElement) return null;

    const clone = reportElement.cloneNode(true) as HTMLElement;
    clone.querySelectorAll('[data-export-remove="true"]').forEach((element) => element.remove());
    clone.querySelectorAll('button, textarea, input').forEach((element) => element.remove());
    clone.querySelectorAll('[title="Open report assistant"]').forEach((element) => element.remove());
    clone.querySelectorAll('iframe, .leaflet-container').forEach((element) => {
      const placeholder = document.createElement('div');
      placeholder.textContent = 'Map layer omitted from image export. See report for interactive GeoCLIP map.';
      placeholder.style.cssText = [
        'display:flex',
        'align-items:center',
        'justify-content:center',
        'min-height:420px',
        'border:1px solid rgba(96,165,250,0.35)',
        'font-family:Arial, sans-serif',
        'font-size:18px',
        `color:${isDarkMode ? '#bfdbfe' : '#7f1d1d'}`,
        `background:${isDarkMode ? '#020617' : '#fff1f2'}`,
      ].join(';');
      element.replaceWith(placeholder);
    });
    clone.style.width = `${reportElement.scrollWidth}px`;
    clone.style.maxWidth = 'none';
    clone.style.minHeight = `${reportElement.scrollHeight}px`;
    clone.style.overflow = 'visible';

    const logoHeader = document.createElement('div');
    logoHeader.setAttribute('data-export-logo', 'true');
    logoHeader.style.cssText = [
      'display:flex',
      'flex-direction:column',
      'align-items:center',
      'justify-content:center',
      'gap:18px',
      'padding:56px 0 18px',
      `background:${isDarkMode ? '#000000' : '#ffffff'}`,
    ].join(';');

    const logoImage = document.createElement('img');
    logoImage.src = new URL(logo.src, window.location.origin).toString();
    logoImage.alt = 'Alethia Logo';
    logoImage.style.cssText = 'height:132px;width:auto;object-fit:contain;display:block;';
    const logoText = document.createElement('div');
    logoText.textContent = 'ALETHIA FORENSIC IMAGE REPORT';
    logoText.style.cssText = [
      'font-family:Arial, sans-serif',
      'font-size:24px',
      'font-weight:900',
      'letter-spacing:0.24em',
      `color:${isDarkMode ? '#93c5fd' : '#b91c1c'}`,
    ].join(';');

    logoHeader.appendChild(logoImage);
    logoHeader.appendChild(logoText);
    clone.insertBefore(logoHeader, clone.firstChild);
    return clone;
  };

  const absolutizeExportUrls = (root: HTMLElement) => {
    root.querySelectorAll('img').forEach((image) => {
      const src = image.getAttribute('src');
      if (src && !src.startsWith('data:')) {
        image.setAttribute('src', new URL(src, window.location.origin).toString());
      }
    });
  };

  const inlineComputedStyles = (source: Element, target: Element) => {
    const computed = window.getComputedStyle(source);
    const style = Array.from(computed).map((property) => `${property}:${computed.getPropertyValue(property)};`).join('');
    (target as HTMLElement).setAttribute('style', `${style};${(target as HTMLElement).getAttribute('style') || ''}`);
    Array.from(source.children).forEach((child, index) => {
      const targetChild = target.children[index];
      if (targetChild) inlineComputedStyles(child, targetChild);
    });
  };

  const buildRenderedExportHtml = async () => {
    const reportElement = reportRef.current;
    const clone = buildExportDocument();
    if (!reportElement || !clone) return null;

    const wrapper = document.createElement('div');
    wrapper.style.position = 'fixed';
    wrapper.style.left = '-100000px';
    wrapper.style.top = '0';
    wrapper.style.width = `${reportElement.scrollWidth}px`;
    wrapper.appendChild(clone);
    absolutizeExportUrls(clone);
    document.body.appendChild(wrapper);
    inlineComputedStyles(wrapper, wrapper);

    const width = wrapper.scrollWidth;
    const height = wrapper.scrollHeight;
    const styles = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
      .map((node) => node.outerHTML)
      .join('\n');
    const html = `
      <!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          ${styles}
          <style>
            body { margin: 0; background: ${isDarkMode ? '#000000' : '#ffffff'}; }
            button, textarea, input { display: none !important; }
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
          </style>
        </head>
        <body>${clone.outerHTML}</body>
      </html>
    `;
    document.body.removeChild(wrapper);
    return { html, width, height };
  };

  const exportReport = async (format: 'png' | 'pdf') => {
    if (!result || exportingFormat) return;
    setError(null);
    setExportingFormat(format);
    await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
    try {
      const html2canvas = (await import('html2canvas')).default;
      const { jsPDF } = await import('jspdf');

      const el = reportRef.current;
      if (!el) throw new Error('Report element not found');

      // Hide Leaflet tile layers — cross-origin tiles can't be captured by html2canvas
      const tilePanes = el.querySelectorAll<HTMLElement>('.leaflet-tile-pane');
      tilePanes.forEach(p => { p.style.visibility = 'hidden'; });

      const canvas = await html2canvas(el, {
        useCORS: true,
        allowTaint: false,
        scale: 2,
        backgroundColor: isDarkMode ? '#000000' : '#ffffff',
        scrollX: 0,
        scrollY: -window.scrollY,
        windowWidth: el.scrollWidth,
        width: el.scrollWidth,
        height: el.scrollHeight,
        logging: false,
      });

      // Restore tile layers
      tilePanes.forEach(p => { p.style.visibility = ''; });

      if (format === 'png') {
        canvas.toBlob(blob => { if (blob) downloadBlob(blob, 'alethia-report.png'); }, 'image/png');
      } else {
        const imgData = canvas.toDataURL('image/jpeg', 0.92);
        const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
        const pageW = pdf.internal.pageSize.getWidth();
        const pageH = pdf.internal.pageSize.getHeight();
        const imgH = (canvas.height / canvas.width) * pageW;
        let heightLeft = imgH;
        let yOffset = 0;

        pdf.addImage(imgData, 'JPEG', 0, yOffset, pageW, imgH);
        heightLeft -= pageH;

        while (heightLeft > 0) {
          yOffset -= pageH;
          pdf.addPage();
          pdf.addImage(imgData, 'JPEG', 0, yOffset, pageW, imgH);
          heightLeft -= pageH;
        }

        pdf.save('alethia-report.pdf');
      }
    } catch (err: any) {
      console.error('Export Error:', err);
      setError(err.message || 'Unable to export report');
    } finally {
      setExportingFormat(null);
    }
  };

  const handleDownloadReportPdf = () => {
    exportReport('pdf');
  };

  const handleDownloadReportImage = () => {
    exportReport('png');
  };

  const renderLandingRedesign = () => {
    const accentText = isDarkMode ? 'text-blue-400' : 'text-red-600';
    const accentBg = isDarkMode ? 'bg-blue-600' : 'bg-red-600';
    const accentBorder = isDarkMode ? 'border-blue-500/30' : 'border-red-500/30';
    const softPanel = isDarkMode ? 'bg-black/70 border-blue-900/30' : 'bg-white border-red-100';
    const mutedText = isDarkMode ? 'text-blue-100/70' : 'text-slate-600';
    const strongText = isDarkMode ? 'text-white' : 'text-slate-950';
    const subtleBg = isDarkMode ? 'bg-blue-950/10' : 'bg-red-50/70';

    const journey = [
      { label: 'Upload', detail: 'Start from the image itself.', icon: Upload },
      { label: 'Trace', detail: 'Search Google, Lens, Bing, and Yandex.', icon: Search },
      { label: 'Verify', detail: 'Check metadata, source pages, location, and AI signals.', icon: ShieldCheck },
      { label: 'Report', detail: 'Export a clear evidence summary.', icon: FileText },
    ];

    const reportPreview = [
      { label: 'Source matches', value: '46', detail: 'Deduped across providers' },
      { label: 'Location basis', value: 'EXIF', detail: 'GeoCLIP fallback available' },
      { label: 'Source review', value: 'Visual', detail: 'Pages checked for matching images' },
      { label: 'Export', value: 'PNG/PDF', detail: 'Shareable report capture' },
    ];

    const checks = [
      {
        title: 'Reverse Image Search',
        body: 'Combines Google reverse search, Lens, Bing, and Yandex into one deduped source set.',
        icon: Search,
      },
      {
        title: 'Metadata and Location',
        body: 'Reads EXIF data first, then uses GeoCLIP probabilities only when they add useful context.',
        icon: Map,
      },
      {
        title: 'Narrative Context',
        body: 'Clusters sources by domain, bias, and relevance so the report explains where the image is being used.',
        icon: PieChart,
      },
      {
        title: 'Source Verification',
        body: 'Fetches source pages, extracts candidate images, and checks whether the uploaded image is actually present.',
        icon: ShieldCheck,
      },
      {
        title: 'Report Assistant',
        body: 'Keeps the full report context available for follow-up questions while the report remains separate.',
        icon: MessageCircle,
      },
    ];

    return (
      <div className="w-full flex flex-col items-center">
        {/* Legacy renderLanding below is intentionally preserved for rollback.
            This redesign keeps upload first while making the report value clearer. */}
        <section className="w-full min-h-screen px-5 sm:px-8 py-10 flex items-center justify-center grid-background">
          <div className="w-full max-w-4xl flex flex-col items-center text-center">
            <div className="relative mb-5">
              <div className={`absolute inset-0 scale-75 blur-3xl ${isDarkMode ? 'bg-blue-500/30' : 'bg-red-500/25'}`} />
              <img
                src={logo.src}
                alt="Alethia Logo"
                className={`relative z-10 h-48 sm:h-56 md:h-64 w-auto object-contain ${!isDarkMode ? 'grayscale brightness-50' : ''}`}
              />
            </div>

            <h1 className={`text-5xl sm:text-6xl md:text-7xl font-black ${strongText}`}>ALETHIA</h1>
            <p className={`mt-4 text-base sm:text-lg font-mono ${accentText}`}>Image evidence and verification reports</p>

            <div
              onClick={() => triggerFileUpload()}
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                handleFileChange(e.dataTransfer.files?.[0] || null);
              }}
              className={`mt-9 w-full max-w-2xl cursor-pointer border p-3 transition-all duration-300 ${
                isDragging
                  ? (isDarkMode ? 'border-blue-300 bg-blue-950/40 shadow-[0_0_55px_rgba(59,130,246,0.35)]' : 'border-red-500 bg-red-50 shadow-[0_0_45px_rgba(239,68,68,0.25)]')
                  : `${softPanel} ${isDarkMode ? 'border-blue-500/40 shadow-[0_0_35px_rgba(59,130,246,0.16)] hover:shadow-[0_0_55px_rgba(59,130,246,0.28)]' : 'border-red-200 shadow-[0_0_30px_rgba(239,68,68,0.12)] hover:shadow-[0_0_45px_rgba(239,68,68,0.2)]'}`
              }`}
            >
              <div className={`border border-dashed ${accentBorder} p-8 sm:p-10 flex flex-col items-center`}>
                <div className={`${accentBg} h-16 w-16 flex items-center justify-center text-white shadow-lg`}>
                  <Upload className="h-8 w-8" strokeWidth={2.5} />
                </div>
                <div className={`mt-5 text-xl font-bold ${strongText}`}>
                  {file ? file.name : 'Upload an image for analysis'}
                </div>
                <div className={`mt-3 max-w-xl text-sm leading-relaxed ${mutedText}`}>
                  Drag and drop or click to begin reverse search, metadata extraction, source-page verification, location analysis, and report generation.
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => document.getElementById('landing-details')?.scrollIntoView({ behavior: 'smooth' })}
              className={`mt-10 w-full max-w-2xl border px-6 py-4 flex items-center justify-center gap-3 font-bold transition-colors ${
                isDarkMode
                  ? 'border-blue-500/30 bg-blue-950/20 text-blue-300 hover:bg-blue-950/40'
                  : 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100'
              }`}
            >
              Scroll down to see what Alethia checks
              <ArrowRight className="h-5 w-5 rotate-90" />
            </button>
          </div>
        </section>

        <section id="landing-details" className="w-full max-w-7xl px-5 sm:px-8 py-20 grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_440px] gap-8 lg:gap-12 items-start">
          <div>
            <div className="max-w-3xl">
              <div className={`text-sm font-mono ${accentText}`}>From image to evidence</div>
              <h2 className={`mt-3 text-4xl font-black leading-tight ${strongText}`}>See where an image spread and what the available evidence actually supports.</h2>
              <p className={`mt-4 text-lg leading-relaxed ${mutedText}`}>
                Alethia combines reverse search, metadata, source-page image checks, geolocation signals, AI detection, and evidence-scoped reporting in one workflow.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-4 gap-3">
              {journey.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className={`border ${softPanel} p-4 min-h-[128px]`}>
                    <Icon className={`h-5 w-5 mb-4 ${accentText}`} />
                    <div className={`font-bold ${strongText}`}>{item.label}</div>
                    <div className={`mt-2 text-sm leading-relaxed ${mutedText}`}>{item.detail}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <aside className={`border ${softPanel} p-5 sm:p-6`}>
              <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-5">
                <div>
                  <div className={`text-sm font-mono ${accentText}`}>Sample output</div>
                  <h2 className={`mt-1 text-2xl font-black ${strongText}`}>Evidence report</h2>
                </div>
                <FileText className={`h-8 w-8 ${accentText}`} />
              </div>

              <div className="py-5 space-y-4">
                <div className={`border ${accentBorder} ${subtleBg} p-4`}>
                  <div className="flex items-center justify-between gap-4">
                    <span className={`text-xs font-mono ${accentText}`}>source trace</span>
                    <span className={`text-xs font-mono ${mutedText}`}>sample workflow</span>
                  </div>

                  <div className="mt-4 grid grid-cols-4 gap-2">
                    {['Google', 'Lens', 'Bing', 'Yandex'].map((provider) => (
                      <div key={provider} className={`border ${accentBorder} px-2 py-3 text-center`}>
                        <Search className={`mx-auto h-4 w-4 ${accentText}`} />
                        <div className={`mt-2 text-[11px] font-bold ${strongText}`}>{provider}</div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 grid grid-cols-[1fr_auto_1fr_auto_1fr] items-center gap-2">
                    <div>
                      <div className={`text-lg font-black ${strongText}`}>46</div>
                      <div className={`text-[11px] leading-tight ${mutedText}`}>matches found</div>
                    </div>
                    <ArrowRight className={`h-4 w-4 ${accentText}`} />
                    <div>
                      <div className={`text-lg font-black ${strongText}`}>31</div>
                      <div className={`text-[11px] leading-tight ${mutedText}`}>unique sources</div>
                    </div>
                    <ArrowRight className={`h-4 w-4 ${accentText}`} />
                    <div>
                      <div className={`flex items-center gap-1 text-lg font-black ${strongText}`}>
                        <ShieldCheck className={`h-4 w-4 ${accentText}`} />
                        18
                      </div>
                      <div className={`text-[11px] leading-tight ${mutedText}`}>visually verified</div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {reportPreview.map((item) => (
                    <div key={item.label} className={`border ${accentBorder} p-3`}>
                      <div className={`text-xs font-mono ${mutedText}`}>{item.label}</div>
                      <div className={`mt-2 text-xl font-black ${strongText}`}>{item.value}</div>
                      <div className={`mt-1 text-xs leading-relaxed ${mutedText}`}>{item.detail}</div>
                    </div>
                  ))}
                </div>

                <div className={`border ${accentBorder} p-4`}>
                  <div className={`flex items-center gap-2 text-sm font-bold ${strongText}`}>
                    <Sparkles className={`h-4 w-4 ${accentText}`} />
                    Report summary
                  </div>
                  <p className={`mt-3 text-sm leading-relaxed ${mutedText}`}>
                    The final report explains what was found, why it matters, which source pages visually matched, and how confident each location signal is.
                  </p>
                </div>
              </div>
          </aside>
        </section>

        <section id="capabilities" className={`w-full border-y ${isDarkMode ? 'bg-zinc-950/80 border-blue-900/25' : 'bg-white border-red-100'} px-5 sm:px-8 py-20`}>
          <div className="max-w-7xl mx-auto">
            <div className="max-w-3xl mb-10">
              <div className={`text-sm font-mono ${accentText}`}>What Alethia checks</div>
              <h2 className={`mt-3 text-4xl font-black ${strongText}`}>Built for debunking image misuse, not just finding similar pictures.</h2>
              <p className={`mt-4 text-lg leading-relaxed ${mutedText}`}>
                The system treats every provider response as evidence that needs cleaning, deduping, and context before it reaches the report.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {checks.map((item) => {
                const Icon = item.icon;
                return (
                  <article key={item.title} className={`border ${softPanel} p-6 min-h-[220px]`}>
                    <Icon className={`h-7 w-7 ${accentText}`} />
                    <h3 className={`mt-6 text-xl font-bold ${strongText}`}>{item.title}</h3>
                    <p className={`mt-3 text-sm leading-relaxed ${mutedText}`}>{item.body}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section id="pipeline" className="w-full max-w-7xl px-5 sm:px-8 py-20">
          <div className={`border ${softPanel} p-6 sm:p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-[360px_minmax(0,1fr)] gap-8 items-start`}>
            <div>
              <div className={`text-sm font-mono ${accentText}`}>Report flow</div>
              <h2 className={`mt-3 text-3xl font-black ${strongText}`}>From upload to shareable evidence.</h2>
              <p className={`mt-4 text-base leading-relaxed ${mutedText}`}>
                The end state is a report that can be reviewed, questioned through the assistant, and exported as a PNG or PDF without including internal controls.
              </p>
              <button
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className={`mt-6 inline-flex items-center gap-3 ${accentBg} px-5 py-3 text-white font-bold transition-opacity hover:opacity-90`}
              >
                <Upload className="h-5 w-5" />
                Start with an image
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                ['1', 'Collect', 'Upload, public URL creation, and provider searches run with live progress.'],
                ['2', 'Verify', 'Source pages are fetched, candidate images are extracted, and visual matches are checked.'],
                ['3', 'Explain', 'The report summarizes metadata, location basis, sources, narrative signals, caveats, and exports.'],
              ].map(([step, title, body]) => (
                <div key={step} className={`border ${accentBorder} p-5 min-h-[190px]`}>
                  <div className={`${accentBg} h-9 w-9 flex items-center justify-center text-white font-black`}>{step}</div>
                  <h3 className={`mt-5 text-xl font-bold ${strongText}`}>{title}</h3>
                  <p className={`mt-3 text-sm leading-relaxed ${mutedText}`}>{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <footer className={`w-full border-t ${isDarkMode ? 'bg-black border-blue-900/25' : 'bg-slate-950 border-slate-800'} px-8 py-10`}>
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src={logo.src} alt="Alethia Logo" className="h-9 w-9 object-contain" />
              <span className="text-white font-black">ALETHIA</span>
            </div>
            <span className="text-sm text-slate-400">Image verification reports for contested visual narratives.</span>
          </div>
        </footer>
      </div>
    );
  };

  const renderLanding = () => {
    const lAccent = isDarkMode ? 'blue' : 'red';
    const lText = isDarkMode ? 'text-blue-500' : 'text-red-600';
    const lBg = isDarkMode ? 'bg-blue-600' : 'bg-red-600';
    const lBorder = isDarkMode ? 'border-blue-900/30' : 'border-red-500/30';
    const lGlow = isDarkMode ? 'shadow-[0_0_25px_rgba(59,130,246,0.5)]' : 'shadow-[0_0_25px_rgba(239,68,68,0.5)]';

    return (
    <div className="w-full flex flex-col items-center">
      {/* Hero Section */}
      <section className="min-h-screen w-full flex flex-col items-center justify-center relative px-8 grid-background">
        <div className={`absolute inset-0 bg-gradient-to-b from-transparent via-${isDarkMode ? '[#00050a]/50 to-[#00050a]' : 'white/50 to-white'} pointer-events-none`}></div>
        
        <div className="z-10 flex flex-col items-center max-w-4xl w-full">
          {/* Centered Logo */}
          <div className="mb-8 hover:scale-105 transition-transform duration-500 cursor-pointer group relative">
            <div className={`absolute inset-0 ${isDarkMode ? 'bg-blue-500/20' : 'bg-red-500/20'} blur-3xl rounded-full scale-75 group-hover:scale-110 transition-transform duration-700`}></div>
            <img 
              src={logo.src} 
              alt="Alethia Logo" 
              className={`h-72 w-auto object-contain relative z-10 mix-blend-screen ${!isDarkMode ? 'grayscale brightness-50' : ''}`} 
            />
          </div>

          {/* Site Name */}
          <h1 className={`text-7xl md:text-9xl font-sans tracking-[0.2em] font-black mb-4 glow-text text-center ${isDarkMode ? 'text-white' : 'text-red-950'}`}>
            ALETHIA
          </h1>

          {/* Subline */}
          <div className="mb-16 space-y-4 text-center">
            <p className={`text-xl md:text-2xl ${lText} font-mono tracking-[0.4em] uppercase font-black`}>Forensic Image Intelligence</p>
            <div className={`h-1 w-32 ${lBg} mx-auto glow-box`}></div>
          </div>

          {/* Upload Zone */}
          <div 
            onClick={() => triggerFileUpload()}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              handleFileChange(e.dataTransfer.files?.[0] || null);
            }}
            className={`w-full max-w-2xl futuristic-panel p-2 cursor-pointer transition-all duration-500 group relative ${
              isDragging 
                ? (isDarkMode ? 'ring-2 ring-blue-400 bg-blue-900/20 shadow-[0_0_50px_rgba(59,130,246,0.3)]' : 'ring-2 ring-red-400 bg-red-900/20 shadow-[0_0_50px_rgba(239,68,68,0.3)]')
                : (isDarkMode ? 'hover:bg-blue-900/5 hover:shadow-[0_0_30px_rgba(59,130,246,0.1)]' : 'hover:bg-red-50/50')
            }`}
          >
            <div className={`flex flex-col items-center justify-center p-12 border ${lBorder} transition-colors ${isDarkMode ? 'bg-black/60' : 'bg-white'}`}>
              <div className={`p-8 ${lBg} rounded-none mb-8 ${lGlow} group-hover:scale-110 transition-all duration-500 relative overflow-hidden`}>
                <div className={`absolute inset-0 bg-white/20 -translate-y-full group-hover:translate-y-full transition-transform duration-1000 ease-in-out`}></div>
                <Upload className="h-12 w-12 text-black" strokeWidth={3} />
              </div>
              
              <span className={`text-2xl font-mono font-bold uppercase tracking-[0.25em] mb-4 text-center transition-colors ${isDarkMode ? 'text-blue-300' : 'text-red-900'}`}>
                {file ? file.name : 'Initialize Data Stream'}
              </span>
              
              <span className={`text-xs font-mono uppercase tracking-[0.4em] font-black transition-colors ${isDarkMode ? 'text-blue-700' : 'text-red-400'}`}>
                Drag & drop or click to upload source
              </span>

              {/* HUD Decorations */}
              <div className={`absolute top-4 right-4 text-[10px] font-mono ${isDarkMode ? 'text-blue-500/40' : 'text-red-500/40'} animate-pulse`}>
                [SYSTEM_READY]
              </div>
              <div className="absolute bottom-4 left-4 flex gap-4 opacity-30">
                <div className="space-y-1">
                  <div className={`h-1 w-12 ${lBg}`}></div>
                  <div className={`h-1 w-8 ${lBg}`}></div>
                </div>
                <div className={`text-[10px] font-mono ${lText}`}>SCAN_PENDING</div>
              </div>
            </div>
          </div>
          
          <div className="mt-12 animate-bounce opacity-50">
            <span className={`${lText} font-mono text-xs uppercase tracking-widest`}>Scroll to explore capabilities</span>
          </div>
        </div>
      </section>

      {/* Narrative/Explanation Section */}
      <section className={`py-32 w-full flex justify-center border-y ${isDarkMode ? 'bg-zinc-950 border-blue-900/20' : 'bg-white border-red-100'}`}>
        <div className="max-w-6xl px-8 flex flex-col md:flex-row gap-16 items-center">
          <div className="w-full md:w-1/2 space-y-8">
            <div className={`inline-block px-3 py-1 ${lBg} text-[10px] font-mono font-black text-white uppercase tracking-[0.3em]`}>
              Operational Overview
            </div>
            <h2 className={`text-5xl md:text-6xl font-sans font-black uppercase leading-[0.9] tracking-tighter ${isDarkMode ? 'text-white' : 'text-red-950'}`}>
              The Forensic <br/> 
              <span className={lText}>Standard for</span> <br/>
              Visual Truth.
            </h2>
          </div>
          <div className="w-full md:w-1/2 space-y-6">
            <p className={`text-xl font-sans leading-relaxed font-medium ${isDarkMode ? 'text-blue-200' : 'text-red-900'}`}>
              Alethia is a high-performance image forensics platform built for the age of synthetic media. 
              We empower analysts, journalists, and investigators with the tools to deconstruct digital content at a neural and cryptographic level.
            </p>
            <p className={`text-lg font-sans leading-relaxed ${isDarkMode ? 'text-blue-500/70' : 'text-red-700/70'}`}>
              By merging advanced neural artifact detection with deep metadata extraction, Alethia transforms ambiguous visual data into verified forensic intelligence. Whether detecting generated deepfakes or pinpointing geospatial origins, we provide the clarity required for high-stakes decision making.
            </p>
            <div className="pt-4 flex flex-wrap gap-x-8 gap-y-4">
              {[
                { label: 'Neural Scan', icon: <Cpu className="h-4 w-4" /> },
                { label: 'Origin Mapping', icon: <Globe className="h-4 w-4" /> },
                { label: 'Bias Indexing', icon: <PieChart className="h-4 w-4" /> }
              ].map((item, idx) => (
                <div key={idx} className={`flex items-center gap-2 text-[10px] font-mono font-black uppercase tracking-[0.2em] ${isDarkMode ? 'text-blue-300' : 'text-red-900'}`}>
                  <span className={lText}>{item.icon}</span>
                  {item.label}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Forensic Pipeline (Our Process) */}
      <section id="pipeline" className={`py-40 w-full max-w-screen-2xl px-8 border-t ${isDarkMode ? 'border-blue-900/20' : 'border-red-100'}`}>
        <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
          <div className="max-w-3xl">
            <h2 className={`text-5xl md:text-7xl font-sans font-black uppercase tracking-widest mb-6 glow-text ${isDarkMode ? 'text-white' : 'text-red-950'}`}>The Forensic Pipeline</h2>
            <p className={`text-2xl font-mono uppercase tracking-wider ${lText}`}>Five stages of cryptographic and visual deconstruction.</p>
          </div>
          <div className="text-right hidden md:block">
            <p className={`text-xs font-mono mb-2 ${isDarkMode ? 'text-blue-900' : 'text-red-900'}`}>LATENCY: 420ms</p>
            <div className="flex gap-1 justify-end">
              {[...Array(12)].map((_, i) => (
                <div key={i} className={`h-4 w-1 ${lBg} ${i > 8 ? 'animate-pulse opacity-30' : ''}`}></div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 relative">
          {/* Connecting Lines (Desktop Only) */}
          <div className={`hidden md:block absolute top-[142px] left-0 w-full h-0.5 -z-10 ${isDarkMode ? 'bg-gradient-to-r from-blue-900/0 via-blue-600/50 to-blue-900/0' : 'bg-gradient-to-r from-red-900/0 via-red-600/50 to-red-900/0'}`}></div>
          
          {[
            { 
              step: "01", 
              label: "Ingestion", 
              icon: <Upload className="h-6 w-6" />,
              mock: (
                <div className={`relative h-56 w-full ${isDarkMode ? 'bg-blue-900/10 border-blue-500/20' : 'bg-red-900/5 border-red-500/20'} border overflow-hidden group-hover:border-${lAccent}-500 transition-colors flex flex-col items-center justify-center p-6`}>
                  <div className="w-full h-full bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.1)_0,transparent_70%)] absolute inset-0"></div>
                  <div className="relative z-10 flex flex-col items-center gap-6">
                    <div className={`w-20 h-20 border-2 ${isDarkMode ? 'border-blue-500' : 'border-red-500'} border-dashed animate-[spin_15s_linear_infinite] rounded-lg`}></div>
                    <div className="flex flex-col items-center gap-2">
                       <Upload className={`h-6 w-6 ${lText} animate-bounce`} />
                       <div className={`text-[10px] font-mono ${lText} tracking-tighter animate-pulse text-center uppercase`}>
                          Establishing <br/> Secure Stream
                       </div>
                    </div>
                  </div>
                  <div className={`absolute bottom-3 left-3 text-[10px] font-mono ${lText} opacity-50`}>008.23.44.12</div>
                </div>
              )
            },
            { 
              step: "02", 
              label: "Metadata", 
              icon: <Aperture className="h-6 w-6" />,
              mock: (
                <div className={`relative h-56 w-full ${isDarkMode ? 'bg-blue-900/10 border-blue-500/20' : 'bg-red-900/5 border-red-500/20'} border p-5 font-mono text-[10px] ${lText} space-y-2.5 overflow-hidden group-hover:border-${lAccent}-500 transition-colors`}>
                  {[
                    ['MAKE', 'SONY'],
                    ['MODEL', 'ILCE-7M3'],
                    ['LEN_ID', 'FE 35MM F1.8'],
                    ['ISO', '100'],
                    ['EXP', '1/125'],
                    ['GPS', '40.7128° N'],
                    ['ALT', '12.4M']
                  ].map(([key, val]) => (
                    <div key={key} className="flex justify-between border-b border-blue-500/10 pb-1">
                      <span>{key}</span>
                      <span className={isDarkMode ? 'text-white' : 'text-red-950'}>{val}</span>
                    </div>
                  ))}
                  <div className={`absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t ${isDarkMode ? 'from-black/40' : 'from-gray-100/40'} to-transparent pointer-events-none`}></div>
                </div>
              )
            },
            { 
              step: "03", 
              label: "Neural Scan", 
              icon: <Activity className="h-6 w-6" />,
              mock: (
                <div className={`relative h-56 w-full ${isDarkMode ? 'bg-blue-900/10 border-blue-500/20' : 'bg-red-900/5 border-red-500/20'} border overflow-hidden group-hover:border-${lAccent}-500 transition-colors flex flex-col justify-end p-5`}>
                   <div className={`absolute top-0 left-0 w-full h-1 ${lBg} ${isDarkMode ? 'shadow-[0_0_15px_rgba(59,130,246,1)]' : 'shadow-[0_0_15px_rgba(239,68,68,1)]'} animate-scan z-10`}></div>
                   <div className="flex flex-col h-full justify-between py-2">
                      <div className="space-y-2">
                        {[0.85, 0.4, 0.75, 0.2].map((w, i) => (
                          <div key={i} className={`h-2 w-full ${isDarkMode ? 'bg-blue-900/20' : 'bg-red-900/10'} rounded-full overflow-hidden`}>
                            <div className={`h-full ${lBg} opacity-30 animate-pulse`} style={{ width: `${w * 100}%`, animationDelay: `${i * 0.5}s` }}></div>
                          </div>
                        ))}
                      </div>
                     <div className="space-y-3">
                       <div className={`flex justify-between text-[10px] font-mono ${lText}`}>
                          <span>AI_PROBABILITY</span>
                          <span className={isDarkMode ? 'text-blue-200' : 'text-red-200'}>94.2%</span>
                       </div>
                       <div className={`h-2.5 w-full ${isDarkMode ? 'bg-blue-900/40' : 'bg-red-950/40'} rounded-full overflow-hidden`}>
                          <div className={`h-full ${lBg} w-[94%] ${lGlow}`}></div>
                       </div>
                       <div className={`text-[10px] font-mono ${lText} opacity-50 leading-tight uppercase`}>
                          GAN ARTIFACTS DETECTED <br/>
                          FFT ANOMALIES AT SCALE 0.4
                       </div>
                     </div>
                   </div>
                </div>
              )
            },
            { 
              step: "04", 
              label: "Clustering", 
              icon: <Globe className="h-6 w-6" />,
              mock: (
                <div className={`relative h-56 w-full ${isDarkMode ? 'bg-blue-900/10 border-blue-500/20' : 'bg-red-900/5 border-red-500/20'} border p-5 group-hover:border-${lAccent}-500 transition-colors flex flex-col justify-between`}>
                  <div className="flex flex-wrap gap-2.5">
                    {[...Array(12)].map((_, i) => (
                      <div key={i} className={`h-10 w-10 border ${isDarkMode ? 'border-blue-500/30' : 'border-red-500/30'} flex items-center justify-center text-[8px] font-mono ${lText} relative overflow-hidden transition-all group-hover:bg-blue-500/10`}>
                        <span className="z-10">P_{i}</span>
                        <div className={`absolute bottom-0 left-0 w-full h-1 ${lBg} opacity-30`}></div>
                      </div>
                    ))}
                  </div>
                  <div className="space-y-2">
                    <div className={`w-full text-[11px] font-mono ${lText} uppercase tracking-tighter`}>Cross-Reference Active</div>
                    <div className="space-y-1">
                      <div className={`w-full text-[10px] font-mono ${lText} opacity-50 uppercase flex justify-between`}>
                        <span>Nodes</span>
                        <span>1.2M</span>
                      </div>
                      <div className={`w-full text-[10px] font-mono ${lText} opacity-50 uppercase flex justify-between`}>
                        <span>Coverage</span>
                        <span>98.4%</span>
                      </div>
                    </div>
                  </div>
                </div>
              )
            },
            { 
              step: "05", 
              label: "Synthesis", 
              icon: <ShieldCheck className="h-6 w-6" />,
              mock: (
                <div className={`relative h-56 w-full ${isDarkMode ? 'bg-blue-900/10 border-blue-500/20' : 'bg-red-900/5 border-red-500/20'} border p-5 flex flex-col items-center justify-center group-hover:border-${lAccent}-500 transition-colors`}>
                   <div className={`p-5 border-2 ${isDarkMode ? 'border-blue-500' : 'border-red-500'} rounded-full mb-6 shadow-[0_0_30px_rgba(59,130,246,0.3)] animate-pulse`}>
                      <Check className={`h-10 w-10 ${lText}`} />
                   </div>
                   <div className="text-center space-y-2">
                     <div className={`text-sm font-mono font-black uppercase tracking-widest ${isDarkMode ? 'text-blue-100' : 'text-red-900'}`}>Report Finalized</div>
                     <div className={`text-[10px] font-mono uppercase ${lText} opacity-70`}>ALETHIA-V4-9882</div>
                     <div className={`mt-3 px-3 py-1 border ${isDarkMode ? 'border-blue-500/40 text-blue-400' : 'border-red-500/40 text-red-600'} text-[9px] font-mono mx-auto w-fit`}>
                        VERIFIED: 2026.02.02
                     </div>
                   </div>
                </div>
              )
            }
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center group">
              <div className={`mb-4 text-sm font-mono font-black tracking-widest ${lText}`}>{item.step}</div>
              <div className="w-full mb-8">
                {item.mock}
              </div>
              <h3 className={`text-base font-mono font-black uppercase tracking-widest mb-1 transition-colors ${isDarkMode ? 'text-blue-400 group-hover:text-blue-100' : 'text-red-600 group-hover:text-red-900'}`}>{item.label}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* Capabilities Section */}
      <section id="capabilities" className={`py-32 w-full px-8 border-y flex justify-center ${isDarkMode ? 'bg-zinc-950 border-blue-900/20' : 'bg-white border-red-100'}`}>
        <div className="max-w-7xl w-full">
          <div className="mb-20">
            <h2 className={`text-4xl md:text-5xl font-mono font-black uppercase tracking-[0.2em] mb-4 ${isDarkMode ? 'text-blue-900' : 'text-red-950'}`}>Forensic Capabilities</h2>
            <div className={`h-1 w-24 ${lBg}`}></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { 
                icon: <Activity className="h-10 w-10" />, 
                title: "Neural Analysis", 
                desc: "Deep-layer synthesis check for AI generation and structural deepfakes." 
              },
              { 
                icon: <Map className="h-10 w-10" />, 
                title: "Geospatial Intel", 
                desc: "Extraction of encoded GPS metadata to pinpoint digital point of origin." 
              },
              { 
                icon: <Aperture className="h-10 w-10" />, 
                title: "Exif Data", 
                desc: "Uncovering hardware signatures, lens specifications, and capture environment." 
              },
              { 
                icon: <PieChart className="h-10 w-10" />, 
                title: "Narrative Matrix", 
                desc: "Analysis of source bias and narrative context through digital source clusters." 
              }
            ].map((feat, i) => (
              <div key={i} className={`border p-8 transition-colors group relative overflow-hidden ${isDarkMode ? 'border-blue-900/30 bg-black hover:bg-blue-950/20' : 'border-red-100 bg-gray-50 hover:bg-red-50'}`}>
                <div className={`absolute top-0 left-0 w-1 h-full ${lBg}`}></div>
                <div className={`${lText} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  {feat.icon}
                </div>
                <h3 className={`text-xl font-mono font-black uppercase tracking-wider mb-4 ${isDarkMode ? 'text-blue-300' : 'text-red-950'}`}>{feat.title}</h3>
                <p className={`font-sans leading-relaxed ${isDarkMode ? 'text-blue-500/70' : 'text-red-700/70'}`}>{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Competitive Advantage (Why Alethia) */}
      <section className="py-32 w-full max-w-6xl px-8">
        <div className="text-center mb-24">
          <h2 className={`text-4xl md:text-5xl font-mono font-black uppercase tracking-[0.2em] mb-4 glow-text ${isDarkMode ? 'text-white' : 'text-red-950'}`}>Beyond Surface Search</h2>
          <p className={`font-mono text-sm uppercase tracking-[0.3em] ${isDarkMode ? 'text-blue-500/60' : 'text-red-600/60'}`}>Alethia vs. Commercial Image Engines</p>
        </div>

        <div className={`grid grid-cols-1 md:grid-cols-3 gap-0 border rounded-none overflow-hidden futuristic-panel ${isDarkMode ? 'border-blue-900/40' : 'border-red-950/20'}`}>
          {/* Header Row */}
          <div className={`col-span-1 hidden md:block p-8 border-b md:border-r ${isDarkMode ? 'bg-blue-950/20 border-blue-900/40' : 'bg-red-950/5 border-red-500/20'}`}></div>
          <div className={`col-span-1 p-8 border-b md:border-r flex flex-col items-center justify-center ${isDarkMode ? 'bg-blue-600/10 border-blue-900/40' : 'bg-red-600/10 border-red-500/20'}`}>
            <span className={`text-2xl font-sans font-black tracking-widest ${isDarkMode ? 'text-blue-100' : 'text-red-950'}`}>ALETHIA</span>
          </div>
          <div className={`col-span-1 p-8 bg-black border-b border-blue-900/40 flex flex-col items-center justify-center opacity-60`}>
            <span className="text-xl font-mono font-bold tracking-widest text-gray-500">STANDARD SEARCH</span>
          </div>

          {[
            { 
              feature: "Image Information", 
              alethia: "Neural synthetic scan for AI/Deepfake detection.", 
              standard: "Binary match only. No integrity check.",
              icon: <ShieldCheck className="h-5 w-5" />
            },
            { 
              feature: "Metadata Depth", 
              alethia: "Cryptographic EXIF deconstruction and GPS mapping.", 
              standard: "Basic image dimensions and resolution data.",
              icon: <Aperture className="h-5 w-5" />
            },
            { 
              feature: "Image Summary", 
              alethia: "Bias matrix and cluster narrative indexing.", 
              standard: "List of visually similar images only.",
              icon: <PieChart className="h-5 w-5" />
            },
            { 
              feature: "Image Analysis", 
              alethia: "LLM-driven analysis of visual context and origins.", 
              standard: "Auto-generated tags (e.g., 'outdoor', 'mountain').",
              icon: <Activity className="h-5 w-5" />
            },
            { 
              feature: "Target Use Case", 
              alethia: "Intelligence, Law Enforcement, OSINT, Media.", 
              standard: "Consumer shopping, stock photo discovery.",
              icon: <Scan className="h-5 w-5" />
            }
          ].map((row, i) => (
            <React.Fragment key={i}>
              <div className={`p-6 md:p-8 border-b md:border-r flex items-center gap-4 ${isDarkMode ? 'bg-black/40 border-blue-900/20' : 'bg-white border-red-100'}`}>
                <div className={lText}>{row.icon}</div>
                <span className={`text-sm font-mono font-black uppercase tracking-wider ${isDarkMode ? 'text-blue-300' : 'text-red-900'}`}>{row.feature}</span>
              </div>
              <div className={`p-6 md:p-8 border-b md:border-r text-sm font-sans leading-relaxed ${isDarkMode ? 'bg-blue-950/5 border-blue-900/20 text-blue-100' : 'bg-red-50 border-red-100 text-red-950'}`}>
                <div className={`md:hidden text-[10px] font-mono mb-2 font-black uppercase ${lText}`}>Alethia Analysis:</div>
                {row.alethia}
              </div>
              <div className={`p-6 md:p-8 border-b text-sm font-sans leading-relaxed opacity-60 ${isDarkMode ? 'bg-black/60 border-blue-900/20 text-gray-400' : 'bg-gray-100 border-red-100 text-gray-600'}`}>
                <div className="md:hidden text-[10px] font-mono text-gray-600 mb-2 font-black uppercase">Standard Search:</div>
                {row.standard}
              </div>
            </React.Fragment>
          ))}
        </div>
      </section>

      {/* Mission Section */}
      <section className={`py-32 w-full border-t flex justify-center ${isDarkMode ? 'bg-[#00050a] border-blue-900/20' : 'bg-slate-50 border-red-100'}`}>
        <div className="max-w-4xl px-8 text-center space-y-12">
          <Scan className={`h-20 w-20 mx-auto animate-pulse ${lText}`} />
          <h2 className={`text-4xl font-mono font-black uppercase tracking-[0.3em] ${isDarkMode ? 'text-blue-900/40' : 'text-red-950'}`}>Veritas in Luce</h2>
          <p className={`text-xl md:text-2xl font-sans leading-relaxed font-light ${isDarkMode ? 'text-blue-300' : 'text-red-900'}`}>
            Alethia utilizes advanced forensic algorithms to strip away the layers of digital manipulation, 
            providing clarity in an era of synthetic media and deep-level disinformation.
          </p>
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className={`px-10 py-5 ${lBg} text-black font-mono font-black uppercase tracking-widest hover:opacity-90 transition-all ${isDarkMode ? 'shadow-[0_10px_30px_rgba(59,130,246,0.3)]' : 'shadow-[0_10px_30px_rgba(239,68,68,0.3)]'}`}
          >
            Start Investigation
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className={`w-full py-12 px-8 border-t text-center ${isDarkMode ? 'bg-black border-blue-900/20' : 'bg-red-950 border-red-950 shadow-[0_-10px_50px_rgba(239,68,68,0.1)]'}`}>
        <div className="flex flex-col items-center gap-6">
          <div className="flex gap-8">
            <span className={`text-xs font-mono font-black ${isDarkMode ? 'text-blue-900' : 'text-red-400'}`}>ALETHIA_V2.0.4</span>
            <span className={`text-xs font-mono font-black ${isDarkMode ? 'text-blue-900' : 'text-red-400'}`}>BUILD_ID_88419</span>
            <span className={`text-xs font-mono font-black ${isDarkMode ? 'text-blue-900' : 'text-red-400'}`}>SYSTEM_STATUS_NOMINAL</span>
          </div>
          <p className={`text-[10px] font-mono uppercase tracking-[0.5em] font-black ${isDarkMode ? 'text-blue-500/30' : 'text-red-200/50'}`}>
            © 2026 ALETHIA FORENSIC INTELLIGENCE. ALL RIGHTS RESERVED.
          </p>
        </div>
      </footer>
    </div>
    );
  };

  const renderResults = () => {
    if (!result) return null;

    const {
      image_description,
      image_url,
      biases = {},
      source_clusters = {},
      earliest_date,
      total_matches,
      exif_data = {},
      geoclip_analysis,
      location_analysis,
      ai_analysis = {}, 
    } = result;

    const verificationStatusByLink = new globalThis.Map(
      (result.source_verification?.sources || []).map((item) => [item.link, item])
    );
    const candidateSourceClusters = (result.candidate_sources || []).reduce<Record<string, any[]>>((acc, item) => {
      const domain = item.source_domain || item.source || 'unknown source';
      const verification = verificationStatusByLink.get(item.link);
      if (!acc[domain]) acc[domain] = [];
      acc[domain].push({
        link: item.link,
        title: `${verification?.image_present ? `[${verification.image_present.replace('_', ' ')}] ` : '[candidate] '}${item.title || item.provider || item.link}`,
      });
      return acc;
    }, {});
    const displayedSourceClusters = showCandidateSources ? candidateSourceClusters : source_clusters;
    const verifiedSourceCount = result.reverse_search_links?.length || 0;
    const candidateSourceCount = result.candidate_sources?.length || 0;

    // --- Analysis Data Derivation ---
    
    let formattedVerdict = "UNKNOWN";
    if (ai_analysis.verdict === 'human') formattedVerdict = "VERIFIED HUMAN";
    else if (ai_analysis.verdict === 'ai_generated') formattedVerdict = "AI GENERATED";
    else if (ai_analysis.verdict === 'deepfake') formattedVerdict = "DEEPFAKE DETECTED";
    else if (ai_analysis.verdict) formattedVerdict = ai_analysis.verdict.toUpperCase();

    const aiScore = (ai_analysis.ai_id_confidence || 0) * 100;
    const humanScore = (ai_analysis.human_confidence || 0) * 100;
    const deepfakeScore = (ai_analysis.deepfake_confidence || 0) * 100;
    const nsfwDetected = ai_analysis.nsfw_is_detected || false;

    const imageUrl = image_url.startsWith('http') ? image_url : `http://127.0.0.1:8000${image_url}`;
    const finalEarliestDate = getEarliestDate(earliest_date, exif_data['DateTime Original']);

    const gpsLocation = exif_data['GPS Location'];
    const hasLocation = gpsLocation && gpsLocation !== 'N/A' && gpsLocation.trim() !== '';
    const hasGeoClipRegion = Boolean(geoclip_analysis?.points?.length);

    // Dynamic Accent Color for Results
    const accent = isDarkMode ? 'blue' : 'red';
    const accentText = isDarkMode ? 'text-blue-400' : 'text-red-600';
    const accentTextLight = isDarkMode ? 'text-blue-400' : 'text-red-400';
    const accentBg = isDarkMode ? 'bg-blue-600' : 'bg-red-600';
    const accentBgLight = isDarkMode ? 'bg-blue-500/20' : 'bg-red-500/10';
    const accentBorder = isDarkMode ? 'border-blue-900/40' : 'border-red-100';
    const accentRing = isDarkMode ? 'ring-blue-500/20' : 'ring-red-500/20';
    const accentShadow = isDarkMode ? 'shadow-[0_0_15px_rgba(59,130,246,0.4)]' : 'shadow-[0_0_15px_rgba(239,68,68,0.3)]';

    // Header Style Constant
    const headerStyle = `flex items-center gap-4 font-mono uppercase tracking-[0.2em] text-2xl font-black transition-colors ${
      isDarkMode 
        ? 'text-blue-400 drop-shadow-[0_0_10px_rgba(96,165,250,0.5)]' 
        : 'text-red-600 drop-shadow-[0_0_10px_rgba(239,68,68,0.3)]'
    }`;

    return (
      <div ref={reportRef} id="alethia-report" className={`w-full transition-colors duration-500 ${isDarkMode ? 'bg-black' : 'bg-white'}`}>
        <div className="max-w-[1900px] mx-auto pt-60 pb-20 px-6">
          {/* Action Row */}
          <div data-export-remove="true" className="flex flex-wrap justify-center gap-5 mb-24">
            <button
              onClick={() => triggerFileUpload()}
              className={`px-16 py-6 ${accentBg} hover:opacity-90 text-white font-black flex items-center gap-4 transition-all border-2 ${
                isDarkMode 
                  ? 'border-blue-400 shadow-[0_0_30px_rgba(59,130,246,0.3)]' 
                  : 'border-red-600 shadow-[0_0_30px_rgba(239,68,68,0.3)]'
              } font-mono uppercase tracking-[0.25em] active:scale-95 text-xl`}
            >
              <Upload className="h-8 w-8" />
              Upload New Image
            </button>
            <button
              onClick={handleDownloadReportImage}
              disabled={Boolean(exportingFormat)}
              className={`px-8 py-5 border-2 font-mono uppercase tracking-[0.2em] text-sm font-black flex items-center gap-3 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                isDarkMode
                  ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                  : 'border-red-300 text-red-700 hover:bg-red-50'
              }`}
            >
              <Download className={`h-5 w-5 ${exportingFormat === 'png' ? 'animate-pulse' : ''}`} />
              {exportingFormat === 'png' ? 'Preparing Image...' : 'Download Image'}
            </button>
            <button
              onClick={handleDownloadReportPdf}
              disabled={Boolean(exportingFormat)}
              className={`px-8 py-5 border-2 font-mono uppercase tracking-[0.2em] text-sm font-black flex items-center gap-3 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                isDarkMode
                  ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                  : 'border-red-300 text-red-700 hover:bg-red-50'
              }`}
            >
              <FileText className={`h-5 w-5 ${exportingFormat === 'pdf' ? 'animate-pulse' : ''}`} />
              {exportingFormat === 'pdf' ? 'Preparing PDF...' : 'Export PDF'}
            </button>
          </div>

          {/* UNIFIED FORENSIC DASHBOARD */}
          <div className={`p-8 lg:p-14 border-2 transition-all duration-500 ${
            isDarkMode 
              ? 'bg-zinc-950 border-blue-500/40 shadow-[0_0_50px_rgba(59,130,246,0.1)]' 
              : 'bg-white border-blue-200 shadow-[0_0_50px_rgba(59,130,246,0.15)]'
          }`}>
            <div className="grid grid-cols-12 gap-12 lg:gap-16 items-stretch">
              
              {/* Visual Source Data */}
              <div className="col-span-12 lg:col-span-6 flex flex-col space-y-8">
                  <div className={headerStyle}>
                      <Layers className="h-8 w-8" />
                      Visual Source Data
                  </div>
                  <div className={`p-2 flex items-center justify-center ring-1 ${accentRing} w-full h-[750px] overflow-hidden group relative transition-colors ${isDarkMode ? 'bg-black' : 'bg-slate-50'}`}>
                      <img 
                        src={imageUrl} 
                        alt="Analyzed content" 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.05]" 
                      />
                  </div>
              </div>

              {/* Image Information + Source List */}
              <div className="col-span-12 lg:col-span-6 grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
                  <section className="flex flex-col space-y-8">
                      <div className={headerStyle}>
                          <ShieldCheck className="h-8 w-8" />
                          Image Information
                      </div>
                      <div className={`p-10 h-[720px] flex flex-col transition-all duration-500 border ${
                        isDarkMode 
                          ? 'bg-black border-blue-900/30 hover:border-blue-500/40 hover:shadow-[0_0_30px_rgba(59,130,246,0.1)]' 
                          : 'bg-white border-red-600/10 hover:border-red-300 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)]'
                      }`}>
                          <div className={`flex justify-between items-center border-b pb-5 mb-6 transition-colors ${isDarkMode ? 'border-blue-900/40' : 'border-red-600/10'}`}>
                            <span className={`text-base font-black ${accentText} font-mono uppercase tracking-[0.25em]`}>Verified Matches</span>
                            <span className={`text-4xl font-mono font-black transition-colors ${isDarkMode ? 'text-white' : 'text-black'}`}>{total_matches || 0}</span>
                          </div>

                          <div className="flex-1 space-y-8 pr-2 pb-6">
                            <div>
                              <h4 className={`${accentText} font-mono text-sm font-black uppercase tracking-[0.3em] mb-4 flex items-center gap-3`}>
                                <Aperture className="h-4 w-4" />
                                Exif Data
                              </h4>
                              <dl className="space-y-4">
                                {[
                                  { label: 'Device', value: exif_data.Model || exif_data.Make ? `${exif_data.Make || ''} ${exif_data.Model || ''}` : null },
                                  { label: 'Iris', value: exif_data['F Number'] || exif_data.Aperture },
                                  { label: 'Shutter', value: exif_data.Exposure || exif_data.ExposureTime },
                                  { label: 'ISO', value: exif_data.ISO }
                                ].map((spec) => (
                                  <div key={spec.label} className={`flex justify-between items-center border-b pb-3 transition-colors last:border-0 ${isDarkMode ? 'border-blue-900/20' : 'border-red-600/10'}`}>
                                    <dt className={`text-sm ${accentText} font-mono uppercase font-black tracking-widest`}>{spec.label}</dt>
                                    <dd className={`text-base font-mono truncate max-w-[240px] transition-colors font-bold ${isDarkMode ? 'text-white' : 'text-black'}`}>{spec.value || 'VOID'}</dd>
                                  </div>
                                ))}
                              </dl>
                            </div>

                            <div className="pb-8">
                              <h4 className={`${accentText} font-mono text-sm font-black uppercase tracking-[0.3em] mb-4 flex items-center gap-3`}>
                                <Cpu className="h-4 w-4" />
                                AI or Not
                              </h4>
                              <dl className="space-y-4">
                                {[
                                  { label: 'Verdict', value: formattedVerdict },
                                  { label: 'AI Generated', value: `${aiScore.toFixed(1)}%` },
                                  { label: 'Human', value: `${humanScore.toFixed(1)}%` },
                                  { label: 'Deepfake Tech', value: `${deepfakeScore.toFixed(1)}%` },
                                  { label: 'Content Filter', value: nsfwDetected ? 'RESTRICTED' : 'SECURE' }
                                ].map((item) => (
                                  <div key={item.label} className={`flex justify-between items-center border-b pb-3 transition-colors last:border-0 ${isDarkMode ? 'border-blue-900/20' : 'border-red-600/10'}`}>
                                    <dt className={`text-sm ${accentText} font-mono uppercase font-black tracking-widest`}>{item.label}</dt>
                                    <dd className={`text-base font-mono transition-colors font-bold ${isDarkMode ? 'text-white' : 'text-black'}`}>{item.value}</dd>
                                  </div>
                                ))}
                              </dl>
                            </div>
                          </div>
                      </div>
                  </section>

                  <section className="flex flex-col space-y-8">
                      <div className={headerStyle}>
                          <Search className="h-8 w-8" />
                          Source List
                      </div>
                      <div className={`p-6 h-[720px] overflow-y-auto custom-scrollbar ring-1 transition-colors ${accentRing} ${isDarkMode ? 'bg-black/40' : 'bg-red-600/5'}`}>
                        <div className={`mb-5 flex flex-col gap-3 border-b pb-5 ${isDarkMode ? 'border-blue-900/30' : 'border-red-100'}`}>
                          <div className={`flex items-center justify-between gap-4 font-mono uppercase tracking-[0.18em] text-[10px] font-black ${isDarkMode ? 'text-blue-400' : 'text-red-700'}`}>
                            <span>{showCandidateSources ? 'All Candidate Sources' : 'Verified Evidence Sources'}</span>
                            <span>{showCandidateSources ? candidateSourceCount : verifiedSourceCount}</span>
                          </div>
                          <button
                            onClick={() => setShowCandidateSources((value) => !value)}
                            className={`w-full py-3 border font-mono uppercase tracking-[0.18em] text-[10px] font-black transition-colors ${
                              isDarkMode
                                ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                                : 'border-red-300 text-red-700 hover:bg-red-50'
                            }`}
                          >
                            {showCandidateSources ? 'Show Verified Sources Only' : `View All Candidate Sources (${candidateSourceCount})`}
                          </button>
                        </div>
                        <SourceList data={displayedSourceClusters} isDarkMode={isDarkMode} accentColor={isDarkMode ? 'blue' : 'red'} />
                        {false && (
                        <button
                          onClick={handleLoadMoreSources}
                          disabled={isLoadingMoreSources}
                          className={`mt-8 w-full py-4 border font-mono uppercase tracking-[0.2em] text-xs font-black transition-colors disabled:opacity-50 ${
                            isDarkMode
                              ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                              : 'border-red-300 text-red-700 hover:bg-red-50'
                          }`}
                        >
                          {isLoadingMoreSources ? 'Loading Sources...' : 'Load More Sources'}
                        </button>
                        )}
                      </div>
                  </section>
              </div>

              {/* Image Analysis Cluster */}
              <div className="col-span-12 xl:col-span-7 flex flex-col space-y-8">
                  <div className={headerStyle}>
                    <Scan className="h-8 w-8" />
                    Image Analysis
                  </div>
                  <div className={`overflow-hidden border-2 transition-all duration-500 ${
                    isDarkMode 
                      ? 'bg-zinc-950 border-blue-900/40 hover:border-blue-500/50 hover:shadow-[0_0_30px_rgba(59,130,246,0.1)]' 
                      : 'bg-slate-50 border-red-100 hover:border-red-300 hover:shadow-[0_0_30px_rgba(239,68,68,0.1)]'
                  }`}>
                    <div className="grid grid-cols-1">
                      
                      <div className={`p-10 border-b transition-colors ${isDarkMode ? 'border-blue-900/40' : 'border-red-100'}`}>
                          <div className={`${accentText} font-mono uppercase tracking-widest font-black text-sm mb-8 flex items-center gap-4`}>
                            <PieChart className="h-6 w-6" />
                            Verified Source Bias Matrix
                          </div>
                          <div className="h-[520px] flex items-center justify-center overflow-hidden">
                            {Object.keys(biases).filter(k => !k.startsWith('_')).length > 0 ? (
                              <BiasPieChart data={biases} height={430} isDarkMode={isDarkMode} geminiPoliticalLean={result.gemini_political_lean} />
                            ) : (
                              <div className="flex flex-col items-center justify-center p-12 text-center h-full">
                                <PieChart className={`h-16 w-16 mb-6 opacity-20 ${isDarkMode ? 'text-blue-500' : 'text-red-500'}`} />
                                <div className={`font-mono uppercase tracking-[0.2em] text-sm font-black ${isDarkMode ? 'text-blue-900' : 'text-red-900'}`}>
                                  Narrative Data Masked
                                </div>
                                <div className={`text-xs font-mono uppercase tracking-widest mt-2 opacity-40 ${isDarkMode ? 'text-blue-500' : 'text-red-500'}`}>
                                  Refining neural signals...
                                </div>
                              </div>
                            )}
                          </div>
                      </div>

                      <div className={`p-10 border-b transition-colors ${isDarkMode ? 'border-blue-900/40' : 'border-red-100'}`}>
                          <div className={`${accentText} font-mono uppercase tracking-widest font-black text-sm mb-8 flex items-center gap-4`}>
                            <Map className="h-6 w-6" />
                            Location Evidence
                          </div>
                          {location_analysis && (
                            <div
                              title={location_analysis.reason}
                              className={`mb-5 inline-flex items-center gap-3 border px-4 py-2 font-mono text-[10px] uppercase tracking-[0.18em] font-black ${
                                isDarkMode
                                  ? 'border-blue-500/30 bg-blue-950/20 text-blue-300'
                                  : 'border-red-200 bg-red-50 text-red-700'
                              }`}
                            >
                              {location_analysis.label}
                            </div>
                          )}
                          <div className={`h-[620px] relative overflow-hidden ring-1 ${accentRing} ${isDarkMode ? 'bg-black' : 'bg-black/20'}`}>
                            {(location_analysis?.location_sources?.length ?? 0) > 0 || hasGeoClipRegion ? (
                              <MultiSourceMap
                                locationAnalysis={location_analysis}
                                geoclipAnalysis={geoclip_analysis}
                                isDarkMode={isDarkMode}
                              />
                            ) : (
                              <div className="absolute inset-0 flex flex-col items-center justify-center">
                                <Map className={`h-12 w-12 mb-5 transition-colors ${isDarkMode ? 'text-blue-900/40' : 'text-red-200'}`} />
                                <span className={`text-sm font-mono uppercase tracking-[0.2em] font-black transition-colors ${isDarkMode ? 'text-blue-900' : 'text-red-300'}`}>No Location Signal</span>
                              </div>
                            )}
                          </div>
                          {/* Multi-source location legend */}
                          {(location_analysis?.location_sources?.length ?? 0) > 0 && (
                            <div className={`mt-5 border p-5 ${isDarkMode ? 'bg-black/80 border-blue-500/30 text-blue-100' : 'bg-white border-red-200 text-slate-900'}`}>
                              <div className={`${accentText} font-mono uppercase tracking-[0.22em] text-xs font-black mb-3`}>Location Sources</div>
                              <div className="flex flex-col gap-2 text-sm">
                                {location_analysis?.device_location?.available && (
                                  <div className="flex items-center gap-2">
                                    <span className="inline-block w-4 h-4 rounded-full border-2 border-blue-500 border-dashed shrink-0" />
                                    <span><span className="font-mono font-bold">EXIF Device GPS</span> — where the camera was: {location_analysis.device_location.display || 'coordinates available'}</span>
                                  </div>
                                )}
                                {location_analysis?.gemini_coordinates && (
                                  <div className="flex items-center gap-2">
                                    <span className="inline-block w-4 h-4 rounded-full bg-orange-500 shrink-0" />
                                    <span><span className="font-mono font-bold">AI-inferred</span> — subject location: {location_analysis.gemini_location?.name || 'inferred'} ({location_analysis.gemini_location?.confidence || '?'} confidence)</span>
                                  </div>
                                )}
                                {location_analysis?.geoclip_used && geoclip_analysis && (
                                  <div className="flex items-center gap-2">
                                    <span className="inline-block w-4 h-4 rounded-full bg-yellow-400 shrink-0" />
                                    <span><span className="font-mono font-bold">GeoCLIP</span> — visual ML estimate: {geoclip_analysis.confidence_percent?.toFixed(1)}% avg confidence</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                      </div>

                    </div>
                  </div>
              </div>

              {/* Visual Narrative Analysis */}
              <div className="col-span-12 xl:col-span-5 flex flex-col space-y-8">
                  <div className={headerStyle}>
                      <Scan className="h-8 w-8" />
                      Event Verification Report
                  </div>
                  <div className={`p-12 flex flex-col relative box-border transition-all duration-500 h-full border ${
                    isDarkMode 
                      ? 'bg-black border-blue-900/40 shadow-[0_0_50px_rgba(59,130,246,0.05)] hover:border-blue-500/50 hover:shadow-[0_0_40px_rgba(59,130,246,0.1)]' 
                      : 'bg-white border-red-50 shadow-xl hover:border-red-300 hover:shadow-[0_0_40px_rgba(239,68,68,0.15)]'
                  }`}>
                      <div className="flex-1 overflow-y-auto custom-scrollbar pr-8">
                        {/* ImageClassificationPanel — replaces plain first impression box */}
                        {(result.gemini_subject_category || result.image_first_impression) && (
                          <ImageClassificationPanel
                            category={result.gemini_subject_category}
                            firstImpression={result.image_first_impression}
                            keyPhrases={result.gemini_key_phrases}
                            isScreenshot={result.gemini_is_screenshot}
                            aiGenerationSignals={result.gemini_ai_generation_signals}
                            isDarkMode={isDarkMode}
                          />
                        )}
                        <div className={`text-2xl leading-[1.8] font-sans transition-colors ${isDarkMode ? 'text-zinc-300' : 'text-slate-800'} ${!isDescriptionExpanded ? 'line-clamp-[25]' : ''}`}>
                            <span className={`${accentText} font-mono font-bold mr-4 text-3xl`}>[ID-001]</span>
                            {image_description 
                              ? renderNarrativeAnalysis(image_description, isDarkMode)
                              : "Processing visual data nodes... Extracting narrative metadata."
                            }
                        </div>
                      </div>
                          <div className={`mt-8 pt-8 flex justify-center items-center bg-transparent border-t-2 transition-colors ${isDarkMode ? 'border-blue-900/40' : 'border-red-600/10'}`}>
                          <button 
                            onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
                            className={`${accentText} hover:opacity-80 text-base font-mono font-black uppercase tracking-widest flex items-center gap-4 transition-colors focus:outline-none`}
                          >
                            {isDescriptionExpanded ? '[ CLOSE REPORT ]' : '[ READ FULL REPORT ]'}
                          </button>
                      </div>
                  </div>
              </div>

              {/* Report Assistant */}
              {false && (
              <div className="col-span-12 flex flex-col space-y-8">
                <div className={headerStyle}>
                  <MessageCircle className="h-8 w-8" />
                  Report Assistant
                </div>
                <div className={`grid grid-cols-1 xl:grid-cols-2 gap-10 p-10 border transition-colors ${
                  isDarkMode
                    ? 'bg-black border-blue-900/40'
                    : 'bg-white border-red-100'
                }`}>
                  <section className="space-y-6">
                    <div className="flex items-center justify-between gap-6">
                      <h4 className={`${accentText} font-mono text-sm font-black uppercase tracking-[0.3em] flex items-center gap-3`}>
                        <Sparkles className="h-5 w-5" />
                        Source Context
                      </h4>
                      <button
                        onClick={handleAnalyzeSources}
                        disabled={isAnalyzingSources}
                        className={`px-5 py-3 border font-mono uppercase tracking-[0.2em] text-xs font-black transition-colors disabled:opacity-50 ${
                          isDarkMode
                            ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                            : 'border-red-300 text-red-700 hover:bg-red-50'
                        }`}
                      >
                        {isAnalyzingSources ? 'Analyzing...' : 'Analyze Sources'}
                      </button>
                    </div>

                    {sourceContext ? (
                      <div className="space-y-5">
                        <div className={`p-5 border ${isDarkMode ? 'border-blue-900/30 bg-blue-950/10' : 'border-red-100 bg-red-50/40'}`}>
                          <div className={`${accentText} font-mono uppercase tracking-[0.25em] text-xs font-black mb-3`}>
                            {sourceContext?.overall_category || 'unknown'}
                          </div>
                          <p className={`text-base leading-relaxed ${isDarkMode ? 'text-zinc-300' : 'text-slate-700'}`}>
                            {sourceContext?.overview || sourceContext?.why_it_matters}
                          </p>
                        </div>
                        <div className="max-h-[420px] overflow-y-auto custom-scrollbar space-y-4 pr-3">
                          {(sourceContext?.source_analyses || []).map((item, index) => (
                            <div key={`${item.url}-${index}`} className={`p-5 border ${isDarkMode ? 'border-blue-900/20' : 'border-red-100'}`}>
                              <div className="flex justify-between gap-4 mb-3">
                                <span className={`${accentText} font-mono uppercase text-xs tracking-[0.2em] font-black`}>
                                  {item.category || 'unknown'}
                                </span>
                                <span className={`font-mono text-xs ${isDarkMode ? 'text-blue-700' : 'text-red-400'}`}>
                                  {Math.round((item.confidence || 0) * 100)}%
                                </span>
                              </div>
                              <a href={item.url} target="_blank" rel="noopener noreferrer" className={`block font-mono text-sm break-all mb-3 ${isDarkMode ? 'text-blue-300' : 'text-red-700'}`}>
                                {item.domain || item.url}
                              </a>
                              <p className={`text-sm leading-relaxed ${isDarkMode ? 'text-zinc-400' : 'text-slate-700'}`}>
                                {item.summary}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className={`p-8 border border-dashed text-center font-mono uppercase tracking-[0.2em] text-xs ${isDarkMode ? 'border-blue-900/40 text-blue-800' : 'border-red-100 text-red-300'}`}>
                        Source context pending
                      </div>
                    )}
                  </section>

                  <section className="space-y-6">
                    <h4 className={`${accentText} font-mono text-sm font-black uppercase tracking-[0.3em] flex items-center gap-3`}>
                      <MessageCircle className="h-5 w-5" />
                      Ask This Report
                    </h4>
                    <textarea
                      value={chatQuestion}
                      onChange={(event) => setChatQuestion(event.target.value)}
                      rows={5}
                      className={`w-full p-5 border font-mono text-sm outline-none resize-none transition-colors ${
                        isDarkMode
                          ? 'bg-black border-blue-900/40 text-blue-200 placeholder:text-blue-900 focus:border-blue-500'
                          : 'bg-white border-red-100 text-slate-900 placeholder:text-red-300 focus:border-red-400'
                      }`}
                      placeholder="Ask about the findings, sources, bias, metadata, dates, or why the report matters."
                    />
                    <button
                      onClick={handleAskReport}
                      disabled={isAskingReport || !chatQuestion.trim()}
                      className={`w-full py-4 border font-mono uppercase tracking-[0.2em] text-xs font-black flex items-center justify-center gap-3 transition-colors disabled:opacity-50 ${
                        isDarkMode
                          ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                          : 'border-red-300 text-red-700 hover:bg-red-50'
                      }`}
                    >
                      <Send className="h-4 w-4" />
                      {isAskingReport ? 'Answering...' : 'Ask Report'}
                    </button>
                    {chatAnswer && (
                      <div className={`p-6 border max-h-[420px] overflow-y-auto custom-scrollbar ${isDarkMode ? 'border-blue-900/30 bg-blue-950/10 text-zinc-300' : 'border-red-100 bg-red-50/40 text-slate-700'}`}>
                        <div className={`${accentText} font-mono uppercase tracking-[0.25em] text-xs font-black mb-4`}>
                          Answer
                        </div>
                        <p className="whitespace-pre-wrap leading-relaxed text-base">{chatAnswer}</p>
                      </div>
                    )}
                  </section>
                </div>
              </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <main className={`min-h-screen transition-colors duration-500 overflow-x-hidden ${isDarkMode ? 'dark-theme' : 'light-theme'} ${isDarkMode ? 'bg-[#00050a] text-blue-400' : 'bg-slate-50 text-slate-800'}`}>
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFileChange(e.target.files?.[0] || null)}
      />
      {/* TopBar only shown in results mode */}
      {result && (
        <div className={`transition-all duration-500 ${showTopBar ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'}`}>
          <TopBar 
            isDarkMode={isDarkMode} 
            onThemeToggle={() => setIsDarkMode(!isDarkMode)} 
            onReset={handleReset}
            showLogo={true}
          />
        </div>
      )}

      {result && !isLoading && (
        <>
          <button
            onClick={() => setIsAssistantOpen(true)}
            className={`fixed right-6 top-1/2 -translate-y-1/2 z-[70] p-5 border shadow-2xl transition-all hover:scale-105 ${
              isDarkMode
                ? 'bg-black/90 border-blue-500/50 text-blue-300 shadow-blue-500/10'
                : 'bg-white border-red-200 text-red-700 shadow-red-500/10'
            }`}
            title="Open report assistant"
          >
            <MessageCircle className="h-7 w-7" />
          </button>

          {isAssistantOpen && (
            <div className="fixed inset-0 z-[90] flex justify-end">
              <button
                className="absolute inset-0 bg-black/50"
                onClick={() => setIsAssistantOpen(false)}
                aria-label="Close report assistant overlay"
              />
              <aside className={`relative h-full w-full max-w-xl overflow-y-auto border-l p-8 ${isDarkMode ? 'bg-black border-blue-900/50 text-zinc-200' : 'bg-white border-red-100 text-slate-800'}`}>
                <div className="flex items-center justify-between gap-6 mb-8">
                  <div className={`font-mono uppercase tracking-[0.25em] text-sm font-black flex items-center gap-3 ${isDarkMode ? 'text-blue-300' : 'text-red-700'}`}>
                    <MessageCircle className="h-5 w-5" />
                    Report Assistant
                  </div>
                  <button
                    onClick={() => setIsAssistantOpen(false)}
                    className={`p-3 border ${isDarkMode ? 'border-blue-900/40 text-blue-300' : 'border-red-100 text-red-700'}`}
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-8">
                  <section className="space-y-4">
                    <button
                      onClick={handleAnalyzeSources}
                      disabled={isAnalyzingSources}
                      className={`w-full py-4 border font-mono uppercase tracking-[0.2em] text-xs font-black transition-colors disabled:opacity-50 ${
                        isDarkMode
                          ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                          : 'border-red-300 text-red-700 hover:bg-red-50'
                      }`}
                    >
                      {isAnalyzingSources ? 'Analyzing Sources...' : 'Analyze Sources'}
                    </button>
                    <button
                      onClick={handleValidateSources}
                      disabled={isValidatingSources}
                      className={`w-full py-4 border font-mono uppercase tracking-[0.2em] text-xs font-black transition-colors disabled:opacity-50 ${
                        isDarkMode
                          ? 'border-amber-500/40 text-amber-300 hover:bg-amber-950/20'
                          : 'border-amber-300 text-amber-700 hover:bg-amber-50'
                      }`}
                    >
                      {isValidatingSources ? 'Validating Sources...' : 'Validate Sources'}
                    </button>
                    {sourceContext && (
                      <div className={`p-5 border ${isDarkMode ? 'border-blue-900/30 bg-blue-950/10' : 'border-red-100 bg-red-50/40'}`}>
                        <div className={`font-mono uppercase tracking-[0.22em] text-xs font-black mb-3 ${isDarkMode ? 'text-blue-300' : 'text-red-700'}`}>
                          {sourceContext.overall_category || 'unknown'}
                        </div>
                        <p className="text-sm leading-relaxed">{sourceContext.overview || sourceContext.why_it_matters}</p>
                      </div>
                    )}
                    {result?.source_verification && (
                      <div className={`p-5 border space-y-4 ${isDarkMode ? 'border-blue-500/30 bg-blue-950/10' : 'border-red-200 bg-red-50/50'}`}>
                        <div className={`font-mono uppercase tracking-[0.22em] text-xs font-black ${isDarkMode ? 'text-blue-300' : 'text-red-800'}`}>
                          Provider Image Checks
                        </div>
                        <div className="grid grid-cols-3 gap-3">
                          {[
                            ['Checked', result.source_verification.summary?.checked ?? 0],
                            ['Confirmed', result.source_verification.summary?.confirmed ?? 0],
                            ['Probable', result.source_verification.summary?.probable ?? 0],
                            ['Not Confirmed', result.source_verification.summary?.not_confirmed ?? 0],
                            ['Uncertain', result.source_verification.summary?.uncertain ?? 0],
                            ['Failed', result.source_verification.summary?.failed ?? 0],
                          ].map(([label, value]) => (
                            <div key={label} className={`p-3 border ${isDarkMode ? 'border-blue-900/30 bg-black/30' : 'border-red-100 bg-white'}`}>
                              <div className={`text-[10px] font-mono uppercase ${isDarkMode ? 'text-blue-700' : 'text-red-400'}`}>{label}</div>
                              <div className={`mt-1 text-lg font-black ${isDarkMode ? 'text-blue-100' : 'text-slate-900'}`}>{value}</div>
                            </div>
                          ))}
                        </div>
                        <div className="max-h-52 overflow-y-auto custom-scrollbar space-y-3">
                          {(result.source_verification.sources || []).slice(0, 8).map((item, index) => (
                            <div key={`${item.link}-${index}`} className={`p-3 border ${isDarkMode ? 'border-blue-900/20 bg-black/20' : 'border-red-100 bg-white'}`}>
                              <div className={`font-mono text-[10px] uppercase tracking-[0.18em] font-black mb-2 ${item.image_present === 'confirmed' || item.image_present === 'probable' ? (isDarkMode ? 'text-blue-300' : 'text-red-700') : 'text-amber-500'}`}>
                                {item.image_present.replace('_', ' ')}
                                {typeof item.hash_distance === 'number' ? ` | dHash ${item.hash_distance}` : ''}
                              </div>
                              <div className="text-xs break-all mb-2">{item.domain || item.link}</div>
                              <p className="text-xs leading-relaxed">{item.evidence_summary}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {sourceValidation && (
                      <div className={`p-5 border space-y-4 ${isDarkMode ? 'border-amber-500/30 bg-amber-950/10' : 'border-amber-200 bg-amber-50/50'}`}>
                        <div className={`font-mono uppercase tracking-[0.22em] text-xs font-black ${isDarkMode ? 'text-amber-300' : 'text-amber-800'}`}>
                          Source Validation
                        </div>
                        <p className="text-sm leading-relaxed">{sourceValidation.summary}</p>
                        <div className="max-h-64 overflow-y-auto custom-scrollbar space-y-3">
                          {(sourceValidation.validated_sources || [])
                            .filter((item) => item.remove_recommended || item.status !== 'relevant')
                            .slice(0, 12)
                            .map((item, index) => (
                              <div key={`${item.link}-${index}`} className={`p-3 border ${isDarkMode ? 'border-amber-500/20 bg-black/30' : 'border-amber-100 bg-white'}`}>
                                <div className={`font-mono text-[10px] uppercase tracking-[0.18em] font-black mb-2 ${item.remove_recommended ? 'text-red-400' : isDarkMode ? 'text-amber-300' : 'text-amber-800'}`}>
                                  {item.remove_recommended ? 'Removal Suggested' : item.status}
                                </div>
                                <div className="text-xs break-all mb-2">{item.domain || item.link}</div>
                                <p className="text-xs leading-relaxed">{item.reason}</p>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  </section>

                  <section className="space-y-4">
                    <div className={`max-h-[430px] overflow-y-auto custom-scrollbar space-y-4 p-4 border ${isDarkMode ? 'border-blue-900/30 bg-blue-950/5' : 'border-red-100 bg-red-50/30'}`}>
                      {chatMessages.length === 0 ? (
                        <div className={`text-sm font-mono uppercase tracking-[0.18em] ${isDarkMode ? 'text-blue-800' : 'text-red-300'}`}>
                          Ask a question about the report, sources, or external context.
                        </div>
                      ) : (
                        chatMessages.map((message, index) => (
                          <div
                            key={`${message.role}-${index}`}
                            className={`p-4 border ${
                              message.role === 'user'
                                ? isDarkMode
                                  ? 'ml-8 border-blue-500/30 bg-blue-950/20 text-blue-100'
                                  : 'ml-8 border-red-200 bg-red-50 text-slate-900'
                                : isDarkMode
                                  ? 'mr-8 border-blue-900/30 bg-black text-zinc-300'
                                  : 'mr-8 border-slate-200 bg-white text-slate-700'
                            }`}
                          >
                            <div className={`mb-2 font-mono text-[10px] uppercase tracking-[0.22em] font-black ${isDarkMode ? 'text-blue-400' : 'text-red-700'}`}>
                              {message.role === 'user' ? 'You' : 'Alethia'}
                            </div>
                            <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>
                          </div>
                        ))
                      )}
                    </div>
                    <textarea
                      value={chatQuestion}
                      onChange={(event) => setChatQuestion(event.target.value)}
                      rows={6}
                      className={`w-full p-5 border font-mono text-sm outline-none resize-none transition-colors ${
                        isDarkMode
                          ? 'bg-black border-blue-900/40 text-blue-200 placeholder:text-blue-900 focus:border-blue-500'
                          : 'bg-white border-red-100 text-slate-900 placeholder:text-red-300 focus:border-red-400'
                      }`}
                      placeholder="Ask about the report, sources, image reuse, metadata, confidence, or narrative context."
                    />
                    <button
                      onClick={handleAskReport}
                      disabled={isAskingReport || !chatQuestion.trim()}
                      className={`w-full py-4 border font-mono uppercase tracking-[0.2em] text-xs font-black flex items-center justify-center gap-3 transition-colors disabled:opacity-50 ${
                        isDarkMode
                          ? 'border-blue-500/40 text-blue-300 hover:bg-blue-950/40'
                          : 'border-red-300 text-red-700 hover:bg-red-50'
                      }`}
                    >
                      <Send className="h-4 w-4" />
                      {isAskingReport ? 'Answering...' : 'Ask Report'}
                    </button>
                  </section>
                </div>
              </aside>
            </div>
          )}
        </>
      )}

      {/* Floating Side Icons for Landing Page */}
      {!result && !isLoading && (
        <div className="fixed right-10 top-1/2 -translate-y-1/2 z-50 flex flex-col gap-6">
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-4 rounded-full shadow-2xl transition-all duration-300 group hover:scale-110 border ${isDarkMode ? 'bg-black/60 border-blue-900/50 text-blue-400 hover:bg-blue-900/30 shadow-blue-500/10' : 'bg-white border-red-100 text-red-600 hover:bg-red-50 shadow-red-500/10'}`}
            title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {isDarkMode ? <Sun className="h-6 w-6" /> : <Moon className="h-6 w-6" />}
          </button>
          
          <button 
            onClick={() => triggerFileUpload()}
            className={`p-4 rounded-full shadow-2xl transition-all duration-300 group hover:scale-110 border ${isDarkMode ? 'bg-black/60 border-blue-900/50 text-blue-400 hover:bg-blue-900/30' : 'bg-white border-red-100 text-red-600 hover:bg-red-50'}`}
            title="Start New Investigation"
          >
            <Upload className="h-6 w-6" />
          </button>

          <button 
            onClick={() => document.getElementById('pipeline')?.scrollIntoView({ behavior: 'smooth' })}
            className={`p-4 rounded-full shadow-2xl transition-all duration-300 group hover:scale-110 border ${isDarkMode ? 'bg-black/60 border-blue-900/50 text-blue-400 hover:bg-blue-900/30' : 'bg-white border-red-100 text-red-600 hover:bg-red-50'}`}
            title="View Forensic Pipeline"
          >
            <Layers className="h-6 w-6" />
          </button>

          <button 
            onClick={() => document.getElementById('capabilities')?.scrollIntoView({ behavior: 'smooth' })}
            className={`p-4 rounded-full shadow-2xl transition-all duration-300 group hover:scale-110 border ${isDarkMode ? 'bg-black/60 border-blue-900/50 text-blue-400 hover:bg-blue-900/30' : 'bg-white border-red-100 text-red-600 hover:bg-red-50'}`}
            title="Forensic Capabilities"
          >
            <Activity className="h-6 w-6" />
          </button>
        </div>
      )}
      
      {!result && !isLoading && renderLandingRedesign()}

      {isLoading && (
        <div className="pt-24">
          {showSkeletonPhase ? (
            <SkeletonLoader isDarkMode={isDarkMode} />
          ) : (
            <PipelineLoader isDarkMode={isDarkMode} events={pipelineEvents} />
          )}
        </div>
      )}
      
      {result && !isLoading && renderResults()}
      
      {error && <div className="mt-4 text-red-500 px-8 text-center text-sm font-mono uppercase tracking-widest">Error: {error}</div>}
    </main>
  );
}
