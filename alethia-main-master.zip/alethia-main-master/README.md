# Alethia — AI-Powered Image Verification & OSINT Platform

> *Aletheia (Greek: ἀλήθεια) — "truth" or "the act of bringing something out of hiding."*

Alethia is an AI-powered open-source intelligence (OSINT) platform that automatically verifies the origin, context, and authenticity of any image in under 90 seconds. Upload an image and receive a forensic-grade report: reverse image sources, media bias breakdown, geolocation analysis, AI-generation detection, and a Gemini-powered investigative summary — all in one place.

---

## Problem Statement

Images have become the primary weapon of misinformation. A single out-of-context photo can spread to millions of people before a fact-check is ever published. Manual image verification — cross-referencing reverse image results, checking metadata, identifying bias in sources, and analyzing geolocation cues — takes a trained journalist 30–90 minutes per image.

Everyday users, students, and even many journalists don't have the tools, time, or expertise to do this. Alethia automates the entire process and makes forensic image analysis accessible to anyone.

---

## Solution Overview

Alethia runs a **14-stage parallel verification pipeline** the moment an image is uploaded:

1. **Upload & Store** — image saved locally and uploaded to Cloudinary for a stable public URL
2. **Multi-Engine Reverse Image Search** — Google Reverse Image (2 pages), Google Lens, Bing, and Yandex run in parallel via SerpAPI
3. **Perceptual Hash Verification** — every source thumbnail is hash-compared (dHash + aHash + center-crop variants) against the original to score visual similarity
4. **Source Deduplication** — URL-normalized dedup across all 4 engines; no duplicate domains
5. **Media Bias Analysis** — 118,000-entry MBFC (Media Bias/Fact Check) dataset lookup; state media override dict for RT, Sputnik, CGTN, etc.; unlisted bucket for unclassified domains
6. **Earliest Date Extraction** — provider-supplied publication dates collected and normalized across all sources
7. **EXIF Metadata Extraction** — GPS coordinates, camera make/model, capture datetime, ISO, focal length via Pillow
8. **Visual Geolocation (GeoCLIP)** — ML model trained on 100M geotagged images estimates where a photo was taken from visual cues alone, with k-means clustering and convex hull confidence scoring
9. **AI-Generation Detection** — AI-or-Not API (with local SDXL transformer fallback) classifies the image as human-made, AI-generated, or deepfake
10. **Gemini Structured First Pass** — Gemini 2.5 Flash reads the image and returns structured JSON: category, location inference, key phrases, screenshot flag, political lean signal
11. **3-Source Location Reconciliation** — EXIF GPS (device location) vs Gemini inference (depicted location) vs GeoCLIP ML estimate are reconciled into a unified location decision
12. **Source Verification** — top sources are cross-referenced for further confirmation using hash similarity tiers
13. **Gemini Comprehensive Report** — full investigative synthesis with Google Search grounding, OSINT-framed prompts adapted to the image category (artwork / news event / historical / political / personal)
14. **Real-Time SSE Streaming** — every stage emits progress events to the frontend as it completes

---

## Key Features

| Feature | Details |
|---|---|
| **Multi-provider SERP** | Google (2 pages) + Google Lens + Bing + Yandex — 4 engines in parallel |
| **Perceptual hashing** | dHash + aHash + center-crop, per-provider thumbnail scoring |
| **GeoCLIP geolocation** | Visual ML geolocation; 5 candidate locations with confidence % |
| **3-source location map** | Interactive Leaflet map shows EXIF GPS pin, Gemini AI pin, GeoCLIP pin simultaneously |
| **Media bias pie chart** | MBFC dataset, state media bucket, unlisted bucket, AI political lean signal |
| **AI-generation detection** | AI-or-Not API + local transformer fallback |
| **Gemini report (grounded)** | Web-search-grounded OSINT report, category-adaptive prompts |
| **Image classification panel** | Structured category badge (artwork / news / political / synthetic / screenshot) + key phrases |
| **Real-time progress ring** | 14-stage circular SSE progress visualization |
| **Dark / light mode** | Full theme toggle |
| **Export to PDF / PNG** | PIL-rendered report export in both modes |
| **Follow-up AI chat** | In-page Gemini chat for follow-up questions after the report |
| **Earliest date tracking** | Provider-supplied dates collected and normalized across all sources |

---

## Technologies Used

### Backend
- **Python 3.11** with **FastAPI** + **Uvicorn**
- **SerpAPI** — Google Reverse Image, Google Lens, Bing Reverse Image, Yandex Images
- **Google Gemini 2.5 Flash** (`google-genai` SDK) — structured first pass + comprehensive report with Search grounding
- **GeoCLIP** (`geoclip` + `transformers` + `torch`) — visual geolocation ML model
- **Pillow** — EXIF metadata extraction
- **imagehash** — perceptual hashing (dHash, aHash)
- **Cloudinary** — public image URL for SERP providers
- **AI-or-Not API** — AI generation detection
- **Pandas** — MBFC media bias dataset (118K entries)
- **tldextract** — domain normalization and deduplication

### Frontend
- **Next.js 15** (React 19, TypeScript)
- **TailwindCSS** — styling and dark/light mode
- **Leaflet** (react-leaflet) — interactive multi-source location map
- **Recharts** — bias pie chart
- **Lucide React** — icons
- **Server-Sent Events (SSE)** — real-time 14-stage pipeline progress

---

## Target Users

- **Journalists & fact-checkers** who need to verify images quickly before publication
- **Researchers & academics** studying misinformation, propaganda, and image manipulation
- **Social media moderators** evaluating potentially viral misinformation content
- **General public** wanting to verify an image they encountered online before sharing
- **Educators** teaching media literacy and digital forensics

---

## Architecture

```
User Upload
    │
    ▼
Next.js Frontend ──── SSE progress stream ────► 14-stage progress ring
    │
    ▼ POST /search/image
FastAPI Backend
    │
    ├── [Thread T1] Cloudinary upload ──► Public URL
    │       └── SerpAPI (Google×2 + Lens) ──► collect ──► hash verify ──► bias split
    │               └── Bing + Yandex (parallel, no hash overhead)
    │
    ├── [Thread T2] EXIF extraction + GeoCLIP geolocation   ┐
    ├── [Thread T3] AI-or-Not detection                     ├─► JOIN ──► Gemini Report
    └── [Thread T4] Gemini structured first pass            ┘
            (all 3 start immediately on file save, before Cloudinary responds)
    │
    ▼
Gemini 2.5 Flash (with Google Search grounding)
    │
    ▼
Consolidated JSON response ──► Frontend renders results
```

---

## Setup (Local)

### Prerequisites
- Python 3.11+
- Node.js 18+
- API keys (see below)

### API Keys Required

| Key | Where to get |
|---|---|
| `SERP_API_KEY` | [serpapi.com](https://serpapi.com) |
| `GOOGLE_API_KEY` or `GEMINI_API_KEY` | [Google AI Studio](https://aistudio.google.com) |
| `CLOUDINARY_CLOUD_NAME` + `CLOUDINARY_API_KEY` + `CLOUDINARY_API_SECRET` | [cloudinary.com](https://cloudinary.com) |
| `AIORNOT_API_KEY` | [aiornot.com](https://aiornot.com) (optional — has local fallback) |

### Backend

```bash
cd backend
cp .env.example .env      # fill in your API keys
pip install -r requirements.txt
uvicorn main:app --port 8001 --reload
```

### Frontend

```bash
cd frontend
npm install
# create .env.local with:
# NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:8001
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

> **Note:** The first request after server start takes 3–5 extra seconds while the GeoCLIP model (~500MB) loads into memory. Subsequent requests are fast.

---

## Environment Variables

### Backend (`backend/.env`)

```env
SERP_API_KEY=your_serpapi_key
GOOGLE_API_KEY=your_google_api_key
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_cloudinary_key
CLOUDINARY_API_SECRET=your_cloudinary_secret
AIORNOT_API_KEY=your_aiornot_key         # optional
GEMINI_MODEL=gemini-2.5-flash            # optional, this is the default
ENABLE_WAYBACK_DATE_CHECKS=false         # optional, Wayback is slow/rate-limited
```

### Frontend (`frontend/.env.local`)

```env
NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:8001
```

---

## Deployment

### Backend (Render)
- Service type: **Web Service**
- Root directory: `backend`
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Minimum RAM: **2GB** (GeoCLIP + PyTorch require ~1.5GB at load time)
- Set all environment variables in the Render dashboard (never in code)

### Frontend (Vercel)
- Import the repository on [vercel.com](https://vercel.com)
- Root directory: `frontend`
- Set `NEXT_PUBLIC_API_BASE_URL` to your Render backend URL
- Deploy

---

## Project Structure

```
alethia/
├── backend/
│   ├── main.py                          # FastAPI app + GeoCLIP warmup
│   ├── requirements.txt
│   ├── .env.example
│   └── routers/
│       ├── search.py                    # Main 14-stage pipeline
│       ├── genai_analysis.py            # Gemini integration (sync, thread-safe)
│       ├── source_verification.py       # Perceptual hash engine
│       ├── clipGeoLocation.py           # GeoCLIP singleton + inference
│       ├── getExif.py                   # EXIF extraction
│       ├── bias.py                      # MBFC bias analysis
│       ├── analysis.py                  # Report chat endpoint
│       ├── export_report.py             # PIL PDF/PNG export
│       └── masterReverseImageSearch/
│           ├── collector.py             # Multi-provider aggregation
│           └── results.py              # ReverseImageResult dataclass
├── frontend/
│   ├── app/
│   │   ├── page.tsx                     # Main SPA (~2400 lines)
│   │   ├── types.ts                     # TypeScript result types
│   │   └── components/
│   │       ├── TopBar.tsx
│   │       ├── Card.tsx
│   │       └── SkeletonLoader.tsx
│   └── next.config.ts
└── render.yaml                          # Render deployment config
```

---

## Limitations

These are known constraints of the current implementation, not bugs — they reflect real-world boundaries of the underlying data sources and models.

| Limitation | Detail |
|---|---|
| **EXIF often missing** | Social platforms (Twitter, Instagram, WhatsApp) strip EXIF metadata before upload — GPS coordinates and camera data will be blank for most viral images |
| **GeoCLIP accuracy** | Visual geolocation can be off by hundreds of kilometers on indoor, studio, or heavily cropped images; accuracy is best on outdoor/landmark scenes |
| **Reverse search coverage** | SerpAPI results depend on what Google/Bing/Yandex have indexed — very recent images or images only shared in closed groups may return zero results |
| **AI detection is an arms race** | AI-or-Not API and local fallback classifiers can be evaded by newer generation models; a "human" label is not a guarantee |
| **MBFC bias data is English-centric** | The 118K-entry MBFC dataset covers primarily English-language and Western outlets; regional/non-English outlets often fall into the "unlisted" bucket |
| **Gemini grounded search is not exhaustive** | Gemini's web search grounding is sampled, not comprehensive — it may miss obscure, paywalled, or regional reporting |
| **Processing time varies** | End-to-end time is 15–90 seconds depending on Gemini API latency, SerpAPI load, and whether GeoCLIP is warm in memory |
| **No video or audio support** | Alethia processes still images only — video frame extraction, audio deepfake detection, and text-only claims are out of scope |
| **No persistent storage** | Reports are not saved server-side; refreshing the page clears results |
| **English-language bias in reports** | Gemini investigative reports perform best on English-language context; analysis of images with non-Latin text or non-Western context may be less detailed |
| **Not a verdict — a tool** | Alethia surfaces evidence and signals; it does not replace a trained journalist or fact-checker. A high similarity score or a Gemini flag is investigative lead, not proof |

---

## Team

| Name | Role |
|---|---|
| **Ammar Sapru** | Solo developer — full-stack, ML integration, OSINT pipeline design |

**Contact:** ammarsaboor40@gmail.com

---

## Hackathon Submission — NextGenHacks 2026

**Project:** Alethia — AI-Powered Image Verification & OSINT Platform  
**Category:** AI Tool / Social Good  
**Problem solved:** Automated image forensics to combat misinformation  
**Live demo:** *(see deployment links above)*  
**Repository:** [github.com/ammarsapru/alethia-main](https://github.com/ammarsapru/alethia-main)
