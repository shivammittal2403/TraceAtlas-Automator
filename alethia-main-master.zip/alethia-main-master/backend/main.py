import faulthandler
import sys
faulthandler.enable()
if sys.platform == "win32":
    import asyncio
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    # Force UTF-8 output on Windows so emoji/non-ASCII in source titles don't crash log_stage
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).with_name(".env"))  # ← fixed path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from routers import analysis, export_report, search
import os

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
    ],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(search.router)
app.include_router(analysis.router)
app.include_router(export_report.router)

os.makedirs("static/uploads", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.on_event("startup")
async def warmup_models():
    import asyncio
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, _warmup_geoclip)


def _warmup_geoclip():
    try:
        from routers.getExif import handle_exif
        import tempfile, os as _os
        from PIL import Image as _Image
        tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
        try:
            _Image.new("RGB", (64, 64), (128, 128, 128)).save(tmp.name)
            tmp.close()
            handle_exif(tmp.name)
        finally:
            _os.unlink(tmp.name)
        print("[startup] GeoCLIP model warmed up", flush=True)
    except Exception as e:
        print(f"[startup] GeoCLIP warmup failed (non-fatal): {e}", flush=True)


@app.get("/")
def read_root():
    return {"message": "Alethia Backend is running"}


@app.get("/api/live/state")
def live_state():
    return {"status": "alive", "version": "2.1"}
