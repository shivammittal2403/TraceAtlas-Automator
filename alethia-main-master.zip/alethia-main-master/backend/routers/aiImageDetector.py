import os
from dotenv import load_dotenv
from huggingface_hub import InferenceClient
from PIL import Image

load_dotenv()

hugging_face_token = os.getenv("HUGGING_FACE_TOKEN")
if not hugging_face_token:
    raise ValueError("HUGGING_FACE_TOKEN not found in environment variables")

client = InferenceClient(token=hugging_face_token)

# 1. Best Model Choice: Swin V2 Base
model_id = "microsoft/swinv2-base-patch4-window12-192-22k"

script_dir = os.path.dirname(os.path.abspath(__file__))
image_path = os.path.join(script_dir, "image.png")

# Verify image exists
if not os.path.exists(image_path):
    raise FileNotFoundError(f"Image not found at: {image_path}")

# 2. Inference call with error handling
# Note: Swin models on HF Inference API use the image_classification task
try:
    print(f"Sending request to Hugging Face API...")
    result = client.image_classification(
        image_path, 
        model=model_id
    )
    
    # Swin V2 is a general classifier, so it will return ImageNet labels (e.g., 'castle')
    # To detect 'AI vs Real', you will eventually fine-tune this model.
    print(f"Top Detection: {result[0]['label']} ({result[0]['score']:.2%})")
except Exception as e:
    print(f"Error during inference: {type(e).__name__}: {e}")