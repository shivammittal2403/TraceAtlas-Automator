import os, requests
from dotenv import load_dotenv
from pathlib import Path
from .aonAnalysis import bk_analysis
from PIL import Image

# Load environment variables from .env file (2 levels up from this script)
env_path = Path(__file__).resolve().parents[2] / '.env'
load_dotenv(dotenv_path=env_path)

# Updated fallback key
# Set API key ENV variable or replace with your own API key
API_KEY = os.getenv("AIORNOT_API_KEY")
IMAGE_ENDPOINT = "https://api.aiornot.com/v2/image/sync"
LOCAL_DETECTOR_MODEL = os.getenv("AI_IMAGE_DETECTOR_MODEL", "Organika/sdxl-detector")
_LOCAL_PIPELINE = None

# By default, ai_generated, deepfake, nsfw, and quality reports run.
# Use 'only' and 'excluding' parameters to select subsets.
# Note: ai_generated and deepfake have their own costs.
def ai_or_not_image(file_path):
    filepath = file_path
    with open(filepath, "rb") as f:
        resp = requests.post(
            IMAGE_ENDPOINT,
            headers={"Authorization": f"Bearer {API_KEY}"},
            files={"image": f},
            params={
            "external_id": "my-tracking-id"  # Optional
            # Example: only run reverse_search:
            # "only": ["reverse_search"]
            # Example: run all defaults except deepfake:
            # "excluding": ["deepfake"]
            }
        )
    resp.raise_for_status()
    result = resp.json()
    
    # print(resp.json())
    return result

# ai_or_not_image("backend\\routers\\exiftest\\DSCN0010.jpg")


def _get_local_detector_pipeline():
    global _LOCAL_PIPELINE
    if _LOCAL_PIPELINE is not None:
        return _LOCAL_PIPELINE
    from transformers import pipeline

    device = int(os.getenv("AI_IMAGE_DETECTOR_DEVICE", "-1"))
    _LOCAL_PIPELINE = pipeline(
        "image-classification",
        model=LOCAL_DETECTOR_MODEL,
        device=device,
    )
    return _LOCAL_PIPELINE


def _label_kind(label: str):
    normalized = (label or "").strip().lower()
    if any(token in normalized for token in ("fake", "ai", "artificial", "generated", "synthetic", "sdxl")):
        return "ai"
    if any(token in normalized for token in ("real", "human", "natural", "photo")):
        return "human"
    return "unknown"


def _local_detector_analysis(file_path):
    detector = _get_local_detector_pipeline()
    with Image.open(file_path) as image:
        results = detector(image.convert("RGB"))

    ai_score = 0.0
    human_score = 0.0
    normalized_results = []
    for item in results:
        label = str(item.get("label", ""))
        score = float(item.get("score", 0.0))
        kind = _label_kind(label)
        normalized_results.append({"label": label, "score": score, "kind": kind})
        if kind == "ai":
            ai_score = max(ai_score, score)
        elif kind == "human":
            human_score = max(human_score, score)

    if ai_score == 0.0 and human_score == 0.0 and normalized_results:
        top = max(normalized_results, key=lambda item: item["score"])
        # Preserve a useful signal even if a model uses unexpected label names.
        ai_score = top["score"] if top["kind"] == "unknown" else ai_score

    verdict = "ai_generated" if ai_score >= human_score and ai_score >= 0.5 else "human"
    return {
        "verdict": verdict,
        "ai_is_detected": verdict == "ai_generated",
        "ai_id_confidence": ai_score,
        "human_is_detected": verdict == "human",
        "human_confidence": human_score,
        "deepfake_is_detected": False,
        "deepfake_confidence": 0.0,
        "nsfw_is_detected": False,
        "detector_provider": "local_huggingface",
        "detector_model": LOCAL_DETECTOR_MODEL,
        "detector_license_note": "Temporary non-commercial SDXL/Wikimedia detector. Replace with the post-trained Alethia SwinV2 detector when ready.",
        "raw_detector_scores": normalized_results,
        "scores": {
            "ai_generated": ai_score,
            "human": human_score,
            "deepfake": 0.0,
        },
    }


def AIorNot_image_analysis(file_path):
    """
    Runs the temporary local detector only when explicitly enabled.
    The paid AIorNot API and the old placeholder response are preserved for rollback.
    """
    try:
        if os.getenv("USE_LOCAL_AI_IMAGE_DETECTOR", "false").lower() not in {"0", "false", "no"}:
            print(f"[Alethia:ai_detector] running local model={LOCAL_DETECTOR_MODEL}")
            return _local_detector_analysis(file_path)

        if API_KEY and os.getenv("USE_PAID_AI_OR_NOT", "false").lower() in {"1", "true", "yes"}:
            print("[Alethia:ai_detector] running paid AIorNot API because USE_LOCAL_AI_IMAGE_DETECTOR is disabled")
            return bk_analysis(ai_or_not_image(file_path))

        # Previous placeholder response preserved for rollback. It claimed a
        # confident human verdict without running a detector, so it must not be
        # returned as real evidence.
        # placeholder_result = {
        #     "report": {
        #         "ai_generated": {
        #             "verdict": "human",
        #             "ai": {"is_detected": False, "confidence": 0.05},
        #             "human": {"is_detected": True, "confidence": 0.95}
        #         },
        #         "deepfake": {"is_detected": False, "confidence": 0.02, "rois": []},
        #         "nsfw": {"is_detected": False},
        #         "meta": {
        #             "width": 1920,
        #             "height": 1080,
        #             "format": "JPEG",
        #             "size_bytes": 102400
        #         }
        #     }
        # }

        print("[Alethia:ai_detector] local detector disabled; returning unknown until Alethia SwinV2 is ready")
        return {
            'verdict': 'unknown',
            'ai_is_detected': False,
            'ai_id_confidence': 0.0,
            'human_is_detected': False,
            'human_confidence': 0.0,
            'deepfake_is_detected': False,
            'deepfake_confidence': 0.0,
            'nsfw_is_detected': False,
            'detector_provider': 'disabled',
            'detector_model': LOCAL_DETECTOR_MODEL,
            'detector_status': 'Temporary local detector disabled to keep uploads responsive.',
            'scores': {
                'ai_generated': 0.0,
                'human': 0.0,
                'deepfake': 0.0,
            },
        }

        # Legacy placeholder implementation preserved below for rollback.
        """
        placeholder_result = {
            "report": {
                "ai_generated": {
                    "verdict": "human",
                    "ai": {"is_detected": False, "confidence": 0.05},
                    "human": {"is_detected": True, "confidence": 0.95}
                },
                "deepfake": {"is_detected": False, "confidence": 0.02, "rois": []},
                "nsfw": {"is_detected": False},
                "meta": {
                    "width": 1920,
                    "height": 1080,
                    "format": "JPEG",
                    "size_bytes": 102400
                }
            }
        }
        
        # Logging for transparency (the user will see this in terminal if they watch logs)
        print(f"[Alethia:ai_detector] returning placeholder AI analysis for {file_path}")
        
        return bk_analysis(placeholder_result)
        """
        
    except Exception as e:
        print(f"[Alethia:ai_detector] local/open detector failed, returning safe fallback: {e}")
        return {
            'verdict': 'unknown',
            'ai_is_detected': False,
            'ai_id_confidence': 0.0,
            'human_is_detected': False,
            'human_confidence': 0.0,
            'deepfake_is_detected': False,
            'deepfake_confidence': 0.0,
            'nsfw_is_detected': False,
            'detector_provider': 'local_huggingface',
            'detector_model': LOCAL_DETECTOR_MODEL,
            'detector_error': str(e),
            'scores': {
                'ai_generated': 0.0,
                'human': 0.0,
                'deepfake': 0.0,
            },
        }
# AIorNot_image_analysis("backend\\routers\\exiftest\\DSCN0010.jpg")
