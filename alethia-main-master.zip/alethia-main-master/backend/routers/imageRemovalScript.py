import os
import shutil

def clear_upload_folder(directory="static/uploads/"):
    if os.path.exists(directory):
        # This deletes the folder and everything inside it
        shutil.rmtree(directory)
    
    # Recreate the empty folder immediately
    os.makedirs(directory, exist_ok=True)
    print(f"Cleaned all files in {directory}")

# Run it
clear_upload_folder()