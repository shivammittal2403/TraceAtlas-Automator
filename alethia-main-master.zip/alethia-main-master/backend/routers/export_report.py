import io
import os
import shutil
import subprocess
import tempfile
import textwrap
from typing import Any, Literal

import requests
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from PIL import Image, ImageDraw, ImageFont
from pydantic import BaseModel, Field


router = APIRouter(prefix="/export", tags=["export"])


class ExportChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ExportReportRequest(BaseModel):
    report: dict[str, Any]
    chat_history: list[ExportChatMessage] = Field(default_factory=list)
    theme: Literal["dark", "light"] = "dark"


class RenderedExportRequest(BaseModel):
    html: str = Field(min_length=1)
    width: int = Field(default=1600, ge=800, le=5000)
    height: int = Field(default=2200, ge=800, le=12000)


def _find_browser():
    candidates = [
        shutil.which("msedge"),
        shutil.which("chrome"),
        shutil.which("chromium"),
        "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
        "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
        "C:/Program Files/Google/Chrome/Application/chrome.exe",
        "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
    ]
    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return candidate
    return None


def _render_html_with_browser(html: str, output_format: Literal["png", "pdf"], width: int, height: int):
    browser = _find_browser()
    if not browser:
        raise HTTPException(status_code=500, detail="No headless browser found for report export. Install Microsoft Edge or Chrome.")

    with tempfile.TemporaryDirectory() as temp_dir:
        html_path = os.path.join(temp_dir, "alethia-export.html")
        output_path = os.path.join(temp_dir, f"alethia-report.{output_format}")
        with open(html_path, "w", encoding="utf-8") as file:
            file.write(html)

        command = [
            browser,
            "--headless=new",
            "--disable-gpu",
            "--hide-scrollbars",
            "--allow-file-access-from-files",
            f"--window-size={width},{height}",
        ]
        if output_format == "pdf":
            command.append(f"--print-to-pdf={output_path}")
        else:
            command.append(f"--screenshot={output_path}")
        command.append(html_path)

        try:
            subprocess.run(command, check=True, timeout=60, capture_output=True)
        except subprocess.CalledProcessError as e:
            detail = e.stderr.decode("utf-8", errors="ignore") or e.stdout.decode("utf-8", errors="ignore")
            raise HTTPException(status_code=500, detail=f"Headless browser export failed: {detail[:1000]}")
        except subprocess.TimeoutExpired:
            raise HTTPException(status_code=504, detail="Headless browser export timed out.")

        if not os.path.exists(output_path):
            raise HTTPException(status_code=500, detail="Headless browser did not create the export file.")
        with open(output_path, "rb") as file:
            return file.read()


def _font(size: int, bold: bool = False):
    candidates = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _wrap(text: str, width: int):
    lines = []
    for paragraph in (text or "").splitlines():
        if not paragraph.strip():
            lines.append("")
            continue
        lines.extend(textwrap.wrap(paragraph, width=width) or [""])
    return lines


def _draw_wrapped(draw: ImageDraw.ImageDraw, text: str, xy: tuple[int, int], font, fill, width: int, line_gap: int = 8, max_lines: int | None = None):
    x, y = xy
    lines = _wrap(text, width)
    if max_lines is not None and len(lines) > max_lines:
        lines = lines[: max_lines - 1] + ["..."]
    for line in lines:
        draw.text((x, y), line, font=font, fill=fill)
        y += font.size + line_gap
    return y


def _fetch_report_image(url: str):
    if not url:
        return None
    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()
        return Image.open(io.BytesIO(response.content)).convert("RGB")
    except Exception:
        return None


def _fit_image(image: Image.Image, size: tuple[int, int], dark: bool = True):
    image = image.copy()
    image.thumbnail(size)
    bg_color = (10, 16, 24) if dark else (240, 242, 245)
    canvas = Image.new("RGB", size, bg_color)
    x = (size[0] - image.width) // 2
    y = (size[1] - image.height) // 2
    canvas.paste(image, (x, y))
    return canvas


def _summary_line(label: str, value: Any):
    if value is None or value == "":
        value = "N/A"
    return f"{label}: {value}"


def _chat_highlights(chat_history: list[ExportChatMessage]):
    highlights = []
    pending_question = None
    for message in chat_history:
        content = " ".join(message.content.split())
        if message.role == "user":
            pending_question = content[:180]
        elif pending_question:
            highlights.append(f"Q: {pending_question}\nA: {content[:260]}")
            pending_question = None
    return highlights[:5]


def build_report_sheet(request: ExportReportRequest):
    report = request.report or {}
    dark = request.theme == "dark"
    bg = (4, 10, 18) if dark else (248, 250, 252)
    panel = (9, 18, 31) if dark else (255, 255, 255)
    border = (59, 130, 246) if dark else (220, 38, 38)
    text = (226, 232, 240) if dark else (15, 23, 42)
    muted = (147, 197, 253) if dark else (127, 29, 29)
    # Light mode: use a visible mid-gray divider instead of near-white pink
    faint = (30, 64, 105) if dark else (200, 200, 210)

    canvas = Image.new("RGB", (1600, 2200), bg)
    draw = ImageDraw.Draw(canvas)
    title_font = _font(54, True)
    section_font = _font(28, True)
    body_font = _font(24)
    small_font = _font(19)
    mono_font = _font(21, True)

    draw.rounded_rectangle((60, 50, 1540, 2150), radius=20, fill=panel, outline=border, width=4)
    draw.text((665, 95), "ALETHIA", font=title_font, fill=text)
    draw.text((575, 160), "FORENSIC IMAGE REPORT", font=mono_font, fill=muted)
    draw.line((120, 220, 1480, 220), fill=faint, width=2)

    image_url = report.get("image_url") or ""
    report_image = _fetch_report_image(image_url)
    img_placeholder_fill = (15, 23, 42) if dark else (220, 222, 228)
    if report_image:
        fitted = _fit_image(report_image, (520, 430), dark=dark)
        canvas.paste(fitted, (120, 270))
    else:
        draw.rectangle((120, 270, 640, 700), fill=img_placeholder_fill, outline=faint, width=2)
        draw.text((250, 455), "IMAGE UNAVAILABLE", font=section_font, fill=muted)

    ai_analysis = report.get("ai_analysis") or {}
    geoclip = report.get("geoclip_analysis") or {}
    exif = report.get("exif_data") or {}
    biases = report.get("biases") or {}
    sources = report.get("reverse_search_links") or []
    source_verification = report.get("source_verification") or {}
    verification_summary = source_verification.get("summary") if isinstance(source_verification, dict) else {}
    location = report.get("location_analysis") or {}

    x = 700
    y = 270
    draw.text((x, y), "KEY FINDINGS", font=section_font, fill=muted)
    y += 48
    finding_lines = [
        _summary_line("Total source matches", report.get("total_matches", len(sources))),
        _summary_line("Visually confirmed pages", verification_summary.get("retained", len(sources)) if isinstance(verification_summary, dict) else len(sources)),
        _summary_line("AI-or-not verdict", ai_analysis.get("verdict", "unknown")),
        _summary_line("GeoCLIP confidence", f"{geoclip.get('confidence_percent', 'N/A')}%" if geoclip else "N/A"),
        _summary_line("GeoCLIP mode", geoclip.get("map_mode", "N/A") if geoclip else "N/A"),
        _summary_line("Device", " ".join([str(exif.get("Make", "") or ""), str(exif.get("Model", "") or "")]).strip() or "N/A"),
        _summary_line("Earliest date", report.get("earliest_date", "N/A")),
    ]
    for line in finding_lines:
        draw.text((x, y), line, font=body_font, fill=text)
        y += 38

    y += 12
    draw.text((x, y), "BIAS / SOURCE SIGNALS", font=section_font, fill=muted)
    y += 44
    if biases:
        for name, value in list(biases.items())[:6]:
            draw.text((x, y), f"{name}: {value}", font=body_font, fill=text)
            y += 34
    else:
        draw.text((x, y), "No bias signals available.", font=body_font, fill=text)

    y = 735
    draw.line((120, y - 35, 1480, y - 35), fill=faint, width=2)
    draw.text((120, y), "AI REPORT SUMMARY", font=section_font, fill=muted)
    y += 48
    y = _draw_wrapped(draw, report.get("image_description", "No report summary available."), (120, y), small_font, text, width=138, line_gap=6, max_lines=17)

    y += 35
    draw.text((120, y), "SOURCE HIGHLIGHTS", font=section_font, fill=muted)
    y += 48
    if sources:
        for source in sources[:6]:
            if not isinstance(source, dict):
                continue
            title = source.get("title") or source.get("source_domain") or source.get("source") or "Source"
            provider = source.get("provider") or "provider"
            y = _draw_wrapped(draw, f"- {title} ({provider})", (140, y), small_font, text, width=120, line_gap=6, max_lines=2)
    else:
        draw.text((140, y), "No source highlights available.", font=body_font, fill=text)
        y += 36

    y += 18
    draw.text((120, y), "LOCATION / METADATA", font=section_font, fill=muted)
    y += 48
    location_text = (
        f"Selected basis: {location.get('selected_source', 'none')}. "
        f"Reason: {location.get('reason', 'No location decision available.')}. "
        f"EXIF captured: {len(exif)} fields."
    )
    y = _draw_wrapped(draw, location_text, (140, y), small_font, text, width=138, line_gap=6, max_lines=4)
    if geoclip and geoclip.get("points"):
        cluster = geoclip.get("primary_cluster") or {}
        center = cluster.get("center") or {}
        geo_text = (
            f"Average confidence: {geoclip.get('confidence_percent')}%. "
            f"Mode: {geoclip.get('map_mode')}. "
            f"Primary estimate: {center.get('lat', 'N/A')}, {center.get('lon', 'N/A')}."
        )
        y = _draw_wrapped(draw, geo_text, (140, y), small_font, text, width=138, line_gap=6, max_lines=3)
    else:
        draw.text((140, y), "No GeoCLIP estimate available.", font=body_font, fill=text)
        y += 36

    highlights = _chat_highlights(request.chat_history)
    if highlights:
        y += 25
        draw.text((120, y), "ASSISTANT CHAT HIGHLIGHTS", font=section_font, fill=muted)
        y += 48
        for highlight in highlights:
            y = _draw_wrapped(draw, f"- {highlight}", (140, y), small_font, text, width=120, line_gap=6, max_lines=5)

    draw.line((120, 2075, 1480, 2075), fill=faint, width=2)
    footer = "Generated by Alethia. Confidence signals are investigative aids, not standalone proof."
    draw.text((120, 2100), footer, font=small_font, fill=muted)
    return canvas


@router.post("/report.png")
def export_report_png(request: ExportReportRequest):
    image = build_report_sheet(request)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="image/png",
        headers={"Content-Disposition": 'attachment; filename="alethia-report.png"'},
    )


@router.post("/report.pdf")
def export_report_pdf(request: ExportReportRequest):
    image = build_report_sheet(request)
    buffer = io.BytesIO()
    image.save(buffer, format="PDF", resolution=160)
    buffer.seek(0)
    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": 'attachment; filename="alethia-report.pdf"'},
    )


@router.post("/rendered.png")
def export_rendered_png(request: RenderedExportRequest):
    content = _render_html_with_browser(request.html, "png", request.width, request.height)
    return StreamingResponse(
        io.BytesIO(content),
        media_type="image/png",
        headers={"Content-Disposition": 'attachment; filename="alethia-report.png"'},
    )


@router.post("/rendered.pdf")
def export_rendered_pdf(request: RenderedExportRequest):
    content = _render_html_with_browser(request.html, "pdf", request.width, request.height)
    return StreamingResponse(
        io.BytesIO(content),
        media_type="application/pdf",
        headers={"Content-Disposition": 'attachment; filename="alethia-report.pdf"'},
    )
