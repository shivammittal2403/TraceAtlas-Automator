import json
import os
from pathlib import Path
from typing import Any, Literal

import requests
from dotenv import load_dotenv
from fastapi import APIRouter, HTTPException
from google import genai
from google.genai import types
from pydantic import BaseModel, Field


router = APIRouter(prefix="/analysis", tags=["analysis"])

SourceCategory = Literal[
    "art",
    "political",
    "medical",
    "news",
    "commercial",
    "satire",
    "educational",
    "social_media",
    "unknown",
]


class SourceContextRequest(BaseModel):
    report: dict[str, Any]
    max_sources: int = Field(default=12, ge=1, le=30)


class SourceValidationRequest(BaseModel):
    report: dict[str, Any]
    source_context: list[dict[str, Any]] = Field(default_factory=list)
    max_sources: int = Field(default=40, ge=1, le=120)


class ReportChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ReportChatRequest(BaseModel):
    report: dict[str, Any]
    question: str = Field(min_length=1, max_length=2000)
    source_context: list[dict[str, Any]] = Field(default_factory=list)
    history: list[ReportChatMessage] = Field(default_factory=list)


def _get_client() -> genai.Client:
    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
    if not api_key:
        for parent in Path(__file__).resolve().parents:
            env_file = parent / ".env"
            if env_file.exists():
                load_dotenv(dotenv_path=env_file)
                api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
                if api_key:
                    break
    if not api_key:
        raise HTTPException(status_code=500, detail="Missing Gemini API key.")
    return genai.Client(api_key=api_key)


def _model_name() -> str:
    return os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


def _compact_report(report: dict[str, Any], max_sources: int = 12):
    reverse_links = report.get("reverse_search_links") or []
    source_verification = report.get("source_verification") or {}
    compact_links = []
    for item in reverse_links[:max_sources]:
        if not isinstance(item, dict):
            continue
        compact_links.append(
            {
                "title": item.get("title") or "",
                "link": item.get("link") or "",
                "source": item.get("source") or item.get("source_domain") or "",
                "provider": item.get("provider") or "",
            }
        )

    return {
        "image_description": report.get("image_description") or "",
        "total_matches": report.get("total_matches"),
        "earliest_date": report.get("earliest_date"),
        "biases": report.get("biases") or {},
        "source_clusters": report.get("source_clusters") or {},
        "exif_data": report.get("exif_data") or {},
        "ai_analysis": report.get("ai_analysis") or {},
        "source_verification": {
            "summary": source_verification.get("summary") if isinstance(source_verification, dict) else {},
            "sources": (source_verification.get("sources") if isinstance(source_verification, dict) else [])[:max_sources],
        },
        "top_sources": compact_links,
    }


def _web_search_context(question: str, report: dict[str, Any]):
    api_key = os.getenv("SERP_API_KEY")
    if not api_key:
        return {"enabled": False, "reason": "SERP_API_KEY is not configured.", "results": []}

    reverse_links = report.get("reverse_search_links") or []
    source_terms = []
    for item in reverse_links[:8]:
        if not isinstance(item, dict):
            continue
        title = item.get("title") or ""
        source = item.get("source_domain") or item.get("source") or ""
        if title:
            source_terms.append(title)
        elif source:
            source_terms.append(source)

    query = " ".join([question, *source_terms[:3]])[:450]
    try:
        response = requests.get(
            "https://serpapi.com/search",
            params={"engine": "google", "q": query, "api_key": api_key, "num": 8},
            timeout=20,
        )
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        return {"enabled": True, "error": str(e), "results": []}

    results = []
    for item in (data.get("organic_results") or [])[:8]:
        results.append(
            {
                "title": item.get("title") or "",
                "link": item.get("link") or "",
                "source": item.get("source") or "",
                "snippet": item.get("snippet") or "",
                "date": item.get("date") or "",
            }
        )
    return {"enabled": True, "query": query, "results": results}


def _safe_json_loads(text: str):
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end != -1 and end > start:
        cleaned = cleaned[start : end + 1]
    return json.loads(cleaned)


@router.post("/source-context")
async def source_context(request: SourceContextRequest):
    client = _get_client()
    compact_report = _compact_report(request.report, request.max_sources)

    prompt = f"""
You are Alethia's source-context classifier. Analyze only the supplied report data.

Return strict JSON with this shape:
{{
  "overall_category": "art|political|medical|news|commercial|satire|educational|social_media|unknown",
  "why_it_matters": "short explanation",
  "source_analyses": [
    {{
      "title": "...",
      "url": "...",
      "domain": "...",
      "category": "art|political|medical|news|commercial|satire|educational|social_media|unknown",
      "confidence": 0.0,
      "summary": "short source-specific summary",
      "relevance": "why this source matters to the image report"
    }}
  ],
  "overview": "concise overview of the findings and their significance"
}}

Rules:
- Do not invent facts not present in the report.
- Classify from titles, domains, source clusters, EXIF, AI analysis, and the report summary.
- If evidence is thin, use "unknown" with low confidence.
- Keep each source summary under 35 words.

REPORT:
{json.dumps(compact_report, ensure_ascii=False)}
"""

    try:
        response = await client.aio.models.generate_content(
            model=_model_name(),
            contents=prompt,
        )
        text = getattr(response, "text", "") or ""
        return _safe_json_loads(text)
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=502, detail=f"Model returned invalid JSON: {e}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Source context analysis failed: {e}")


def validate_sources_payload(report: dict[str, Any], source_context: list[dict[str, Any]] | None = None, max_sources: int = 40):
    client = _get_client()
    compact_report = _compact_report(report, max_sources)
    source_context = source_context or []

    prompt = f"""
You are Alethia's source validator. Decide whether each source appears relevant to the uploaded image and report.

Return strict JSON:
{{
  "validated_sources": [
    {{
      "link": "...",
      "title": "...",
      "domain": "...",
      "status": "relevant|uncertain|irrelevant",
      "confidence": 0.0,
      "reason": "short explanation",
      "remove_recommended": false
    }}
  ],
  "summary": "short validation overview"
}}

Rules:
- Use the report summary, source title/domain/link/provider, source context, and SOURCE_VERIFICATION evidence.
- Treat image_present=confirmed as strong evidence the source contains the uploaded image.
- Treat image_present=probable as useful but not conclusive.
- Treat image_present=not_confirmed as evidence against relevance unless title/domain/context explains it.
- Mark sources irrelevant when they appear unrelated, generic, or off-topic.
- Use uncertain when there is not enough evidence to remove.
- Prefer conservative removal: only set remove_recommended=true when the source is likely unrelated.
- Keep reasons under 28 words.

REPORT:
{json.dumps(compact_report, ensure_ascii=False)}

SOURCE_CONTEXT:
{json.dumps(source_context[:40], ensure_ascii=False)}
"""

    response = client.models.generate_content(
        model=_model_name(),
        contents=prompt,
    )
    text = getattr(response, "text", "") or ""
    return _safe_json_loads(text)


@router.post("/source-validation")
async def source_validation(request: SourceValidationRequest):
    try:
        return validate_sources_payload(request.report, request.source_context, request.max_sources)
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=502, detail=f"Model returned invalid JSON: {e}")
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Source validation failed: {e}")


@router.post("/report-chat")
async def report_chat(request: ReportChatRequest):
    client = _get_client()
    compact_report = _compact_report(request.report, 100)
    web_context = _web_search_context(request.question, request.report)
    history = [
        {"role": message.role, "content": message.content}
        for message in request.history[-6:]
    ]

    prompt = f"""
You are Alethia's report assistant. Answer the user's question using the supplied report, all supplied source links, source-context evidence, recent chat, and web-search context when available.

Response rules:
- Keep the report as the core evidence, but use web-search context to verify, challenge, or add context when useful.
- If the report does not contain enough evidence, say what is missing.
- Be concise, factual, and evidence-grounded.
- Explain why findings matter when useful.
- Do not claim a source is original unless the report proves it.
- If web-search context is thin or unavailable, say so plainly.
- Distinguish what the report shows from what external search suggests.
- Mention source domains or links when they materially support the answer.

REPORT:
{json.dumps(compact_report, ensure_ascii=False)}

SOURCE_CONTEXT:
{json.dumps(request.source_context[:20], ensure_ascii=False)}

WEB_SEARCH_CONTEXT:
{json.dumps(web_context, ensure_ascii=False)}

RECENT_CHAT:
{json.dumps(history, ensure_ascii=False)}

QUESTION:
{request.question}
"""

    try:
        response = await client.aio.models.generate_content(
            model=_model_name(),
            contents=prompt,
        )
        return {"answer": getattr(response, "text", "") or "No answer returned.", "web_context": web_context}
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Report chat failed: {e}")
