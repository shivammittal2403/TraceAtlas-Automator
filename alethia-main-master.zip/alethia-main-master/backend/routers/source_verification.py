import io
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin, urlparse

import requests
from PIL import Image


DEFAULT_HEADERS = {
    "User-Agent": "AlethiaBot/0.1 (+image verification research; contact local developer)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
}
IMAGE_HEADERS = {
    "User-Agent": DEFAULT_HEADERS["User-Agent"],
    "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
}
IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


class SourceImageExtractor(HTMLParser):
    def __init__(self, base_url: str):
        super().__init__()
        self.base_url = base_url
        self.image_urls: list[str] = []
        self.title = ""
        self.meta_description = ""
        self._in_title = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]):
        attr = {key.lower(): value for key, value in attrs if value}
        tag = tag.lower()

        if tag == "title":
            self._in_title = True
            return

        if tag == "img" or tag == "source":
            for key in ("src", "data-src", "data-original", "data-lazy-src", "data-image", "data-url"):
                self._add_url(attr.get(key))
            self._add_srcset(attr.get("srcset"))
            self._add_srcset(attr.get("data-srcset"))
            return

        if tag == "meta":
            prop = (attr.get("property") or attr.get("name") or "").lower()
            content = attr.get("content")
            if prop in {"og:image", "og:image:url", "twitter:image", "twitter:image:src"}:
                self._add_url(content)
            if prop in {"description", "og:description", "twitter:description"} and content and not self.meta_description:
                self.meta_description = content.strip()
            return

        if tag == "link":
            rel = (attr.get("rel") or "").lower()
            if "image_src" in rel or "preload" in rel:
                self._add_url(attr.get("href"))

    def handle_endtag(self, tag: str):
        if tag.lower() == "title":
            self._in_title = False

    def handle_data(self, data: str):
        if self._in_title and data.strip():
            self.title += data.strip()

    def _add_srcset(self, value: str | None):
        if not value:
            return
        for part in value.split(","):
            self._add_url(part.strip().split(" ")[0])

    def _add_url(self, value: str | None):
        if not value:
            return
        value = value.strip()
        if not value or value.startswith("data:"):
            return
        absolute = urljoin(self.base_url, value)
        parsed = urlparse(absolute)
        if parsed.scheme in {"http", "https"} and parsed.netloc:
            self.image_urls.append(absolute)


def perceptual_dhash_from_image(image: Image.Image) -> int:
    image = image.convert("L").resize((9, 8), Image.Resampling.LANCZOS)
    pixels = list(image.getdata())
    bits = []
    for row in range(8):
        offset = row * 9
        for column in range(8):
            bits.append(1 if pixels[offset + column] > pixels[offset + column + 1] else 0)
    value = 0
    for bit in bits:
        value = (value << 1) | bit
    return value


def perceptual_ahash_from_image(image: Image.Image) -> int:
    image = image.convert("L").resize((8, 8), Image.Resampling.LANCZOS)
    pixels = list(image.getdata())
    average = sum(pixels) / len(pixels)
    value = 0
    for pixel in pixels:
        value = (value << 1) | (1 if pixel >= average else 0)
    return value


def center_crop(image: Image.Image, ratio: float = 0.82) -> Image.Image:
    width, height = image.size
    crop_width = max(1, int(width * ratio))
    crop_height = max(1, int(height * ratio))
    left = max(0, (width - crop_width) // 2)
    top = max(0, (height - crop_height) // 2)
    return image.crop((left, top, left + crop_width, top + crop_height))


def image_hash_profile(image: Image.Image) -> dict[str, int]:
    # The old implementation used only one 64-bit dHash:
    # return {"dhash": perceptual_dhash_from_image(image)}
    # That is too brittle for reverse-search thumbnails, crops, compression, and
    # provider re-encodes, so keep a small multi-view profile without adding a
    # new dependency.
    return {
        "dhash": perceptual_dhash_from_image(image),
        "ahash": perceptual_ahash_from_image(image),
        "center_dhash": perceptual_dhash_from_image(center_crop(image)),
        "center_ahash": perceptual_ahash_from_image(center_crop(image)),
    }


def perceptual_hash_profile_from_file(image_path: str) -> dict[str, int]:
    with Image.open(image_path) as image:
        return image_hash_profile(image)


def perceptual_hash_profile_from_bytes(content: bytes) -> dict[str, int]:
    with Image.open(io.BytesIO(content)) as image:
        return image_hash_profile(image)


def hamming_distance(left: int, right: int) -> int:
    return (left ^ right).bit_count()


def visual_similarity_from_distance(distance: int) -> float:
    return max(0.0, min(1.0, 1 - (distance / 64)))


def compare_hash_profiles(left: dict[str, int], right: dict[str, int]) -> dict[str, Any]:
    distances = {}
    for key, left_hash in left.items():
        right_hash = right.get(key)
        if right_hash is None:
            continue
        distances[key] = hamming_distance(left_hash, right_hash)
    if not distances:
        return {"best_distance": None, "avg_distance": None, "best_method": None, "distances": {}, "similarity": None, "avg_similarity": None}
    best_method, best_distance = min(distances.items(), key=lambda item: item[1])
    # avg_distance is the primary classification metric.  Using best_distance alone
    # causes false positives: ahash picks up similar low-frequency color distributions
    # in unrelated portrait images (e.g. Mona Lisa vs a news photo of a person) and
    # can produce a distance of 15 for completely different subjects.  Requiring the
    # AVERAGE across all hash views to be low eliminates those false positives while
    # still confirming the same image across resolutions/compression levels.
    avg_distance = sum(distances.values()) / len(distances)
    return {
        "best_distance": best_distance,
        "avg_distance": round(avg_distance, 2),
        "best_method": best_method,
        "distances": distances,
        "similarity": round(visual_similarity_from_distance(best_distance), 4),
        "avg_similarity": round(visual_similarity_from_distance(avg_distance), 4),
    }


def _looks_like_image_url(url: str) -> bool:
    path = urlparse(url).path.lower()
    return path.endswith(IMAGE_EXTENSIONS)


def _dedupe_keep_order(values: list[str], limit: int) -> list[str]:
    seen = set()
    output = []
    for value in values:
        key = value.split("#", 1)[0]
        if key in seen:
            continue
        seen.add(key)
        output.append(value)
        if len(output) >= limit:
            break
    return output


def extract_candidate_images(page_url: str, html: str, max_images: int = 12):
    parser = SourceImageExtractor(page_url)
    parser.feed(html)

    regex_urls = re.findall(r"https?://[^'\"\s<>]+?\.(?:jpg|jpeg|png|webp|gif)(?:\?[^'\"\s<>]*)?", html, flags=re.I)
    candidates = parser.image_urls + regex_urls
    image_like = [url for url in candidates if _looks_like_image_url(url)]
    if image_like:
        candidates = image_like + candidates
    return {
        "page_title": parser.title.strip()[:220],
        "meta_description": parser.meta_description.strip()[:320],
        "image_urls": _dedupe_keep_order(candidates, max_images),
    }


def fetch_page(url: str, timeout: int = 12, max_bytes: int = 2_000_000):
    response = requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)
    response.raise_for_status()
    content_type = response.headers.get("content-type", "")
    if "text/html" not in content_type and "application/xhtml" not in content_type and "xml" not in content_type:
        return "", content_type
    return response.text[:max_bytes], content_type


def fetch_image_hash_profile(url: str, timeout: int | None = None, max_bytes: int = 5_000_000):
    timeout = timeout or int(os.getenv("SOURCE_VERIFICATION_IMAGE_TIMEOUT", "4"))
    response = requests.get(url, headers=IMAGE_HEADERS, timeout=timeout, stream=True)
    response.raise_for_status()
    content_type = response.headers.get("content-type", "")
    chunks = []
    total = 0
    for chunk in response.iter_content(chunk_size=65536):
        if not chunk:
            continue
        total += len(chunk)
        if total > max_bytes:
            raise ValueError("candidate image exceeded size limit")
        chunks.append(chunk)
    content = b"".join(chunks)
    return perceptual_hash_profile_from_bytes(content), content_type, total


def provider_attestation_level(source: dict[str, Any], candidate_urls: list[str]) -> str:
    provider = (source.get("provider") or "").lower()
    if provider in {"google_reverse_image", "google_reverse_image_page_2", "bing_reverse_image", "yandex_images"}:
        return "provider_asserted"
    if provider == "google_lens" and candidate_urls:
        return "provider_visual_match"
    return "unverified"


def verify_single_source(source: dict[str, Any], uploaded_profile: dict[str, int], max_candidate_images: int = 10):
    link = source.get("link") or ""
    candidate_urls = _dedupe_keep_order(source.get("candidate_image_urls") or [], max_candidate_images)
    provider_level = provider_attestation_level(source, candidate_urls)
    result = {
        "link": link,
        "title": source.get("title") or "",
        "domain": source.get("source_domain") or source.get("source") or "",
        "provider": source.get("provider") or "",
        "provider_result_url": source.get("provider_result_url") or "",
        "page_fetch_status": "not_used",
        "page_title": "",
        "meta_description": "",
        "candidate_image_count": len(candidate_urls),
        "best_candidate_image": None,
        "image_present": "uncertain",
        "provider_attestation": provider_level,
        "visual_similarity": None,
        "hash_distance": None,
        "hash_method": None,
        "hash_distances": {},
        "evidence_summary": "Source was not checked.",
    }
    if not link:
        result["page_fetch_status"] = "missing_link"
        result["evidence_summary"] = "No source URL was available."
        return result

    if not candidate_urls:
        result["page_fetch_status"] = "not_checked"
        result["image_present"] = "uncertain"
        result["evidence_summary"] = "Provider returned a source result but did not include same-result image URLs; page walking is disabled, so image presence cannot be deterministically checked."
        return result

    # Page-walking fallback is intentionally disabled. The previous behavior
    # fetched publisher HTML and extracted arbitrary page images, but that was
    # slow, brittle, and risked verifying images unrelated to the provider result.
    # html, content_type = fetch_page(link)
    # extracted = extract_candidate_images(link, html, max_candidate_images)
    # image_urls = extracted["image_urls"]

    best = None
    for image_url in candidate_urls:
        try:
            image_profile, content_type, byte_count = fetch_image_hash_profile(image_url)
            comparison = compare_hash_profiles(uploaded_profile, image_profile)
            distance = comparison["best_distance"]
            if distance is None:
                continue
            candidate = {
                "url": image_url,
                "hash_distance": distance,
                "hash_method": comparison["best_method"],
                "hash_distances": comparison["distances"],
                "visual_similarity": comparison["similarity"],
                "content_type": content_type,
                "bytes": byte_count,
            }
            if best is None or distance < best["hash_distance"]:
                best = candidate
        except Exception:
            continue

    if not best:
        result["image_present"] = provider_level if provider_level != "unverified" else "uncertain"
        result["page_fetch_status"] = "candidate_fetch_failed"
        if provider_level != "unverified":
            result["evidence_summary"] = "Provider returned this as a reverse-image source, but candidate image URLs could not be downloaded and hashed. Treat as provider-attested, not hash-confirmed."
        else:
            result["evidence_summary"] = "Same-result candidate image URLs were found, but none could be downloaded and hashed."
        return result

    result["best_candidate_image"] = best["url"]
    result["hash_distance"] = best["hash_distance"]
    result["hash_method"] = best["hash_method"]
    result["hash_distances"] = best["hash_distances"]
    result["visual_similarity"] = best["visual_similarity"]
    # Use avg_distance (average across all hash views) as the classification metric.
    # best_distance alone produces false positives: ahash gives ~15 for unrelated
    # portrait images. avg_distance requires broad agreement across hash algorithms.
    avg_dist = best.get("avg_distance") if best.get("avg_distance") is not None else best["hash_distance"]
    if avg_dist <= 8:
        result["image_present"] = "confirmed"
        result["evidence_summary"] = f"Provider image visually matches upload (avg hash distance {avg_dist:.1f} across {len(best['hash_distances'])} views)."
    elif avg_dist <= 15:
        result["image_present"] = "probable"
        result["evidence_summary"] = f"Provider image is visually similar to upload (avg hash distance {avg_dist:.1f})."
    elif provider_level != "unverified":
        result["image_present"] = provider_level
        result["evidence_summary"] = f"Provider returned this as a reverse-image source; local hash check inconclusive (avg distance {avg_dist:.1f}). Treat as provider-attested."
    else:
        result["image_present"] = "not_confirmed"
        result["evidence_summary"] = f"Provider images did not closely match the upload (avg hash distance {avg_dist:.1f})."
    return result


def quick_verify_thumbnail(
    candidate_image_urls: list[str],
    uploaded_profile: dict[str, int],
    max_to_check: int = 3,
    timeout: int = 3,
) -> dict:
    """
    Quickly compare up to max_to_check thumbnail URLs from a provider result against
    the uploaded image hash profile.  Used at collection time for per-provider tagging.

    Returns:
        match:      "confirmed" | "probable" | "not_matched" | "no_thumbnails" | "failed"
        distance:   int (best hamming distance) or None
        similarity: float 0–1 or None
        url:        str (best candidate URL) or None
        checked:    int (how many thumbnails were actually downloaded)
    """
    urls = [u for u in (candidate_image_urls or []) if u]
    if not urls:
        return {"match": "no_thumbnails", "distance": None, "similarity": None, "url": None, "checked": 0}

    best: dict | None = None
    checked = 0
    for url in urls[:max_to_check]:
        try:
            profile, _, _ = fetch_image_hash_profile(url, timeout=timeout)
            comparison = compare_hash_profiles(uploaded_profile, profile)
            dist = comparison.get("best_distance")
            if dist is None:
                continue
            checked += 1
            if best is None or dist < best["distance"]:
                best = {"url": url, "distance": dist, "similarity": comparison.get("similarity")}
        except Exception:
            continue

    if best is None:
        return {"match": "failed", "distance": None, "similarity": None, "url": None, "checked": checked}

    # Use avg_distance so that a single hash type (ahash) cannot alone produce a
    # false positive for unrelated portrait images.
    avg_dist = best.get("avg_distance") if best.get("avg_distance") is not None else best["distance"]
    if avg_dist <= 8:
        match = "confirmed"
    elif avg_dist <= 15:
        match = "probable"
    else:
        match = "not_matched"

    return {
        "match": match,
        "distance": best["distance"],
        "avg_distance": avg_dist,
        "similarity": best["similarity"],
        "url": best["url"],
        "checked": checked,
    }


def verify_sources_against_image(
    image_path: str,
    sources: list[dict[str, Any]],
    max_sources: int | None = None,
    max_candidate_images: int | None = None,
):
    configured_max_sources = int(os.getenv("SOURCE_VERIFICATION_MAX_SOURCES", "0"))
    max_candidate_images = max_candidate_images or int(os.getenv("SOURCE_VERIFICATION_MAX_IMAGES", "6"))

    # The old implementation checked only the first N provider results. Preserve
    # that behavior here for rollback, but select a provider/domain-diverse batch
    # so a large result set can be reduced without sending hundreds of URLs to an LLM.
    # selected_sources = [source for source in sources if isinstance(source, dict) and source.get("link")][:max_sources]
    candidates = [source for source in sources if isinstance(source, dict) and source.get("link")]
    max_sources = max_sources or configured_max_sources or len(candidates)
    selected_sources = []
    seen_links = set()
    seen_domains = set()
    seen_providers = set()

    # Reserve one candidate per provider before ranking the remaining pool.
    for source in candidates:
        provider = (source.get("provider") or "unknown").lower()
        if provider not in seen_providers:
            selected_sources.append(source)
            seen_providers.add(provider)
            seen_links.add(source.get("link"))
            seen_domains.add((source.get("source_domain") or source.get("source") or urlparse(source.get("link") or "").netloc).lower())
        if len(selected_sources) >= max_sources:
            break

    # Prefer one page per domain so the bounded batch covers the broadest
    # available propagation surface instead of a single provider/domain cluster.
    for source in candidates:
        link = source.get("link")
        if link in seen_links:
            continue
        domain = (source.get("source_domain") or source.get("source") or urlparse(link or "").netloc).lower()
        if domain in seen_domains:
            continue
        selected_sources.append(source)
        seen_links.add(link)
        seen_domains.add(domain)
        if len(selected_sources) >= max_sources:
            break

    if len(selected_sources) < max_sources:
        for source in candidates:
            if source.get("link") in seen_links:
                continue
            selected_sources.append(source)
            seen_links.add(source.get("link"))
            if len(selected_sources) >= max_sources:
                break
    summary = {
        "checked": 0,
        "confirmed": 0,
        "probable": 0,
        "provider_asserted": 0,
        "provider_visual_match": 0,
        "not_confirmed": 0,
        "uncertain": 0,
        "failed": 0,
    }
    if not selected_sources:
        return {"summary": summary, "sources": []}

    try:
        uploaded_profile = perceptual_hash_profile_from_file(image_path)
    except Exception as e:
        return {
            "summary": summary,
            "sources": [],
            "error": f"Unable to hash uploaded image for source verification: {e}",
        }

    verified = []
    configured_workers = int(os.getenv("SOURCE_VERIFICATION_WORKERS", "16"))
    worker_count = min(configured_workers, max(1, len(selected_sources)))
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(verify_single_source, source, uploaded_profile, max_candidate_images): index
            for index, source in enumerate(selected_sources)
        }
        ordered = [None] * len(selected_sources)
        for future in as_completed(futures):
            index = futures[future]
            try:
                ordered[index] = future.result()
            except Exception as e:
                ordered[index] = {
                    "link": selected_sources[index].get("link"),
                    "title": selected_sources[index].get("title") or "",
                    "domain": selected_sources[index].get("source_domain") or selected_sources[index].get("source") or "",
                    "provider": selected_sources[index].get("provider") or "",
                    "page_fetch_status": "failed",
                    "image_present": "uncertain",
                    "provider_attestation": provider_attestation_level(selected_sources[index], selected_sources[index].get("candidate_image_urls") or []),
                    "visual_similarity": None,
                    "hash_distance": None,
                    "hash_method": None,
                    "hash_distances": {},
                    "candidate_image_count": 0,
                    "best_candidate_image": None,
                    "evidence_summary": f"Verification worker failed: {str(e)[:160]}",
                }

    for item in ordered:
        if not item:
            continue
        verified.append(item)
        summary["checked"] += 1
        image_present = item.get("image_present")
        if image_present in summary:
            summary[image_present] += 1
        if "failed" in str(item.get("page_fetch_status") or ""):
            summary["failed"] += 1

    verified_links = {
        item.get("link")
        for item in verified
        if item.get("image_present") in {"confirmed", "probable", "provider_asserted", "provider_visual_match"} and item.get("link")
    }
    verification_by_link = {item.get("link"): item for item in verified if item.get("link")}
    retained_sources = []
    for source in selected_sources:
        link = source.get("link")
        if link not in verified_links:
            continue
        enriched = dict(source)
        evidence = verification_by_link.get(link, {})
        enriched["image_present"] = evidence.get("image_present")
        enriched["verification_status"] = evidence.get("image_present")
        enriched["visual_similarity"] = evidence.get("visual_similarity")
        enriched["hash_distance"] = evidence.get("hash_distance")
        enriched["hash_method"] = evidence.get("hash_method")
        enriched["provider_attestation"] = evidence.get("provider_attestation")
        enriched["verification_summary"] = evidence.get("evidence_summary")
        enriched["best_candidate_image"] = evidence.get("best_candidate_image")
        retained_sources.append(enriched)
    summary["retained"] = len(retained_sources)
    summary["candidates_received"] = len(candidates)
    return {"summary": summary, "sources": verified, "retained_sources": retained_sources}
