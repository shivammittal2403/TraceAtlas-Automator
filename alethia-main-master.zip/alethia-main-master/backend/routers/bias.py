import csv
import os
from dotenv import load_dotenv

load_dotenv()

# Known state-controlled or state-funded propaganda outlets that MBFC
# misclassifies as merely "right-center". These are overridden regardless of
# what the CSV says so the bias chart correctly labels them for a
# misinformation detection tool.
STATE_MEDIA_OVERRIDES = {
    "rt.com": "state-media",
    "sputniknews.com": "state-media",
    "sputnik": "state-media",
    "tass.ru": "state-media",
    "tass.com": "state-media",
    "xinhua.net": "state-media",
    "xinhuanet.com": "state-media",
    "cgtn.com": "state-media",
    "almayadeen.net": "state-media",
    "presstv.ir": "state-media",
    "presstv.com": "state-media",
    "globalvoices.org.ru": "state-media",
    "voanews.com": "state-media-soft",  # US government-funded but editorially independent
    "bbc.com": None,  # public but NOT state-propaganda — leave alone
    "bbc.co.uk": None,
}


def get_bias_data_path():
    path = os.getenv("BIASEDATA_PATH") or "mbfc.csv"
    if os.path.isabs(path):
        return path
    return os.path.join(os.path.dirname(__file__), path)


def load_bias_dictionaries(csv_path):
    bias_by_source = {}
    factual_by_source = {}

    with open(csv_path, newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            source = (row.get("source") or "").strip().lower()
            bias = (row.get("bias") or "").strip()
            factual_reporting = (row.get("factual_reporting") or "").strip()

            if not source:
                continue
            if bias:
                bias_by_source[source] = bias
            if factual_reporting:
                factual_by_source[source] = factual_reporting

    return bias_by_source, factual_by_source


def _resolve_bias(domain: str) -> str | None:
    """
    Look up bias for a domain. Applies state-media overrides first.
    Returns the bias label or None if the domain is not in MBFC.
    """
    key = domain.strip().lower()
    # Remove www. prefix for lookup
    if key.startswith("www."):
        key = key[4:]

    # Override known state media
    if key in STATE_MEDIA_OVERRIDES:
        override = STATE_MEDIA_OVERRIDES[key]
        return override  # may be None (leave alone) or a bias string

    return BIAS_BY_SOURCE.get(key)


BIAS_DATA_PATH = get_bias_data_path()
BIAS_BY_SOURCE, FACTUAL_REPORTING_BY_SOURCE = load_bias_dictionaries(BIAS_DATA_PATH)


def bias_split(domains: list[str]) -> dict:
    """
    Given a list of domain strings from verified sources, return a bias breakdown.

    Includes:
    - Standard MBFC categories with percentage of matched sources
    - "state-media" bucket for known propaganda outlets
    - "unlisted" count and percentage for domains not in MBFC
    - Raw counts alongside percentages for the chart tooltip

    Percentages are computed over ALL sources (matched + unlisted), not just
    matched sources, so the chart correctly shows what fraction is unknown.
    """
    print("--- bias_split function called ---", flush=True)

    score: dict[str, int] = {}
    unlisted_count = 0
    total = len(domains)

    for domain in domains:
        bias = _resolve_bias(str(domain))
        if bias is None:
            unlisted_count += 1
        else:
            score[bias] = score.get(bias, 0) + 1

    if total == 0:
        result = {"no_sources": 100.0}
        print("Bias: no sources", flush=True)
        return result

    values_bias: dict[str, float | int] = {}
    for label, count in score.items():
        values_bias[label] = round((count / total) * 100, 2)

    # Add unlisted as its own bucket
    if unlisted_count > 0:
        values_bias["unlisted"] = round((unlisted_count / total) * 100, 2)

    # Expose raw counts so frontend tooltip can show "X of Y sources"
    values_bias["_counts"] = score | {"unlisted": unlisted_count}
    values_bias["_total"] = total

    print(f"Bias percentages (total={total}, unlisted={unlisted_count}): {values_bias}", flush=True)
    return values_bias
