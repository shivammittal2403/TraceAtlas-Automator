import tldextract
# from mock_response import dictionary_serp

def clean_dict(input_dict):
    sources_links = {}# a dictionary which holds the title of the publisher provided by serp along with the corresponding links these are meant to be the source clusters
    clean_links = []#a list to hold the cleaned links, meaning the base domain of the links
    
    def get_base_domain(url):#extracts the base domain from a url ie google.com from https://www.google.com/search?q=example for example
        ext = tldextract.extract(url)
        return f"{ext.domain}.{ext.suffix}"
        

    print(f"function clean_dict called. Keys: {input_dict.keys()}")
    
    # Try multiple potential keys for SerpAPI results
    results = input_dict.get('image_results')
    if results is None:
        results = input_dict.get('organic_results')
    if results is None:
        results = input_dict.get('visual_matches')
    if results is None:
        results = []

    print(f"Found {len(results)} results to process.")
    if not results:
        return [], [], {}

    image_links = [
        result.get("link")
        for result in results
        if isinstance(result, dict) and result.get("link")
    ]
    # print(image_links)#second comment to understand
    print(f"[Alethia:clean_dict] normalized image links: {len(image_links)}")

    for result in results:
        if not isinstance(result, dict):
            continue
        link = result.get("link")
        if not link:
            continue
        source_domain = result.get("source_domain") or result.get("source") or get_base_domain(link)
        if source_domain not in sources_links:
            sources_links[source_domain] = [link]
        else:
            sources_links[source_domain].append(link)
        clean_links.append(get_base_domain(link))# to be used later for bias analysis

    print(f"Number of image links: {len(image_links)}")
    print(f"Image links: {image_links[:5]}")  # Print first 5 image links for brevity
    return image_links,clean_links, sources_links
# clean_dict(dictionary_serp)
