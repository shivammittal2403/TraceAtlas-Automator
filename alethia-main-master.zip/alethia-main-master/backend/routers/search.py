from fastapi import APIRouter, BackgroundTasks, UploadFile, File, HTTPException, Query
from fastapi.responses import JSONResponse, StreamingResponse
from typing import List, Optional
import os, uuid, requests, time, traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime
from .handle_serp import handle_serp_response
from routers.upload import upload_image_to_cloudinary
from routers.getExif import handle_exif
from .aon.aiOrNot import AIorNot_image_analysis
from .genai_analysis import generate_comprehensive_report, generate_image_first_impression, generate_structured_first_pass
from .masterReverseImageSearch.collector import collect_all_reverse_image_links, dedupe_results, extract_serp_results, results_to_serp_payload
from .yandexReverseImageSearch.yandex_reverse import search_yandex_reverse_image
from .bingReverseImageSearch.bing_reverse import search_bing_reverse_image
from routers.analysis import validate_sources_payload
from routers.source_verification import verify_sources_against_image
from routers.bias import bias_split
import json
import asyncio
import math

# from serpapi import GoogleSearch
SERP_KEY = os.getenv("SERP_API_KEY")

if not SERP_KEY:
    raise ValueError("Environment variable SERP_API_KEY must be set.")

router = APIRouter(prefix="/search", tags=["search"])

REVERSE_IMAGE_PAGE_START = 10
SERPAPI_ENDPOINT = "https://serpapi.com/search"
PIPELINE_STAGES = [
    "upload",
    "cloudinary",
    "google_reverse",
    "google_lens",
    "bing_reverse",
    "yandex_reverse",
    "reverse_collect",
    "source_verification",
    "serp_processing",
    "exif",
    "geoclip",
    "ai_or_not",
    "gemini",
    "source_validation",
    "response",
]
PROGRESS_EVENTS = {}


def log_stage(request_id: str, provider: str, message: str):
    print(f"[Alethia:{request_id}][{provider}] {message}", flush=True)


def emit_progress(progress_id: Optional[str], stage: str, status: str, message: str = "", meta: Optional[dict] = None):
    if not progress_id:
        return
    event = {
        "stage": stage,
        "status": status,
        "message": message,
        "meta": meta or {},
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    PROGRESS_EVENTS.setdefault(progress_id, []).append(event)


def geoclip_summary(exif_data):
    locations = exif_data.get("Estimated Locations") if isinstance(exif_data, dict) else None
    if not isinstance(locations, list) or not locations:
        return None

    points = []
    for index, location in enumerate(locations[:5], start=1):
        try:
            points.append(
                {
                    "match": index,
                    "lat": float(location.get("lat")),
                    "lon": float(location.get("lon")),
                    "confidence": float(location.get("confidence", 0)),
                }
            )
        except (TypeError, ValueError, AttributeError):
            continue

    if not points:
        return None

    clusters = geoclip_clusters(points)
    primary_cluster = clusters[0] if clusters else None
    has_majority_cluster = bool(primary_cluster and primary_cluster["count"] >= 3)
    average_confidence = sum(point["confidence"] for point in points) / len(points)
    return {
        "points": points,
        "polygon": convex_hull(primary_cluster["points"] if has_majority_cluster else points),
        "clusters": clusters,
        "primary_cluster": primary_cluster,
        "map_mode": "majority_point" if has_majority_cluster else "polygon",
        "average_confidence": average_confidence,
        "confidence_percent": round(average_confidence * 100, 2),
        "confidence_level": "low" if average_confidence < 0.15 else "medium" if average_confidence < 0.45 else "high",
    }


def location_decision(exif_data, geo_summary, structured_first_pass=None):
    """
    Reconcile location signals from three sources:
      EXIF GPS   → device/camera location (shown as device_location, not subject location)
      Gemini     → AI inference of where the SUBJECT is (primary subject location)
      GeoCLIP    → visual ML estimate (used only when confidence >= 15%)

    Returns a unified location_analysis dict that the frontend maps as 3 pin types.
    """
    gps_display = exif_data.get("GPS Location") if isinstance(exif_data, dict) else None
    exif_coordinates = exif_data.get("GPS Coordinates Decimal") if isinstance(exif_data, dict) else None
    geoclip_center = None
    geoclip_confidence_pct = 0.0
    if geo_summary and geo_summary.get("primary_cluster"):
        geoclip_center = geo_summary["primary_cluster"].get("center")
        geoclip_confidence_pct = geo_summary.get("confidence_percent", 0.0)

    has_explicit_exif = bool(
        gps_display
        and "Estimated:" not in str(gps_display)
        and str(gps_display) not in {"N/A", "No GPS Data"}
    )

    # Gemini location from structured first pass
    gemini_location = None
    gemini_coords = None
    if structured_first_pass and isinstance(structured_first_pass.get("location"), dict):
        loc = structured_first_pass["location"]
        conf = loc.get("confidence", "insufficient")
        if conf in ("high", "medium") and loc.get("lat") is not None and loc.get("lon") is not None:
            gemini_location = loc
            gemini_coords = {"lat": loc["lat"], "lon": loc["lon"]}

    # GeoCLIP is only trusted above 15% confidence
    geoclip_trusted = geoclip_center is not None and geoclip_confidence_pct >= 15.0

    # Select the primary subject location (NOT the device location)
    # Hierarchy: Gemini (high/medium) > GeoCLIP (>=15%) > EXIF (last resort subject proxy) > none
    if gemini_location:
        selected_source = "gemini"
        selected_coordinates = gemini_coords
        label = "AI-inferred subject location"
        reason = f"Gemini identified the subject location from visual context with {gemini_location.get('confidence')} confidence."
    elif geoclip_trusted:
        selected_source = "geoclip"
        selected_coordinates = geoclip_center
        label = f"GeoCLIP visual estimate ({geoclip_confidence_pct:.1f}% confidence)"
        reason = f"No high-confidence Gemini location. GeoCLIP returned {geoclip_confidence_pct:.1f}% confidence estimate."
    elif has_explicit_exif:
        selected_source = "exif"
        selected_coordinates = exif_coordinates
        label = "EXIF device GPS (subject location unresolved)"
        reason = "No Gemini or GeoCLIP location available. EXIF GPS shows where the device was, not necessarily what is depicted."
    else:
        selected_source = "none"
        selected_coordinates = None
        label = "No location signal available"
        reason = "No EXIF GPS, Gemini inference, or GeoCLIP estimate could resolve a location."

    # Build list of which sources are available
    location_sources = []
    if has_explicit_exif:
        location_sources.append("exif")
    if gemini_location:
        location_sources.append("gemini")
    if geoclip_trusted:
        location_sources.append("geoclip")

    return {
        "selected_source": selected_source,
        "label": label,
        "reason": reason,
        "gps_display": gps_display,
        "selected_coordinates": selected_coordinates,
        "geoclip_used": geoclip_trusted,
        "geoclip_coordinates": geoclip_center,
        "geoclip_confidence_percent": geoclip_confidence_pct,
        # Device location shown separately — EXIF tells you where the camera was, not the subject
        "device_location": {
            "display": gps_display,
            "coordinates": exif_coordinates,
            "available": has_explicit_exif,
        },
        # Gemini subject location inference
        "gemini_location": gemini_location,
        "gemini_coordinates": gemini_coords,
        # All available sources for the frontend multi-pin map
        "location_sources": location_sources,
    }


def haversine_km(left, right):
    radius_km = 6371
    lat1 = math.radians(left["lat"])
    lat2 = math.radians(right["lat"])
    delta_lat = math.radians(right["lat"] - left["lat"])
    delta_lon = math.radians(right["lon"] - left["lon"])
    a = math.sin(delta_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(delta_lon / 2) ** 2
    return radius_km * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def geoclip_clusters(points, threshold_km=75):
    clusters = []
    for point in points:
        placed = False
        for cluster in clusters:
            if haversine_km(point, cluster["center"]) <= threshold_km:
                cluster["points"].append(point)
                cluster["count"] = len(cluster["points"])
                cluster["center"] = weighted_center(cluster["points"])
                cluster["average_confidence"] = sum(item["confidence"] for item in cluster["points"]) / cluster["count"]
                placed = True
                break
        if not placed:
            clusters.append(
                {
                    "points": [point],
                    "count": 1,
                    "center": dict(point),
                    "average_confidence": point["confidence"],
                }
            )
    return sorted(clusters, key=lambda cluster: (cluster["count"], cluster["average_confidence"]), reverse=True)


def weighted_center(points):
    total_weight = sum(max(point["confidence"], 0.0001) for point in points)
    return {
        "lat": sum(point["lat"] * max(point["confidence"], 0.0001) for point in points) / total_weight,
        "lon": sum(point["lon"] * max(point["confidence"], 0.0001) for point in points) / total_weight,
        "confidence": sum(point["confidence"] for point in points) / len(points),
    }


def convex_hull(points):
    if len(points) <= 2:
        return points

    sorted_points = sorted(points, key=lambda point: (point["lon"], point["lat"]))

    def cross(origin, left, right):
        return ((left["lon"] - origin["lon"]) * (right["lat"] - origin["lat"])) - (
            (left["lat"] - origin["lat"]) * (right["lon"] - origin["lon"])
        )

    lower = []
    for point in sorted_points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= 0:
            lower.pop()
        lower.append(point)

    upper = []
    for point in reversed(sorted_points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= 0:
            upper.pop()
        upper.append(point)

    return lower[:-1] + upper[:-1]


def _parallel_exif_geoclip(file_path, progress_id, request_id):
    exif_data = {}
    try:
        emit_progress(progress_id, "exif", "running", "Extracting metadata and camera signals.")
        log_stage(request_id, "exif", f"calling handle_exif for={file_path}")
        ex_data = handle_exif(file_path)
        if ex_data:
            exif_data = ex_data
            log_stage(request_id, "exif", f"extraction successful keys={list(exif_data.keys())}")
            emit_progress(progress_id, "exif", "complete", "Metadata extraction complete.", {"keys": list(exif_data.keys())})
        else:
            log_stage(request_id, "exif", "handle_exif returned None or empty")
            emit_progress(progress_id, "exif", "warning", "No metadata returned.")
    except Exception as e:
        log_stage(request_id, "exif", f"CRITICAL ERROR in handle_exif: {e}")
        emit_progress(progress_id, "exif", "warning", f"Metadata extraction warning: {e}")

    geo_summary = geoclip_summary(exif_data)
    if geo_summary:
        emit_progress(progress_id, "geoclip", "complete", "GeoCLIP returned estimated location matches.", {"confidence_percent": geo_summary["confidence_percent"]})
    else:
        emit_progress(progress_id, "geoclip", "warning", "GeoCLIP did not return usable estimated matches.")
    return exif_data, geo_summary


def _parallel_ai_or_not(file_path, progress_id, request_id):
    ai_analysis = {}
    try:
        emit_progress(progress_id, "ai_or_not", "running", "Checking AI-generation likelihood.")
        result = AIorNot_image_analysis(file_path)
        if result is not None:
            ai_analysis = result
        emit_progress(progress_id, "ai_or_not", "complete", "AI-generation check complete.", {"verdict": ai_analysis.get("verdict")})
    except Exception as e:
        log_stage(request_id, "ai_or_not", f"Error processing AI detection: {e}")
        emit_progress(progress_id, "ai_or_not", "warning", f"AI-generation check warning: {e}")
    return ai_analysis


def _parallel_gemini_first_pass(file_path, progress_id, request_id):
    try:
        emit_progress(progress_id, "gemini", "running", "Running structured image classification.")
        result = generate_structured_first_pass(file_path)
        if result:
            emit_progress(progress_id, "gemini", "running", f"Classification: {result.get('subject_category', 'unknown')}.")
            log_stage(request_id, "gemini", f"structured first pass category={result.get('subject_category')} location_confidence={result.get('location', {}).get('confidence')}")
        else:
            log_stage(request_id, "gemini", "structured first pass returned None")
        return result
    except Exception as e:
        log_stage(request_id, "gemini", f"Structured first pass failed: {e}")
        return None


@router.get("/progress/{progress_id}")
async def progress_stream(progress_id: str):
    PROGRESS_EVENTS.setdefault(progress_id, [])

    async def event_generator():
        cursor = 0
        idle_ticks = 0
        while idle_ticks < 600:
            events = PROGRESS_EVENTS.get(progress_id, [])
            while cursor < len(events):
                event = events[cursor]
                cursor += 1
                yield f"data: {json.dumps(event)}\n\n"
                if event.get("stage") == "response" and event.get("status") in {"complete", "failed"}:
                    await asyncio.sleep(1)
                    PROGRESS_EVENTS.pop(progress_id, None)
                    return
            idle_ticks += 1
            await asyncio.sleep(0.5)

    return StreamingResponse(event_generator(), media_type="text/event-stream")


def collect_earliest_dates_per_provider(results: list[dict]) -> dict:
    """
    Scan all candidate results, parse their provider-supplied date strings,
    group by provider, and return the earliest date per provider plus the
    global earliest across all providers.

    Dates that cannot be parsed are silently dropped.  Provider date strings
    arrive in a variety of formats; the most common are handled here.
    """
    from datetime import datetime

    DATE_FORMATS = [
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%d %B %Y",
        "%B %d, %Y",
        "%b %d, %Y",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S",
        "%d/%m/%Y",
        "%m/%d/%Y",
    ]

    provider_dates: dict[str, list[str]] = {}
    for result in results:
        if not isinstance(result, dict):
            continue
        provider = (result.get("provider") or "unknown").strip()
        raw_date = (result.get("date") or "").strip()
        if not raw_date:
            continue
        normalized: str | None = None
        for fmt in DATE_FORMATS:
            try:
                dt = datetime.strptime(raw_date, fmt)
                normalized = dt.strftime("%Y-%m-%d")
                break
            except (ValueError, TypeError):
                continue
        if normalized:
            provider_dates.setdefault(provider, []).append(normalized)

    per_provider: dict[str, str] = {}
    for provider, dates in provider_dates.items():
        unique_sorted = sorted(set(dates))
        if unique_sorted:
            per_provider[provider] = unique_sorted[0]  # earliest first

    global_earliest = min(per_provider.values()) if per_provider else ""
    return {
        "per_provider": per_provider,
        "earliest": global_earliest,
        "parsed_count": sum(len(v) for v in provider_dates.values()),
    }


def result_count(data, keys):
    if not isinstance(data, dict):
        return 0
    total = 0
    for key in keys:
        value = data.get(key)
        if isinstance(value, list):
            total += len(value)
    return total


def call_serpapi_provider(request_id: str, provider: str, params: dict, result_keys: tuple[str, ...]):
    log_stage(request_id, provider, f"request start engine={params.get('engine')}")
    try:
        response = requests.get(SERPAPI_ENDPOINT, params=params, timeout=60)
    except Exception as e:
        log_stage(request_id, provider, f"request failed: {e}")
        return {}

    log_stage(request_id, provider, f"http status={response.status_code}")
    if response.status_code != 200:
        log_stage(request_id, provider, f"http error body={response.text[:500]}")
        return {}

    try:
        data = response.json()
    except Exception as e:
        log_stage(request_id, provider, f"json decode failed: {e}")
        return {}

    keys = list(data.keys()) if isinstance(data, dict) else []
    log_stage(request_id, provider, f"response keys={keys}")
    if isinstance(data, dict) and data.get("error"):
        log_stage(request_id, provider, f"provider returned no usable results: {data.get('error')}")
        return data

    log_stage(request_id, provider, f"usable result count={result_count(data, result_keys)}")
    return data


def extract_valid_date(date_str):
    try:
        return datetime.fromisoformat(date_str)
    except Exception:
        return None

def remove_file(path):
    if os.path.exists(path):
        os.remove(path)
        print(f"Removed file: {path}")


def source_clusters_from_results(results):
    clusters = {}
    for result in results:
        source = result.get("source_domain") or result.get("source")
        link = result.get("link")
        if not source or not link:
            continue
        clusters.setdefault(source, []).append(link)
    return clusters


def source_context_from_results(results, limit=80):
    context = []
    seen = set()
    for result in results or []:
        if not isinstance(result, dict):
            continue
        link = result.get("link")
        if not link or link in seen:
            continue
        seen.add(link)
        context.append(
            {
                "title": result.get("title") or "",
                "snippet": result.get("snippet") or "",
                "source": result.get("source") or result.get("source_domain") or "",
                "source_domain": result.get("source_domain") or result.get("source") or "",
                "provider": result.get("provider") or "unknown",
                "date": result.get("date") or "",
                "link": link,
                "image_present": result.get("image_present") or result.get("verification_status") or "",
            }
        )
        if len(context) >= limit:
            break
    return context


@router.get("/image/more")
async def more_image_sources(
    image_url: str = Query(..., description="Public image URL returned by the first upload response."),
    provider: str = Query("google_reverse_image", description="google_reverse_image, google_lens, yandex_images, or bing_reverse_image."),
    start: int = Query(10, ge=0, description="Offset for Google reverse image pagination."),
    page: int = Query(1, ge=0, description="Page number for Yandex Images pagination."),
    lens_type: str = Query("visual_matches", description="Google Lens type: all, visual_matches, exact_matches, products, about_this_image."),
):
    provider = provider.strip().lower()

    try:
        if provider == "google_reverse_image":
            params = {
                "engine": "google_reverse_image",
                "image_url": image_url,
                "api_key": SERP_KEY,
                "start": start,
            }
            response = requests.get(SERPAPI_ENDPOINT, params=params, timeout=60)
            response.raise_for_status()
            raw_data = response.json()
            results = extract_serp_results(raw_data, "google_reverse_image")
            next_cursor = {"start": start + 10, "page": page}
        elif provider == "google_lens":
            params = {
                "engine": "google_lens",
                "url": image_url,
                "api_key": SERP_KEY,
                "type": lens_type,
            }
            response = requests.get(SERPAPI_ENDPOINT, params=params, timeout=60)
            response.raise_for_status()
            raw_data = response.json()
            results = extract_serp_results(raw_data, "google_lens")
            next_cursor = {"start": start, "page": page}
        elif provider == "yandex_images":
            raw_data = {}
            results = search_yandex_reverse_image(image_url=image_url, page=page)
            next_cursor = {"start": start, "page": page + 1}
        elif provider == "bing_reverse_image":
            raw_data = {}
            results = search_bing_reverse_image(image_url=image_url)
            next_cursor = {"start": start, "page": page}
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported provider: {provider}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"{provider} pagination failed: {e}")

    normalized_results = [result for result in dedupe_results(results)]
    result_dicts = [
        {
            "link": result.link,
            "source": result.source,
            "source_domain": result.source_domain,
            "title": result.title,
            "provider": result.provider,
            "kind": result.kind,
            "raw_source": result.raw_source,
            "snippet": result.snippet,
            "date": result.date,
            "candidate_image_urls": result.candidate_image_urls,
        }
        for result in normalized_results
    ]

    return JSONResponse(
        content={
            "provider": provider,
            "count": len(result_dicts),
            "next": next_cursor,
            "reverse_search_links": result_dicts,
            "source_clusters": source_clusters_from_results(result_dicts),
            "raw_keys": list(raw_data.keys()) if isinstance(raw_data, dict) else [],
        }
    )

@router.post("/image")
def search_image(background_tasks: BackgroundTasks, file: UploadFile = File(...), progress_id: Optional[str] = Query(None)):
    request_id = str(uuid.uuid4())[:8]
    upload_dir = "static/uploads/"
    os.makedirs(upload_dir, exist_ok=True)

    ext = os.path.splitext(file.filename)[1]
    file_name = f"{uuid.uuid4()}{ext}"
    #below is the updloaded image path. calls from ai or not and exif can be added here
    file_path = os.path.join(upload_dir, file_name)

    try:
        emit_progress(progress_id, "upload", "running", "Saving uploaded image locally.")
        # Save uploaded file to local path
        with open(file_path, "wb") as f:
            content = file.file.read()
            f.write(content)
        background_tasks.add_task(remove_file, file_path)
        log_stage(request_id, "upload", f"saved local file={file_path} bytes={len(content)} content_type={file.content_type}")
        emit_progress(progress_id, "upload", "complete", "Uploaded image saved.", {"bytes": len(content), "content_type": file.content_type})

        # Upload to Cloudinary and get public URL
        emit_progress(progress_id, "cloudinary", "running", "Publishing image for reverse-search providers.")
        public_url = upload_image_to_cloudinary(file_path)
        log_stage(request_id, "cloudinary", f"public_url={public_url}")
        if not public_url:
            emit_progress(progress_id, "cloudinary", "failed", "Cloudinary upload failed.")
            raise HTTPException(status_code=502, detail="Cloudinary upload failed.")
        emit_progress(progress_id, "cloudinary", "complete", "Public analysis URL created.")
    except HTTPException:
        raise
    except Exception as e:
        log_stage(request_id, "upload", f"upload preparation failed: {e}")
        emit_progress(progress_id, "upload", "failed", f"Upload preparation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Upload preparation failed: {e}")
#-------------------------serp api call
    # Call SerpAPI
    params = {
        "engine": "google_reverse_image",
        "image_url": public_url,
        "api_key": SERP_KEY,
    }

    params_for_lens = {
        "engine": "google_lens",
        "url": public_url,
        "api_key": SERP_KEY,
    }

    emit_progress(progress_id, "google_reverse", "running", "Checking Google Reverse Image results.")
    reverse_image_page_2_params = dict(params)
    reverse_image_page_2_params["start"] = REVERSE_IMAGE_PAGE_START
    emit_progress(progress_id, "google_lens", "running", "Checking Google Lens visual matches.")

    # Launch EXIF + AI-or-Not + Gemini first pass immediately alongside SERP calls
    early_executor = ThreadPoolExecutor(max_workers=3)
    exif_geo_future = early_executor.submit(_parallel_exif_geoclip, file_path, progress_id, request_id)
    ai_future = early_executor.submit(_parallel_ai_or_not, file_path, progress_id, request_id)
    gemini_first_pass_future = early_executor.submit(_parallel_gemini_first_pass, file_path, progress_id, request_id)

    with ThreadPoolExecutor(max_workers=3) as executor:
        google_reverse_future = executor.submit(
            call_serpapi_provider,
            request_id,
            "google_reverse_image_page_1",
            params,
            ("image_results", "organic_results", "reverse_image_search"),
        )
        google_reverse_page_2_future = executor.submit(
            call_serpapi_provider,
            request_id,
            "google_reverse_image_page_2",
            reverse_image_page_2_params,
            ("image_results", "organic_results", "reverse_image_search"),
        )
        lens_future = executor.submit(
            call_serpapi_provider,
            request_id,
            "google_lens",
            params_for_lens,
            ("visual_matches", "exact_matches", "organic_results"),
        )
        data = google_reverse_future.result()
        reverse_image_page_2_data = google_reverse_page_2_future.result()
        lens_data = lens_future.result()

    if reverse_image_page_2_data:
        page_2_titles = [item.get("title") for item in reverse_image_page_2_data.get("image_results", [])[:5]]
        log_stage(request_id, "google_reverse_image_page_2", f"sample titles={page_2_titles}")
    google_reverse_count = result_count(data, ("image_results", "organic_results", "reverse_image_search")) + result_count(reverse_image_page_2_data, ("image_results", "organic_results", "reverse_image_search"))
    emit_progress(
        progress_id,
        "google_reverse",
        "complete" if google_reverse_count else "warning",
        "Google Reverse Image returned matches." if google_reverse_count else "Google Reverse Image returned no indexed matches.",
        {"count": google_reverse_count},
    )
    lens_count = result_count(lens_data, ("visual_matches", "exact_matches", "organic_results"))
    emit_progress(
        progress_id,
        "google_lens",
        "complete" if lens_count else "warning",
        "Google Lens returned visual matches." if lens_count else "Google Lens returned no visual matches.",
        {"count": lens_count},
    )
    if "error" in (data or {}):
        log_stage(request_id, "google_reverse_image_page_1", f"provider error={data['error']}")

    emit_progress(progress_id, "bing_reverse", "running", "Checking Bing reverse-image sources.")
    emit_progress(progress_id, "yandex_reverse", "running", "Checking Yandex image results.")
    emit_progress(progress_id, "reverse_collect", "running", "Collecting and deduplicating reverse-image sources.")
    reverse_search_results = collect_all_reverse_image_links(
        file_path=file_path,
        public_url=public_url,
        google_reverse_data=data,
        google_lens_data=lens_data,
        google_reverse_page_2_data=reverse_image_page_2_data,
    )
    candidate_sources = list(reverse_search_results)
    combined_search_data = results_to_serp_payload(reverse_search_results)

    processed_data = {
        "image_description": "No description available.",
        "biases": {},
        "source_clusters": {},
    }

    # Extract dates from all candidate results grouped by provider.
    # This runs immediately after collection so every provider's dates are captured
    # before any downstream filtering (source verification) reduces the set.
    provider_date_info = collect_earliest_dates_per_provider(candidate_sources)
    log_stage(request_id, "dates", f"per-provider dates={provider_date_info['per_provider']} earliest={provider_date_info['earliest']}")
    processed_data["earliest_date"] = provider_date_info["earliest"]
    processed_data["earliest_date_per_provider"] = provider_date_info["per_provider"]
    log_stage(request_id, "collector", f"combined reverse image links after dedupe={len(reverse_search_results)}")
    provider_counts = {}
    for result in reverse_search_results:
        provider = result.get("provider") if isinstance(result, dict) else getattr(result, "provider", None)
        if not provider:
            continue
        provider_counts[provider] = provider_counts.get(provider, 0) + 1
    bing_count = provider_counts.get("bing_reverse_image", 0)
    yandex_count = provider_counts.get("yandex_images", 0)
    emit_progress(
        progress_id,
        "bing_reverse",
        "complete" if bing_count else "warning",
        "Bing returned reverse-image sources." if bing_count else "Bing returned no usable reverse-image sources.",
        {"count": bing_count},
    )
    emit_progress(
        progress_id,
        "yandex_reverse",
        "complete" if yandex_count else "warning",
        "Yandex returned image sources." if yandex_count else "Yandex returned no usable image sources.",
        {"count": yandex_count},
    )
    emit_progress(progress_id, "reverse_collect", "complete", "Reverse-image sources collected and deduplicated.", {"count": len(reverse_search_results)})

    # Join parallel early-analysis tasks (EXIF/GeoCLIP, AI-or-Not, Gemini first pass)
    # These were launched alongside the SERP calls and should be done or nearly done by now.
    try:
        exif_data, geo_summary = exif_geo_future.result(timeout=45)
    except Exception as e:
        log_stage(request_id, "exif", f"parallel exif/geoclip failed: {e}")
        exif_data, geo_summary = {}, None

    try:
        ai_analysis = ai_future.result(timeout=45)
    except Exception as e:
        log_stage(request_id, "ai_or_not", f"parallel ai-or-not failed: {e}")
        ai_analysis = {}

    try:
        structured_first_pass = gemini_first_pass_future.result(timeout=60)
    except Exception as e:
        log_stage(request_id, "gemini", f"parallel gemini first pass failed: {e}")
        structured_first_pass = None
    finally:
        early_executor.shutdown(wait=False)

    location_analysis = location_decision(exif_data, geo_summary, structured_first_pass)
        
    organic_results = combined_search_data.get("organic_results", [])
    print("---------------------------------", flush=True)
    # Previous debug output printed every organic result and could overwhelm or
    # crash Windows terminals with provider URLs containing non-CP1252 text.
    # print(f"organic results:- {organic_results}")
    log_stage(request_id, "collector", f"organic result count={len(organic_results)}")
    log_stage(request_id, "collector", f"organic result sample={organic_results[:5]}")
    total_matches = combined_search_data.get("search_information", {}).get("total_results", 0)

    # Fix: If API reports 0 total results but we have organic results, use the count of organic results
    if total_matches == 0 and organic_results:
        total_matches = len(organic_results)

    # --- NEW: Generate Comprehensive AI Report ---
    # This overrides the basic description from handle_serp_response if successful
    # Report generation previously ran here against unverified provider results.
    # It now runs after deterministic source-page image verification below so the
    # model receives the original image plus a compact, evidence-backed source set.
    # ---------------------------------------------

    source_verification = None
    try:
        emit_progress(progress_id, "source_verification", "running", "Checking provider reverse-image attestations and local visual hashes.")
        source_verification = verify_sources_against_image(file_path, reverse_search_results, max_sources=60)
        verification_summary = source_verification.get("summary", {}) if isinstance(source_verification, dict) else {}
        emit_progress(
            progress_id,
            "source_verification",
            "complete",
            "Provider attestation and local image checks complete.",
            verification_summary,
        )
    except Exception as e:
        log_stage(request_id, "source_verification", f"Source page verification failed: {e}")
        emit_progress(progress_id, "source_verification", "warning", f"Source page verification warning: {e}")

    retained_sources = (
        source_verification.get("retained_sources", [])
        if isinstance(source_verification, dict)
        else []
    )
    reverse_search_results = retained_sources
    total_matches = len(reverse_search_results)
    filtered_search_data = results_to_serp_payload(reverse_search_results)
    processed_data["source_clusters"] = source_clusters_from_results(reverse_search_results)
    processed_data["event_context_sources"] = source_context_from_results(candidate_sources, limit=80)
    filtered_domains = [
        source.get("source_domain") or source.get("source")
        for source in reverse_search_results
        if source.get("source_domain") or source.get("source")
    ]
    processed_data["biases"] = bias_split(filtered_domains)
    if os.getenv("ENABLE_WAYBACK_DATE_CHECKS", "false").lower() not in {"0", "false", "no"}:
        try:
            emit_progress(progress_id, "serp_processing", "running", "Processing verified source dates and clusters.")
            verified_serp_result = handle_serp_response(filtered_search_data, None)
            if verified_serp_result:
                wayback_date = verified_serp_result.get("earliest_date", "")
                # Use Wayback date only if it predates the provider-supplied earliest
                current_earliest = processed_data.get("earliest_date", "")
                if wayback_date and (not current_earliest or wayback_date < current_earliest):
                    processed_data["earliest_date"] = wayback_date
                    log_stage(request_id, "serp_processing", f"Wayback date {wayback_date} predates provider dates; using Wayback.")
            emit_progress(progress_id, "serp_processing", "complete", "Verified source processing complete.")
        except Exception as e:
            log_stage(request_id, "serp_processing", f"Error processing verified sources: {e}")
            emit_progress(progress_id, "serp_processing", "warning", f"Verified source processing warning: {e}")
    else:
        # provider_date_info is already stored in processed_data["earliest_date"] above.
        emit_progress(
            progress_id,
            "serp_processing",
            "complete" if processed_data.get("earliest_date") else "warning",
            f"Earliest date from provider results: {processed_data.get('earliest_date') or 'none found'}",
        )

    # Use first_impression from structured first pass; fall back to a brief async call only if unavailable
    first_visual_assessment = None
    if structured_first_pass and structured_first_pass.get("first_impression"):
        first_visual_assessment = structured_first_pass["first_impression"]
        log_stage(request_id, "gemini", f"using first impression from structured first pass ({len(first_visual_assessment)} chars)")
    else:
        try:
            log_stage(request_id, "gemini", "structured first pass had no impression; running fallback first impression")
            emit_progress(progress_id, "gemini", "running", "Creating image-only first impression.")
            first_visual_assessment = generate_image_first_impression(file_path)
        except Exception as e:
            log_stage(request_id, "gemini", f"fallback first impression failed: {e}")

    try:
        log_stage(request_id, "gemini", "generating comprehensive OSINT report with verified evidence")
        emit_progress(progress_id, "gemini", "running", "Generating full AI evidence report.")
        comprehensive_desc = generate_comprehensive_report(
            file_path,
            filtered_search_data,
            exif_data,
            ai_analysis,
            source_verification,
            first_visual_assessment,
            candidate_sources=candidate_sources,
            biases=processed_data.get("biases"),
            location_analysis=location_analysis,
            structured_first_pass=structured_first_pass,
        )
        if comprehensive_desc:
            processed_data["image_first_impression"] = first_visual_assessment
            processed_data["image_description"] = comprehensive_desc
            emit_progress(progress_id, "gemini", "complete", "Image-aware evidence report generated.")
        else:
            emit_progress(progress_id, "gemini", "warning", "Gemini returned no report text; keeping fallback description.")
    except Exception as e:
        import traceback
        print(f"[CRITICAL][gemini] comprehensive report failed: {type(e).__name__}: {e}", flush=True)
        traceback.print_exc()
        log_stage(request_id, "gemini", f"Failed to generate comprehensive report: {e}")
        emit_progress(progress_id, "gemini", "warning", f"Final AI report error: {type(e).__name__}: {e}")

    source_validation = None
    if os.getenv("ENABLE_LLM_SOURCE_VALIDATION", "false").lower() not in {"0", "false", "no"}:
        try:
            emit_progress(progress_id, "source_validation", "running", "Validating source relevance.")
            validation_report = {
                "image_url": public_url,
                "total_matches": total_matches,
                "reverse_search_links": reverse_search_results,
                "exif_data": exif_data,
                "geoclip_analysis": geo_summary,
                "ai_analysis": ai_analysis,
                "source_verification": source_verification,
            }
            validation_report.update(processed_data)
            source_validation = validate_sources_payload(validation_report, source_verification.get("sources", []) if isinstance(source_verification, dict) else [], 60)
            emit_progress(
                progress_id,
                "source_validation",
                "complete",
                "Source relevance validation complete.",
                {"validated": len(source_validation.get("validated_sources", [])) if isinstance(source_validation, dict) else 0},
            )
        except Exception as e:
            log_stage(request_id, "source_validation", f"Source validation failed: {e}")
            emit_progress(progress_id, "source_validation", "warning", f"Source validation warning: {e}")
    else:
        emit_progress(progress_id, "source_validation", "complete", "LLM source validation skipped; provider-image hash verification is authoritative.")

    response_payload = {
        "image_url": public_url,
        "total_matches": total_matches,
        "reverse_search_links": reverse_search_results,
        "candidate_sources": candidate_sources,
    }
    response_payload.update(processed_data)
    response_payload["exif_data"] = exif_data
    response_payload["geoclip_analysis"] = geo_summary
    response_payload["location_analysis"] = location_analysis
    response_payload["image_first_impression"] = processed_data.get("image_first_impression") or first_visual_assessment
    response_payload["source_verification"] = source_verification
    response_payload["source_validation"] = source_validation
    response_payload["ai_analysis"] = ai_analysis
    response_payload["earliest_date_per_provider"] = processed_data.get("earliest_date_per_provider", {})
    # Structured first pass fields — used by frontend ImageClassificationPanel, map, bias signal
    if structured_first_pass:
        response_payload["gemini_subject_category"] = structured_first_pass.get("subject_category")
        response_payload["gemini_key_phrases"] = structured_first_pass.get("key_phrases") or []
        response_payload["gemini_is_screenshot"] = structured_first_pass.get("is_screenshot") or False
        response_payload["gemini_political_lean"] = structured_first_pass.get("political_lean_signal")
        response_payload["gemini_location"] = structured_first_pass.get("location")
        response_payload["gemini_ai_generation_signals"] = structured_first_pass.get("ai_generation_signals") or []
    else:
        response_payload["gemini_subject_category"] = None
        response_payload["gemini_key_phrases"] = []
        response_payload["gemini_is_screenshot"] = False
        response_payload["gemini_political_lean"] = None
        response_payload["gemini_location"] = None
        response_payload["gemini_ai_generation_signals"] = []

    log_stage(request_id, "response", f"returning payload total_matches={total_matches} source_clusters={len(response_payload.get('source_clusters') or {})}")
    emit_progress(progress_id, "response", "complete", "Report payload ready.", {"total_matches": total_matches})
    return JSONResponse(content=response_payload)
