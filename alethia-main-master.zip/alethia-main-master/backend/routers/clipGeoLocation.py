import threading
import torch
from geoclip import GeoCLIP

_model_lock = threading.Lock()
_GEOCLIP_MODEL = None


def _unwrap_clip_image_features(output):
    """Keep GeoCLIP compatible with Transformers versions returning model outputs."""
    if torch.is_tensor(output):
        return output
    if hasattr(output, "pooler_output") and output.pooler_output is not None:
        return output.pooler_output
    if isinstance(output, (tuple, list)) and output:
        return output[0]
    raise TypeError(f"Unsupported CLIP image feature output: {type(output).__name__}")


def _make_geoclip_model():
    global _GEOCLIP_MODEL
    if _GEOCLIP_MODEL is not None:
        return _GEOCLIP_MODEL
    with _model_lock:
        if _GEOCLIP_MODEL is not None:
            return _GEOCLIP_MODEL
        model = GeoCLIP()
        original_get_image_features = model.image_encoder.CLIP.get_image_features

        def get_image_features_tensor(*args, **kwargs):
            return _unwrap_clip_image_features(original_get_image_features(*args, **kwargs))

        model.image_encoder.CLIP.get_image_features = get_image_features_tensor
        _GEOCLIP_MODEL = model
    return _GEOCLIP_MODEL


def locate_image(image_path):
    model = _make_geoclip_model()
    top_pred_gps, top_pred_prob = model.predict(image_path, top_k=5)

    results = []
    for i in range(5):
        lat, lon = top_pred_gps[i]
        confidence = float(top_pred_prob[i].item()) if hasattr(top_pred_prob[i], "item") else float(top_pred_prob[i])
        print(f"Match {i+1}: {lat:.6f}, {lon: .6f} | Confidence: {confidence:.4f}")
        results.append({"lat": float(lat), "lon": float(lon), "confidence": confidence})

    return results
