import os
from typing import Any

import requests

from ..masterReverseImageSearch.results import extract_url_value, make_result


SERPAPI_ENDPOINT = "https://serpapi.com/search"


def _result_from_item(item: dict[str, Any], link_key: str, kind: str):
    link = item.get(link_key)
    if not link:
        return None
    original_image = item.get("original_image") if isinstance(item.get("original_image"), dict) else {}
    thumbnail = item.get("thumbnail") if isinstance(item.get("thumbnail"), dict) else {}
    return make_result(
        link=link,
        source=item.get("source") or item.get("domain"),
        title=item.get("title") or item.get("name") or item.get("snippet") or "",
        provider="yandex_images",
        kind=kind,
        candidate_image_urls=[
            extract_url_value(original_image),
            extract_url_value(thumbnail),
        ],
        snippet=item.get("snippet") or item.get("description") or "",
        width=original_image.get("width") or thumbnail.get("width") or "",
        height=original_image.get("height") or thumbnail.get("height") or "",
    )


def _parse_yandex_response(data: dict[str, Any]):
    results = []
    for item in data.get("image_results", []):
        if not isinstance(item, dict):
            continue

        # Match the Google reverse/Lens contract: one canonical publisher page
        # per selected result item, with source/domain and title metadata.
        result = _result_from_item(item, "link", "page")
        if result:
            results.append(result)

    # Previous behavior preserved for rollback. It processed several collections
    # and emitted page, image, thumbnail, and preview URLs as separate matches.
    # for key in ("image_results", "images_results", "similar_images", "shopping_results"):
    #     values = data.get(key)
    #     if not isinstance(values, list):
    #         continue
    #     for item in values:
    #         if not isinstance(item, dict):
    #             continue

    #         for link_key, kind in (
    #             ("link", "page"),
    #             ("source", "page"),
    #             ("original", "image"),
    #             ("image", "image"),
    #             ("thumbnail", "thumbnail"),
    #         ):
    #             result = _result_from_item(item, link_key, kind)
    #             if result:
    #                 results.append(result)

    # image_preview = data.get("image_preview", {})
    # if isinstance(image_preview, dict):
    #     image = image_preview.get("image", {})
    #     if isinstance(image, dict):
    #         result = _result_from_item(image, "link", "image_preview")
    #         if result:
    #             results.append(result)

    return results


def search_yandex_reverse_image(image_url: str | None = None, page: int | None = None):
    if not image_url:
        return []

    api_key = os.getenv("SERP_API_KEY")
    endpoint = os.getenv("YANDEX_SERPAPI_ENDPOINT", SERPAPI_ENDPOINT)

    if not api_key:
        print("Skipping Yandex reverse image search: SERP_API_KEY is not set.")
        return []

    params = {
        "engine": "yandex_images",
        "url": image_url,
        "api_key": api_key,
        "tab": os.getenv("YANDEX_REVERSE_IMAGE_TAB", "about"),
    }
    if page is not None and page > 0:
        params["p"] = page
    response = requests.get(endpoint, params=params, timeout=30)
    response.raise_for_status()
    return _parse_yandex_response(response.json())
