import os
from typing import Any

import requests

from ..masterReverseImageSearch.results import dedupe_url_key, make_result, normalize_url


DEFAULT_ENDPOINT = "https://serpapi.com/search"


def _result_from_item(item: dict[str, Any], link_key: str, kind: str):
    link = item.get(link_key)
    if not link:
        return None
    return make_result(
        link=link,
        provider="bing_reverse_image",
        source=item.get("source") or item.get("domain"),
        title=item.get("title") or item.get("name") or "",
        kind=kind,
        provider_result_url=item.get("link") if link_key == "source" else "",
        candidate_image_urls=[
            item.get("original"),
            item.get("cdn_original"),
            item.get("thumbnail"),
        ],
        snippet=item.get("snippet") or item.get("description") or "",
        date=item.get("date") or "",
        width=item.get("width") or "",
        height=item.get("height") or "",
        image_format=item.get("format") or "",
        file_size=item.get("file_size") or "",
    )


def _parse_bing_response(data: dict[str, Any]):
    results = []
    seen_links = set()

    # Process related content first, then add pages containing this image only
    # when their publisher page was not already returned by related content.
    for key in ("related_content", "pages_with_this_image"):
        for item in data.get(key, []):
            if not isinstance(item, dict):
                continue

            page_result = _result_from_item(item, "source", "page")
            if not page_result:
                continue

            # Previous behavior only removed fragments and trailing slashes.
            # normalized_link = normalize_url(page_result.link).lower()
            normalized_link = dedupe_url_key(page_result.link)
            if normalized_link in seen_links:
                continue

            seen_links.add(normalized_link)
            results.append(page_result)

    # Previous behavior preserved for rollback. It emitted the publisher page,
    # original image, Bing CDN image, and ads as separate reverse-image matches.
    # for key in ("pages_with_this_image", "related_content"):
    #     for item in data.get(key, []):
    #         if not isinstance(item, dict):
    #             continue

    #         page_result = _result_from_item(item, "source", "page")
    #         if page_result:
    #             results.append(page_result)

    #         original_result = _result_from_item(item, "original", "image")
    #         if original_result:
    #             results.append(original_result)

    #         cdn_result = _result_from_item(item, "cdn_original", "image")
    #         if cdn_result:
    #             results.append(cdn_result)

    # for item in data.get("ads", []):
    #     if not isinstance(item, dict):
    #         continue
    #     result = _result_from_item(item, "link", "ad")
    #     if result:
    #         results.append(result)

    return results


def search_bing_reverse_image(file_path: str | None = None, image_url: str | None = None):
    api_key = os.getenv("SERP_API_KEY")
    endpoint = os.getenv("BING_SERPAPI_ENDPOINT", DEFAULT_ENDPOINT)
    if not api_key:
        print("Skipping Bing reverse image search: SERP_API_KEY is not set.")
        return []

    if not image_url:
        print("Skipping Bing reverse image search: public image URL is not available.")
        return []

    params = {
        "engine": "bing_reverse_image",
        "image_url": image_url,
        "api_key": api_key,
        "mkt": os.getenv("BING_REVERSE_IMAGE_MARKET", "en-US"),
    }
    response = requests.get(endpoint, params=params, timeout=30)
    response.raise_for_status()
    return _parse_bing_response(response.json())
