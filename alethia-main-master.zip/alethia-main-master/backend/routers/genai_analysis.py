import json
import mimetypes
import os
import time
from pathlib import Path

from dotenv import load_dotenv
from google import genai
from google.genai import types


def _sync_retry(call_fn, max_retries: int = 3, base_delay: float = 3.0):
    """Retry a synchronous callable on transient 503/429 errors with exponential backoff."""
    for attempt in range(max_retries):
        try:
            return call_fn()
        except Exception as e:
            msg = str(e)
            is_transient = any(x in msg for x in ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "quota"))
            if is_transient and attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)
                print(f"[genai] transient error on attempt {attempt + 1}/{max_retries}: {type(e).__name__} — retrying in {delay:.0f}s", flush=True)
                time.sleep(delay)
                continue
            raise


def _get_client() -> genai.Client:
    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
    if not api_key:
        for parent in Path(__file__).resolve().parents:
            env_file = parent / ".env"
            if env_file.exists():
                load_dotenv(dotenv_path=env_file)
                api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
                if api_key:
                    break
    if not api_key:
        raise RuntimeError("No GOOGLE_API_KEY / GEMINI_API_KEY found")
    return genai.Client(api_key=api_key)


def _model_name() -> str:
    return os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


def _image_part(image_path: str) -> types.Part | None:
    if not os.path.exists(image_path):
        print(f"[genai] image path does not exist: {image_path}")
        return None
    mime = mimetypes.guess_type(image_path)[0] or "image/jpeg"
    data = Path(image_path).read_bytes()
    return types.Part.from_bytes(data=data, mime_type=mime)


def _safe_json(text: str) -> dict:
    cleaned = text.strip().strip("`")
    if cleaned.lower().startswith("json"):
        cleaned = cleaned[4:].strip()
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end > start:
        cleaned = cleaned[start:end + 1]
    return json.loads(cleaned)


def generate_image_first_impression(image_path: str) -> str | None:
    """Synchronous — safe to call from threads without asyncio.run()."""
    image_part = _image_part(image_path)
    if not image_part:
        return None

    prompt = (
        "Look only at the supplied image. Do not use web, metadata, source, bias, or prior context.\n"
        "In 1-2 concise lines, state the first visual impression.\n"
        "Separate visible content from identity, event, origin, authorship, intent, or authenticity "
        "unless it is visually obvious.\n"
        "If it appears to be artwork, say so plainly. If it appears to be a news/event photograph, say so.\n"
        "If it appears digitally altered or synthetically generated, note that."
    )

    try:
        client = _get_client()
        model = _model_name()
        response = _sync_retry(lambda: client.models.generate_content(
            model=model, contents=[prompt, image_part],
        ))
        return (response.text or "").strip() or None
    except Exception as e:
        print(f"[genai] first impression failed: {type(e).__name__}: {e}", flush=True)
        return None


def generate_structured_first_pass(image_path: str) -> dict | None:
    """
    Synchronous structured analysis of the image. Safe to call from threads.
    Returns JSON with subject_category, location inference, key_phrases,
    is_screenshot, and political_lean_signal.
    """
    image_part = _image_part(image_path)
    if not image_part:
        return None

    prompt = """Analyze this image and return ONLY valid JSON (no markdown, no explanation).

{
  "first_impression": "1-2 sentence visual description",
  "subject_category": "famous_artwork|news_event|historical|political|location_landmark|personal|possibly_synthetic|screenshot|unknown",
  "subject_is_famous": true,
  "location": {
    "name": "City, Country or Region or null",
    "lat": null,
    "lon": null,
    "confidence": "high|medium|low|insufficient",
    "evidence_type": "visual_landmark|source_consensus|visual_context|insufficient"
  },
  "political_lean_signal": null,
  "is_screenshot": false,
  "ai_generation_signals": [],
  "key_phrases": ["phrase1", "phrase2"]
}

Rules:
- subject_category: choose the single best match.
- location: only provide lat/lon when you have real visual or contextual evidence. Set confidence=insufficient if genuinely unknown.
- political_lean_signal: string only for political/news/propaganda images describing who circulates it and how; null otherwise.
- is_screenshot: true if this appears to be a screenshot of a social media post, message, or news article.
- ai_generation_signals: list any visual artifacts suggesting AI generation (empty list if none).
- key_phrases: 3-7 terms that best identify the subject for reverse search context.
- DO NOT hallucinate coordinates. If location is unknown set lat/lon to null."""

    try:
        client = _get_client()
        model = _model_name()
        response = _sync_retry(lambda: client.models.generate_content(
            model=model, contents=[prompt, image_part],
        ))
        text = (response.text or "").strip()
        return _safe_json(text)
    except json.JSONDecodeError as e:
        print(f"[genai] structured first pass JSON parse failed: {e}", flush=True)
        return None
    except Exception as e:
        print(f"[genai] structured first pass failed: {type(e).__name__}: {e}", flush=True)
        return None


def _compact_sources(sources, limit=35):
    compact = []
    seen_domains: dict[str, int] = {}
    for source in sources or []:
        if not isinstance(source, dict):
            continue
        domain = source.get("source_domain") or source.get("source") or ""
        seen_domains[domain] = seen_domains.get(domain, 0) + 1
        compact.append({
            "title": source.get("title") or "",
            "snippet": source.get("snippet") or "",
            "domain": domain,
            "provider": source.get("provider") or "unknown",
            "date": source.get("date") or "",
            "link": source.get("link") or "",
            "verification": source.get("image_present") or source.get("verification_status") or "",
        })
        if len(compact) >= limit:
            break
    return compact, seen_domains


def format_data_for_prompt(
    serp_data,
    exif_data,
    ai_analysis,
    source_verification=None,
    candidate_sources=None,
    biases=None,
    location_analysis=None,
):
    verified_sources = serp_data.get("organic_results", []) if isinstance(serp_data, dict) else []
    verified_context, verified_domains = _compact_sources(verified_sources, limit=30)
    candidate_context, candidate_domains = _compact_sources(candidate_sources or [], limit=45)
    verification = source_verification or {}
    verification_summary = verification.get("summary", {}) if isinstance(verification, dict) else {}
    verification_samples = (verification.get("sources", []) if isinstance(verification, dict) else [])[:25]

    verdict = ai_analysis.get("verdict", "Unknown")
    ai_conf = ai_analysis.get("ai_id_confidence", 0)
    human_conf = ai_analysis.get("human_confidence", 0)

    # Strip location fields from exif_data — they are reported separately below with
    # explicit source labels to prevent Gemini from misattributing GeoCLIP estimates as EXIF GPS.
    GPS_KEYS = {"GPS Location", "GPS Coordinates Decimal", "Estimated Locations"}
    exif_display = {k: v for k, v in (exif_data or {}).items() if k not in GPS_KEYS}

    # Determine whether a true camera-embedded GPS coordinate exists
    raw_gps_location = (exif_data or {}).get("GPS Location", "")
    gps_coords = (exif_data or {}).get("GPS Coordinates Decimal")
    has_true_exif_gps = bool(gps_coords) and "Estimated:" not in str(raw_gps_location)

    if has_true_exif_gps:
        exif_gps_line = f"EXIF GPS (camera-embedded): {raw_gps_location} | decimal: {gps_coords}"
    else:
        exif_gps_line = "EXIF GPS (camera-embedded): NONE — this image has no GPS coordinates in its EXIF block."

    geoclip_locations = (exif_data or {}).get("Estimated Locations") or []
    if geoclip_locations:
        top = geoclip_locations[0]
        geoclip_line = (
            f"GeoCLIP visual ML estimate (NOT EXIF — inferred from image pixels, not camera metadata): "
            f"lat={top['lat']:.6f}, lon={top['lon']:.6f}, confidence={top['confidence']:.4f}. "
            f"All {len(geoclip_locations)} candidates: {json.dumps(geoclip_locations, ensure_ascii=False)}"
        )
    else:
        geoclip_line = "GeoCLIP visual ML estimate: not available."

    loc = location_analysis or {}
    selected_src = loc.get("selected_source", "none")
    selected_coords = loc.get("selected_coordinates")
    gemini_loc = loc.get("gemini_location")

    return f"""
    === FORENSIC DATA START ===
    [EXIF METADATA — camera/device info only; GPS is reported in its own section below]
    {json.dumps(exif_display, ensure_ascii=False, default=str)}

    [GPS COORDINATES — SOURCE DISAMBIGUATION (CRITICAL: attribute each coordinate set correctly)]
    {exif_gps_line}
    {geoclip_line}
    Gemini AI location inference (visual context, from structured first pass): {json.dumps(gemini_loc, ensure_ascii=False)}
    Reconciled primary location selected by pipeline: source={selected_src}, coords={json.dumps(selected_coords, ensure_ascii=False)}
    RULE: When you write your report, never say "EXIF metadata shows coordinates X,Y" unless EXIF GPS above is PRESENT (not NONE).
    If the coordinates come from GeoCLIP, label them as "GeoCLIP visual estimate" with their confidence score.
    If they come from Gemini inference, label them as "AI-inferred location".

    [AI DETECTION TECHNICAL ANALYSIS]
    Verdict: {verdict}
    AI Confidence Score: {ai_conf}
    Human Confidence Score: {human_conf}

    [VERIFIED IMAGE EVIDENCE SOURCES]
    Hash-confirmed/probable is strongest. Provider-attested means reverse-image provider returned
    the source as matching but local thumbnail hash did not independently confirm it.
    Domain counts: {json.dumps(verified_domains, ensure_ascii=False)}
    Sources: {json.dumps(verified_context, ensure_ascii=False)}

    [BROADER EVENT/SOURCE CONTEXT]
    Reverse-search candidates from Google/Lens/Bing/Yandex. Treat as context, not proof.
    Domain counts: {json.dumps(candidate_domains, ensure_ascii=False)}
    Sources: {json.dumps(candidate_context, ensure_ascii=False)}

    [BIAS / FACTUALITY SPLIT FOR VERIFIED SOURCES]
    {json.dumps(biases or {}, ensure_ascii=False)}

    [LOCATION SIGNALS]
    {json.dumps(loc, ensure_ascii=False)}

    [SOURCE IMAGE-PRESENCE CHECKS]
    Summary: {json.dumps(verification_summary, ensure_ascii=False)}
    Representative Verification Diagnostics: {json.dumps(verification_samples, ensure_ascii=False)}
    === FORENSIC DATA END ===
    """


def generate_comprehensive_report(
    image_path,
    serp_data,
    exif_data,
    ai_analysis,
    source_verification=None,
    first_visual_assessment=None,
    candidate_sources=None,
    biases=None,
    location_analysis=None,
    structured_first_pass=None,
) -> str | None:
    print("--- genai_analysis: generating comprehensive OSINT report ---", flush=True)

    image_part = _image_part(image_path)
    if not image_part:
        return None

    data_context = format_data_for_prompt(
        serp_data, exif_data, ai_analysis,
        source_verification,
        candidate_sources=candidate_sources,
        biases=biases,
        location_analysis=location_analysis,
    )

    structured_ctx = ""
    if structured_first_pass:
        structured_ctx = f"""
    [STRUCTURED IMAGE CLASSIFICATION — from fast first pass]
    Category: {structured_first_pass.get('subject_category', 'unknown')}
    Subject famous: {structured_first_pass.get('subject_is_famous', False)}
    AI location inference: {json.dumps(structured_first_pass.get('location'), ensure_ascii=False)}
    Is screenshot: {structured_first_pass.get('is_screenshot', False)}
    Key phrases: {structured_first_pass.get('key_phrases', [])}
    Political lean signal: {structured_first_pass.get('political_lean_signal')}
    AI generation signals: {structured_first_pass.get('ai_generation_signals', [])}
    """

    prompt = f"""
    You are Alethia — an AI-powered OSINT analyst specializing in image provenance,
    misinformation detection, and contextual verification.

    You have the image PLUS forensic intelligence from five reverse image search engines,
    EXIF metadata, geolocation models, and AI detection.

    {data_context}

    {structured_ctx}

    [IMAGE-ONLY FIRST IMPRESSION]
    {first_visual_assessment or "No separate first impression was available."}

    === YOUR MISSION ===
    Produce a complete, intelligence-grade OSINT report on this image.

    Use your web search capability (if available) to look up:
    - Any famous events, artworks, locations, or people matching the visual content
    - Whether this image has been used in misinformation, propaganda, or viral miscontextualization
    - Recent news or controversies related to what is shown
    - Historical context if this depicts a historical place, event, or artwork

    Then integrate EVERYTHING — your search findings + the forensic data — into a single coherent report.

    === IMAGE TYPE DETECTION (CRITICAL) ===
    Before writing anything, determine the image category and adapt your analysis:

    - FAMOUS ARTWORK: Identify artist, title, period, location. Discuss controversies, vandalism,
      forgery claims, or online misuse.
    - NEWS / CURRENT EVENT: Identify the specific event, date, location, parties involved.
      Is this image being used to misrepresent a different event or time period?
    - HISTORICAL EVENT / PLACE: Identify the historical significance.
    - POLITICAL / PROPAGANDA: What narrative does this image push? Which political actors benefit?
      Identify the specific claim and evaluate its accuracy.
    - LOCATION / LANDMARK: Identify the place, notable history, current events.
    - PERSONAL / UNIDENTIFIED: Do NOT identify private individuals. Focus on context and spread.
    - POSSIBLY AI-GENERATED: Highlight visual artifacts, AI detector results, synthetic media risk.

    === OUTPUT RULES ===
    1. TONE: Professional, intelligence-grade. Confident where evidence is strong; explicit about uncertainty.
    2. FORMAT: Use UPPERCASE section headers followed by a colon. Use "- " for bullets. Blank line between sections.
    3. INTEGRATION: Weave web search findings with forensic data.
    4. EVIDENCE TIERS: Hash-confirmed > Provider-attested > Candidate context only.
    5. DO NOT: Name private individuals. Claim certainty without evidence. Skip sections.

    === REQUIRED SECTIONS ===

    IMAGE OBSERVATION:
    - Describe the visual content in 1-2 lines.
    - State the image category.

    SUBJECT IDENTIFICATION AND CONTEXT:
    - Use search AND source evidence to identify what is shown.
    - Cite which sources or search findings support your identification.

    LOCATION ASSESSMENT:
    - State the most credible location for the subject of this image.
    - Hierarchy: EXIF GPS (strongest) > source/event consensus > GeoCLIP estimate (weakest).
    - Explain reasoning and note conflicts between signals.

    PROPAGATION AND SOURCE ANALYSIS:
    - How widely is this image circulating? Across what domain types?
    - Are sources framing it consistently or contradictorily?
    - Bias distribution of verified sources.
    - Note hash-confirmed vs provider-attested sources.

    MISINFORMATION AND MISUSE ASSESSMENT:
    - Is there evidence this image is being used out of context, mislabeled, or weaponized?
    - If yes: what is the false claim? What does the evidence actually show?
    - If no: say so clearly.

    AI GENERATION AND AUTHENTICITY SIGNAL:
    - AI detector verdict and confidence level.
    - Visual indicators of synthetic generation.
    - Risk assessment: real image, AI fake, or edited real image?

    HISTORICAL OR CULTURAL SIGNIFICANCE:
    - Broader significance of what is shown.
    - Skip only if the image shows nothing of historical or cultural significance.

    LIMITATIONS:
    - Key gaps in the forensic data.
    - What additional investigation would increase confidence?

    FINAL ASSESSMENT: [AUTHENTIC CONTEXT / MISCONTEXTUALIZED / AI-GENERATED / EDITED MEDIA / ARTWORK/NON-NEWS / INSUFFICIENT EVIDENCE]
    - Confidence: LOW / MEDIUM / HIGH
    - Two specific evidence-based reasons for your verdict.
    """

    try:
        client = _get_client()
        model = _model_name()
        search_tool = types.Tool(google_search=types.GoogleSearch())
        response = _sync_retry(lambda: client.models.generate_content(
            model=model,
            contents=[prompt, image_part],
            config=types.GenerateContentConfig(tools=[search_tool]),
        ))
        text = (response.text or "").strip()
        print(f"[genai] comprehensive report received ({len(text)} chars)", flush=True)
        return text or None
    except Exception as e:
        print(f"[genai] search-grounded report failed ({type(e).__name__}: {e}); retrying without grounding", flush=True)
        try:
            client = _get_client()
            model = _model_name()
            response = _sync_retry(lambda: client.models.generate_content(
                model=model, contents=[prompt, image_part],
            ))
            text = (response.text or "").strip()
            print(f"[genai] fallback report received ({len(text)} chars)", flush=True)
            return text or None
        except Exception as e2:
            import traceback
            print(f"[CRITICAL][genai] both grounded and fallback report failed: {type(e2).__name__}: {e2}", flush=True)
            traceback.print_exc()
            return None
