import mimetypes
import os
import pathlib

from dotenv import load_dotenv
from google import genai
from google.genai import types


def describe_image(image_path):
    if not image_path:
        print("No image path provided or an error occurred.")
        return "No image path provided or an error occurred."

    load_dotenv()
    api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
    if not api_key:
        return "Description unavailable."

    client = genai.Client(api_key=api_key)
    model_name = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    mime = mimetypes.guess_type(image_path)[0] or "image/jpeg"
    data = pathlib.Path(image_path).read_bytes()
    image_part = types.Part.from_bytes(data=data, mime_type=mime)

    try:
        print("--- LEGACY describe_image.py CALLED ---")
        response = client.models.generate_content(
            model=model_name,
            contents=[
                "Describe the image in detail, including the objects, colors, and any text present.",
                image_part,
            ],
        )
        return (response.text or "").strip() or "Description unavailable."
    except Exception as e:
        print(f"An error occurred: {e}")
        return "Description unavailable."
