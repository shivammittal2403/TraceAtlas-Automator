from dataclasses import asdict, is_dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from ..bingReverseImageSearch.bing_reverse import search_bing_reverse_image
from ..yandexReverseImageSearch.yandex_reverse import search_yandex_reverse_image
from .results import ReverseImageResult, dedupe_url_key, extract_url_value, get_base_domain, make_result, normalize_url


def log_provider(provider: str, message: str):
    print(f"[Alethia:collector][{provider}] {message}", flush=True)


_THUMBNAIL_VERIFY_CAP = int(__import__("os").getenv("THUMBNAIL_VERIFY_CAP", "20"))


def _apply_thumbnail_verification(
    results: list[ReverseImageResult],
    uploaded_profile: dict[str, int],
    provider: str,
    workers: int = 8,
) -> dict[str, int]:
    """
    For each result from a single provider, download its candidate thumbnails and
    compare against the uploaded image hash.  Tags the result in-place with
    thumbnail_match / thumbnail_distance / thumbnail_similarity.

    Returns per-provider counts: {confirmed, probable, not_matched, no_thumbnails, failed}
    """
    from ..source_verification import quick_verify_thumbnail

    stats: dict[str, int] = {"confirmed": 0, "probable": 0, "not_matched": 0, "no_thumbnails": 0, "failed": 0}

    # Cap per-provider thumbnail verification to avoid long tails on providers that
    # return hundreds of results (Bing in particular). Results beyond the cap keep
    # thumbnail_match=None (treated as "no_thumbnails" downstream).
    verify_results = results[:_THUMBNAIL_VERIFY_CAP]
    skipped = len(results) - len(verify_results)
    if skipped:
        log_provider(provider, f"thumbnail verification capped at {_THUMBNAIL_VERIFY_CAP} (skipping {skipped} results)")

    def _verify_one(result: ReverseImageResult):
        vr = quick_verify_thumbnail(result.candidate_image_urls, uploaded_profile)
        result.thumbnail_match = vr["match"]
        dist = vr.get("avg_distance") if vr.get("avg_distance") is not None else vr.get("distance")
        sim = vr.get("similarity")
        result.thumbnail_distance = int(round(dist)) if dist is not None else -1
        result.thumbnail_similarity = sim if sim is not None else -1.0
        return vr["match"]

    with ThreadPoolExecutor(max_workers=min(workers, max(1, len(verify_results)))) as executor:
        futures = {executor.submit(_verify_one, r): r for r in verify_results}
        for future in as_completed(futures):
            try:
                match = future.result()
            except Exception:
                match = "failed"
            stats[match] = stats.get(match, 0) + 1

    log_provider(provider, f"thumbnail verification: {stats}")
    return stats


def extract_serp_results(data: dict[str, Any] | None, provider: str) -> list[ReverseImageResult]:
    if not data:
        return []

    candidates = []
    for key in ("image_results", "organic_results", "visual_matches", "reverse_image_search"):
        values = data.get(key)
        if isinstance(values, list):
            candidates.extend(values)

    results = []
    for item in candidates:
        if not isinstance(item, dict):
            continue
        link = item.get("link") or item.get("url") or item.get("source_link")
        if not link:
            continue
        candidate_image_urls = [
            extract_url_value(item.get("image")),
            extract_url_value(item.get("thumbnail")),
            extract_url_value(item.get("original")),
            extract_url_value(item.get("original_image")),
        ]
        result = make_result(
            link=link,
            source=item.get("source"),
            title=item.get("title") or item.get("name") or item.get("snippet") or "",
            provider=provider,
            candidate_image_urls=candidate_image_urls,
            snippet=item.get("snippet") or item.get("description") or "",
            date=item.get("date") or "",
            width=item.get("image_width") or item.get("width") or item.get("thumbnail_width") or "",
            height=item.get("image_height") or item.get("height") or item.get("thumbnail_height") or "",
        )
        if result:
            results.append(result)
    return results


def ensure_reverse_result(result: ReverseImageResult | dict[str, Any] | None) -> ReverseImageResult | None:
    if not result:
        return None
    if isinstance(result, ReverseImageResult):
        return result
    if isinstance(result, dict):
        return make_result(
            link=result.get("link") or result.get("url") or "",
            source=result.get("source") or result.get("source_domain") or result.get("raw_source"),
            title=result.get("title") or "",
            provider=result.get("provider") or "unknown",
            kind=result.get("kind") or "page",
            provider_result_url=result.get("provider_result_url") or "",
            candidate_image_urls=result.get("candidate_image_urls") or [],
            snippet=result.get("snippet") or result.get("description") or "",
            date=result.get("date") or "",
            width=result.get("width") or "",
            height=result.get("height") or "",
            image_format=result.get("image_format") or result.get("format") or "",
            file_size=result.get("file_size") or "",
        )
    if is_dataclass(result):
        return ensure_reverse_result(asdict(result))
    return None


def dedupe_results(results: list[ReverseImageResult | dict[str, Any]]) -> list[ReverseImageResult]:
    seen = set()
    deduped = []
    for result in results:
        normalized_result = ensure_reverse_result(result)
        if not normalized_result:
            continue
        # Previous behavior only removed fragments and trailing slashes.
        # key = normalize_url(normalized_result.link).lower()
        key = dedupe_url_key(normalized_result.link)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(normalized_result)
    return deduped


def collect_all_reverse_image_links(
    file_path: str,
    public_url: str | None = None,
    google_reverse_data: dict[str, Any] | None = None,
    google_lens_data: dict[str, Any] | None = None,
    google_reverse_page_2_data: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    # Compute the uploaded image hash once so every provider batch can be verified
    # against it in-place before the results are combined and deduplicated.
    uploaded_profile: dict[str, int] | None = None
    try:
        from ..source_verification import perceptual_hash_profile_from_file
        uploaded_profile = perceptual_hash_profile_from_file(file_path)
        log_provider("hash", "uploaded image hash profile ready for per-provider thumbnail verification")
    except Exception as e:
        log_provider("hash", f"could not compute uploaded image hash — per-provider verification skipped: {e}")

    results: list[ReverseImageResult | dict[str, Any]] = []

    google_reverse_results = extract_serp_results(google_reverse_data, "google_reverse_image")
    log_provider("google_reverse_image", f"normalized page results={len(google_reverse_results)}")
    if uploaded_profile and google_reverse_results:
        _apply_thumbnail_verification(google_reverse_results, uploaded_profile, "google_reverse_image")
    results.extend(google_reverse_results)

    google_reverse_page_2_results = extract_serp_results(google_reverse_page_2_data, "google_reverse_image_page_2")
    log_provider("google_reverse_image_page_2", f"normalized page results={len(google_reverse_page_2_results)}")
    if uploaded_profile and google_reverse_page_2_results:
        _apply_thumbnail_verification(google_reverse_page_2_results, uploaded_profile, "google_reverse_image_page_2")
    results.extend(google_reverse_page_2_results)

    google_lens_results = extract_serp_results(google_lens_data, "google_lens")
    log_provider("google_lens", f"normalized page results={len(google_lens_results)}")
    if uploaded_profile and google_lens_results:
        _apply_thumbnail_verification(google_lens_results, uploaded_profile, "google_lens")
    results.extend(google_lens_results)

    # Google Cloud Vision is intentionally disabled. The provider implementation
    # is preserved so it can be restored later if billing and usage are revisited.
    # try:
    #     from ..cloudVision.webDetectionLS import detect_web
    #     results.extend(detect_web(file_path) or [])
    # except Exception as e:
    #     print(f"Cloud Vision web detection failed, continuing without it: {e}")

    # Bing + Yandex run fully in parallel (API call only, no thumbnail verification).
    # Google+Lens results are already hash-verified — Bing/Yandex are supplemental context.
    def _bing_pipeline():
        r = search_bing_reverse_image(file_path=file_path, image_url=public_url)
        log_provider("bing_reverse_image", f"normalized page results={len(r)}")
        return r

    def _yandex_pipeline():
        r = search_yandex_reverse_image(image_url=public_url)
        log_provider("yandex_images", f"normalized page results={len(r)}")
        return r

    with ThreadPoolExecutor(max_workers=2) as executor:
        bing_future = executor.submit(_bing_pipeline)
        yandex_future = executor.submit(_yandex_pipeline)

        try:
            bing_results = bing_future.result()
            results.extend(bing_results)
        except Exception as e:
            log_provider("bing_reverse_image", f"failed, continuing without it: {e}")

        try:
            yandex_results = yandex_future.result()
            results.extend(yandex_results)
        except Exception as e:
            log_provider("yandex_images", f"failed, continuing without it: {e}")

    deduped_results = dedupe_results(results)
    provider_counts: dict[str, int] = {}
    thumbnail_match_counts: dict[str, int] = {"confirmed": 0, "probable": 0, "not_matched": 0, "no_thumbnails": 0, "failed": 0}
    for result in deduped_results:
        provider_counts[result.provider] = provider_counts.get(result.provider, 0) + 1
        match = result.thumbnail_match or "no_thumbnails"
        thumbnail_match_counts[match] = thumbnail_match_counts.get(match, 0) + 1
    duplicate_count = len(results) - len(deduped_results)
    log_provider(
        "dedupe",
        f"raw={len(results)} duplicates_removed={duplicate_count} "
        f"provider_counts_after_dedupe={provider_counts} "
        f"thumbnail_matches={thumbnail_match_counts}",
    )

    return [asdict(result) for result in deduped_results]


def results_to_serp_payload(results: list[dict[str, Any]]) -> dict[str, Any]:
    image_results = []
    for result in results:
        link = result.get("link")
        if not link:
            continue
        image_results.append(
            {
                "link": link,
                "source": result.get("source") or get_base_domain(link),
                "source_domain": result.get("source_domain") or result.get("source") or get_base_domain(link),
                "title": result.get("title") or "",
                "provider": result.get("provider") or "unknown",
                "kind": result.get("kind") or "page",
                "raw_source": result.get("raw_source") or "",
                "provider_result_url": result.get("provider_result_url") or "",
                "candidate_image_urls": result.get("candidate_image_urls") or [],
                "snippet": result.get("snippet") or "",
                "date": result.get("date") or "",
                "width": result.get("width") or "",
                "height": result.get("height") or "",
                "image_format": result.get("image_format") or "",
                "file_size": result.get("file_size") or "",
            }
        )

    return {
        "image_results": image_results,
        "organic_results": image_results,
        "search_information": {"total_results": len(image_results)},
    }
