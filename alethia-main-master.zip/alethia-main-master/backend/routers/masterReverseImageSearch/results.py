from dataclasses import dataclass, field
from urllib.parse import parse_qsl, urlencode, urldefrag, urlparse, urlunparse

import tldextract


@dataclass
class ReverseImageResult:
    link: str
    source: str
    source_domain: str
    title: str = ""
    provider: str = "unknown"
    kind: str = "page"
    raw_source: str = ""
    provider_result_url: str = ""
    candidate_image_urls: list[str] = field(default_factory=list)
    snippet: str = ""
    date: str = ""
    width: str = ""
    height: str = ""
    image_format: str = ""
    file_size: str = ""
    # Per-provider thumbnail hash verification (populated during collection)
    thumbnail_match: str = ""       # "confirmed", "probable", "not_matched", "no_thumbnails", "failed"
    thumbnail_distance: int = -1    # Best hamming distance across hash views (-1 = not computed)
    thumbnail_similarity: float = -1.0  # 0.0–1.0 (-1.0 = not computed)


def get_base_domain(url: str) -> str:
    # Previous behavior used tldextract here. Preserve the intent, but keep it
    # out of the reverse-search hot path because its public-suffix cache lock can
    # block provider parsing on Windows.
    # try:
    #     ext = tldextract.extract(url)
    #     if ext.domain and ext.suffix:
    #         return f"{ext.domain}.{ext.suffix}"
    # except Exception:
    #     pass

    parsed = urlparse(str(url))
    host = (parsed.hostname or str(url)).lower()
    if host.startswith("www."):
        host = host[4:]
    parts = [part for part in host.split(".") if part]
    if len(parts) >= 2:
        return ".".join(parts[-2:])
    return host or str(url)


def normalize_url(url: str) -> str:
    return urldefrag(str(url).strip())[0].rstrip("/")


TRACKING_QUERY_PARAMETERS = {
    "dclid",
    "fbclid",
    "gclid",
    "igshid",
    "mc_cid",
    "mc_eid",
    "msclkid",
    "ref_src",
    "s_cid",
    "vero_conv",
    "vero_id",
}


def dedupe_url_key(url: str) -> str:
    """Build a provider-independent key without changing the displayed URL."""
    normalized_url = normalize_url(url)
    parsed = urlparse(normalized_url)

    hostname = (parsed.hostname or "").lower()
    if hostname.startswith("www."):
        hostname = hostname[4:]

    port = parsed.port
    if port and not (
        (parsed.scheme.lower() == "http" and port == 80)
        or (parsed.scheme.lower() == "https" and port == 443)
    ):
        hostname = f"{hostname}:{port}"

    filtered_query = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        lower_key = key.lower()
        if lower_key.startswith("utm_") or lower_key in TRACKING_QUERY_PARAMETERS:
            continue
        filtered_query.append((key, value))

    filtered_query.sort(key=lambda item: (item[0].lower(), item[1]))
    normalized_path = parsed.path.rstrip("/") or "/"

    # Scheme is intentionally omitted so HTTP and HTTPS versions of the same
    # source page dedupe across providers.
    return urlunparse(("", hostname, normalized_path, "", urlencode(filtered_query, doseq=True), ""))


def extract_url_value(value):
    if isinstance(value, dict):
        return value.get("link") or value.get("url") or value.get("source") or value.get("original")
    if isinstance(value, str):
        return value
    return None


def looks_like_url(value: str | None) -> bool:
    if not value:
        return False
    parsed = urlparse(value)
    return bool(parsed.scheme and parsed.netloc)


def _dedupe_values(values: list[str | None]) -> list[str]:
    seen = set()
    output = []
    for value in values:
        clean = extract_url_value(value)
        if not clean:
            continue
        clean = normalize_url(clean)
        if clean in seen:
            continue
        seen.add(clean)
        output.append(clean)
    return output


def make_result(
    link: str,
    provider: str,
    source: str | None = None,
    title: str = "",
    kind: str = "page",
    provider_result_url: str = "",
    candidate_image_urls: list[str | None] | None = None,
    snippet: str = "",
    date: str = "",
    width: str = "",
    height: str = "",
    image_format: str = "",
    file_size: str = "",
):
    link = extract_url_value(link)
    source = extract_url_value(source) or source
    if not link:
        return None
    clean_link = normalize_url(link)
    if not clean_link:
        return None
    source_domain = get_base_domain(source) if looks_like_url(source) else get_base_domain(clean_link)
    return ReverseImageResult(
        link=clean_link,
        source=source_domain,
        source_domain=source_domain,
        title=title or "",
        provider=provider,
        kind=kind,
        raw_source=source or "",
        provider_result_url=normalize_url(provider_result_url) if provider_result_url else "",
        candidate_image_urls=_dedupe_values(candidate_image_urls or []),
        snippet=str(snippet or ""),
        date=str(date or ""),
        width=str(width or ""),
        height=str(height or ""),
        image_format=str(image_format or ""),
        file_size=str(file_size or ""),
    )
