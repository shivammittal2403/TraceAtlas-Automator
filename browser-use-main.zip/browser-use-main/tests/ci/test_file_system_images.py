"""Tests for image file support in the FileSystem."""

import base64
import io
from pathlib import Path

import pytest
from PIL import Image

from browser_use.filesystem.file_system import Base64BinaryFile, FileSystem


class TestImageFiles:
	"""Test image file operations - only external reading supported."""

	def create_test_image(self, width: int = 100, height: int = 100, format: str = 'PNG') -> bytes:
		"""Create a test image and return bytes."""
		img = Image.new('RGB', (width, height), color='red')
		buffer = io.BytesIO()
		img.save(buffer, format=format)
		buffer.seek(0)
		return buffer.read()

	@pytest.mark.asyncio
	async def test_read_external_png_image(self, tmp_path: Path):
		"""Test reading external PNG image file."""
		# Create an external image file
		external_file = tmp_path / 'test.png'
		img_bytes = self.create_test_image(width=300, height=200, format='PNG')
		external_file.write_bytes(img_bytes)

		fs = FileSystem(tmp_path / 'workspace')
		structured_result = await fs.read_file_structured(str(external_file), external_file=True)

		assert 'message' in structured_result
		assert 'Read image file' in structured_result['message']
		assert 'images' in structured_result
		assert structured_result['images'] is not None
		assert len(structured_result['images']) == 1

		img_data = structured_result['images'][0]
		assert img_data['name'] == 'test.png'
		assert 'data' in img_data
		# Verify base64 is valid
		decoded = base64.b64decode(img_data['data'])
		assert decoded == img_bytes

	@pytest.mark.asyncio
	async def test_read_external_jpg_image(self, tmp_path: Path):
		"""Test reading external JPG image file."""
		# Create an external image file
		external_file = tmp_path / 'photo.jpg'
		img_bytes = self.create_test_image(width=150, height=100, format='JPEG')
		external_file.write_bytes(img_bytes)

		fs = FileSystem(tmp_path / 'workspace')
		structured_result = await fs.read_file_structured(str(external_file), external_file=True)

		assert 'message' in structured_result
		assert 'images' in structured_result
		assert structured_result['images'] is not None

		img_data = structured_result['images'][0]
		assert img_data['name'] == 'photo.jpg'
		decoded = base64.b64decode(img_data['data'])
		assert len(decoded) > 0

	@pytest.mark.asyncio
	async def test_read_jpeg_extension(self, tmp_path: Path):
		"""Test reading .jpeg extension (not just .jpg)."""
		external_file = tmp_path / 'test.jpeg'
		img_bytes = self.create_test_image(format='JPEG')
		external_file.write_bytes(img_bytes)

		fs = FileSystem(tmp_path / 'workspace')
		structured_result = await fs.read_file_structured(str(external_file), external_file=True)

		assert structured_result['images'] is not None
		assert structured_result['images'][0]['name'] == 'test.jpeg'

	@pytest.mark.asyncio
	async def test_read_nonexistent_image(self, tmp_path: Path):
		"""Test reading a nonexistent image file."""
		fs = FileSystem(tmp_path / 'workspace')
		structured_result = await fs.read_file_structured('/path/to/nonexistent.png', external_file=True)

		assert 'message' in structured_result
		assert 'not found' in structured_result['message'].lower()
		assert structured_result['images'] is None

	@pytest.mark.asyncio
	async def test_corrupted_image_file(self, tmp_path: Path):
		"""Test reading a corrupted image file."""
		external_file = tmp_path / 'corrupted.png'
		# Write invalid PNG data
		external_file.write_bytes(b'Not a valid PNG file')

		fs = FileSystem(tmp_path / 'workspace')
		structured_result = await fs.read_file_structured(str(external_file), external_file=True)

		# Should still return base64 data (we don't validate image format)
		assert 'message' in structured_result
		assert 'Read image file' in structured_result['message']
		# Base64 encoding will succeed even for invalid image data
		assert structured_result['images'] is not None

	@pytest.mark.asyncio
	async def test_large_image_file(self, tmp_path: Path):
		"""Test reading a large image file."""
		# Create a large image (2000x2000)
		external_file = tmp_path / 'large.png'
		img = Image.new('RGB', (2000, 2000), color='blue')
		img.save(str(external_file), format='PNG')

		fs = FileSystem(tmp_path / 'workspace')
		structured_result = await fs.read_file_structured(str(external_file), external_file=True)

		assert 'images' in structured_result
		assert structured_result['images'] is not None
		# Verify base64 data is present and substantial
		assert len(structured_result['images'][0]['data']) > 10000

	@pytest.mark.asyncio
	async def test_multiple_images_in_sequence(self, tmp_path: Path):
		"""Test reading multiple images in sequence."""
		fs = FileSystem(tmp_path / 'workspace')

		# Create three different images
		for i, color in enumerate(['red', 'green', 'blue']):
			img_file = tmp_path / f'image_{i}.png'
			img = Image.new('RGB', (100, 100), color=color)
			img.save(str(img_file), format='PNG')

		# Read them all
		results = []
		for i in range(3):
			img_file = tmp_path / f'image_{i}.png'
			result = await fs.read_file_structured(str(img_file), external_file=True)
			results.append(result)

		# Verify all were read successfully
		for i, result in enumerate(results):
			assert result['images'] is not None
			assert result['images'][0]['name'] == f'image_{i}.png'

	@pytest.mark.asyncio
	async def test_different_image_formats(self, tmp_path: Path):
		"""Test reading different image format variations."""
		fs = FileSystem(tmp_path / 'workspace')

		# Test .jpg
		jpg_file = tmp_path / 'test.jpg'
		img = Image.new('RGB', (50, 50), color='yellow')
		img.save(str(jpg_file), format='JPEG')
		result_jpg = await fs.read_file_structured(str(jpg_file), external_file=True)
		assert result_jpg['images'] is not None

		# Test .jpeg
		jpeg_file = tmp_path / 'test.jpeg'
		img.save(str(jpeg_file), format='JPEG')
		result_jpeg = await fs.read_file_structured(str(jpeg_file), external_file=True)
		assert result_jpeg['images'] is not None

		# Test .png
		png_file = tmp_path / 'test.png'
		img.save(str(png_file), format='PNG')
		result_png = await fs.read_file_structured(str(png_file), external_file=True)
		assert result_png['images'] is not None

	@pytest.mark.asyncio
	async def test_image_with_transparency(self, tmp_path: Path):
		"""Test reading PNG with transparency (RGBA)."""
		external_file = tmp_path / 'transparent.png'
		# Create RGBA image with transparency
		img = Image.new('RGBA', (100, 100), color=(255, 0, 0, 128))
		img.save(str(external_file), format='PNG')

		fs = FileSystem(tmp_path / 'workspace')
		structured_result = await fs.read_file_structured(str(external_file), external_file=True)

		assert structured_result['images'] is not None
		assert len(structured_result['images'][0]['data']) > 0


class TestActionResultImages:
	"""Test ActionResult with images field."""

	def test_action_result_with_images(self):
		"""Test creating ActionResult with images."""
		from browser_use.agent.views import ActionResult

		images = [{'name': 'test.png', 'data': 'base64_encoded_data_here'}]

		result = ActionResult(
			extracted_content='Read image file test.png',
			long_term_memory='Read image file test.png',
			images=images,
			include_extracted_content_only_once=True,
		)

		assert result.images is not None
		assert len(result.images) == 1
		assert result.images[0]['name'] == 'test.png'
		assert result.images[0]['data'] == 'base64_encoded_data_here'

	def test_action_result_without_images(self):
		"""Test ActionResult without images (default behavior)."""
		from browser_use.agent.views import ActionResult

		result = ActionResult(extracted_content='Some text', long_term_memory='Memory')

		assert result.images is None

	def test_action_result_with_multiple_images(self):
		"""Test ActionResult with multiple images."""
		from browser_use.agent.views import ActionResult

		images = [
			{'name': 'image1.png', 'data': 'base64_data_1'},
			{'name': 'image2.jpg', 'data': 'base64_data_2'},
		]

		result = ActionResult(
			extracted_content='Read multiple images',
			long_term_memory='Read image files',
			images=images,
			include_extracted_content_only_once=True,
		)

		assert result.images is not None
		assert len(result.images) == 2
		assert result.images[0]['name'] == 'image1.png'
		assert result.images[1]['name'] == 'image2.jpg'

	def test_action_result_with_empty_images_list(self):
		"""Test ActionResult with empty images list."""
		from browser_use.agent.views import ActionResult

		result = ActionResult(
			extracted_content='No images',
			images=[],
		)

		# Empty list is still valid
		assert result.images == []


if __name__ == '__main__':
	pytest.main([__file__, '-v'])


class TestBinaryFileCreation:
	"""The agent can author a tiny binary file (base64) that becomes a real, uploadable image."""

	PNG_1X1 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR4nGNgAAIAAAUAAXpeqz8AAAAASUVORK5CYII='

	async def test_write_png_produces_real_bytes(self, tmp_path: Path):
		fs = FileSystem(str(tmp_path))
		# write_file action appends a trailing newline; that must be tolerated
		result = await fs.write_file('logo.png', self.PNG_1X1 + '\n')
		assert 'successfully' in result
		raw = (fs.get_dir() / 'logo.png').read_bytes()
		assert raw[:8] == b'\x89PNG\r\n\x1a\n'  # real PNG magic, not base64 text
		assert len(raw) > 0

	async def test_binary_file_is_uploadable_by_basename(self, tmp_path: Path):
		fs = FileSystem(str(tmp_path))
		await fs.write_file('pic.gif', 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7')
		fobj = fs.get_file('pic.gif')  # the exact resolution upload_file uses
		assert fobj is not None
		assert fobj.full_name == 'pic.gif'

	async def test_describe_does_not_leak_base64(self, tmp_path: Path):
		fs = FileSystem(str(tmp_path))
		await fs.write_file('logo.png', self.PNG_1X1)
		desc = fs.describe()
		assert self.PNG_1X1[:24] not in desc  # base64 never enters the prompt
		assert '[binary png file' in desc

	async def test_invalid_base64_is_rejected_no_corrupt_file(self, tmp_path: Path):
		fs = FileSystem(str(tmp_path))
		result = await fs.write_file('bad.png', 'this is definitely not base64 @@@')
		assert 'Error' in result
		assert not (fs.get_dir() / 'bad.png').exists()  # no 0-byte / corrupt file left for upload
		# No ghost entry in the in-memory filesystem / state either
		assert 'bad.png' not in fs.list_files()
		assert 'bad.png' not in [f for f in fs.get_state().model_dump().get('files', {})]

	async def test_valid_base64_but_not_an_image_is_rejected(self, tmp_path: Path):
		"""'aGVsbG8=' is valid base64 (-> b'hello') but not a PNG: must be rejected, not written."""
		fs = FileSystem(str(tmp_path))
		result = await fs.write_file('fake.png', 'aGVsbG8=')
		assert 'Error' in result
		assert not (fs.get_dir() / 'fake.png').exists()
		assert 'fake.png' not in fs.list_files()

	async def test_wrong_magic_for_extension_is_rejected(self, tmp_path: Path):
		"""PNG bytes written under a .gif name are rejected (magic mismatch)."""
		fs = FileSystem(str(tmp_path))
		result = await fs.write_file('mislabeled.gif', self.PNG_1X1)
		assert 'Error' in result
		assert 'mislabeled.gif' not in fs.list_files()

	async def test_state_round_trip_preserves_binary(self, tmp_path: Path):
		fs = FileSystem(str(tmp_path))
		await fs.write_file('logo.png', self.PNG_1X1)
		original_bytes = (fs.get_dir() / 'logo.png').read_bytes()
		fs2 = FileSystem.from_state(fs.get_state())
		restored = fs2.get_file('logo.png')
		assert isinstance(restored, Base64BinaryFile)
		# Content integrity, not just existence: decoded bytes must round-trip and be a real PNG
		assert restored._decoded() == original_bytes
		assert restored._decoded()[:8] == b'\x89PNG\r\n\x1a\n'
