# Independent enterprise assessment

## Scope and confidence

Snapshot: main `2a8789eb7cc401b327796e32458b9733674ecbc9`, 30 September 2026.
Review: source, migrations, API, frontend, CI definitions, internal doctor outputs and local tests.
Not reviewed: a customer's production installation, real provider entitlements, complete historical secrets, paid vendor accounts, vendor hands-on benchmark, external penetration test, real hosted Supabase/Storage/JWT flows or production logs.

High confidence: observed file/code behavior and local command results.
Medium confidence: product/enterprise maturity judgment.
Low/unknown: deployed availability, external customer usage and comparative accuracy.

## Two kinds of maturity must not be mixed

| Axis | Judgment | Meaning |
|---|---:|---|
| Repository/code engineering | 7/10 | Real implementation, regressions, sensible boundaries; not comprehensive assurance |
| Implemented feature depth | 5/10 | Multiple useful layers, often thin and uneven |
| Operationally proven product | About 2.5/10 | Very limited live/hosted proof in available evidence |
| Overall market maturity | 3.3/10 | Weighted independent estimate below |

## Market score rubric

0 = absent; 2 = prototype or predominantly fixtures; 4 = usable bounded capability but incomplete proof; 6 = dependable scoped pilot; 8 = operated enterprise capability with independent acceptance; 9 = superior outcomes for an explicitly defined market/workflow; 10 = not a sustainable blanket claim.

| Dimension | Weight | Score | Reason |
|---|---:|---:|---|
| Code engineering | 10% | 7.0 | Passing regression suites and clear boundaries; typed/lint/coverage/signing/load controls incomplete |
| Actual live-source depth | 20% | 2.5 | 23 paths, no successful live execution recorded here; provider coverage/limits/freshness unvalidated |
| Social intelligence | 10% | 2.0 | Profile normalization/imports and limited public lookups; deep content/interaction/historical coverage not established |
| Dark-web and CTI corpus | 10% | 2.0 | Feed/index/import/interop primitives; no proven licensed collection operations or maintained corpus |
| AI and media intelligence | 10% | 3.5 | Guardrails and signals exist; factual quality, model benchmarks and live inference unproven |
| Investigation UX | 15% | 4.5 | Graph filters/path/views/casework exist; scale, rich transforms and analyst trials absent |
| Production reliability | 15% | 2.5 | Queue/worker foundations; fencing, atomic effects, hosted restore and SLO evidence incomplete |
| Enterprise governance | 10% | 3.0 | RLS/audit/retention/AAL2 foundations; federation, lifecycle and operational assurance missing |

Weighted total = 3.3/10. This is a reviewer estimate, not 33% of Maltego's features, accuracy or value. An uncertainty band of 3–4 is more honest than false precision.

## Verified inventory

| Unit | Count/state | What it actually means |
|---|---|---|
| Playbooks | 40 | Named methods; not 40 fully independent live data platforms |
| Internal spider modules/rules | 9 / 8 | Bounded typed-event engine and correlations |
| External tool adapters | 34, 29 executable boundaries | Installed here: 0; execution verified here: 0 |
| Intelligence sources | 37 | 23 implemented request paths; others may be import-only |
| Live successful source proofs | 0 in audit runtime | Does not inventory other deployments |
| Upstream capability contracts | 49 | 4 configured-ready; 0 execution-verified here |
| OpenCTI connector packages | 308 | 308 present after submodule checkout; 303 Compose files; 0 TraceAtlas live-verified |
| Research metadata | 4,096 papers | Not 4,096 implemented algorithms |
| AI Employee procedures | 28 | Governed analyst procedures, not autonomous expert employees |
| Cloud job families | 4 | Domain passive, IP passive, URL metadata, hash reputation |
| API handlers / migrations | 17 / 8 | Useful control-plane foundation |

Counts overlap. Never sum this table into a total “working tools” number.

## Verification results

Latest snapshot: 191 Python tests pass; 25 Node graph/target tests pass; compilation, bash syntax and repository secret scan pass. Browser and PGlite jobs are defined in CI but not independently rerun as hosted tests in this assessment.

Initial earlier checkpoint `dd0bea3...` without the optional submodule: 185 tests ran with 1 failure and 2 errors in OpenCTI tests. After current-main refresh and pinned-source initialization, 191 pass. The setup script already attempts the fetch and degrades gracefully if it fails. The remaining issue is clarity/separation of optional-source tests, not a demonstrated broken core.

Static deployment doctor: 14 pass, 2 warnings, 1 failure. The failure is frontend version 1.8.0 versus package 1.9.0. Missing Supabase env configuration belongs to this audit runtime.

Readiness: `core_ready=false`, `production_ready=false`, `competitive_ready=false`, score 22. This command's internal scale is distinct from this market assessment.

## Assessment design defects

The internal maturity score is 7/10, including UX 9/10, despite no stored source runs and no hosted proof. Several points are earned through file existence or substring checks in `src/traceatlas/maturity.py`. These are useful implementation checks, not outcome evidence.

`DeploymentDoctor.run(production=True)` can mark production ready based on local files and environment syntax. It makes no network reachability, tenant, restore or uptime check. Maturity reuses that boolean for labels such as hosted UX/tenant tests. Repair this semantic conflation before trusting internal ratings.

Do not remove the existing limitations; make them enforceable in the score system.

## Enterprise adoption judgment

Appropriate now: supervised local use, synthetic demos, engineering pilots, explicitly bounded authorized investigations with manual verification.

Not justified by current evidence: contractual enterprise SLA, blanket vendor parity, autonomous attribution, independent deepfake/identity verdicts, regulated-production compliance claims or universal social/dark-web coverage.
