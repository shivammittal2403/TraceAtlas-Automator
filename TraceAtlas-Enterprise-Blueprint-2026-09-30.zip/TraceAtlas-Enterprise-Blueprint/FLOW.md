# End-to-end flows and failure semantics

Status: target behavior. Existing and missing implementations are mapped in INTEGRATION_MAP.md.

## Investigation flow

```mermaid
flowchart TD
    A["Question and purpose"] --> B["Authority and scope"]
    B --> C["Coverage and cost preview"]
    C --> D{"Human approval needed?"}
    D -->|Yes| E["Approval bound to plan"]
    D -->|No| F["Reserve usage and queue"]
    E --> F
    F --> G["Fenced connector steps"]
    G --> H["Permitted evidence and observations"]
    H --> I["Graph and timeline"]
    I --> J["Contradictions and hypotheses"]
    J --> K["Human review"]
    K --> L["Decision brief and signed export"]
```

At every stage, show unsupported sources, freshness, limitations and uncertainty. “No result” can be stated only after a successful supported query with known coverage.

## Job state machine

```mermaid
stateDiagram-v2
    [*] --> Proposed
    Proposed --> Blocked: scope or entitlement absent
    Proposed --> Approved: policy passes
    Approved --> Queued: budget reserved
    Queued --> Running: lease and fence issued
    Running --> Waiting: rate limit or retry
    Waiting --> Queued: deadline permits
    Running --> Finalizing: bounded result
    Finalizing --> Completed: atomic effects committed
    Running --> Partial: usable incomplete result
    Running --> Failed: terminal failure
    Running --> Cancelled: cooperative cancellation
    Queued --> Cancelled: no call made
    Running --> Queued: stale lease recovery
    Partial --> [*]
    Completed --> [*]
    Failed --> [*]
    Cancelled --> [*]
    Blocked --> [*]
```

“Completed” does not mean investigator verified the findings. Review state is separate. Stale recovery increments the attempt/fence; old attempts cannot finalize.

## Provider action flow

1. Validate verified session, scope version, authority expiry, source approval and source-specific entitlement.
2. Normalize exact input; public-IP/host restrictions and controlled DNS/redirect/egress rules run outside AI.
3. Reserve expected quota/cost under the tenant/source ledger.
4. Persist step identity and attempt before the call.
5. Enforce total deadline, byte/record/page/resource limits and cancellation.
6. Validate schema and classify transport/auth/quota/record-not-found/drift failures.
7. Minimize data before persistence; retain raw content only when explicitly permitted.
8. Finalize idempotent effects under current fence and reconcile reserved/actual/uncertain cost.
9. Publish durable completion/failure event through the outbox.

## Concurrent-worker finalization

```mermaid
sequenceDiagram
    participant A as Worker old attempt
    participant DB as Job database
    participant B as Worker new attempt
    participant E as Evidence store
    A->>DB: Claim attempt 1 and fence 1
    Note over A,DB: Heartbeat expires
    DB->>DB: Recover and increment attempt
    B->>DB: Claim fence 2
    A->>E: Stage permitted object
    A->>DB: Finalize with fence 1
    DB-->>A: Reject stale effects
    B->>E: Stage permitted object
    B->>DB: Finalize with fence 2
    DB->>DB: Commit case effects and outbox atomically
    DB-->>B: One canonical result
```

Orphan staging cleanup is bounded and must not remove evidence referenced by finalized records or protected by holds.

## Identity resolution flow

Candidate → independent supporting/conflicting observations → named reviewer/rationale → versioned link or reversible merge → preserved original IDs → ability to split/undo. Name or username similarity alone never proves common identity.

## AI Employee flow

Question → authorized evidence retrieval → evidence snapshot/version → candidate hypotheses with supporting/opposing citations → claim entailment/rule checks → abstain on insufficiency → analyst decision.

The model may suggest the next discriminating source/action. The deterministic coordinator checks policy and requests human approval when required. Model text cannot authorize collection.

## Monitoring flow

Eligible watchlist → approved schedule → bounded re-collection → compare stable fields → classify changed/unchanged/unknown/stale/error → severity and review → permitted notification → lifecycle state.

Provider failure must never produce a false “unchanged” status. Retractions, deleted records and entitlement expiry are distinct events.
