# AI and media evaluation specification

The current 8-case benchmark checks output schemas/citation references. It is a good regression layer, not a factual intelligence benchmark.

## Evaluation layers

| Layer | Data / test | Metric and failure condition |
|---|---|---|
| Output contract | Existing schema tests, unknown IDs, malformed fields | All deterministic validation tests pass |
| Retrieval authorization | Two tenants, revoked case grants, malicious decoys | Zero unauthorized evidence retrieval/output |
| Claim grounding | ≥200 independently adjudicated claim-evidence pairs, positive/negative/insufficient | Supported-claim precision target ≥0.95; unsupported assertion rate ≤0.02 |
| Contradictions | Conflicting dates/owners/feed retractions, recycled handles | All critical contradictions disclosed; no forced attribution |
| Injection resistance | ≥100 synthetic indirect-instruction cases | Zero forbidden tool action or cross-boundary leak |
| Investigator usefulness | Held-out workflows and blinded analyst review | Task completion/time/quality improvements with uncertainty reported |
| Drift | Model/version/prompt/source-schema changes | Requalification before promotion; rollback when quality regresses |

Thresholds are proposed release targets, not current achieved metrics. Report dataset size, class balance, inter-rater agreement and confidence intervals; do not optimize only the held-out set.

## Media modules

### Metadata and provenance

Hash original permitted files, retain acquisition provenance, inspect EXIF/container metadata, state missing/spoofable fields and transformations. SHA-256 proves byte identity, not authentic content, author identity or capture time.

### OCR and document signals

Use consented/owned fixtures across languages, low light, blur, compression and scripts relevant to intended users. Report character/word error, bbox/page accuracy and extraction completeness. Link statements to page/region.

### Audio and video

Optional ASR model with versioned weights/license and bounded local execution. Report WER by language/noise, alignment accuracy, timestamps, clipping and uncertainty. Speaker diarization is not person identification.

Video extraction uses bounded frame sampling and frame/time-span citations; missing intervals stay explicit.

### Visual/geographic hypotheses

Use permitted landmarks and coarse geographic context. Output candidate locations with evidence and uncertainty; never a private person's exact-location verdict from an image or IP. Geolocation evaluation needs consented/lawful datasets and known resolution.

### Manipulation/deepfake signals

Do not label metadata or perceptual hash as a deepfake detector. A future optional model requires licensing, adversarial/cross-domain/compression evaluation, measured false positives, abstention and explicit “signal, not forensic proof” output.

Do not add unconsented face identification or biometric search as a default capability.

## Model registry

Model ID/version, weights checksum, license, execution environment, prompt/retrieval version, dataset hashes, accepted metrics/limits, safety review, resource/cost caps, approval and retirement date.

## Promotion rule

An AI/media feature stays experimental until its evaluator passes and a reviewer approves the observed use case. No model-generated claim updates the source-observation record directly.
