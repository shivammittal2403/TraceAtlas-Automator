# Research to implementation — make the 4,096-paper pack useful

## Current truth

The repository contains audited paper metadata, patent records and gap/match metadata. It does not implement or reproduce 4,096 algorithms. Metadata completeness, source count and automatic matching are not scientific validation.

## Graduation ledger

Paper identity → relevance question → full lawful primary text reviewed → method/data/license understood → minimal reproduction → baseline comparison → independent holdout → safety/resource review → bounded integration → monitored outcome.

Fields: paper URL/DOI, version/date, hypothesis, applicability, dataset license, reproduction code commit, parameters/seeds, metrics, limitations, evidence artifacts, reviewer, decision and expiry.

Never label a paper “implemented” merely because its title appears in a catalog or a related function was written.

## First three research tracks

1. Entity alignment: precision-first candidate generation using non-sensitive permitted public attributes; namesakes/recycled handles/conflicts; human reversible adjudication.
2. CTI extraction: typed IoC/TTP/event relationships from permitted reports, with source span/time provenance and retractions.
3. Grounded narrative: claim entailment, contradiction disclosure and useful abstention over case evidence.

These are proposed tracks, not selected proven winning papers. Select primary papers through a new focused review and reproduce their exact assumptions before use.

## Acceptance

Each method must beat a declared simple baseline on the relevant held-out metric without degrading privacy, interpretability, latency or operating cost beyond approved bounds. Report negative results. Dataset leakage into prompts/training or repeated tuning on the holdout invalidates the result.

## Why 4,000 implementations is the wrong target

Most methods overlap, require incompatible datasets or address different tasks. Three well-qualified methods inside working investigator flows can be more valuable than thousands of superficial “paper-inspired” features. A useful research pack is a selection engine, not a product-maturity score multiplier.
