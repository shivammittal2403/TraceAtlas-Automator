# Target architecture

Status: proposed repair target; not deployed or implemented by this package.

## Decision

Keep a modular Python core and Supabase-backed control plane. Preserve the current frontend during Phase 0/1; choose component/renderer migration only after UX and scale experiments. Do not rewrite the whole product into microservices to create the appearance of enterprise maturity.

Vercel hosts the UI and bounded control API. Supabase provides Auth, Postgres authorization/state, Storage and Realtime where configured. An isolated execution runtime is required for resident Python tools, heavy native media jobs and third-party containers. It can be private managed container compute or on-prem; this design does not mandate Oracle or provision a new vendor.

A database and an HTTP function are not substitutes for every scanner, browser, GPU or container workload. Short approved provider calls may run in bounded functions if runtime/plan limits are verified. Durable checkpoints must remain outside request memory [S10–S11].

## Trust topology

```mermaid
flowchart TD
    UI["Investigator workspace"] --> API["Control API and policy"]
    API --> DB["Auth and tenant state"]
    API --> Q["Durable jobs and budget"]
    Q --> W["Isolated execution workers"]
    W --> EXT["Approved APIs or services"]
    W --> FINAL["Fenced evidence finalization"]
    FINAL --> DB
    FINAL --> STORE["Private evidence storage"]
    FINAL --> OUT["Transactional event outbox"]
    OUT --> UI
    DB --> AI["Tenant-scoped retrieval and AI"]
    AI --> REVIEW["Human review and decision"]
    REVIEW --> DB
```

## Modules and responsibilities

| Module | Owns | Must not own |
|---|---|---|
| Identity | Verified session, organization/case roles, privileged step-up | Editable profile metadata as authorization |
| Scope/policy | Purpose, authorized entities/actions, expiry, data-class and egress rules | An LLM's interpretation of permission |
| Connector registry | Versioned contracts, source approval, entitlement state | Automatic execution merely because a tool name exists |
| Workflow coordinator | DAG version, steps, budget, deadlines, retries/cancel | Arbitrary shell or model-generated executable plans |
| Executor | One approved step under lease/fence and resource limits | Broad cross-tenant reads or uncontrolled URL fetching |
| Evidence | Permitted artifacts, normalized observations, hashes, provenance | Declaring provider content true |
| Entity graph | Canonical IDs, typed claims/relationships, derived projections | Destructive automatic identity merging |
| Casework | Notes, review, hypotheses, decisions, collaboration changes | Hiding contradictory or stale observations |
| AI Employee | Authorized evidence retrieval, structured hypotheses and briefs | Autonomous verdicts, scope grants or external actions |
| Operations | Health, source SLOs, queue telemetry, backup/restore, incident response | Logs containing reusable credentials or unminimized case content |

## Mandatory invariants

1. Tenant and case context are assigned by verified server identity, never trusted from a client-only field.
2. Every paid/network step has an approved source/action/input contract and budget reservation.
3. Every accepted effect references a valid current attempt fence.
4. Evidence, observations, graph projection, review task and outbox are one logical transaction.
5. Source observation, analyst assertion, model hypothesis and human decision are distinct records.
6. Permissions apply to database queries, storage objects, signed URLs, subscriptions, exports and AI retrieval.
7. Provider/network/model failures are explicit outcomes, never “no evidence found.”
8. AI cannot grant itself actions, change authority or transform untrusted text into instructions.
9. Provenance and retractions survive projection rebuilds and export/import.
10. Production readiness requires expiring observed proof; local syntax cannot satisfy it.

## Write design

The executor uploads a bounded artifact into a private staging prefix using an attempt-bound reference. It computes the permitted artifact hash and records transformation/redaction metadata. A single finalization RPC locks the job attempt, checks current fence/lease/policy and atomically inserts idempotent evidence metadata, observations, graph changes, source result, review record and outbox.

If DB finalization fails, no public case projection points at the staged object; cleanup reconciles orphan artifacts without touching finalized/held objects. If publishing fails, the outbox remains pending. Consumers deduplicate by outbox event ID.

This provides idempotent effects over at-least-once execution. It does not make an external API's billable call exactly once under an ambiguous timeout. That uncertainty is surfaced and reconciled.

## Data/query design

Postgres remains authoritative; store typed entities/relationships with case/tenant indexes and bounded neighborhood queries. Use private object storage for larger permitted artifacts. Begin with indexed relational graph projections and full-text search. Add a dedicated graph/search engine only when measured queries justify the operational cost.

If vector retrieval is added, tenant/case/permission filtering must occur before retrieval or in the retrieval query—not by asking a model to ignore other tenants' documents.

## Evolution and deployment

Changes are additive and feature-gated. Preserve CLI/export formats through schema adapters. Expand then backfill then dual-read/test then switch; defer destructive migration until a separate approved change. Development fixtures stay visibly synthetic. A hosted route does not silently fall back to sample data.

Gate worker image and API by build SHA, schema compatibility and workflow contract version. Never promote an artifact that passed only local smoke tests as enterprise-ready.
