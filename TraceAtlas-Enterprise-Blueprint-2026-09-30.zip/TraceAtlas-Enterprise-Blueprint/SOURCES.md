# Primary source register

Reviewed 30 September 2026. Statements from vendor sites are attributed vendor claims, not independent benchmarks. Availability varies by plan and permission. Pages may change; this package records the review scope without redistributing full copyrighted pages.

| ID | Primary source | Claim used / limitation |
|---|---|---|
| S01 | [Maltego Graph](https://www.maltego.com/graph/) | Visual link analysis, external/internal data integration and repeatable investigation workflow; not a measured performance comparison |
| S02 | [Maltego Data Hub documentation](https://docs.maltego.com/en/support/solutions/articles/15000010778-the-transform-hub) | Hub can install transforms, sets, entities, machines and icons; credentials may be required |
| S03 | [Maltego collaboration documentation](https://docs.maltego.com/en/support/solutions/articles/15000010791-collaboration) | Multiple users can work on a graph in a secure session; implementation-specific behavior |
| S04 | [Social Links Crimewall](https://sociallinks.io/products/sl-crimewall) | Vendor claims 500+ sources; extraction/workflow/case collaboration/graph-table-map/ML/reporting/monitoring; not verified coverage/accuracy |
| S05 | [Recorded Future Intelligence Graph](https://www.recordedfuture.com/platform/intelligence-graph) | Vendor claims over 1 million indexed sources, ontology/event graph, multiple intelligence classes and risk analytics; counts are not directly comparable to connector packages |
| S06 | [SpiderFoot official README](https://github.com/smicallef/spiderfoot/blob/master/README.md) | 200+ modules, publisher/subscriber model, correlation, web/CLI/exports; module availability does not prove every endpoint works today |
| S07 | [Recon-ng official repository](https://github.com/lanmaster53/recon-ng) | Modular web-based reconnaissance framework; not a claim of enterprise platform parity |
| S08 | [OpenCTI data model](https://docs.opencti.io/latest/usage/data-model/) | Knowledge graph and STIX 2.1 model/interchange |
| S09 | [OpenCTI connector deployment](https://docs.opencti.io/latest/deployment/connectors/) | Import/enrichment/stream/file boundaries; dedicated tokens and actual platform configuration are required |
| S10 | [Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security) | Grants and policies both matter; exposed-schema RLS, views and service-role boundaries require attention |
| S11 | [Vercel Functions limitations](https://vercel.com/docs/functions/limitations) | Runtime/plan-specific limits need verification; no unsupported universal timeout figure is hardcoded in this plan |

Supabase's changelog Markdown endpoint was attempted but the retrieval service rejected its content type. No Supabase schema implementation was performed; the coding prompt requires refreshing relevant documentation/changelog before an actual implementation.

## Repository evidence versus external sources

The code-specific claims come from the pinned repository and command artifacts in EVIDENCE_REGISTER.md, not vendor pages. Score, strategic estimates, staffing/time horizons and proposed acceptance metrics are reviewer judgments or targets.

## No invented sources

The user's long directory list is not represented as verified availability/API entitlement. Ambiguous providers and absent licenses remain unresolved until individually investigated. This assessment does not declare every tool on that list safe, maintained, legal or compatible.
