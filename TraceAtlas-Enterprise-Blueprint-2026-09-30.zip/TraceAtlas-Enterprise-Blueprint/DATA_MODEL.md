# Data model and migration contract

These are target logical records, not SQL applied to a live database. Existing tables must be mapped before implementation. Generate migration filenames through the current Supabase CLI; review grants/RLS together [S10].

## Existing foundation

The repository contains organizations/members, cases/assets, investigation jobs/events, evidence, graph entities/edges, source runs, notes/reviews, saved views/collaboration and audit/retention/hold migrations. Do not create parallel competing tables for these concepts.

## Target logical additions or extensions

| Record | Required fields | Invariant |
|---|---|---|
| Scope version | tenant, case, purpose, authorized entity/action set, authority ref, approver, expiry, data classes, egress policy, version/hash | Immutable approval context; expired/revoked scopes stop new steps |
| Source approval | connector/version, permitted fields/actions/use/export, entitlement reference, plan/region, review date/expiry | Catalog membership never grants execution |
| Workflow version | DAG hash, typed steps, action contracts, total limits, approval rules | Reproducible plan; no arbitrary code from model output |
| Job attempt | job, monotonic attempt/fence, token, worker, lease expiry, heartbeat, deadline, outcome | Every effect must match the active attempt |
| Connector step | job/attempt, step ID, source/action/input fingerprint, state, cursor, retries, bounds, start/end, failure code | Completed step replay is idempotent; secret-free checkpoint |
| Usage reservation | tenant/source/job/step, quota units, currency, upper-bound estimate, reserved/settled/uncertain, actual usage | Atomic tenant/source budget; unknown costs remain unknown |
| Artifact reference | tenant/case, storage key, hash, bytes/type, permitted retention, acquisition/transform time, redaction manifest, source run | Private namespace and allowed-content policy |
| Observation | source stable ID, subject, predicate, typed value/object, source assertion time, collected/observed time, artifact ref, coverage/limitations | Provider statement is not a truth verdict |
| Claim | proposition, classification, reviewer/model/rule version, cited observations, counterevidence, confidence semantics | Confidence not auto-invented or conflated with provenance |
| Resolution event | candidate/original entity IDs, decision, rationale, reviewer, version, supersedes, reversible projection change | No destructive loss of original evidence identity |
| Retraction | affected observation/claim/source record, date, reason, producer, superseding reference | Consumers know prior conclusions may be invalid |
| Outbox event | unique ID, tenant/case, aggregate version, event type, permitted payload, pending/published/attempts | Inserted transactionally with state; consumers deduplicate |
| Readiness proof | build/schema/source/model versions, environment, test/harness/dataset hash, evidence refs, timestamps/expiry, reviewer/signature | Static config cannot impersonate observed hosted tests |
| Decision journal | question, options, evidence snapshot, uncertainty, human decision, rationale, follow-up | AI advice and accountable decision remain distinct |

## Common fields

All case data: `organisation_id`, `case_id`, stable UUID, schema version, created/updated timestamps and classification/retention metadata. Cross-table foreign keys must enforce matching tenant/case, not merely valid UUIDs.

All external records: source/provider ID, method/version, source timestamp and timezone basis, collected time, first/last seen, license/usage restriction and provenance hash. Unknown timestamps stay unknown.

## Constraint and policy design

- Unique step and evidence-effect fingerprints are case/job-scoped where required; no global dedupe leak across tenants.
- Validate tenant membership, case grants and operation role for reads, edits, reviews, collection, exports and subscriptions.
- User-editable metadata is never authorization input.
- Use invoker semantics for exposed views; tightly bound definer RPCs, fixed search path, narrow grants, validated session/role and payload sizes.
- Index tenant/case foreign keys, source/run times, job state/lease, stable provider IDs and outbox delivery state.
- Retention deletion must resolve artifacts, projections, derived search/vector indexes, exports and allowed caches; legal hold checks precede deletion.
- Store tenant HMAC fingerprints for sensitive identifiers when justified; an unsalted public hash of a low-entropy identifier is not anonymization.

## Schema migration sequence

1. Inventory existing tables/RPC signatures and collect baseline migration tests.
2. Add new columns/tables/constraints and grants/RLS; default new execution gates off.
3. Backfill using resumable bounded batches; keep old readers supported.
4. Run migration replay, role-negative, concurrency and old/new client compatibility tests.
5. Dual-read or compare projections; require operator sign-off before switching.
6. Observe error/latency/index cost; keep rollback/revert path.
7. Remove old columns only in a separately approved later release with backup and retention review.

This document intentionally does not invent a production migration identifier or execute a schema change.
