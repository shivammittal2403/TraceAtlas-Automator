# Matched benchmark and analyst pilot

## Objective

Determine whether TraceAtlas improves defined authorized investigation tasks without sacrificing evidence quality, privacy or reliability. Do not compare tool-name counts or vendor marketing source counts.

## Trial design

- Three workflow families W01–W03, each with ten representative cases where feasible.
- At least ten experienced analysts; counterbalanced order to reduce learning effects.
- Same lawful targets, time window, task instructions and entitlement level wherever possible.
- Freeze product builds, provider plans, data snapshot dates and model versions.
- Blinded independent reviewers adjudicate reports using a ground-truth/expected-evidence rubric.
- Record unavailable access and source-plan differences instead of “penalizing” a product for a feature not licensed in the trial.
- Separate public documentation comparison from hands-on paid vendor trials.

## Metrics

| Metric | Definition |
|---|---|
| Task completion | Required question answered with acceptable evidence, not merely report generated |
| Analyst time | Active investigator minutes and end-to-end elapsed time separately |
| Link precision | Correct accepted relationships / all accepted relationships |
| Expected-evidence recall | Recovered expected evidence / adjudicated expected evidence within the approved source scope |
| Unsupported assertions | Claims not supported by cited evidence / evaluated claims |
| Provenance completeness | Claims with permitted source/date/method/artifact references |
| Freshness | Observation delay relative to source availability, with missing data explicit |
| Investigation cost | Entitlements, API units, compute/storage and analyst effort; amortization declared |
| Reliability | Failed/partial/cancelled/degraded runs, recovery and duplicate side effects |
| Privacy and usability | Unauthorized/sensitive outputs, analyst assistance/errors, accessibility |

## Comparison rules

Maltego: graph/pivot/transform/case report tasks.
Social Links: permitted organizational-social/corporate extraction plus network/timeline questions.
Recorded Future: relevant CTI triage/context/freshness within licensed datasets, not a fake comparison to an empty local feed.
SpiderFoot/Recon-ng: shared authorized passive collection tasks and evidence quality.
OpenCTI: STIX knowledge management/interoperability tasks, not social account collection.

## Statistical reporting

Show per-case/per-analyst distributions, median/p95, effect sizes and confidence intervals. Include failures and incomplete tasks. Small pilots can reveal usability problems but cannot establish global market superiority.

Proposed narrow win criterion: at least 25% median active-time reduction or 30% lower qualified total task cost, with non-inferior evidence quality and zero critical privacy/authorization violations. These are targets, not current results.

## Pilot stages

1. Synthetic/local workflow rehearsal.
2. Approved live canaries and staging tenant qualification.
3. Two-week supervised analyst pilot.
4. Thirty-day operated source/reliability observation.
5. Independent review, limitations and specific permitted public claims.

Store consent/authority and data use separately from public benchmark reports. Redact identifiers; preserve reproducible permitted artifacts. Do not publish private case data.
