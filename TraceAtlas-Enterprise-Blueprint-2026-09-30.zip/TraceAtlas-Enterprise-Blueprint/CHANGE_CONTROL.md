# Change control and proof of completion

## Branch and review policy

Refresh authorized repository snapshot, preserve existing user work, create a scoped local branch, implement one repair tranche, add tests and evidence, and review the diff. Push/open PR/merge/deploy only with explicit authority. This document creates no external write permission.

No force-push or destructive reset. Do not mix unrelated user changes into a repair. Respect applicable AGENTS.md and installed skill instructions.

## PR template

- Problem IDs and exact decision/user outcome.
- Current baseline SHA and changed paths.
- Behavior added/changed/preserved and known exclusions.
- Schema/RPC/contract compatibility and migration/rollback plan.
- Security/privacy/license/data-flow changes.
- Tests: commands, environment, pass/fail, artifacts and hashes.
- Live/hosted proof: scope/entitlement/date/expiry or NOT_VERIFIED.
- Remaining blockers, operating owner and feature gates.

## Status vocabulary

PLANNED, IMPLEMENTED, FIXTURE_VERIFIED, LIVE_VERIFIED, HOSTED_VERIFIED, OPERATED, OUTCOME_VALIDATED, BLOCKED, RETIRED.

Never use COMPLETE when required proof belongs to a later state. No automatic promotion from fixture to live or file existence to hosted.

## Done means

Code exists, tests exercise expected and denied behavior, critical regressions pass, evidence is linked, docs reflect limitations, permissions are reviewed, rollback is safe, and a named reviewer signs the appropriate gate.

A task can be locally complete and externally blocked. Report both honestly.

## Release evidence

Build SHA/digest, schema/workflow/source/model versions, SBOM, dependency/license review, test results, signed provenance, staging qualification, risk acceptance, release notes and operator runbooks.

Keep secrets and case payloads out of release artifacts. Do not include downloaded third-party source trees in a blueprint ZIP just to inflate its size.
