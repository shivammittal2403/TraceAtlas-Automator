# Roadmap, ownership and resource reality

## Product problem statement

For authorized organizational investigators who lose time switching between sources and cannot confidently trace conclusions, TraceAtlas should provide a permission-scoped evidence graph, repeatable collection and decision brief that reduces investigator effort while preserving provenance, uncertainty and accountability.

Initial customer: small organizational security/CTI investigation teams, including approved NGO/SME use. Expand regulated/government use only after data/operating requirements are qualified.

Non-goals: replace every intelligence vendor, scrape every private social platform, identify people through faces, track private locations, retrieve reusable breached secrets, or make autonomous accusation/exploitation decisions.

## Outcomes, not vanity KPIs

Time to defensible answer; reviewed-link precision; evidence completeness; unauthorized output count; source freshness; cost per completed task; recovery time; analyst completion/adoption. Tool/paper count is inventory, not success.

## Planning envelope

The following are rough planning assumptions, not quotations or delivery commitments:

| Horizon | Plausible outcome if dependencies are satisfied | Not promised |
|---|---|---|
| 0–30 days | Truthful baseline, first execution repairs, source approvals and staged harness | Enterprise parity |
| 30–90 days | Bounded W01 pilot with live proof, investigator workflow and initial ops | Broad Social Links-level acquisition |
| 3–6 months | Qualified scoped product, stable graph/AI evaluation, staged identity/recovery | Recorded Future corpus recreation |
| 6–12 months | Enterprise qualification for agreed customers/workflows, independent trials | Universal superiority |
| 12–24+ months | Broader source partnerships, specialized differentiated outcomes | Completion without recurring source maintenance/funding |

Indicative team: 3–4 backend/connector engineers, 1–2 graph/frontend engineers, 1 data/OSINT lead, 1 QA/evaluation engineer, and shared/dedicated SRE/security/privacy/product ownership. Some roles may overlap; roughly 7–10 effective full-time contributors is a planning scenario, not a requirement established by market research.

A solo or volunteer team should sharply reduce scope and extend the schedule. More prompts do not remove data contracts or operational staffing.

## Work estimation

Initial backlog can be sized at roughly 50–100 engineering person-weeks before broad enterprise qualification, plus source procurement, independent datasets, operators and ongoing maintenance. This order-of-magnitude estimate must be recalibrated after Phase 0 spikes; it is not a fixed-cost proposal.

## Cost worksheet

Annual total = engineering/QA + source subscriptions/usage + compute + database/storage/backup + observability + security assessment + support/training + legal/privacy review.

Track per-source unit economics, per-case API/AI cost, redundant calls and retained-artifact growth. Use actual quotations and workload measurements before setting pricing. No dollar/rupee subscription prices are invented here.

## Build versus integrate

Build: evidence/claim semantics, governed orchestration, reversible graph workflow, transparent uncertainty and customer-specific decision experience.
Integrate: entitled data, CTI feeds, registries, optional media runtimes and standards-compatible platforms.
Partner: source access and maintenance, independent analyst evaluation, operating assurance.

## Kill or defer criteria

Defer a source without clear lawful entitlement, stable identity or workflow value. Defer a model without measurable improvement. Do not fund a major frontend/graph/database rewrite without a failed measured requirement. Stop using any “10/10” score that lacks an explicit rubric and observed proof.
