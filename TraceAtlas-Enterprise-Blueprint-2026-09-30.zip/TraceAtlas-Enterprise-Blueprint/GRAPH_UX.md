# Investigator workspace and graph UX

## Current versus target

Current: vanilla frontend, graph import/normalization, filters, bounded paths, layouts, evidence references, saved views and collaboration foundations.
Target: a complete investigator loop, not a prettier dashboard.

## Workspace

| Surface | Required behavior |
|---|---|
| Case header | Purpose, authority/scope status, case role, build/schema version and last sync |
| Entity search | Stable entity/source IDs, namesake candidates, no forced matches |
| Graph canvas | Selection, grouping, pinned coordinates, bounded neighborhood, confidence/freshness/claim classification |
| Transform palette | Applicable actions for selected entities; entitlement, fields, coverage, cost and scope preview |
| Execution drawer | DAG/step state, progress, quota, cancellation, explicit partial/errors and retry limits |
| Evidence inspector | Source assertion, timestamps, permitted artifact/hash, transformations, limitations and counterevidence |
| Timeline/map/table | Shared filters; original timezone and coarse geo uncertainty preserved |
| Review queue | Proposed links/claims, supporting/opposing evidence, reviewer rationale and undo/supersede |
| Brief/export | Reviewed claims, unresolved questions, source restrictions and signed manifest |

## Non-negotiable interactions

1. Right-click or keyboard action palette on selected nodes.
2. Dry-run action preview showing exactly what will be sent to which source.
3. Expand one/two hops with bounded server queries; show omitted records rather than pretending completeness.
4. Shortest-path explanation with edge provenance; a path is association, not causal/identity proof.
5. Merge/split preview and reversible history; original observations remain addressable.
6. Save view without modifying source evidence.
7. Side-by-side source comparison and contradictions.
8. Visible stale, retracted, model-generated and analyst-reviewed states.
9. Reconnect/conflict handling with durable aggregate revisions.
10. Keyboard navigation, screen-reader labels, focus states and error announcements.

## Scale plan

Start with performance measurements on the existing renderer. Offload layout calculations, virtualize tables, retrieve paginated subgraphs and defer labels/details.

Target qualification workload: 10k entities/30k relationships, 10 concurrent analysts, specified commodity analyst hardware and staging load. The 100k/300k corpus is server-query/selective-view capacity—not a promise to render every label simultaneously.

Evaluate Canvas/WebGL renderers only after an ADR comparing latency, accessibility, export quality, licensing and integration effort. Do not migrate frontend framework/graph store merely to claim sophistication.

## Analyst acceptance script

Select authorized entity → preview/run permitted action → inspect new evidence → identify namesake → compare contradiction → explore path/timeline → review candidate → recover network disconnect → export reproducible brief.

Measure completion, time, wrong links, missed evidence, assistance required, perceived confidence and cost. Developer-operated demos do not qualify as investigator acceptance.
