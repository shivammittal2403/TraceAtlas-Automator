# Evidence register and assessment limits

## Repository identity

- Repository: https://github.com/shivammittal2403/TraceAtlas-Automator
- Current main observed through GitHub and fetched locally: `2a8789eb7cc401b327796e32458b9733674ecbc9`.
- Commit: merge PR #14, governed supplied archive integrations.
- Version: 1.9.0. Pinned OpenCTI connector source: `55ca0dfa4129050cb607fdaf6b1a7457e0ae3476`.
- Date: 30 September 2026. Evidence-bound snapshot, not a permanent inventory.
- Local tracked worktree was clean after inspection/test execution.

## Commands and preserved outputs

All commands below ran in the assessment clone with no arbitrary third-party source collection.

| Evidence | Command | Observed outcome |
|---|---|---|
| E01 `evidence/tests.log` | `PYTHONPATH=src python -m unittest discover -s tests -q` | 191 tests pass after pinned optional submodule initialization |
| E02 `evidence/nodeTests.log` | `node --test tests/test_graph_model.cjs tests/test_target_validation.cjs` | 25 pass |
| E03 `evidence/readiness.json` | `PYTHONPATH=src python -m traceatlas.cli readiness --json` | core/production/competitive false, score 22 |
| E04 `evidence/maturity.json` | `PYTHONPATH=src python -m traceatlas.cli maturity --json` | Internal score 7; 23 live contracts, 0 live proofs, 0 source runs, production false |
| E05 `evidence/deployment.json` | `PYTHONPATH=src python -m traceatlas.cli deployment doctor --json` | 14 pass, 2 warnings, 1 frontend-version failure; exit 2 |
| E06 `evidence/integrations.json` | `PYTHONPATH=src python -m traceatlas.cli integrations doctor --json` | 34 tools; 0 installed/verified here |
| E07 `evidence/capabilities.json` | `PYTHONPATH=src python -m traceatlas.cli capabilities doctor --json` | 49 boundaries; 4 ready, 0 execution-verified here |
| E08 `evidence/opencti.json` | `PYTHONPATH=src python -m traceatlas.cli opencti-connectors doctor --json` | 308 packages/303 Compose files present; live verified 0; Docker/config absent here |
| E09 `evidence/benchmark.json` | `PYTHONPATH=src python -m traceatlas.cli benchmark --json` | 8/8 evidence-output contract cases pass |
| E10 `evidence/secrets.log` | `python scripts/check_secrets.py` | Scanner reports clean |
| E11 | `python -m compileall -q src api vercel_control.py` | Pass |
| E12 | `bash -n setup.sh start.sh set.sh` | Pass |

E11/E12 were invoked after the Node command in the same shell call and produced no errors. No hosted browser/SQL production suite was run here.

## Static evidence anchors

Paths link into the immutable assessed commit, not a moving main branch:

- [Internal scoring](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/src/traceatlas/maturity.py): file/string gates and static deployment-ready reuse.
- [Static deployment doctor](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/src/traceatlas/deployment.py): files/env syntax/version; no hosted probe.
- [Worker effects](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/src/traceatlas/cloud_worker.py): independent writes before completion.
- [Job RPC/lease definitions](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/supabase/migrations/20260925000100_traceatlas_control_plane.sql): worker-ID completion and 15-minute stale recovery.
- [Source status](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/docs/SOURCE_INTEGRATION_STATUS.md): catalog versus action paths and remaining step/usage work.
- [Existing gap ledger](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/docs/BLUEPRINT_TASK_LEDGER.csv): 28 previously identified delivery gaps and acceptance blockers.
- [Archive status](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/docs/SUPPLIED_INTEGRATION_STATUS.md): 49 contracts, not 49 operational runtimes.
- [AI benchmark](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/src/traceatlas/benchmark.py): contract/citation validation.
- [Resolution review](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/src/traceatlas/resolution.py): human link judgment, no automatic merge.
- [CI](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/.github/workflows/ci.yml): recursive submodule, local/fixture/SQL/browser/build jobs.
- [Frontend version](https://github.com/shivammittal2403/TraceAtlas-Automator/blob/2a8789eb7cc401b327796e32458b9733674ecbc9/public/index.html): 1.8.0 footer.

## Important qualifications

The first tested checkpoint was `dd0bea353e106d8fc7719be3f5b1ac665dac13cc` without initialized optional source; 185 tests ran, 1 failed and 2 errored in OpenCTI tests. Main then moved to the assessed SHA; pinned source was fetched and 191 tests passed. This is not evidence that the current configured core suite is broken.

GitHub combined commit-status response for latest SHA contained an empty statuses array. That endpoint is not complete check-runs evidence; this assessment does not claim current-main CI/check-run success from it.

No Vercel production project/logs were inspected for this assessment. Missing local environment variables and empty local ledgers are not proof that a different installation is unavailable.

No commercial vendor performance was tested. Official capabilities are vendor claims; competitive gap judgments are inferences from reviewed implementation versus published category capabilities.

No raw secret value, personal investigation target or private case record is included in this package.

## Integrity

SHA256SUMS covers the package contents except itself. The checksum list detects accidental alteration; it is not a trusted signature or external custody anchor. validate_pack.py checks links, required files, IDs, JSON and checksums. Neither the validator nor ZIP passes the product's enterprise gates.
