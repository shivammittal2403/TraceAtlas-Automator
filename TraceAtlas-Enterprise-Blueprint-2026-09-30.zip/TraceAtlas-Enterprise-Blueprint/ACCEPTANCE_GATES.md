# Release and 9/10 acceptance gates

These are proposed targets, not achieved results. Numbers must be qualified against declared environment, workload, source plans and independent datasets.

## Gates

| Gate | Required evidence | Proposed pass rule | Problem IDs |
|---|---|---|---|
| G01 Truth and readiness | Build/version matrix and readiness-negative fixtures | Configured/unreachable/unverified deployment cannot be called hosted-verified; claims have evidence/type/expiry | P01 P02 P08 P36 |
| G02 Durable execution | Multi-session races, stale attempts and failpoints at all effects | No stale accepted effect; no duplicate canonical effects; no partial finalized case projection; ambiguous external charge explicit | P03 P04 P11 |
| G03 Sources | Authorized canaries and 30-day health for prioritized actions | ≥5 priority actions recent live-verified; contract/error tests pass; source coverage/freshness/quota transparent | P05 P12 P13 P14 |
| G04 Authorization and lifecycle | Real hosted sessions, direct API/storage/channel negative suite, rotation/offboarding | Zero cross-tenant/case leakage; removed access obeys approved revocation target; keys never client-exposed | P06 P26 P27 P28 |
| G05 Recovery and operations | Isolated hosted restore, hash/role verification, paging drill | Measured RPO ≤15 min/RTO ≤4 h for qualified pilot plan; alerts have accountable owner | P07 P31 |
| G06 Evidence and resolution | Signed export verifier, tamper/retraction/merge-split tests | 100% reviewed claims traceable; unknown preserved; undo restores provenance; adjudicated link precision ≥0.98 target | P18 P25 P33 |
| G07 Workflow coverage | W01–W03 expected outputs/action matrix and social/CTI source limitations | ≥95% required output fields populated or explicitly unsupported/unknown; no unsupported field invented; missing critical coverage blocks that workflow | P10 P15 P16 P17 |
| G08 Resilience | 10-user load, reconnect/revocation, provider failure, crash/outbox tests | No data/isolation loss; bounded queue recovery; p95 queue/control targets met at declared workload | P21 P30 P31 |
| G09 Investigator UX/scale | 10 independent analysts; 10k/30k visible-workload test, 100k selective-query test | ≥90% unaided golden-task completion; p95 common graph interactions <200 ms after load; initial qualified subgraph <3 s | P19 P20 P21 |
| G10 AI Employee | ≥200 held-out claim pairs, ≥100 injection cases, independent review | Supported-claim precision ≥0.95, unsupported assertions ≤0.02; zero forbidden actions/leaks; correct abstention | P22 P23 |
| G11 Media | Consented/owned multilingual/compression/noise dataset, pinned model reports | Declared module-specific accuracy met; citations to frames/spans; no identity/authenticity certainty; safe resource handling | P24 P25 |
| G12 Release assurance | Full regressions, real Postgres/hosted tests, supply-chain/DAST/independent assessment | No unaccepted critical/high release findings; signed provenance; contract compatibility; offline core tests pass | P09 P29 P30 P32 |
| G13 Product outcomes | Matched, counterbalanced vendor/task trial and representative pilot | Claim superiority only where quality is non-inferior and time/cost meaningfully better with uncertainty reported | P34 P35 P36 |

G07's 95% is completeness of reporting fields, not a claim of 95% real-world data recall. A workflow with unavailable essential sources fails even if it labels them unknown.

## Proof manifest

Environment, build SHA, schema version, source/model/workflow versions, harness/dataset hashes, authorized scope reference, time/window, result counts, failures, artifact references, reviewer and expiry.

Replayable local proof and authorized hosted proof are separate. A manual operator-signed proof is not cryptographic trust unless signer keys and verification policy are governed.

## Rating rules

- Local regression success earns engineering credit, not source coverage or enterprise operations credit.
- Source/action live proof expires after a contract/credential/entitlement change or the defined freshness interval.
- An unresolved tenant leak, stale-effect acceptance, missing recovery or source entitlement blocks enterprise release.
- A 6/10 scoped pilot needs functioning live workflows and investigator acceptance.
- An 8/10 enterprise candidate needs all safety/reliability gates and operated proof, with documented remaining market gaps.
- A 9/10 scoped product needs all gates, independent customer outcomes and no critical missing workflow requirement.
- “Better than Maltego/Social Links/Recorded Future in general” requires evidence across the claimed scope; passing a narrow benchmark does not support a universal claim.

## Audit status now

All gates above are NOT_QUALIFIED or PARTIAL. Existing regressions, transport safeguards and evidence contracts satisfy parts of them; they do not close the complete gate. The current 3.3/10 market estimate is not upgraded by this package.
