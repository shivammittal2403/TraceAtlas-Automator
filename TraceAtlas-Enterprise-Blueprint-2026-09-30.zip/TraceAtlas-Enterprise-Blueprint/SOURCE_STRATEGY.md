# Source strategy — depth before count

The project should not promise a universal source estate. Start with three authorized golden workflows; graduate source actions only when they materially improve one workflow.

## Initial workflows

| Workflow | Data needed | Decision output |
|---|---|---|
| W01 Organizational exposure | Owned domains/public IPs, DNS/RDAP, public technical metadata, approved archive/CTI | Attributable assets, dated exposures, uncertainty and remediation priority |
| W02 Public organizational identity/corporate review | Official registration/filings, owned/consented public professional accounts, explicit public links | Relationship/timeline claims with independent corroboration and namesake warnings |
| W03 Threat report to reviewed intelligence | Permitted report/feed, IoCs/TTPs, validity dates, source lineage/retractions, internal asset relevance | Reviewed CTI evidence and versioned STIX export |

## Activation waves

### Wave A: prove a minimal live spine

Choose five existing actions that support approved targets: DNS, RDAP, InternetDB, permitted Wayback index lookup and an owned organization's public GitHub account metadata.

Validate current official endpoint contracts, quotas, attribution and expected fixtures before calling. A repository path does not establish current endpoint correctness.

### Wave B: enrich, do not bloat

Select Shodan or Censys, VirusTotal hash reputation, GreyNoise/IPWHOIS, one approved corporate-registry source, and one operator-controlled CTI feed/service. Keys and plan-specific permissions must be explicitly configured. No hidden paid calls.

### Wave C: deepen social and archive workflow

Use official/licensed APIs or user-approved exports for public organizational/consented data. Add action-level support for posts, interactions, source times and lawful archives only where permitted. LinkedIn/Instagram/Facebook/TikTok/Snapchat import-only support must remain labeled import-only until a real approved action is implemented and verified.

### Wave D: monitored intelligence

Continuous approved CTI metadata, watchlists, retractions and corporate/exposure changes. Require health history, cost control and retention/notification governance before increasing schedule frequency.

## The supplied tool list

The repository records 196 supplied entries reconciled to 187 canonical candidates. Each belongs to one of:

- approved API/service candidate;
- local owned/consented-file analyzer;
- import/export interoperability;
- dataset/training/directory;
- external launcher/manual workflow;
- ambiguous identity or unverified provider;
- unavailable/unsupported/licensing-blocked;
- excluded harmful or authority-intensive collection.

This assessment does not claim to have validated every candidate's availability or terms. Names such as “PRISM”, “Hive”, “KeyFinder”, “TracePoint” or “Glint” are ambiguous without owner/repo/version. Do not fabricate adapters from names.

## Exclusions

No phone-to-private-account bots, credential theft, reusable leaked password retrieval, private-profile bypass, stolen cookies, automated private-person location tracking, unconsented biometric identification or IMSI interception. Wi-Fi/device context must be owned/authorized, coarse and purpose-limited. Pentest execution is a separate governed product boundary, not an accidental side effect of importing an OSINT ZIP.

## Source acquisition economics

For every action record license/terms review, permitted downstream use, retention/export rules, official contact/docs, pricing model, quota, credentials, maintenance owner, expected value and failure substitute.

Distinguish “source data not available” from “engineering not finished.” API access rights and proprietary historical corpora cannot be solved by a coding prompt.

## Ranking rule

Rank by workflow coverage gain, adjudicated quality, freshness, permitted use, stability, analyst time saved and total operating cost. Source count is secondary. A new source that duplicates low-quality claims can make intelligence worse.
