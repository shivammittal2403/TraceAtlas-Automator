# Competitor comparison — compare the right category

Official-source review date: 30 September 2026. Vendor statements below are vendor-published claims, not independently validated performance. Plan, subscription, jurisdiction and source availability can change actual access. No paid vendor hands-on trial was run.

## These products have different moats

| Product/category | Published capability | TraceAtlas's current gap | Strategy |
|---|---|---|---|
| Maltego Graph | Visual link analysis, OSINT/commercial/internal integrations and repeatable investigative workflows; Data Hub installs transforms, entities and machines [S01–S03] | Transform-centric graph interaction, reusable workflow depth, proven analyst ergonomics and partner ecosystem | Build a graph execution workbench; do not confuse a graph viewer with it |
| Social Links Crimewall | Vendor claims 500+ sources; case collaboration, extraction, scripts, graph/table/map, reports, ML/media and monitoring [S04] | Entitled live social coverage, source depth, content/history/network analysis and source maintenance operations | Buy/build licensed access selectively, then validate complete workflows |
| Recorded Future | Vendor claims over 1 million indexed sources, ontology/event graph, technical/open/dark-web/telemetry/research correlation and risk analytics [S05] | Maintained historical corpus, continuous ingestion, multilingual ontology, research operations and calibrated product intelligence | Integrate licensed CTI and specialize; do not promise to recreate its global data estate |
| SpiderFoot open source | 200+ modules, publisher/subscriber collection, correlation, CLI/web and exports [S06] | Internal TraceAtlas spider engine has 9 modules and 8 rules; adapter presence is not native coverage | Preserve governance; develop a tested passive compatibility layer and outcome-based coverage |
| Recon-ng | Modular web reconnaissance framework designed for repeatable collection [S07] | Proven module execution/maintenance and reconnaissance operator workflow | Use isolated passive adapters where appropriate; not an enterprise collaboration benchmark |
| OpenCTI | STIX 2.1 knowledge graph; ingestion, enrichment, stream and export connector classes [S08–S09] | TraceAtlas's connector snapshot is not a running OpenCTI data pipeline | Treat it as a service/interop boundary with scoped connector credentials |

Official links and claim bounds are in [SOURCES.md](SOURCES.md).

## Why your tool is behind

### Against Maltego

TraceAtlas currently offers evidence graph import, normalization, filters, shortest paths and saved views. Maltego's value proposition is not merely drawing circles: an analyst can pivot through data providers and repeat processes inside the graph workflow. Secure simultaneous graph collaboration is documented [S03]. TraceAtlas has collaboration foundations but lacks equivalent hosted acceptance evidence and transform UX depth.

Verdict: substantially behind as an everyday visual investigation workstation. No numeric “X times worse” claim is defensible without matched analyst testing.

### Against Social Links

Ten social-facing request contracts in an internal inventory do not imply access to ten full social intelligence datasets. GitHub, Discord invite metadata, developer platforms, approved imports and a profile lookup are not interchangeable with post/search/history/follower/comment coverage.

Vendor breadth is also not a guarantee of accuracy or legal appropriateness. Compare stable IDs, retained fields, timestamps, allowed use, failure rates and investigator task completion.

Verdict: far behind on social acquisition and depth. Current governance is promising; it does not compensate for missing data.

### Against Recorded Future

Adding OpenCTI connector source trees does not create years of historical intelligence, continuously refreshed entities, researcher adjudication, telemetry, risk scores or production feed operations. Recorded Future is not simply “another OSINT scanner.”

Verdict: very far behind as a global intelligence provider. An integration-plus-specialization strategy is more credible than a clone strategy.

### Against SpiderFoot and Recon-ng

These are narrower automation frameworks, not equal substitutes for enterprise case management. TraceAtlas can potentially differentiate on evidence packaging, constrained execution and human review, but currently has thinner demonstrated collection breadth and no adapter executions verified in this audit runtime.

Verdict: do not claim superiority until a shared authorized passive benchmark demonstrates it.

## Where TraceAtlas could genuinely win

| Potential wedge | Required proof |
|---|---|
| Evidence transparency and reproducibility | Every claim resolves to permitted evidence, collection time, method/version and replay limitations |
| Local/private organizational workflows | A deployable, recoverable on-prem/private mode and tested data-egress policy |
| Analyst cost transparency | Per-case entitlement/cost budget with no duplicate billable retries |
| Indian/SME/NGO organizational exposure workflow | Approved representative cases, multilingual briefs and measured task-time advantage |
| Vendor-neutral interoperability | Round-trip evidence/STIX exports without loss of markings, provenance or access restrictions |
| Explainable uncertainty | Namesake, recycled-handle and conflicting-source tests; no forced identity merge |

No row is a current “better than Maltego” assertion.

## Boundaries of this comparison

We did not evaluate every OSINT tool in the market. Specialized tools such as an IP search engine, reverse-image engine, corporate registry, browser archive or username checker should be compared as components, not assigned an overall enterprise-product score. Their inclusion in a directory creates no coverage entitlement.
