# Existing code to target repair map

Do not replace working modules without a demonstrated need. Paths below are present in the assessed snapshot; proposed additions are explicitly marked.

| Existing location | Preserve | Extend / repair |
|---|---|---|
| `src/traceatlas/deployment.py` | Static files/env/version checks and limitations | Rename static-ready semantics; independent hosted proof contract |
| `src/traceatlas/readiness.py`, `maturity.py` | Explicit blockers, evidence counts | Split static/fixture/live/hosted/outcome axes; expiry and independent proofs |
| `src/traceatlas/intelligence/contracts.py`, `sources.py` | Typed source contracts and state | Action-specific entitlement, fields/use/expiry/cost/coverage |
| `intelligence/transport.py`, `provider.py` | Fixed/bounded transport, safe failure codes and schema checks | Cancellation/deadline integration, canaries, source drift policy |
| `intelligence/hub.py`, `db.py` | Sanitized normalized results and durable local source runs | Distinct observation versus claim; staged/fenced hosted finalization |
| `cloud_worker.py`, `worker_cli.py` | Four allowlisted passive workflows and non-root boundary | Attempt fence/heartbeat, durable connector steps, atomic effects, budget/outbox |
| `supabase/migrations/` | RLS, grants, audit/hold/AAL2, replay/admission protections | Additive attempt/step/usage/outbox/scope records with real multi-session tests |
| `api/*.py`, `vercel_control.py` | Same-origin controls, HttpOnly cookie and RLS delegation | Workflow API contracts, cancellations, access lifecycle, abuse limits, API schema |
| `public/app.js`, `graph-model.js` | Existing filters, paths, normalization, views | Transform palette, progress, reversible graph operations, scale/accessibility |
| `resolution.py` | Human-reviewed candidates and no automatic merge | Versioned reversible merge/split projection and identity eval |
| `collaboration.py`, `api/views.py`, `api/collaboration.py` | Case state/revision foundations | Real reconnect/revocation/conflict behavior and analyst presence |
| `employee/service.py`, `brief.py`, `skills.py` | Human decision model and procedures | Bounded retrieval, scenario schema, skill evaluations, decision journal |
| `intelligence/ai.py`, `benchmark.py` | Strict output/citation checks | Entailment and contradiction eval, model version/drift monitoring |
| `intelligence/media.py`, `fusion_board.py` | Metadata/integrity signals and cautious fusion | Optional validated OCR/ASR/video/geo signal stack; no identity overclaims |
| `evidence.py`, `report.py` | Hash verification and bundle/report formats | Hosted envelope, signed manifest/anchors, restrictions/retractions |
| `capabilities/`, `integrations/` | Explicit isolated boundaries, archive audit, parser/pin patterns | Selected genuine passive installations and witnessed execution contracts |
| `opencti_connectors.py`, `third_party/opencti-connectors` | Pinned source/checksums, execution disabled default | Optional fixture separation, external service configuration; no automatic mass deployment |
| `operations.py` | SQLite recovery drill | Hosted authoritative state/artifact/key recovery and runbooks |
| `.github/workflows/`, `scripts/` | Test/CodeQL/SBOM/package baseline | Immutable pins, typing/lint/coverage, image/DAST/provenance/signing gates |

## New modules — proposed only

Potential logical modules: `scope`, `workflow_steps`, `usage`, `readiness_proofs`, `outbox`, `evaluations`. Place them only after reviewing existing equivalents. Avoid a duplicate “enterprise engine” parallel to the existing core.

## Integration acceptance

A PR must state current path, changed behavior, schema impact, preserved contract, fixture proof, live/hosted proof required and blocker. Keep legacy/local workflows usable unless a security issue requires explicit deprecation.
