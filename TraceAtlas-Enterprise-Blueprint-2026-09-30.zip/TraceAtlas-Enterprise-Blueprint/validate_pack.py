#!/usr/bin/env python3
"""Read-only integrity/structure validator for this documentation package."""
from pathlib import Path
import hashlib
import json
import re
import sys

root = Path(__file__).resolve().parent
errors = []
required = {
    "README.md", "EXECUTIVE_VERDICT.md", "ENTERPRISE_ASSESSMENT.md",
    "COMPETITOR_COMPARISON.md", "PROBLEM_STATEMENTS.md", "ARCHITECTURE.md",
    "FLOW.md", "DATA_MODEL.md", "CONNECTOR_SDK.md", "SOURCE_STRATEGY.md",
    "GRAPH_UX.md", "AI_EMPLOYEE.md", "AI_MEDIA_EVALUATION.md",
    "SECURITY_PRIVACY.md", "OPERATIONS.md", "INTEGRATION_MAP.md", "REPAIR.md",
    "ACCEPTANCE_GATES.md", "BENCHMARK_PLAN.md", "ROADMAP_AND_RESOURCES.md",
    "RESEARCH_TO_IMPLEMENTATION.md", "CHANGE_CONTROL.md",
    "MASTER_IMPLEMENTATION_PROMPT.md", "PHASE_PROMPTS.md",
    "EVIDENCE_REGISTER.md", "SOURCES.md",
}
for name in sorted(required):
    if not (root / name).is_file():
        errors.append("Missing required file: " + name)
for path in sorted(root.glob("*.md")):
    content = path.read_text(encoding="utf-8")
    if not content.strip():
        errors.append("Empty document: " + path.name)
    for target in re.findall(r"\]\(([^)]+)\)", content):
        if "://" in target or target.startswith("#"):
            continue
        relative = target.split("#", 1)[0]
        if relative and not (path.parent / relative).is_file():
            errors.append("Broken link in " + path.name + ": " + target)
    if content.count("```") % 2:
        errors.append("Unbalanced fence in " + path.name)
problem_text = (root / "PROBLEM_STATEMENTS.md").read_text(encoding="utf-8")
ids = re.findall(r"^\| (P\d{2}) \|", problem_text, re.M)
if ids != [f"P{x:02d}" for x in range(1, 37)]:
    errors.append("Problem IDs must be P01-P36 exactly once and in order")
gate_text = (root / "ACCEPTANCE_GATES.md").read_text(encoding="utf-8")
gates = re.findall(r"^\| (G\d{2}) ", gate_text, re.M)
if gates != [f"G{x:02d}" for x in range(1, 14)]:
    errors.append("Gate IDs must be G01-G13 exactly once and in order")
for pid in ids:
    if pid not in gate_text:
        errors.append("Problem missing gate mapping: " + pid)
for path in (root / "evidence").glob("*.json"):
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        errors.append("Invalid evidence JSON: " + path.name + ": " + str(exc))
sums_path = root / "SHA256SUMS"
if sums_path.is_file():
    listed = set()
    for line in sums_path.read_text().splitlines():
        digest, name = line.split("  ", 1)
        candidate = (root / name).resolve()
        if root not in candidate.parents:
            errors.append("Unsafe checksum path: " + name)
            continue
        listed.add(name)
        if not candidate.is_file() or hashlib.sha256(candidate.read_bytes()).hexdigest() != digest:
            errors.append("Checksum mismatch: " + name)
    actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()
              and p.name != "SHA256SUMS" and "__pycache__" not in p.parts}
    if listed != actual:
        errors.append("Checksum manifest does not cover exactly the package")
else:
    errors.append("SHA256SUMS missing")
report = {"status": "fail" if errors else "pass", "markdown_documents": len(required),
          "problem_statements": len(ids), "acceptance_gates": len(gates),
          "errors": errors}
print(json.dumps(report, indent=2))
sys.exit(1 if errors else 0)
