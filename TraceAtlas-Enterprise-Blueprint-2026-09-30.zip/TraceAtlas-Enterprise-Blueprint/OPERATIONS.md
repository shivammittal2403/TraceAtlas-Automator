# Production operations and recovery

Status: required target operating model. No real production SLO is asserted by this package.

## Service objectives for initial pilot

Targets to qualify and then contract: control API 99.5% monthly availability; p95 ordinary authenticated control request <750 ms excluding external provider time; queue wait p95 <60 s at declared workload; source-specific freshness/latency targets; 100% outcome/audit classification coverage.

Vendor/API downtime should not disappear from reports. Separate control-plane availability, connector success, data freshness and investigation completion.

## Telemetry

Trace IDs: request, tenant pseudonymous ID, case/job/step/attempt, source/action/version, workflow hash, build/schema version. Avoid raw target values, credentials and full evidence in general logs.

Metrics: queue age/depth, claim/finalization latency, stale attempts, outbox lag, retry/dead-letter count, budget reservations/uncertain settlement, source status and schema drift, bytes/records, cancellations, denied operations, AI abstention/grounding failures, storage growth, restoration success.

## Alert contracts

| Condition | Owner / immediate action |
|---|---|
| Unauthorized access or suspected cross-tenant leak | SEC: isolate affected path, preserve audit, rotate/revoke scoped credentials, incident process |
| Stale attempts accepted or duplicate case effects | ENG/SRE: stop new affected workflows, fix fence/finalization, reconcile effects |
| Source repeatedly fails/auth expires/schema changes | DATA: mark degraded, stop blind retry, renew entitlement or update contract |
| Queue/outbox age breaches objective | SRE: inspect worker lease/capacity, recover safely, avoid uncontrolled duplicate calls |
| Budget/uncertain charge mismatch | DATA/finance: stop expansion, reconcile provider usage; no silent repeated purchase |
| Backup absent or restore failed | SRE: block promotion, repair/redo isolated restore |
| AI grounding regression | PM/SEC: switch off affected model feature; deterministic evidence summaries remain |

## Recovery

Proposed pilot targets: RPO ≤15 min, RTO ≤4 h for authoritative case state. These require a backup/PITR plan and measured drills; not all service plans provide the same retention/recovery options.

Back up database, private artifacts, schema/configuration, signing/key recovery references and permitted model/workflow versions. Restore in isolated staging with no live outbound collection. Verify hashes, tenant policies, signed exports, retention/hold state, job/outbox reconciliation and revoked memberships.

Do not restart restored queued jobs automatically: their authority, budget and prior billable calls may be stale or already executed.

## Deployment and rollback

Pin artifact digest/build SHA; run migration compatibility checks; provision preview/staging explicitly; execute smoke, tenant, worker and restore gates; promote only with existing authorization. Revert application using compatible schema; do not destructively roll back case data.

The assessment requested no deployment. This document is not deployment authority.

## Runbook minimum

Provider outage, credential expiry, schema drift, worker crash, lease recovery, object orphan reconciliation, outbox retry, session revocation, data deletion/hold, abuse burst, model regression, compromised dependency and restore/PITR.

Each runbook needs trigger, evidence to preserve, accountable owner, safe actions, customer impact, recovery checks and escalation.
