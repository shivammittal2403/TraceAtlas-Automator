# Security, privacy and assurance contract

This is an engineering/control plan, not legal advice or a claim of DPDP/GDPR/ISO/SOC compliance. Applicable obligations and collection permissions require qualified review for the actual organization, jurisdiction, data and intended use.

## Current positive controls

Same-origin mutation checks; HttpOnly/Secure/SameSite session cookie; tenant RLS migrations; narrow worker RPC/table allowlists; non-root worker definition; explicit authorization/owned/consent gates; personal-data reduction; audit immutability; retention/hold foundation; AAL2 administrative controls; secret scanner/CodeQL definitions.

No exploitable credential leak was confirmed in this bounded review. No successful tenant-bypass exploit was run. Missing hosted proof is a release risk, not evidence that RLS is universally broken.

## Trust boundaries and threats

| Boundary | Threat | Required mitigation / test |
|---|---|---|
| Browser → API | CSRF, replay, unauthorized case/role, malformed payload | Verified session, same-origin/CSRF strategy, object auth, bounds, idempotency |
| API → Data API | BOLA, stale membership, insecure views/definer RPCs | Grants plus RLS, permission matrix, fixed search paths, explicit execution grants |
| Worker → DB | Privileged cross-tenant effects, stale lease writes | Scoped gateway, tenant/case FK checks, fence-bound finalization |
| Worker → providers | SSRF, redirects/DNS rebinding, oversize response, credential leakage | Fixed action templates, controlled egress/DNS/redirect policy, resource bounds, secret-safe errors |
| Storage → users | Guessable keys, broad signed URL, stale URL after revocation | Private buckets, tenant/case policy, short bounded URL TTL, permission recheck and deletion |
| Realtime → users | Cross-tenant channels, stale subscription after revocation | Scoped auth/topic policy, revocation/reconnect tests |
| Evidence → AI | Indirect prompt injection, invented attribution, unauthorized retrieval | Data-only context, deterministic tool policy, citation/entailment checks, tenant-filtered retrieval |
| Dependencies → runtime | Compromised package/tool/container, unlicensed use | Pins, SBOM/advisories/provenance, isolation, license review, signed releases |

## Hosted authorization qualification

Two organizations with overlapping entity labels and different cases. Roles: anonymous, member, analyst, reviewer, case-restricted member, admin, owner, removed member and worker.

For every route/table/RPC/view/bucket/channel/export test read/create/update/delete/subscribe. Include direct requests outside the UI, forged client tenant/case IDs, child-object parent mismatch, expired/revoked sessions, case archive/closure, downgrade and last-owner changes.

Supabase secret/service-role access bypasses ordinary RLS; keep it worker-only and reduce the permitted gateway to explicit actions. Do not interpret a worker test as a user authorization test [S10].

## Identity lifecycle

Enterprise federation and SCIM when required by the customer; group/role mapping, step-up for sensitive operations, break-glass access with alerts, offboarding/session revocation and tenant/case access removal. Do not use editable profile metadata for authorization.

## Data governance

Every case has purpose, authority, data-class, retention and disclosure policy. Every source has permitted fields/use/export and approval expiry. Collect minimum useful data; store reusable credentials, private residential/contact identifiers and sensitive biometric data neither by accident nor as “more features.”

Use redaction manifests and labeled withheld fields. When raw content cannot lawfully be retained, preserve permitted response metadata/hash and say replay is limited. Do not falsely advertise full evidential reproducibility.

Propagate delete/expiry/retraction to artifacts, graph/search/vector projections, caches and exported shares when technically controllable. Holds require approved reason/access and release lifecycle.

## Secrets

Tenant-scoped encrypted secret references, least-privilege provider users, expiry/rotation/revocation tests and redacted telemetry. No secret values in prompts, client bundles, fixture archives, manifests or reports. Customer key requirements need a real KMS lifecycle, not an environment-variable rename.

## Release assurance

Safe staged DAST and independent penetration test; critical/high findings fixed or formally risk-accepted with bounded compensating controls; dependency/image/IaC review, immutable action pins and artifact signing/provenance. Document vuln disclosure and remediation SLAs.

No scan alone qualifies the product as secure. Re-test after relevant schema/auth/storage/tool changes.
