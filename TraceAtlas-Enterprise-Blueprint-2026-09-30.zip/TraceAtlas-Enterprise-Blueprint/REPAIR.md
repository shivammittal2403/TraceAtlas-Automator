# Repair program — dependency-ordered delivery

This is an implementation plan, not a completion claim. Calendar windows below are indicative team-planning estimates; entitlement/procurement/production authority can dominate elapsed time.

## Phase 0 — truthful baseline, week 1–2

P36, P01, P02, P08, P09.

- Refresh main, preserve worktree, inventory versions/status and current source action coverage.
- Fix single-source build version consistency.
- Separate optional OpenCTI source tests from core unit tests; preserve pinned integration integrity checks.
- Replace hosted-ready labels driven by files/env syntax with configuration-ready and NOT_VERIFIED states.
- Add expiring evidence-backed proof records and capability-state dashboard.
- Select W01–W03, accepted targets, metrics and exclusions.

Exit: G01 and relevant G12 unit checks. No market score upgrade simply for changing documentation.

## Phase 1 — durable execution, week 2–6

P03, P04, P11, P28.

- Versioned scope/workflow contract, durable steps, budget reservations.
- Attempt fence/lease heartbeat; bounded transactional finalization and outbox.
- Cancellation/deadline propagation and partial/failure semantics.
- Object staging/orphan reconciliation with legal-hold protection.
- Two-session database races and failpoint suite, including ambiguous paid-provider response.

Exit: G02 and local G08. No live sources are mass-enabled.

## Phase 2 — genuinely operational sources, week 4–10

P05, P12–P17, P25.

- Activate five Wave A actions on approved canaries; 30-day observation begins.
- Activate selected Wave B only after license/entitlement approvals.
- Introduce source freshness/schema/quota health, canary evidence and degraded states.
- Build one complete social/corporate export/API workflow, not 50 profile badges.
- CTI metadata feed/retraction lifecycle without reusable leaked secrets.

Exit: G03 and first accepted G07 workflows. Missing access rights remain blockers; no fabricated scrape fallback.

## Phase 3 — investigator product, week 6–14

P10, P18–P21, P32, P33.

- Transform palette, dry-run scope/cost preview, progress/cancel, evidence inspector.
- Typed graph claims, reversible merge/split, contradiction timeline.
- Private artifact/evidence envelope/signing and standards export.
- Multi-user case roles, conflict/reconnect/revocation behavior.
- Load-qualified paginated graph; published API schema.

Exit: G06/G09 and hosted collaboration qualification. Do not ship irreversible automatic identity merges.

## Phase 4 — reliable intelligence assistance, week 10–18

P22–P24, P34.

- Held-out claim-evidence evaluation and independent adjudication.
- AI scenario/decision journal, permission-scoped retrieval and injection tests.
- Optional licensed media analyzers with frame/span provenance and measured limits.
- Replicate three relevant research methods; integrate only methods with demonstrated holdout value.

Exit: G10/G11. Experimental model features remain off if evaluators fail.

## Phase 5 — enterprise qualification, week 12–24+

P06, P07, P26–P31, P35.

- Hosted tenant/JWT/Storage/Realtime negative tests.
- SSO/SCIM/offboarding where required, vault/rotation and customer operating controls.
- Hosted backup/PITR/object/key restore, incident drill, source/SLO dashboards.
- Load/chaos/DAST/supply-chain signing and independent security assessment.
- 10-analyst matched pilot, followed by 30-day operational observation.

Exit: G04/G05/G08/G12/G13. Contractual enterprise claims require observed operation, not this calendar.

## First implementation PRs

| PR | Scope | Acceptance | Needs external access? |
|---|---|---|---|
| R01 | Build identity + truthful readiness + optional-source unit fixtures | G01; regressions; no static hosted-proof escalation | No |
| R02 | Attempt/fence + staged atomic finalization/outbox | G02 failpoints and multi-session test DB | Isolated test DB/runtime |
| R03 | Step state + deadline/cancellation + usage reservations | Duplicate/uncertain retry and cancellation tests | Fixtures initially |
| R04 | Five-source live conformance harness/dashboard | G03 with authorized canaries | Approved targets/providers |
| R05 | Hosted tenant/storage/realtime + restore qualification | G04/G05 | Explicit staging authority |
| R06 | Transform workspace + reversible resolution | G06/G09 | Analyst cohort and staging |
| R07 | Grounding/media evaluation + skill manifests | G10/G11 | Licensed/consented datasets/models |
| R08 | Identity lifecycle/release/operations + pilot | G08/G12/G13 | Operator/IdP/customer access |

## Closure record

Problem ID, PR/build SHA, exact changed paths, migration compatibility, test artifacts/hashes, live/hosted proof/date/expiry, reviewer, outstanding risk and rollback. Missing proof means PARTIAL or BLOCKED, not COMPLETE.

## Stop rules

Stop unsafe or unauthorized collection. Pause external mutation when permission is absent. Disable only the affected feature for a quality/security regression; preserve evidence and working legacy paths. Do not patch tests to accept broken behavior or raise the score without new evidence.
