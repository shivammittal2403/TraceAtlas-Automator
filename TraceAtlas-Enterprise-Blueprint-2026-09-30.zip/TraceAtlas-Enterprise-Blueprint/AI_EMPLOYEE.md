# AI Employee — an analyst assistant, not an omniscient employee

Existing 28 skills are analyst procedures. Keep them, but stop treating the label “skill” as evidence that the model has performed the task competently.

## Role contract

The assistant provides evidence-backed scenarios, uncertainty, next discriminating questions and decision briefs. The human owns attribution, interpretation, operational decisions and external action.

## Skill manifest

Each skill needs ID/version, question class, scope/data classes, required evidence, allowed tool actions, output schema, abstention rules, evaluation dataset/version, metrics, known failure modes and maintenance owner.

Research retrieval is methodology context, not case-specific evidence. Do not claim the assistant “knows 4,096 papers” merely because metadata search returns them.

## Output schema

- Question and evidence snapshot.
- Verified observations: precise source statements with evidence IDs and time.
- Analytical hypotheses: supporting/opposing evidence, assumptions and alternatives.
- Unknowns: coverage gaps, conflicting dates, missing entitlement or factual basis.
- Recommended next checks: bounded, policy-valid, costed actions.
- Decision options: consequences and uncertainties, not an autonomous verdict.
- Human decision: separate record, author/time/rationale.

“Confidence” must have defined semantics; avoid invented numeric certainty. Prefer calibrated bands or explicitly uncalibrated analytical confidence when no statistical model exists.

## Authority and tool use

The deterministic coordinator enforces tenant/case access, input typing, source allowlists, budget, scope, approvals and deadlines. The model receives no provider secret, service-role key or arbitrary shell.

Tool proposal is not tool permission. Retrieved webpages, archives, documents and reports are untrusted data even if they contain instructions addressed to an AI.

## Retrieval

Query authorization filters first, retrieve only allowed case artifacts, preserve provenance and evidence versions, limit context and log references rather than raw sensitive content. Tenant caches and embeddings are permission-scoped; revocation/retention propagates to derived indexes.

## Evaluation

Evaluate each supported skill on held-out cases: citation correctness, entailment, contradiction handling, uncertainty, namesake rejection, scope violations and useful next checks. Add adversarial documents, malicious tool descriptions and cross-tenant decoys.

A factual statement with an existing but irrelevant citation must fail. A graceful “insufficient evidence” must count as correct when appropriate.

## Example safe scenario

An owned domain appears in a licensed threat feed. The assistant presents: benign shared hosting, stale/retracted record, or attributable exposure. It cites what supports each, identifies the missing date/ownership link, and proposes an approved technical check. It does not call the organization compromised solely because a provider labels an IP malicious.

## Do not build

No autonomous accusation, “criminal person” scoring, private-person tracking, unlimited self-learning collection, purchased/stolen credential testing or automatic exploitation. Product usefulness comes from disciplined evidence, not unbounded agency.
