# Connector SDK and graduation contract

Status: target specification. Preserve existing `intelligence/contracts.py`, `provider.py`, `transport.py` and source sanitization rather than building an uncontrolled second request stack.

## Capability states

Discovery → identity confirmed → terms reviewed → contract implemented → fixture verified → entitled/configured → live canary verified → operated → retired.

Export-only, design-only and blocked are separate states, not lower scores to be silently promoted. A source can be fixture-verified but not live-verified. A connector version/schema/entitlement change expires the corresponding proof.

## Required contract

| Section | Fields |
|---|---|
| Identity | source ID, official owner/URL/docs, connector version, license, maintenance owner |
| Action | exact action, typed inputs and outputs, unsupported inputs, known coverage and limitations |
| Authority | allowed purpose, target class, scope/consent requirement, jurisdiction/entitlement review reference |
| Authentication | secret reference names only, tenant/provider credential scope, rotation/expiry rules |
| Transport | fixed hosts, methods/path templates, redirect/DNS policy, deadline/bytes/pages/records/concurrency bounds |
| Cost | quota units, estimation method, upper bound, provider billable retry semantics, uncertainty handling |
| Normalization | stable source IDs, source timestamps, permitted fields, schema validator and sanitizer version |
| Evidence | permitted artifact policy, transformations, response/artifact hashes, source-run and job/attempt IDs |
| Operations | canary target, health/SLO, rate-limit behavior, schema-drift strategy, deprecation owner |
| Failure | stable secret-safe codes, retryability, partial/no-result semantics, circuit-breaker behavior |

## Result envelope example

```json
{
  "schema": "traceatlas.connector-result/v2",
  "source": "example-approved-source",
  "connector_version": "2.0.0",
  "action": "public_asset_metadata",
  "tenant_id": "<server-bound>",
  "case_id": "<server-bound>",
  "job_id": "<job>",
  "step_id": "<step>",
  "attempt_fence": 2,
  "scope_version": "<approved-scope-hash>",
  "input_fingerprint": "<tenant-scoped-fingerprint>",
  "status": "completed",
  "records": [],
  "coverage": {"complete_for_action": false, "limitations": ["provider-plan-limited"]},
  "artifact_refs": [],
  "cost": {"state": "settled", "units": 1, "amount": null},
  "failure": null,
  "collected_at": "<UTC>",
  "source_time_basis": "unknown"
}
```

This example is a proposed contract, not an existing repository API. Tenant IDs are server-bound and cannot be selected by connector output.

## Failure semantics

Supported codes: `not_configured`, `scope_denied`, `entitlement_expired`, `quota_exhausted`, `rate_limited`, `deadline_exceeded`, `cancelled`, `schema_mismatch`, `record_not_found`, `network_unavailable`, `partial_result`, `unsafe_response`, `stale_attempt`.

Auth rejection does not trigger anonymous fallback. Schema mismatch does not become an empty successful collection. Retry scheduling respects provider Retry-After, overall deadline and budget; never repeat a potentially billable request blindly after an ambiguous response.

## Contract test suite per connector

Happy path, real empty result, missing/invalid credential, 401/403, 404/action-specific not found, 429, transient 5xx, timeout, byte/page overflow, invalid encoding, schema drift, malicious embedded instructions, redaction, unsupported scope, SSRF/private target, cancellation and restart.

Live canary is separately approved and must use owned assets, public organizational data or explicitly consented subjects. Store no reusable secrets in fixtures or logs. A captured permitted response can become a sanitized regression fixture.

## Installation and sandboxing

Pin executable version/container digest and parser contract. No shell interpolation; argv allowlist only. Non-root runtime, constrained egress/filesystem/resources, no host credentials or shared browser cookies. Browser-based collection remains disabled until an isolated-session and approved-site contract exists. Do not bypass sign-in walls, CAPTCHA, paywalls or provider restrictions.

## “Working” dashboard

Display catalogued, implemented, fixture-verified, entitlement-ready, recently live-verified, degraded and retired counts separately. Show last successful run/date/version, coverage, cost and errors. Never label an external launcher URL as a native integration.
