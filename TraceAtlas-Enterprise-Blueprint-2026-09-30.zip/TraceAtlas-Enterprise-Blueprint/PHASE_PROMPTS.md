# Focused phase prompts

Use the master prompt's authority/truth/safety rules with each prompt. Do not attempt every phase as one giant unreviewable commit.

## Phase 0: truthful readiness and baseline

Inspect current main and implement P01/P02/P08/P09/P36. Preserve existing user work. Create one build identity, correct frontend/API/worker version mismatch, split static configuration checks from expiring observed proof, and ensure offline core tests use minimal optional-vendor fixtures. Existing full source integrity tests stay separately explicit. Tests must show unreachable-but-configured deployments remain NOT_VERIFIED and static strings cannot produce hosted/competitive status. Deliver baseline manifest, changed paths, regression artifacts, G01 status and external blockers. No push/deploy unless explicitly authorized.

## Phase 1: durable execution

Read cloud_worker.py, existing job/RPC migrations and replay/admission tests. Implement current attempt fence/lease heartbeat, durable connector steps, total deadlines/cancellation, atomic bounded finalization and outbox, plus usage reservation/settlement/uncertainty. Stage artifacts safely and reconcile orphans. Preserve existing allowlists/RLS. Add two-session races and failpoint tests before rating G02. No old attempt may write canonical case effects or complete a new attempt. Do not promise exactly-once external billing.

## Phase 2: five real sources

Select the five Wave A actions against documented approved targets. Verify current official endpoint/terms/plan limitations. Add contract fixtures and approved live canary harness that records source/action/version/date/hash/coverage/errors/cost. Missing access marks BLOCKED; no scrape fallback. Show implemented versus recently live-verified versus operated counts separately. No provider keys in logs/client/evidence. Deliver G03/G07 matrix and observation plan, not a universal source count.

## Phase 3: investigator graph workflow

Implement transform/action palette, typed applicability, scope/cost preview, step progress/cancel, evidence/source-time inspector, conflict/contradiction timeline, reversible merge/split and collaborative revision/reconnect behavior. Benchmark existing renderer before selecting replacement. Preserve import/export formats. Use synthetic fixtures plus approved analyst acceptance. Deliver G06/G09 results, 10k graph workload metrics and 100k bounded-query limits.

## Phase 4: AI and media quality

Keep current strict schema/citation tests. Add ≥200 independent held-out claim-evidence pairs and ≥100 synthetic injection cases, permission-scoped retrieval and abstention. Produce supporting/opposing scenarios and human decision journal. Media must cite page/region/frame/span and state measured error/limitations. No biometric identity/private-person location/autonomous accusation. Deliver dataset hashes, reviewers, model/prompt versions, metrics and G10/G11 status. Failing models remain experimental.

## Phase 5: enterprise operating proof

On explicitly authorized staging, qualify real JWT/Data API/Storage/Realtime tenant isolation, role/offboarding/SSO/SCIM lifecycle, secret rotation, backup/PITR/artifact/key restore, queue/outbox/cancellation/load drills, observability and signed release provenance. Run approved safe DAST and independent security review. Deliver G04/G05/G08/G12 and measured RPO/RTO/SLO window. Static env checks cannot pass hosted gates.

## Phase 6: competitor outcome trial

Run BENCHMARK_PLAN.md with approved targets, real vendor entitlements, counterbalanced analyst order and blinded adjudication. Report task-time, evidence quality, false links, cost and failures with confidence intervals. Claim superiority only for the named tasks where it was measured. If vendor access/analyst cohort is missing, deliver runnable harness and mark G13 BLOCKED. Do not assign invented competitor scores.
