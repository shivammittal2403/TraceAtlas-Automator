import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
os.chdir(BASE_DIR)
sys.path.insert(0, str(BASE_DIR))

from modules.config import validate_config
from modules.feed_loader import load_feeds_from_files
from modules.feed_fetcher import fetch_articles
from modules.deduplicator import deduplicate_articles
from modules.language_tools import detect_language
from modules.article_scraper import process_urls_in_parallel
from modules.hybrid_classifier import classify_article
from modules.logger_utils import setup_logger, log_article_summary
from modules.run_stats import RunStats
from modules.output_writer import (
    write_hourly_output,
    write_daily_output,
    write_rss_output,
)
from app.dashboard import build_dashboard
from modules.cost_tracker import get_today_spend, get_total_spend
from modules.darkweb_monitor import fetch_darkweb_intel
from modules.feed_health import log_health_summary
from modules.webhook import dispatch as webhook_dispatch
from modules.watchlist_monitor import tag_articles_with_vendors, run_watchlist_monitor
from modules.newsapi_fetcher import fetch_newsapi_articles
from modules.region_inferrer import infer_articles_regions
from modules.nvd_fetcher import fetch_nvd_cves
from modules.epss_enricher import enrich_articles_with_epss
from modules.kev_enricher import enrich_articles_with_kev
from modules.attack_tagger import tag_articles_with_attack
from modules.trend_detector import update_trends


def enrich_articles(articles, summarize=False, stats=None):
    url_list = [a["link"] for a in articles]
    url_to_content = process_urls_in_parallel(url_list)

    if stats:
        stats.scrape_successes = sum(1 for v in url_to_content.values() if v)
        stats.scrape_failures = sum(1 for v in url_to_content.values() if not v)

    enriched = []
    ingested_at = datetime.now(timezone.utc).isoformat()
    for article in articles:
        original_url = article["link"]
        full_content = url_to_content.get(original_url)

        lang = detect_language(article["title"])

        # Skip classification for pre-classified articles (e.g., NVD CVEs)
        pre_classified = article.get("is_cyber_attack") is not None and article.get("confidence", 0) > 0
        if pre_classified:
            result = {
                "is_cyber_attack": article["is_cyber_attack"],
                "category": article.get("category", "General Cyber Threat"),
                "confidence": article.get("confidence", 0),
                "translated_title": article.get("translated_title", article["title"]),
                "summary": article.get("summary", ""),
            }
        else:
            result = classify_article(
                title=article["title"],
                content=full_content if summarize else None,
                source_language=lang,
            )

        if stats:
            if result.get("_cached"):
                stats.cache_hits += 1
            else:
                stats.cache_misses += 1
            if result.get("_ai_enhanced"):
                stats.ai_escalations = getattr(stats, "ai_escalations", 0) + 1

        enriched_article = {
            **article,
            "translated_title": result.get("translated_title", article["title"]),
            "language": lang,
            "is_cyber_attack": result.get("is_cyber_attack", False),
            "category": result.get("category", "Unknown"),
            "confidence": result.get("confidence", 0),
            "full_content": full_content,
            "summary": result.get("summary", ""),
            # ingested_at is when THIS pipeline first processed the article —
            # never a substitute for `published` (the event's own date).
            # `timestamp` is a deprecated alias kept for API back-compat;
            # nothing may sort or compute freshness from it.
            "ingested_at": ingested_at,
            "timestamp": ingested_at,
        }

        if enriched_article["is_cyber_attack"]:
            if summarize and enriched_article["summary"]:
                log_article_summary(original_url, enriched_article["summary"])
            enriched.append(enriched_article)
            if stats:
                stats.cyber_articles += 1
        else:
            if stats:
                stats.non_cyber_articles += 1

    return enriched


def main():
    setup_logger()
    validate_config()
    # Install SSRF guard at process start so every outbound fetch (feed
    # fetchers, article scraper, url resolver, NVD/EPSS enrichers) can't be
    # tricked into hitting localhost / cloud IMDS via DNS rebinding.
    from modules.safe_http import install_ssrf_guard
    install_ssrf_guard()
    # Reset the LLM circuit breaker for this run — it's process-local state
    # that persists across calls within a run but should start clean at the
    # top of each run.
    from modules.llm_client import reset_circuit
    reset_circuit()
    logging.info("==== Starting ThreatDigest Main Run ====")

    stats = RunStats()

    feed_paths = [
        str(BASE_DIR / "config" / "feeds_bing.yaml"),
        str(BASE_DIR / "config" / "feeds_google.yaml"),
        str(BASE_DIR / "config" / "feeds_native.yaml"),
    ]
    all_feeds = load_feeds_from_files(feed_paths)
    stats.feeds_loaded = len(all_feeds)
    if not all_feeds:
        logging.warning("No feeds found. Exiting.")
        stats.finalize()
        return

    raw_articles = fetch_articles(all_feeds)
    # Drop health entries for feeds removed from config — leftovers otherwise
    # inflate the dead/error counts /api/health reports forever.
    try:
        from modules.feed_health import prune_unconfigured
        prune_unconfigured([f["url"] for f in all_feeds])
    except Exception as e:
        logging.debug(f"Feed-health prune skipped: {e}")
    log_health_summary()

    # Operator alert when sources are dying. Silent feed failure is the worst
    # failure mode for a threat-intel product — coverage shrinks while the
    # dashboard keeps looking normal. Cooldown-deduped inside dispatch.
    try:
        from modules.feed_health import get_health_json
        from modules.telegram import dispatch_ops_alert
        fh = get_health_json()
        broken = fh.get("dead", 0) + fh.get("silent", 0)
        threshold = int(os.getenv("FEED_ALERT_THRESHOLD", "5"))
        if broken >= threshold:
            dead_urls = ", ".join(
                d.get("url", "?")[:60] for d in fh.get("dead_feeds", [])[:5]
            )
            dispatch_ops_alert(
                key="feeds_degraded",
                subject=f"{broken} feeds dead or silent (threshold {threshold})",
                detail=f"Dead: {dead_urls}" if dead_urls else "See /api/health for the list.",
            )
    except Exception as e:
        logging.debug(f"Feed ops alert skipped: {e}")

    # Dark web monitoring (zero cost — clearnet aggregators)
    try:
        darkweb_articles = fetch_darkweb_intel()
        if darkweb_articles:
            raw_articles.extend(darkweb_articles)
            logging.info(f"Dark web: added {len(darkweb_articles)} items")
    except Exception as e:
        logging.warning(f"Dark web monitoring failed: {e}")

    # NewsAPI — structured security news (rate-limited: at most once per 30 min)
    try:
        newsapi_articles = fetch_newsapi_articles()
        if newsapi_articles:
            raw_articles.extend(newsapi_articles)
            logging.info(f"NewsAPI: added {len(newsapi_articles)} articles")
    except Exception as e:
        logging.warning(f"NewsAPI fetch failed: {e}")

    # NVD CVE monitoring (zero cost — public API)
    try:
        nvd_articles = fetch_nvd_cves()
        if nvd_articles:
            raw_articles.extend(nvd_articles)
            logging.info(f"NVD: added {len(nvd_articles)} high/critical CVEs")
    except Exception as e:
        logging.warning(f"NVD CVE fetch failed: {e}")

    # Watchlist monitor — custom brand/asset keywords (self-hosted only)
    try:
        watchlist_articles = run_watchlist_monitor()
        if watchlist_articles:
            raw_articles.extend(watchlist_articles)
            logging.info(f"Watchlist: added {len(watchlist_articles)} custom keyword articles")
    except Exception as e:
        logging.warning(f"Watchlist monitor failed: {e}")

    stats.articles_fetched = len(raw_articles)
    if not raw_articles:
        logging.warning("No articles fetched.")
        stats.finalize()
        return

    unique_articles = deduplicate_articles(raw_articles)
    stats.articles_after_dedup = len(unique_articles)
    stats.news_reviewed = len(raw_articles)
    if not unique_articles:
        logging.info("No new articles after deduplication.")
        stats.finalize()
        return

    enriched_articles = enrich_articles(unique_articles, summarize=True, stats=stats)
    # Tag every article with matching suggest-list vendors (fast regex pass)
    enriched_articles = tag_articles_with_vendors(enriched_articles)
    # Refine region assignments using content-based inference
    enriched_articles = infer_articles_regions(enriched_articles)

    # EPSS exploit prediction scores for CVE-containing articles
    try:
        enriched_articles = enrich_articles_with_epss(enriched_articles)
    except Exception as e:
        logging.warning(f"EPSS enrichment failed: {e}")

    # CISA KEV — flag CVEs confirmed exploited in the wild. Authoritative
    # "act now" signal; complements EPSS (probability) with verified fact.
    try:
        enriched_articles = enrich_articles_with_kev(enriched_articles)
    except Exception as e:
        logging.warning(f"KEV enrichment failed: {e}")

    # CVE exploitation narratives (LLM-generated, cached by CVE ID).
    # Only fires for CVSS>=8.0 or EPSS>=80th percentile; cache makes
    # subsequent runs free for the same CVE. caller="cve_narrative".
    try:
        from modules.cve_narrative import enrich_articles_with_cve_narratives
        enriched_articles = enrich_articles_with_cve_narratives(enriched_articles)
    except Exception as e:
        logging.warning(f"CVE narrative enrichment failed: {e}")

    # MITRE ATT&CK technique tagging
    try:
        enriched_articles = tag_articles_with_attack(enriched_articles)
    except Exception as e:
        logging.warning(f"ATT&CK tagging failed: {e}")

    # CVE ID extraction — surfaces `cve_ids` on each article so the dashboard
    # can facet by CVE. Runs before write so values are persisted.
    try:
        from modules.incident_correlator import annotate_articles_with_cves
        cve_hits = annotate_articles_with_cves(enriched_articles)
        logging.info(f"CVE annotation: {cve_hits}/{len(enriched_articles)} articles tagged with CVE IDs")
    except Exception as e:
        logging.warning(f"CVE annotation failed: {e}")

    # Deep TTP extraction over full article bodies. Gated on
    # is_cyber_attack + body length; cache-first so re-runs cost
    # nothing. caller="ttp_extract".
    try:
        from modules.ttp_extractor import enrich_articles_with_ttps
        enrich_articles_with_ttps(enriched_articles)
    except Exception as e:
        logging.warning(f"TTP extraction failed: {e}")

    # IOC extraction — pulls IPs, domains, hashes, URLs, emails out of article
    # body text so the dashboard and /api/iocs can surface indicators. Runs
    # before write so values are persisted.
    try:
        from modules.ioc_extractor import annotate_articles_with_iocs
        ioc_hits = annotate_articles_with_iocs(enriched_articles)
        logging.info(f"IOC annotation: {ioc_hits}/{len(enriched_articles)} articles tagged with indicators")
    except Exception as e:
        logging.warning(f"IOC annotation failed: {e}")

    # Victim-sector tagging — labels each article with the SECTOR of the
    # victim (Healthcare, Finance, Government, OT, ...). `feed_region` is
    # source geography; `victim_sectors` is who got hit. Runs before write.
    try:
        from modules.victim_tagger import annotate_articles_with_sectors
        sector_hits = annotate_articles_with_sectors(enriched_articles)
        logging.info(f"Sector annotation: {sector_hits}/{len(enriched_articles)} articles tagged with victim sectors")
    except Exception as e:
        logging.warning(f"Sector annotation failed: {e}")

    # Trend detection — update keyword/category frequency tracking
    try:
        update_trends(enriched_articles)
    except Exception as e:
        logging.warning(f"Trend detection failed: {e}")

    stats.articles_enriched = len(enriched_articles)
    if not enriched_articles:
        logging.info("No cyberattack-related articles after enrichment.")
        stats.finalize()
        return

    write_hourly_output(enriched_articles)
    write_daily_output(enriched_articles)
    write_rss_output(enriched_articles)

    # Webhook alerts (optional — only runs if WEBHOOK_URL is configured)
    try:
        webhook_dispatch(enriched_articles)
    except Exception as e:
        logging.debug(f"Webhook dispatch skipped: {e}")

    # Load full corpus for AI features (not just new batch)
    from modules.output_writer import load_existing, STATIC_DAILY
    all_articles = load_existing(STATIC_DAILY)
    if not all_articles:
        all_articles = enriched_articles

    # Telegram KEV alerts (optional — only runs if TELEGRAM_BOT_TOKEN +
    # TELEGRAM_CHAT_ID are configured). Dispatch against the FULL corpus, not
    # just the new fetch batch: most KEV-tagged articles are older items
    # (CVE coverage in news takes hours/days to surface, and CISA can add a
    # CVE to KEV after the article was first enriched). Re-applying the KEV
    # enricher catches both. Per-CVE permanent dedup so the same KEV entry
    # never re-alerts; per-batch cap of 5 prevents flooding on backfill.
    # NOTE: enrich_articles_with_kev is imported at module top. Re-importing
    # it here made it function-local and broke the batch KEV enrichment above
    # with UnboundLocalError on every run (silently caught as "KEV enrichment
    # failed").
    try:
        from modules.telegram import dispatch_telegram_kev_alerts
        dispatch_telegram_kev_alerts(enrich_articles_with_kev(all_articles))
    except Exception as e:
        logging.debug(f"Telegram KEV dispatch skipped: {e}")

    # AI enrichment (optional — only runs if LLM API key is set).
    # When AI_ENRICHMENT_INLINE=0 the scheduler runs AI features on a
    # separate cadence (scripts/run_ai_enrichment.py) so Groq rate limits
    # and load-shed events don't block feed fetching.
    if os.getenv("AI_ENRICHMENT_INLINE", "1") == "1":
        try:
            from modules.ai_enrichment import run_ai_enrichment
            run_ai_enrichment(all_articles, new_batch=enriched_articles)
        except Exception as e:
            logging.warning(f"AI enrichment skipped: {e}")
    else:
        logging.info("AI enrichment skipped in pipeline (AI_ENRICHMENT_INLINE=0) — runs out-of-band")

    # Briefing staleness check — runs regardless of AI enrichment success/failure.
    # Self-healing flag surfaces on /api/health. Double-wrapped so a bug here
    # can never crash the pipeline run.
    try:
        from modules.briefing_health import (
            check_briefing_freshness, write_stale_flag, clear_stale_flag,
        )
        max_age = float(os.getenv("BRIEFING_STALE_HOURS", "3"))
        freshness = check_briefing_freshness(max_age_hours=max_age)
        if freshness["stale"]:
            logging.error(
                f"Briefing is stale: age={freshness['age_hours']:.1f}h, "
                f"reason={freshness['reason']}"
            )
            write_stale_flag(freshness)
            # Surface to the operator — a stale briefing previously only
            # showed up in logs while the dashboard kept serving old analysis.
            try:
                from modules.telegram import dispatch_ops_alert
                dispatch_ops_alert(
                    key="briefing_stale",
                    subject=f"Intelligence briefing stale ({freshness['age_hours']:.1f}h old)",
                    detail=str(freshness.get("reason", "unknown reason")),
                )
            except Exception as alert_exc:
                logging.debug(f"Briefing ops alert skipped: {alert_exc}")
        else:
            clear_stale_flag()
    except Exception as e:
        logging.debug(f"Briefing staleness check skipped: {e}")

    # Incident clustering + actor profiles on FULL corpus
    try:
        if all_articles:
            from modules.incident_correlator import cluster_articles
            cluster_articles(all_articles)

            from modules.actor_profiler import generate_profiles
            generate_profiles(all_articles)
    except Exception as e:
        logging.warning(f"Clustering/profiling failed: {e}")

    stats.finalize()

    try:
        build_dashboard()
    except Exception as e:
        logging.warning(f"Dashboard generation failed: {e}")

    logging.info(
        f"==== ThreatDigest Run Complete - {len(enriched_articles)} articles | "
        f"API cost today: ${get_today_spend():.4f} | "
        f"Total spend: ${get_total_spend():.4f} ===="
    )


if __name__ == "__main__":
    main()
