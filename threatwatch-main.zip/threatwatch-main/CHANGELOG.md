# Changelog

All notable changes to ThreatWatch are documented here.

## 2026-06-12 — Full-system overhaul: data accuracy, silent-failure elimination, UI truthfulness + redesign foundation

A three-phase audit (discover → plan → execute) of the entire pipeline,
storage, server, AI layer, and dashboard, executed as ~20 reviewable commits.
Theme: accuracy is non-negotiable — no fabricated values, no silent failures,
no UI element implying something fired when it didn't.

### Critical correctness
- **KEV batch enrichment had failed on every pipeline run** with
  `UnboundLocalError` (a function-local re-import shadowed the module import),
  silently caught and logged as "KEV enrichment failed" — 40 occurrences/24h
  confirmed in production logs. Articles now actually receive CISA KEV flags
  in the main enrichment path.
- **SQLite and JSON corpora could diverge without bound** (live instances
  disagreed 2,007 vs 1,741 articles; the JSON corpus actually held 4,303).
  `db.sync_corpus()` mirrors the merged corpus exactly — upsert + delete-absent
  in one transaction. `/api/articles` and `/api/health` can no longer disagree.
- **Fabricated timestamps eliminated**: enrichment time was stored as
  `timestamp` and used for corpus ordering (old re-enriched articles surfaced
  as breaking news); dark-web items with no date were stamped `published=now()`
  and bypassed the cutoff; RSS fell back to render-time now(). Articles now
  carry `ingested_at`, ordering/cutoff/AI-recency all key on the real
  publication date, and undated dark-web items are dropped.
- **Non-atomic writes fixed everywhere** (tmp+rename): the server could read —
  and cache for 30s — a torn half-written daily_latest.json/stats.json;
  alert-dedup state could corrupt to {} and re-fire every alert.

### Silent failures now surface
- HTTP-200-but-unparseable feeds (WAF/challenge pages) were recorded as
  healthy "ok, 0 new" — now recorded as failures. One malformed entry no
  longer fails the whole feed. New `silent` health state for feeds that
  respond but have never produced one article. Health entries for feeds
  removed from config are pruned (they inflated dead counts forever).
- Operator Telegram alerts (24h cooldown) when ≥5 feeds are dead/silent or
  the briefing goes stale — these failures previously lived only in
  container logs.
- Briefing tier cascade: the served tier, stale-serves
  (`served_stale`/`stale_reason` after a hallucination rejection), and
  threat-level provenance (`threat_level_source`) are now recorded and
  shown in the UI. `generated_at` is never re-stamped on cache hits.
- LLM "HIGH" threat level is no longer silently DOWNGRADED to MODERATE —
  synonyms map to the closest enum level with provenance.

### AI honesty
- Actor profiles labelled `llm_generated_unverified` (description/aliases/
  attribution come from model training data, not the corpus), regenerate
  after 30 days, and the prompt instructs Unknown-over-guessing.
- Cluster syntheses are CVE-ground-checked like the main briefing and
  rejected on hallucinated IDs; AI cache keys carry prompt/model salts so
  stale verdicts don't outlive prompt fixes; daily cache expiry sweep.
- Top-stories `significance` normalised to the documented enum.

### Enrichment
- EPSS scores get a 6h disk cache (was a live API call every 10-minute tick;
  outages silently dropped all scores — stale scores now serve WITH a
  warning). KEV stale-cache fallback escalates to ERROR past 48h.
- Trend spikes no longer emit `Infinity` (invalid JSON) — count-weighted
  ratio + `new_emergence` flag.
- MD5/SHA1 hex only counts as an IOC when the text mentions hashes/samples
  (git commits and UUIDs in prose no longer surface as indicators).

### Integrations
- STIX 2.1 export is now actually valid: UUID-form identity id (the old
  literal id made OpenCTI/MISP/Sentinel reject the whole bundle),
  `created_by_ref` provenance instead of semantically-invalid
  `indicator indicates identity`, content-derived stable bundle id so TAXII
  dedup and ETag caching work.
- `/api/since` pages oldest-first with a lossless cursor (the old cursor
  silently skipped every unreturned article for paging clients) and
  tolerates unencoded `+` in timestamps.
- `/api/articles` no longer leaks scraped `full_content`.
- Removed the dormant legacy RSS writer that used conflicting GUIDs.

### Dashboard (truthfulness + redesign foundation)
- Threat level defaults to `THREAT: —` (unknown), never a false LOW.
- Incident Clusters panel restored (its render targeted a missing div —
  the feature was silently dead); dead code removed.
- The 2-minute refresh actually updates the briefing again (it keyed on a
  legacy field and ignored every modern briefing) and now also refreshes
  Headlines/Clusters/actor profiles; a visible "Checked HH:MM:SS UTC"
  stamp distinguishes quiet-and-fresh from stale-page.
- Briefing panel surfaces stale-serves, threat-level provenance, and the
  serving tier. Sector Impact counts articles, not regex occurrences.
- New **KEV ACTIVE** stat with one-click feed filtering.
- Design system: rem type scale (10px floor, 221 px sizes replaced),
  spacing tokens, WCAG-AA contrast fixes for Solarized/Phosphor,
  theme-aware chart palette, honest chart-scaling legends, score-formula
  tooltips, UTC hover anchors on relative times.
- Accessibility: keyboard activation for all interactive elements, feed
  cards focusable with aria-labels, landmarks, modal dialog semantics +
  focus management on the watch drawer, live regions, visible focus rings.
- Self-links are root-relative (self-hosted installs no longer point at
  the hosted demo).

### Security / dependencies / performance
- requirements.txt pinned to production-verified versions (feedparser had
  no constraint at all); defusedxml for externally-fetched XML;
  /api/quality + /api/groq-usage removed from wildcard CORS; watchlist
  GET auth now has regression coverage.
- Rendered-page gzip memoized (was recompressed per request); the
  always-"now" Last-Modified header removed (it defeated
  If-Modified-Since; ETag handles conditional GETs).
- Retention cleanup can no longer age-delete live output files
  (briefing.json/daily_latest.json had a 365-day time bomb); AI cache
  swept daily.

### Tests
- 1,483 tests passing (was 1,438 with 6 date-rotted failures). New
  regression coverage for every fix above; time-dependent fixtures made
  rotation-proof.


## 2026-05-14 — Featherless primary model swap: DeepSeek-V3.2 → openai/gpt-oss-120b

Context: with the tier-aware downgrade guard now in place, the next constraint was that Featherless itself was 429ing every single call for 24h+ ("concurrency_limit_exceeded"). Direct probe of the Featherless API showed `feather_pro_plus` has a 4-unit concurrency cap, DeepSeek-V3.2 costs 4 units per request, and 2 units were persistently in use by an unidentified workload — leaving only 2 units headroom. Net: zero possibility of DeepSeek-V3.2 ever serving until the plan is upgraded or the phantom 2-unit holder is identified and stopped.

### Operations
- **`FEATHERLESS_MODEL` swapped from `deepseek-ai/DeepSeek-V3.2` (cost 4) to `openai/gpt-oss-120b` (cost 2)** in production `~/threatwatch/.env`. `.env.example` updated with a model-selection comment block documenting the concurrency-cost trade-off so self-hosters know which models fit their plan tier.
- Container recreated via `docker compose up -d --force-recreate pipeline` (NOT `docker restart` — that keeps the original env). Pipeline tier-init log confirms: "Featherless configured — global briefing will prefer openai/gpt-oss-120b (32K ctx)".
- User-stated invariant ("primary will always be featherless") preserved — only the model identity changed, the tier ordering and the downgrade guard remain in force.
- **Known unresolved:** 2 of 4 Featherless concurrency units are persistently occupied by an unidentified workload despite operator confirming ThreatWatch is the only consumer of the key. Worth a Featherless support ticket using `org_bpTBrVnRedrQXGYw7eNxF` from the error payload; could be a stuck Featherless-side slot, a leaked long-running call, or a misattribution.

### Why this model
- `openai/gpt-oss-120b` is OpenAI's open-source 120B reasoning model. Largest parameter count available at concurrency_cost ≤ 2 on `feather_pro_plus`.
- Verified working live (~5s response, clean structured output, includes a `reasoning` field) when DeepSeek-V3.2 was rejecting every request.
- Strong at strict-JSON output and multi-document synthesis, which is exactly what the briefing prompt needs to produce a usable `week_in_review`.
- Same 32K context as DeepSeek-V3.2 — no prompt-length regression.
- Fully reversible: flip `FEATHERLESS_MODEL` back to `deepseek-ai/DeepSeek-V3.2` and recreate the container once the 2-unit phantom is resolved or the plan is upgraded.

### Alternatives considered (canonical 2-unit options at `feather_pro_plus`)
- `zai-org/GLM-4.7-Flash` — strong reasoning, multilingual; operator KB already lists GLM-4.6 as a fallback preference. Viable second choice.
- `Qwen/Qwen3.6-27B` — latest Qwen, smaller but very recent; good multilingual for non-English feeds.
- `Qwen/Qwen3-Coder-Next` — 80B MoE but coder-tuned; weaker on narrative synthesis.
- `mistralai/Mistral-Small-3.1-24B`, `google/gemma-4-31B` — solid baselines but smaller.

## 2026-05-14 — Tier-aware downgrade guard: Featherless briefings survive Groq-fallback regens

Context: operator reported the briefing's `week_in_review` was missing major 2-day-old incidents (Canvas LMS / ShinyHunters mega-breach, Google AI-attack warning, ScreenConnect malware campaign, Foxconn restart). Live diagnosis showed the briefing engine + KEV enrichment were fine (9 KEV articles hoisted per cycle) — the actual cause was tier dispatch: Featherless (tier 1) 429ing on concurrency exhaustion and Claude Bridge (tier 2) 502ing on Claude Max session quota, every cycle. Every ~2h, an 8b Groq briefing was overwriting the previous Featherless-served briefing, and the 8b model couldn't synthesize trailing-context into a useful `week_in_review`.

### Fixed
- **Tier-aware downgrade guard (`modules/briefing_generator.py`)**: a new module-level helper trio (`_tier_rank`, `_briefing_age_hours`, `_should_skip_downgrade`) plus an in-flow check in `generate_briefing` that loads the prior briefing from disk and refuses to overwrite it if the new attempt downgraded to a lower-quality tier AND the prior is younger than `BRIEFING_DOWNGRADE_GUARD_HOURS` (default 4h; set to 0 to disable). When the guard fires, `_save_briefing`, `cache_result`, and `_record_api_call` are all skipped — so the next pipeline tick can retry the premium tier immediately instead of waiting out the 1h cooldown. Tier ranks: `featherless=1` (primary) > `anthropic=claude_bridge=2` > `openai=groq=3` > `ollama=4`; unknown = 99.
- User-stated invariant — "primary will always be featherless" — is now enforced structurally: a fresh Featherless briefing on disk cannot be wiped by a Groq fallback within the 4h window.

### Operations
- New env knob: `BRIEFING_DOWNGRADE_GUARD_HOURS=4` (default 4). Tune up for longer "premium-tier preservation" windows; set to 0 to revert to the prior always-overwrite behavior.
- New log line: `Briefing downgrade skipped — kept prior featherless/deepseek-ai/DeepSeek-V3.2 (age 1.3h) instead of overwriting with groq/llama-3.1-8b-instant (BRIEFING_DOWNGRADE_GUARD_HOURS=4.0).` — surfaced any time the guard fires, so the operator can see exactly when premium-tier preservation is in effect.
- Hot-deploy: `docker cp modules/briefing_generator.py threatwatch-pipeline:/app/modules/briefing_generator.py && docker restart threatwatch-pipeline`. No env changes required (defaults apply).
- Companion infra concern (not in this commit): Featherless 429s ("concurrency exhausted") indicate another project is saturating the shared plan; Claude Bridge 502s indicate Claude Max session quota is being hit. Both worth addressing at the subscription/plan level so tier 1 + tier 2 actually serve more reliably.

### Testing
- 23 new tests across 4 classes in `test_briefing_generator.py`:
  - `TestTierRank` (7 cases): rank values for each known tier + unknown + None.
  - `TestBriefingAgeHours` (4 cases): missing/unparseable timestamps, recent ISO, Z-suffix variant.
  - `TestShouldSkipDowngrade` (9 cases): guard disabled, no prior, no provider, same tier, upgrade, within-window downgrade, outside-window downgrade, Bridge protection from Groq, Featherless protection from Bridge.
  - `TestDowngradeGuardEndToEnd` (3 cases): fresh Featherless prior blocks Groq overwrite, stale Featherless prior allows Groq overwrite, no prior saves new briefing normally.
- 76/76 pass on `test_briefing_generator.py`; 157/158 pass across all three briefing test modules. The single remaining failure (`test_generated_at_stamped_after_llm_call` in `test_briefing_gen.py`) is the same pre-existing flake noted in the 2026-05-07 entry, unrelated.

## 2026-05-10 — Feed triage: -7 dead/broken sources, +2 working replacements

Context: `/api/quality` reported 5 dead + 16 error-status feeds (out of 164 tracked). Triage probing from the VPS network with the production UA showed most "error" status feeds were false positives (slow publishers with no fresh content within `FEED_CUTOFF_DAYS=7`), but several high-value sources had genuinely drifted URLs or been sunset.

### Operations
- **Removed (commented out with audit trail in `config/feeds_native.yaml`)**:
  - `https://threatpost.com/feed/` — site frozen since Kaspersky sunset (2022); will never produce fresh content within the cutoff window.
  - `https://news.sophos.com/en-us/feed`, `https://news.sophos.com/en-us/category/threat-research/feed/` — both 301-redirect to `www.sophos.com/en-us/blog/feed` which times out from the VPS network (bot-blocked or down).
  - `https://msrc.microsoft.com/blog/feed` — Microsoft sunset the RSS feed; URL now 301-redirects to an HTML landing page. No drop-in RSS replacement located.
  - `https://www.trendmicro.com/en_us/research.rss.html` — 404; replaced (see below).
  - `https://googleprojectzero.blogspot.com/feeds/posts/default` — 302-redirects to the new canonical URL; replaced (see below).
  - `https://blog.sekoia.io/feed/` — Sekoia's WAF returns 403 specifically to the Chrome UA used by `feed_fetcher.py` (feedparser/curl/ThreatWatch UAs all get 200). Re-enable once per-feed UA overrides land in `feed_fetcher.py`.

- **Added (verified from VPS with production UA)**:
  - `https://feeds.feedburner.com/TrendMicroResearch` — 100 entries, latest dated today.
  - `https://projectzero.google/feed.xml` — Project Zero's new canonical URL; 10 entries (slow but high-value publisher; latest entry is typically outside the 7-day window, will surface when they post).

- Net change: 79 → 74 active feeds; 16 erroring → ~10 expected after next cycle (false-positive low-signal feeds remain since they're not actually broken). No code change; `threatdigest_main.py` reloads `feeds_native.yaml` at the start of each fetch cycle, so changes apply on the next pipeline tick after `git pull`.

## 2026-05-07 — Briefing success log reports the actual served tier (closes #3)

Context: with three briefing tiers in play (Featherless → Claude Bridge → Groq+8B), the success log line `Intelligence briefing generated via openai/llama-3.1-8b-instant` always echoed the configured `BRIEFING_MODEL` regardless of which tier actually served. This was load-bearing telemetry that masked the KEV-signal-missing bug for weeks (caught only by reading prompt source, not logs — see 2026-05-06 entry). The data existed in `data/state/groq_usage.json` per-caller tags, but the in-process result of the dispatch never surfaced which tier won.

### Fixed
- **Tier-aware success log + `provider` field (`modules/briefing_generator.py`)**: `_call_openai_compatible` now sets a module-level `_LAST_SERVED_TIER` sentinel (`featherless/<model>` | `claude_bridge/<model>` | `groq/<model>`) as a side effect on each tier branch. `generate_briefing` and `generate_regional_briefings` read the sentinel and stamp it onto `briefing["provider"]` and the success log line. Anthropic branch retains its explicit `anthropic/<LLM_MODEL>` format. Defensive fallback to the legacy `openai/<BRIEFING_MODEL>` format if the sentinel is unset (should never happen on the openai-compatible path post-fix). Single-threaded pipeline assumption documented inline; if concurrent briefing generation is ever added, switch to a tuple return.

### Architecture
- **Why a module-level sentinel rather than a tuple return**: the alternative — changing `_call_openai_compatible` to return `(reply, served_tier)` — would have forced ~30 mock updates across `tests/test_briefing_generator.py`, `test_briefing_gen.py`, `test_briefing_featherless_routing.py`. The pipeline runs sequentially in a single process (briefings generated one after the other in `threatdigest_main.py`), so a module-level sentinel is safe today. Documented and revisitable.

### Testing
- New `TestServedTierLogging` class in `test_briefing_generator.py` (5 cases): provider stamped as `featherless/<model>` when Featherless serves, `claude_bridge/<model>` when Featherless fails and Bridge serves, `groq/<BRIEFING_MODEL>` when both premium tiers fail, `groq/<BRIEFING_MODEL>` when no premium tier is configured, success log line contains `via featherless/...` (not the legacy `via openai/...` format).
- `test_briefing_gen.py::test_successful_generation` updated to patch `_LAST_SERVED_TIER=None` so sibling test files (e.g. `test_briefing_featherless_routing.py` which calls the real dispatch) don't bleed state.
- 53/53 pass on `test_briefing_generator.py`; 134/135 pass across all three briefing test modules. The single remaining failure (`test_generated_at_stamped_after_llm_call`) is pre-existing on HEAD, unrelated to this change.

### Operations
- Hot-deploy: `docker cp modules/briefing_generator.py threatwatch-pipeline:/app/modules/briefing_generator.py && docker restart threatwatch-pipeline`. Code-path-only change, no env change required.
- Verification (next ~30-min AI cycle): pipeline log line will read `Intelligence briefing generated via featherless/deepseek-ai/DeepSeek-V3.2.` (or whichever tier won) — accurate per-cycle. Cross-check with `data/state/groq_usage.json` `featherless:briefing` / `claude_bridge:briefing` / `groq:briefing` counters.

## 2026-05-06 — Briefing share-payload enrichment + KEV-listed extended tenure (72h default)

Context: shipped two quality-of-life upgrades to the briefing surface plus a side-fix for a latent KEV signal bug discovered during planning.

### Added
- **Rich briefing share payload (`threatwatch.html`)**: SHARE button on the briefing card now copies a paste-ready block with level + UTC timestamp header, headline, one-paragraph what_happened (truncated at 280 chars), top 3 priority actions, outlook, and dashboard URL. Mirrors `modules/telegram.py` shape so the same content fits Slack, Teams, Telegram, email signatures (~600-1400 chars). Previous payload was just `level\nheadline\n\nurl` — three lines, no context, useless on its own.
- **KEV-listed extended tenure in what_happened (`modules/briefing_generator.py`)**: actively-exploited CVEs (CISA KEV-listed) get hoisted from days 2-3 back into the headline section when within `HIGH_PRIORITY_TENURE_HOURS` (default 72). Patches typically roll out across 3-day windows; previous strict 24h bucketing dropped urgent items off the headline even while they were operationally fresh. Cap at 72h so the section doesn't converge with `week_in_review`. Env-tunable; new helper `_hoist_kev_listed()`.

### Fixed
- **KEV signal missing from briefing prompt (`modules/briefing_generator.py`)**: out-of-band AI enrichment (`AI_ENRICHMENT_INLINE=0`, prod default since 2026-04-22) loads articles from `daily_latest.json` which does NOT persist the `kev_listed` field — KEV enrichment writes in-memory and the save path strips it. Result: the briefing prompt's KEV-prominent treatment had been firing on zero KEV signal for weeks. Re-apply `enrich_articles_with_kev()` at briefing time before `_split_by_age`. Idempotent for already-enriched articles. Latent bug — no telemetry to detect because the success log always tags the briefing as `via openai/llama-3.1-8b-instant` regardless of tier (see #3).

### Testing
- 48 tests on `test_briefing_generator.py` pass (43 existing untouched + 5 new `TestHoistKevListed`): hoist within tenure / outside tenure / empty day3 / invalid-timestamp defensive keep / non-KEV never hoisted.

### Operations
- New env var: `HIGH_PRIORITY_TENURE_HOURS=72` (set lower for stricter "breaking only" cadence, higher to ride out CRITICAL items longer).
- Hot-deploy: `docker cp` + `docker restart` per service; `CACHE_TTL=30s` for the server HTML cache so the share-button change can also propagate without restart.
- Verification (next ~30-min AI cycle): pipeline log shows `Hoisted N KEV-listed article(s) from days 2-3 -> headline section (within 72h tenure window)` when applicable.

## 2026-05-04 — SSRF guard allowlist (unblock Claude Bridge tier 2)

Context: yesterday's multi-tier briefing fallback (`0b5f9c3`) shipped with tier 2 structurally broken in production. Pipeline logs from `2026-05-04 02:43:54` showed every Featherless 429 falling straight through to Groq+8B, never exercising Claude Bridge. Root cause: the process-wide SSRF guard (`modules/safe_http.py`, added 2026-04-21) refuses any hostname resolving to a non-public IP — but the bridge URL `http://172.21.0.1:8400/v1` is *intentionally* the docker bridge gateway. Correct guard, legitimate target, zero way through.

### Fixed
- **SSRF guard now allowlists configured internal URLs (`modules/safe_http.py`)**: new `_build_allowlist()` reads `CLAUDE_BRIDGE_URL` at install time, parses out the host, and short-circuits the public-IP check for that one host. An unconfigured bridge URL leaves the allowlist empty — previous behaviour preserved. Allowlist is logged at install: `SSRF guard allowlist: ['172.21.0.1']`. Read-once at startup; changing the env requires a process restart, same lifecycle as `install_ssrf_guard` itself.

### Testing
- 26/26 tests on `test_safe_http.py` pass (15 existing untouched + 3 new `TestAllowlist` cases): allowlisted host bypasses the IP check; non-allowlisted host at the same private IP is still blocked; unset `CLAUDE_BRIDGE_URL` keeps the allowlist empty so generic private-IP refusal still fires.

### Operations
- Hot-deploy via `docker cp modules/safe_http.py threatwatch-pipeline:/app/modules/safe_http.py && docker restart threatwatch-pipeline`. Container healthy after 8s. Live verification: `2026-05-04 17:41:12 | INFO | SSRF guard allowlist: ['172.21.0.1']` followed by `SSRF guard installed on urllib3 create_connection`. Closes #2.
- Tier 2 (Claude Bridge) is now reachable when Featherless 429s. Confirmation that tier 2 actually serves a briefing end-to-end will land in a future entry once the next Featherless throttle event happens organically.


## 2026-05-03 — Multi-tier LLM routing for the daily briefing (Featherless → Claude Bridge → Groq+8B)

Context: the global briefing prompt (~7-8K) had been clamped (40 articles × 80 chars/summary × 1200 max_tokens) to fit Groq free-tier 6K TPM. That worked but left the briefing perpetually one feed-volume spike away from a 429-cliff and capped output detail at ~1200 tokens. Introduce a 3-tier cascade so the briefing has real headroom while still degrading gracefully when premium tiers fail.

### Added
- **Tier 1 — Featherless.ai (`modules/llm_client.py`, `modules/config.py`, `modules/briefing_generator.py`)**: paid OpenAI-compatible provider, `deepseek-ai/DeepSeek-V3.2` at 32K ctx. Primary path for the global briefing. Output cap raised 1200→4000 tokens (`feather_max_tokens` kwarg) since Featherless's 32K context allows a richer narrative without prompt clipping. Single-shot, no retries — token is shared across multiple of the operator's projects so 429 = step down. Env: `FEATHERLESS_API_KEY`, `FEATHERLESS_BASE_URL`, `FEATHERLESS_MODEL`, `FEATHERLESS_TIMEOUT`. Usage tagged `featherless:<caller>` in `data/state/groq_usage.json`.
- **Tier 2 — Claude Bridge (`modules/llm_client.py`, `modules/config.py`, `modules/briefing_generator.py`)**: host-local OpenAI-compatible shim that proxies to the `claude` CLI using a Claude Max subscription. Operated by RedBlue's claude-bridge service on the same host (port 8400). 2nd-tier briefing fallback — zero per-token cost, rate-limited by the shared Max session, ignores `max_tokens` and `response_format` (CLI doesn't expose them). Single-shot, 300s timeout. Env: `CLAUDE_BRIDGE_URL`, `CLAUDE_BRIDGE_MODEL`, `CLAUDE_BRIDGE_TIMEOUT`. Usage tagged `claude_bridge:<caller>`. Requires UFW allow rule for ThreatWatch's docker subnet (`172.21.0.0/16` → host:8400).
- **Tier 3 — Groq + `llama-3.1-8b-instant` (existing, last-resort)**: keeps the 1200-token cap so the prompt still fits free-tier headroom on Groq.
- **Per-provider routing kwargs (`briefing_generator._call_openai_compatible`)**: `prefer_featherless: bool` gates the cascade — only the global briefing opts in. Regional briefings, top_stories, attack_tagger, cve_narrative, ttp_extractor, and the hybrid classifier all stay on Groq direct (high-frequency or small-prompt callers don't need premium tiers and would crowd out other consumers). `feather_max_tokens: int | None` decouples the Featherless output cap from the Groq fallback cap.

### Architecture
- **Each tier is independent**: each has its own `*_available()` gate, and a failure on tier N never retries tier N — control flow drops straight to tier N+1. Failures log a warning naming which tier fell through, so live logs reveal which tier ultimately served any given briefing.
- **Featherless concurrency reality**: each big model (`deepseek-ai/DeepSeek-V3.2`, `kimi-k2`, `glm46-357b`) costs **4 concurrency** on Featherless and the Premium tier total is **4** — effective concurrent requests across all consumers ≈ 1. Briefing makes 1 call per pipeline run (~daily), so ThreatWatch's share is negligible.
- **Bridge auth**: bridge has no API key — it consumes the host's `~/.claude/` OAuth session. ThreatWatch sees only an HTTP endpoint; coordinate with RedBlue/ARBI before widening usage.

### Operations
- **Required `.env` for full cascade**: `FEATHERLESS_API_KEY=rc_...`, `FEATHERLESS_BASE_URL=https://api.featherless.ai/v1`, `FEATHERLESS_MODEL=deepseek-ai/DeepSeek-V3.2`, `CLAUDE_BRIDGE_URL=http://172.21.0.1:8400/v1`, `CLAUDE_BRIDGE_MODEL=sonnet`. Both layers are optional — without them the briefing keeps using Groq+8B as before.
- **Required UFW**: `sudo ufw allow from 172.21.0.0/16 to any port 8400 proto tcp comment "claude-bridge from threatwatch"` (only RedBlue's `172.25.0.0/16` was allowed before).
- **Startup logs** confirm wiring: `Featherless configured — global briefing will prefer deepseek-ai/DeepSeek-V3.2 (32K ctx); Groq+llama-3.1-8b-instant fallback.` and `Claude Bridge configured at http://172.21.0.1:8400/v1 (sonnet); 2nd-tier briefing fallback.`
- **`docker-compose.yml`**: `pipeline` service `environment:` block extended with `FEATHERLESS_*` and `CLAUDE_BRIDGE_*` passthroughs.

### Testing
- 1402 tests pass (up from 1380). +51 new tests across `test_featherless_client.py` (17), `test_claude_bridge_client.py` (13), `test_briefing_featherless_routing.py` (21). Coverage: per-provider single-shot policy (no retries on 429/5xx), `response_format` graceful fallback for DeepSeek/GLM (which don't natively support JSON mode), missing-config guards, usage-tagging, output-cap split (Featherless 4000 / Groq 1200), and the 3-tier cascade (Bridge takes over when Feather unavailable/fails, Groq when both fail, Bridge skipped on regional path).

## 2026-04-27 — Telegram outage RCA + fixes (briefing TPM, KEV full-corpus dispatch, 14d age cutoff)

Context: Telegram channel had been silent since 2026-04-26. Two independent root causes converged. Both fixed and pushed; 12 KEV alerts fired in the first hour after the fix landed (5 from manual force-run + 7 from natural pipeline ticks).

### Fixed
- **Briefing crossed Groq's per-request 6K TPM cap (`modules/config.py`, `modules/briefing_generator.py`, `docker-compose.yml`)**: every briefing 429'd on every key for 28h+ straight while classify/attack_llm/regional kept succeeding (their per-call sizes were under 6K). Critical insight: Groq's free-tier 6K TPM is enforced **per-request**, not just per-minute throughput — 3 rotating keys do NOT raise the per-call ceiling, and switching 70B→8B doesn't help (same 6K cap on all free-tier models). Fix: switch the global briefing call to `llama-3.1-8b-instant` (env: `BRIEFING_MODEL`), drop `_MAX_BRIEFING_ARTICLES` 80→40, `_DIGEST_SUMMARY_CHARS` 250→80, `max_tokens` 2000→1200. Real probe: 4,450 prompt + 473 completion = 4,933 tokens (~350 token margin under cap). Regional briefings keep the 80-article cap (their per-call size was already fine).
- **KEV alerts dispatched against the new fetch batch only (`threatdigest_main.py`)**: most KEV-tagged articles are older items already deduplicated out (CVE coverage takes hours/days to surface; CISA can list a CVE long after the article was first enriched). Result: `KEV: flagged 0 articles` every tick despite 12+ KEV CVEs in the live corpus. Fix: dispatch against `all_articles` (full `daily_latest.json` corpus) with KEV enricher re-applied so newly-listed CVEs are caught on older articles.
- **`scripts/cleanup.py` ModuleNotFoundError at scheduler startup**: missing `sys.path` bootstrap caused `from modules.config import ...` to crash on every scheduler tick (cleanup ran with exit code 1, then pipeline continued without cleanup). Added the standard 2-line bootstrap.

### Added
- **TELEGRAM_KEV_MAX_AGE_DAYS (default 14) (`modules/telegram.py`)**: suppresses KEV alerts whose `date_added` is older than the cutoff. Stale CVEs are silently stamped into the dedup state so they never alert AND never retry on later runs. Set to 0 to disable the filter (alerts every never-before-seen KEV CVE — pre-2026-04-27 behavior). Defensive: missing or unparseable `date_added` falls through to the main loop instead of being silently silenced. Necessary because today's full-corpus dispatch fix initially fired alerts for 5 CVEs that have been on KEV for 90+ days (oldest = 315 days) — technically still "actively exploited" per CISA, but alerting a year-old listing as breaking news was misleading.

### Operations
- **Briefing model is env-tunable (`BRIEFING_MODEL` in `.env`)**, default `llama-3.1-8b-instant`. Set to `llama-3.3-70b-versatile` only if the prompt is also brought back under 6K (today it isn't).
- **Backfill drain complete** for KEV alerts: 12 alerts sent, 12 KEV CVEs in corpus, 0 pending. From here on only freshly-listed CVEs (within `TELEGRAM_KEV_MAX_AGE_DAYS`) trigger alerts.

### Testing
- 142 tests pass on the changed surface (`test_briefing_generator`, `test_briefing_gen`, `test_telegram`, `test_kev_enricher`). +4 new telegram tests for the cutoff: stale-silenced-not-sent, fresh-alerts, filter-off (`=0`), malformed-date fallthrough.

## 2026-04-25 — Cache-staleness fixes, historical enrichment backfills, top_stories on 8B

Context: the free-tier capitalization features shipped 2026-04-23 were verified live this session — `cve_narrative`, `ttp_extract`, and `attack_llm` all firing in production telemetry. Two regressions surfaced and got fixed: top_stories had been silently returning stale 28-hour-old selections (cache had no TTL), and once that fix landed it 429'd every cycle because its 70B prompt loses TPM contention against briefing/regional that fire seconds before. 1129 historical articles were also backfilled with the new enrichers (366 TTPs, 37 CVE narratives, 446 summaries) — ~63% of the ~2300-article corpus brought up to current enrichment standards in one pass.

### Fixed
- **top_stories cache staleness (`modules/top_stories.py`)**: `ai_cache` has no read-side TTL, so a digest-only cache key let `top_stories` return the same selection forever when fuzzy-dedup was making the corpus near-static day-to-day. Observed: 28 hours since the last LLM call despite a 1-hour cooldown window. Fix: bucket the cache key by UTC date (`topstories_2026-04-25_<digest_hash>`) so the editorial pass is forced to rerun ≥1×/day even when the underlying digest hash is unchanged.
- **top_stories TPM contention (`modules/llm_client.py`, `modules/briefing_generator.py`, `modules/top_stories.py`)**: the AI enrichment chain runs briefing → regional (×3) → top_stories → summaries back-to-back. By the time `top_stories`' 5K-token 70B prompt fires, every key has 429'd from the burst. Plumbed an optional `model` kwarg through `call_llm` and `_call_openai_compatible` so callers can opt into a lighter Groq model. `top_stories` now defaults to `llama-3.1-8b-instant` (env: `TOP_STORIES_MODEL`) and caps its digest at 30 articles (env: `TOP_STORIES_MAX_ARTICLES`) to fit 8B's 8K context window — editorial selection doesn't need 70B's depth, and the smaller token cost fits within the TPM left after briefing/regional. Verified live: ~3.5K tokens/call, 8 stories generated, `provider: openai/llama-3.1-8b-instant`.
- **backfill_summaries TPM trips (`scripts/backfill_summaries.py`)**: original script blasted batches with no inter-pass delay, tripped the circuit breaker mid-run under contention with the live pipeline. Added `BACKFILL_SUMMARY_SLEEP` between passes (default 10s), a `reset_circuit()` per pass, and a single retry-after-pause on empty pass — a streak of transient 429s no longer truncates the run.

### Added
- **Daily-average AI tokens tile (`threatwatch.html`)**: today's count is partial and resets each midnight UTC, which made the bottom-left tile read low for most of the day. Switched to a daily average computed from `/api/groq-usage`'s `last_7d` window (today excluded as partial). Tile label is now "AI TOKENS / DAY"; tooltip retains today-so-far for context.
- **Historical CVE narrative backfill script (`scripts/backfill_cve_narratives.py`)**: one-shot iteration over `daily_latest.json` running the existing `cve_narrative` enricher against qualifying CVEs (CVSS ≥ 8.0 or EPSS percentile ≥ 0.80) that lack a narrative. Writes back via merge-by-hash and mirrors into SQLite. 8s pacing, 3 lifetime backoffs, fits free-tier TPM cleanly because narrative prompts are ~500 tokens. Cleared the 37-article backlog this session.
- **Historical TTP backfill script (`scripts/backfill_tactical_analysis.py`)**: same shape for `ttp_extract`, with two important differences born of pain: (a) per-call retry budget instead of lifetime — a TPM streak can no longer exhaust a single global counter and starve every subsequent article; (b) always sleeps `--sleep` between articles regardless of outcome, so a give-up path can't burn through the queue at hundreds per second. The 70B model is too token-heavy for free-tier TPM under contention with the live pipeline (~1.8K tokens/call saturates a per-key minute window), so override `LLM_MODEL=llama-3.1-8b-instant` when running this script. Cleared the 366-article backlog this session.

### Operations
- **1129 articles enriched this session** across three backfills: 366 TTPs (`tactical_analysis`), 37 CVE narratives, 446 summaries (730 of 1180 stragglers remain — the 8B model couldn't generate non-empty JSON for articles with thin body content; left for another session).
- **Day's token usage 683K of ~1M envelope (~68%)** — TTP backfill alone burned ~480K via 8B model. Multi-key rotation is account-scoped on Groq free tier (not per-key) — when account TPM caps out, all 3 keys 429 in the same second. Smaller prompts dodge this; pacing helps.

### Testing
- 89 tests on the changed modules (`test_top_stories`, `test_briefing_generator`, `test_llm_client`) — patched `_TOP_STORIES_MODEL` rather than `LLM_MODEL` in the success-generation test, and added implicit coverage for the new `model` kwarg via the existing call paths.

## 2026-04-23 — Free-Tier Groq Capitalization (CVE narratives · TTP extractor · LLM ATT&CK fallback · tokens tile)

Context: per-caller Groq usage (landed 2026-04-22) showed we were using <5% of the free daily token budget. This session capitalises on the unused headroom with three LLM-backed enrichments and swaps the dashboard's always-$0 cost tile for live token throughput.

### Added
- **CVE exploitation narratives (`modules/cve_narrative.py`)**: new LLM pass that turns raw NVD metadata (CVSS, vector, CWE, affected products, EPSS percentile) into a 3-sentence analyst narrative — *what an attacker practically does, who's exposed, how urgent*. Gated at CVSS ≥ 8.0 OR EPSS percentile ≥ 0.80 so only actually-dangerous CVEs burn tokens. Cached by CVE ID (descriptions are immutable per NVD), so each CVE is paid for exactly once across its lifetime. Envelope at 20–30 new high-sev CVEs/day × ~1.5K tokens ≈ 30–45K tokens/day before cache hits. Wired into `threatdigest_main.main` between EPSS enrichment and ATT&CK tagging. `caller="cve_narrative"`.
- **Deep TTP extractor (`modules/ttp_extractor.py`)**: second LLM pass over the *full scraped body* of high-signal incident articles, producing structured `tactical_analysis = {summary, ttps[], persistence[], lateral_movement[], impact[], confidence}`. Today's classifier and ATT&CK tagger only see title + short summary, so the tactical gold (exact persistence mechanisms, lateral-movement paths, C2 behaviours) that lives in body paragraphs was being discarded. Gated on `is_cyber_attack` + body ≥ 500 chars; cache-first by article hash; hard-capped at `TTP_EXTRACT_MAX_CALLS=40`/run so one noisy feed day can't exhaust the budget. `caller="ttp_extract"`.
- **LLM fallback for ATT&CK under-tagging (`modules/attack_tagger.py`)**: opt-in (`LLM_ATTACK_FALLBACK=true`) pass that escalates cyber-incident articles the regex pass tagged with fewer than `LLM_ATTACK_FALLBACK_MIN=2` techniques to the LLM, which returns up to 5 canonical ATT&CK IDs. Regex-validated (`Txxxx` / `Txxxx.yyy`) before merge so hallucinated IDs are dropped; each LLM-sourced technique is stamped `source="llm"` for transparency. Cache-first by article hash; budget-capped by `LLM_ATTACK_FALLBACK_MAX_CALLS=100`/run. `caller="attack_llm"`.
- **AI tokens tile on dashboard (`threatwatch.html`)**: bottom-left footer tile switched from "API COST TODAY" (which read `pipeline_summary.api_cost_today`, an Anthropic-SDK-only figure that was always $0.00 on this deployment) to "AI TOKENS TODAY" sourced from `/api/groq-usage`. Shows total prompt + completion tokens for the day, human-formatted (12.3K / 1.45M); hover tooltip breaks down total calls, avg tokens/call, and prompt vs completion split.

### Testing
- 1270 tests / 95%+ coverage — up from 1233. +37 tests across the three new LLM paths: cache hit/miss, gating thresholds (CVSS/EPSS, body length, is_cyber_attack), budget caps, malformed-JSON / invalid-ID / hallucinated-ID defences, merge semantics (regex ∪ LLM, no duplicates, tactic deduping), and caller tagging so the Groq usage tracker attributes spend correctly.

## 2026-04-22 — Pipeline Runtime + AI Decoupling + ATT&CK on Actors

### Fixed
- **Briefing staleness alarm (`modules/briefing_generator.py`)**: `generated_at` was stamped at function entry rather than at save time. Under Groq rate-limit backoff the LLM call could block for 100+ min, so every saved briefing looked hours old the moment it hit disk and tripped the staleness alarm immediately. Now stamped at save time across all three paths (fresh generation, cache hit, regional).
- **Abandoned feed_health entries (`serve_threatwatch.build_health`)**: feeds disabled in config lingered in `feed_health.json` with their final error status and inflated the `/api/health` error count. Now only counts entries checked within the last 24h.

### Performance
- **LLM circuit breaker + timeout tightening (`modules/llm_client.py`)**: runs were taking 3–5+ hours each on the VPS vs. the intended 10-min interval. Root cause: `urllib3.Retry(status_forcelist=[500,502,503,504])` with default `respect_retry_after_header=True` — a single Groq 503 with a long `Retry-After` cascaded into hours of blocked time across retries × keys × per-run LLM calls. Removed urllib3 retry entirely; added explicit 5xx/Timeout/ConnectionError handling that rotates keys without retry; tightened default timeout 90s → 30s (`LLM_TIMEOUT`); added a process-local circuit breaker (`LLM_CIRCUIT_THRESHOLD=3`) that short-circuits remaining calls after N consecutive failures in a run. Verified: one run went 341 min → 45 min.

### Added
- **Decoupled AI enrichment architecture**: the four AI tiers (global briefing, regional digests, top stories, article summaries) now live in `modules/ai_enrichment.py` and run out-of-band via `scripts/run_ai_enrichment.py`. `scripts/run_pipeline.py` invokes AI every `AI_ENRICHMENT_EVERY` pipeline ticks (default 3 = ~30 min) independent of the 10-min fetch loop. `AI_ENRICHMENT_INLINE=0` (new default) skips inline AI; set to `1` to restore legacy inline behaviour. Fetch pipeline is no longer blocked by Groq rate limits.
- **ATT&CK on actor profiles (`modules/actor_profiler.py`)**: every profile now carries `observed_techniques: [{id, count}]` and `observed_tactics: [{name, count}]` aggregated from articles mentioning the actor. Refreshed every run for both new and existing profiles, grounding the LLM-generated `signature_ttps` narrative in data-driven evidence.
- **ATT&CK on dashboard (`threatwatch.html`)**: actor spotlight cards render the top 3 observed techniques as compact accent-coloured pills (`T1566×3 T1486×2`); hover tooltip appends observed tactics. Falls back to the LLM-described `signature_ttps` line when observed data isn't present so the card stays functional for older profiles. 9/17 live actors now carry evidence-backed TTPs.
- **Briefing threat-level webhook alerts (`modules/webhook.py`)**: `dispatch_briefing_alert(briefing)` fires when the global briefing's `threat_level` is at or above `WEBHOOK_BRIEFING_MIN_LEVEL` (default ELEVATED). Deduplicated by level-change + `WEBHOOK_BRIEFING_COOLDOWN_HOURS` (default 6h) so the same level doesn't re-alert every tick. Slack/Discord payload uses level-appropriate emojis and includes up to 3 priority actions; generic JSON payload carries the full structured fields. Wired into the AI enrichment orchestrator.
- **Groq LLM usage tracker (`modules/groq_usage.py`)**: the existing `cost_tracker.py` only worked for Anthropic SDK responses — the bulk of pipeline LLM traffic (classification, briefing, regional, top stories, summaries, actor profiles, cluster synth) was invisible. New tracker reads OpenAI-style `response.usage.prompt_tokens` / `completion_tokens` and aggregates per-day / per-key / per-caller in `data/state/groq_usage.json`. Keys are masked to an 8-char prefix + ellipsis so the secret never hits disk; last 90 days retained. Callers tagged: `classify`, `briefing`, `regional`, `top_stories`, `summaries`, `actor_profile`, `cluster_synth`. Exposed via new endpoint `GET /api/groq-usage` which returns today's totals, per-key breakdown, per-caller breakdown, and 7-day daily totals.

### Fixed
- **Actor profiler schema mismatch (hotfix)**: `actor_profiler.extract_actors_from_articles` was reading `t.get("id")` but `attack_tagger` emits `{technique_id, technique_name, tactic}` dicts — caused zero `observed_techniques` on the live API despite 535/2184 articles carrying ATT&CK tags. Now reads `technique_id` first, falls back to `id` for forward-compat. Regression-locked with a test that uses the real attack_tagger schema.

### Performance
- **Fetch concurrency + URL-resolver timeouts**: `MAX_FEED_FETCH_THREADS` and `MAX_SCRAPER_THREADS` both 8 → 16 (env-tunable). URL resolver HEAD timeout 5s → 3s (`URL_RESOLVER_REDIRECT_TIMEOUT`), GET 8s → 5s (`URL_RESOLVER_CANONICAL_TIMEOUT`). News-site timeouts were inherited from LLM-call defaults and too generous for the actual latency profile.

### Testing
- 1233 tests / 95% coverage (modules/) — up from 1141 / 92%. +92 tests across 15 modules, concentrated on the new circuit-breaker paths, decoupling orchestrator, actor ATT&CK aggregation, briefing alert thresholds + cooldown, Groq-usage per-key/per-caller aggregation, and long-standing coverage gaps in `feed_health`, `trend_detector`, `briefing_health`, `nvd_fetcher`, and `newsapi_fetcher`.

## 2026-04-21 — CTI Platform + Security Hardening + SQLite Migration

### Added
- Campaign persistence (`modules/campaign_tracker.py`): stable UUIDs keyed by `(entity_type, entity_name)` that survive across pipeline reclusters. Persists to `data/output/campaigns.json`. Tracks `first_observed` (ever-earliest), `last_observed`, `total_observed_articles`, `status` (active, dormant, archived by 14d and 90d thresholds), capped at 500 hashes per campaign. Atomic tmp+rename writes.
- Victim-sector taxonomy (`modules/victim_tagger.py`): 14-sector regex taxonomy (Healthcare, Finance, Government, Education, Energy, Technology, Telecom, Retail, Manufacturing, Transportation, Media, Legal, Critical Infrastructure, Hospitality). Writes `victim_sectors` list onto each article.
- IOC extraction (`modules/ioc_extractor.py`): IPv4, IPv6, domains, URLs, SHA256, SHA1, MD5, emails with defang handling (`[.]`, `hxxp://`, `[at]`), TLD allowlist, placeholder-IP blocklist. Writes `iocs` dict on each article.
- CVE write-back (`modules/incident_correlator.annotate_articles_with_cves`): extracts CVE IDs to `cve_ids` on every article so the dashboard can facet by CVE.
- New API endpoints: `GET /api/cve/<ID>`, `GET /api/campaigns[?status=...]`, `GET /api/campaign/<uuid>`.
- `modules/date_utils.py`: single source of truth for feed/article date parsing. Consolidates four divergent parsers across `feed_fetcher`, `output_writer`, `darkweb_monitor`, `incident_correlator`.
- `modules/safe_http.py`: process-wide SSRF guard that monkey-patches urllib3 `create_connection` to re-validate hostnames at connect time, closing the DNS-rebind TOCTOU in `is_safe_url`.
- Frontend pills on each article card: CVE pill (clickable, filters feed), IOC pill (type-grouped tooltip), sector pill (clickable, filters feed), story pill (prefers campaign `first_observed` so long-running campaigns keep their true age across 7-day corpus rotations).
- Nightly Docker volume backup (`scripts/backup_volume.sh`), rotates to 7 archives in `~/backups/threatwatch/`. Cron at 03:15 UTC.
- `scripts/cleanup.py` applies `ARCHIVE_RETENTION_DAYS` (default 30) to `hourly/` and `daily/` subdirs; previously retained 365 days of archive snapshots.
- STIX 2.1: confidence field, relationship objects, `object_refs` including indicator IDs.
- RSS: `<guid>`, `<category>`, `atom:link rel="self"` per item.
- Briefing staleness detection (`modules/briefing_health.py`): never-raising freshness check compares `generated_at` against `BRIEFING_STALE_HOURS` (default 3h). Surfaces via pipeline ERROR log, self-healing flag file (`data/state/briefing_stale.flag`), and new `briefing_stale` / `briefing_age_hours` fields on `/api/health`.
- SQLite migration complete: Phase 1 shadow-write (commit `a433720`), Phase 2 env-gated read adapter (commit `4ffd1d7`), Phase 3 prune cutoff + `READ_FROM_SQLITE=1` active in production. JSON files kept as fallback for parity-check.
- Per-feed signal score, `/api/since` cursor, `/api/feedback` endpoint, offsite volume backup.
- `scripts/backfill_summaries.py`: one-shot script to generate AI summaries for articles that predate the pipeline's summarization window.

### Security
- Fix `javascript:` URI XSS via feed `<link>`: `safeHref()` allowlist (`http:`, `https:`, `mailto:`).
- Rate limiter reads `X-Real-IP` only when TCP peer is a configured trusted proxy (`TRUSTED_PROXIES` env var, default `127.0.0.1,::1`). Prevents shared rate-limit bucket for all nginx-proxied users.
- Thread-safety fixes on `serve_threatwatch._cache`, `url_resolver._CACHE` (FIFO eviction), `feed_health.record_fetch`, `hybrid_classifier._escalation_count`.
- Pipeline container healthcheck now tests `stats.json` mtime under 25 minutes (was: file-exists-only).
- Bearer token auth for POST `/api/watchlist` (`WATCHLIST_TOKEN` env var).
- HSTS header, CSP Google Fonts allowlist, 64KB POST limit on `/api/watchlist`.
- Sanitized error responses — no internal paths or exceptions exposed.
- CORS restricted on `/api/health` and `/api/watchlist`; `CORS_ORIGIN` env var for opt-in.
- Rate limiter IP eviction prevents unbounded memory growth.
- Thread-safe atomic writes for watchlist persistence (tmp+rename).
- Remove `CSP script-src 'unsafe-inline'` via `data-click-action` delegation.

### Fixed
- `output_writer._parse_pub_date` no longer falls back to `datetime.now()` on parse failure.
- `darkweb_monitor._parse_date` format-slice bug replaced with shared `date_utils.parse_datetime`.
- `deduplicate_articles` no longer mutates caller article dicts.
- Incident correlator persists all clusters (not just top 15) and emits `first_seen` + `article_hashes` per cluster.
- Tag darkweb victim posts from title only; expanded benign-domain list.
- Sector false-positives on darkweb posts; benign-domain IOC filter.
- `/api/feedback` fail-closed; scheduler heartbeat.

### Changed
- `_MAX_SUMMARIES_PER_RUN` raised from 30 to 150 (env-overridable `MAX_SUMMARIES_PER_RUN`).
- SSR payload strips `article_hashes` from per-cluster objects after annotation.
- `depends_on: service_started` (not `service_healthy`) for the server container.
- Strip `full_content` from SSR payload.
- `/api/articles` always returns envelope `{articles, total, offset, limit, has_more}`.
- Coverage threshold raised from 65% to 75%; 765 tests total.

## 2026-03-19 — UI Redesign + Multi-Theme System

### Added
- Full UI redesign with professional modern look
- 5 switchable themes: Nightwatch (dark), Parchment (light), Solarized, Arctic, Phosphor (CRT)
- Theme dropdown picker with localStorage persistence
- IBM Plex Mono + Space Grotesk typography
- Phosphor CRT scanline overlay effect

## 2026-03-18 — NewsAPI + Briefing Hardening

### Added
- NewsAPI integration with rate limiting (free tier: 100 req/day)
- Three-layer region accuracy fix (content inference, ISO-2 codes, multi-region collapse)
- Non-Commercial License

### Fixed
- Briefing accuracy (max_tokens, cache key, schema validation)
- Crash bug in briefing generator

## 2026-03-15 — Features Expansion

### Added
- Brand Watch tab — monitor custom brand keywords
- Tech Watch tab — 244 vendors across 18 categories
- APT Tracker with actor intelligence grid
- IOC Tracker with ThreatFox integration
- STIX 2.1 export endpoint
- Webhook alerts (Slack and generic)
- Watchlist monitor module
- Feed search in left panel
- IOC export functionality
- NEW/APT CRITICAL badges

## 2026-03-14 — Architecture + CI/CD

### Added
- `/api/health` endpoint
- `scripts/run_pipeline.py` scheduler
- Docker Compose two-service deployment
- GitHub Actions CI (lint, test, coverage, pip-audit, Docker build)
- 243 initial tests

### Security
- SSRF protection on URL fetching
- Security headers (CSP, X-Frame-Options, nosniff)
- XSS escaping on SSR data injection
- Docker non-root user
- Rate limiting (120 req/min per IP)
